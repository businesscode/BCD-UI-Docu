/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} href   The link to check
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.url.classifyLink)
  @description   Classifies a link as either internal, external, or injection (i.e. usually dangerous).
  @method classifyLink

  @example
  if( bcdui.util.url.classifyLink(url) === bcdui.util.url.CLASSIFY_LINK_RESULT.SAFE_EXTERNAL ) warnOpen(url);
  @return {string}  One of bcdui.util.url.CLASSIFY_LINK_RESULT: 'injection' | 'internal' | 'external'
@memberOf bcdui.util.url
 */
export function classifyLink(href) { return ""; };
