/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.url)
 * @description   Utilities for working with URLs
 * @namespace bcdui.util.url
 */

/**
 * Classification of a URL
 */
export const CLASSIFY_LINK_RESULT = {};
