/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(Date|string)} startDate   First day of the date range
  @param {(Date|string)} endDate   Last day of the date range
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.isYearRange)
  @description   Tests if the specified date range exactly covers exactly one or more years
  @method isYearRange

  @example
  // Usage
var ret = bcdui.util.datetime.isYearRange( startDate, endDate );

@return {boolean} 
@memberOf bcdui.util.datetime
 */
export function isYearRange(startDate, endDate) { return false; };
