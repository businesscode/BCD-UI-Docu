/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {integer} month 
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.getShortMonthName)
  @description   The month name as abbreviated string (e.g. "Jul")
  @method getShortMonthName
@return {string}  .
@memberOf bcdui.util.datetime
 */
export function getShortMonthName(month) { return ""; };
