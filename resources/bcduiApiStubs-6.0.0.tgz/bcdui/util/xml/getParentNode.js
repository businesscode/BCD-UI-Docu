/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(DomElement|DomAttribute)} node 
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.getParentNode)
  @description   Determines the parent element of a node, no matter if it is an attribute nodeor an element. It is quite useful especially for attribute nodes, because theparentNode property does not work on them.
  @method getParentNode
@return {DomElement}  The parent element of the specified node.
@memberOf bcdui.util.xml
 */
export function getParentNode(node) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
