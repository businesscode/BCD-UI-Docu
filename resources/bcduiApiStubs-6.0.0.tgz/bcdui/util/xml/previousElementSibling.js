/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.previousElementSibling)
  @description 
  @method previousElementSibling
@return {void}
  @memberOf bcdui.util.xml
 */
export function previousElementSibling() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
