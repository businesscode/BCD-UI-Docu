/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.removeEmptyCells)
  @description   Removes empty rows and columns from a WRS cube document.Empty meanign all measures are NaN, including blank or wrs:nullParameters:  paramModel - DOM or DataProvider containing xp:RemoveEmptyCells, see xsltParams-1.0.0.xsd  paramSetId - optional id selecting the parameter setThe parameter set must have &commat;apply='rowCol' for the transformation to run.Optional attributes on xp:RemoveEmptyCells:
  @method removeEmptyCells
@return {void}
  @memberOf bcdui.wrs
 */
export function removeEmptyCells() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
