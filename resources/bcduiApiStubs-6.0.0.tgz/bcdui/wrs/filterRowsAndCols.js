/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.filterRowsAndCols)
  @description   Filters rows and/or col-dim columns of a WRS according to an f:Filter inside anxp:OrderRowsAndCols parameter set.  JavaScript equivalent of the f:Filter part oforderRowsAndCols.xslt + orderRowsAndColsTemplate.xslt.Parameters:  paramModel - DOM or DataProvider containing xp:OrderRowsAndCols  paramSetId - optional id selecting the parameter setTwo kinds of filter, distinguished by which bRef the f:Expression targets:  Row filter   – bRef matches a header column with &commat;dimId (a row dimension).                 f:Expression is evaluated against the row's wrs:C cell values.                 Special &commat;value constants:                   dimNull  (bcdui.core.magicChar.dimEmpty = \uE0F0) – keep rows where the cell is non-empty OR &commat;bcdGr='1'                   dimTotal (bcdui.core.magicChar.dimTotal = \uE0F0 + '1') – compare the cell's &commat;bcdGr attribute against '1'                 Operator &commat;op: =, !=, <, >, <=, >= (< > <= >= use numeric comparison).  Column filter – bRef matches one of the col-dim level IDs stored in                  wrs:Columns/&commat;colDimLevelIds.  The bRef's 1-based position in that                  pipe-separated list determines which pipe-segment of the col-dim                  measure column's &commat;id is compared.  Only columns with &commat;valueId where
  @method filterRowsAndCols
@return {void}
  @memberOf bcdui.wrs
 */
export function filterRowsAndCols() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
