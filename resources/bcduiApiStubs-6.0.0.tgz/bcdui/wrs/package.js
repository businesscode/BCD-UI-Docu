/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs)
 * @description   Package for functionality around Wrs format
 * @namespace bcdui.wrs
 */

/**
 * Evaluates calc:* expression trees against provided cell values.JavaScript equivalent of Client/src/xslt/calculation/calculation.xslt.The XSLT is a code generator that emits XPath strings; this module is adirect evaluator — same semantics, no code generation step.Supported operators (n-ary, same precedence rules as XPath):  calc:Add  +    calc:Sub  -    calc:Mul  *    calc:Div  /Supported functions (XPath 1.0 string-trick equivalents):  calc:Max(a,b)  calc:Min(a,b)  calc:Coa(a,b)  calc:Zin(a)  calc:Niz(a)    calc:Abs(a)    calc:Igt(a,b)  calc:Ian(a)  calc:Sgn(a)Leaf nodes:  calc:ValueRef  @idRef (optional @aggr, @dmRef) looked up via resolver(idRef, aggr, node) → number  calc:Value     constant (text content)Entry points:  bcdui.wrs.calculationFormulas.eval(calcElem, resolver, preEval)    Evaluates a <calc:Calc> element, handling @zeroIfNullOp='true'.    Optional preEval(node, resolver) may intercept and return a number.  bcdui.wrs.calculationFormulas.evalExpr(node, resolver, preEval)    Evaluates any single calc:* node (no zeroIfNullOp wrapping).    Used by bcdui.wrs.calculation to evaluate sub-expressions such as    the denominator operand of calc:Div.resolver: function(idRef: string) => number  Called for each calc:ValueRef.  Must return NaN for missing/empty cells.  Receives the ValueRef element as third argument (idRef, aggr, node) so callers can also evaluate @dmRef.preEval: function(node: Element, resolver) → number|undefined  Optional hook called before recursion. If it returns a number, that value is used.
 */
export const calculationFormulas = {};

/**
 * Singleton for GenericHtmlBuilder for generating HTML from WRS data.Default for Renderer but can be used in non-default chains
 */
export const htmlBuilder = {};
