/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.wrs.GenericHtmlBuilder
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.GenericHtmlBuilder)
  @description Creates an HTML table from a Wrs document, use default it like `chain: bcdui.wrs.htmlBuilder`It can do row- and colspans for documents that have a grouping in the first n columns.It can sort rows and columns by domension valuesThe colspans require that the header columns have pipe-separated captions for each column dimension.Additionally, it formats numeric values by applying scale and unit, especially %.All parameters are defined in xsltParams-1.0.0.xsd and at transform() method and can be provided per XML or JavaScript.Extension point: Rendering of wrs:R/wrs:C can be overwritten bya) deriving class HtmlBuilder and overriding the createMeasureCell() methodb) then providing the transform() method bound to the instance as a transformer
  @description Only needed when subclassing. Simply use global singleton `bcdui.wrs.htmlBuilder` in other cases.
  
  @example
  // Create your specialized HtmlBuilder by overwriting createMeasureCell()class MyHtmlBuilder extends bcdui.wrs.HtmlBuilder {  createMeasureCell({tr, cell, row, colDefs, parameters}) {    // Locally overwrite values here ...    let myCell = { value: 42, colDef: cell.colDef };    let td = super.createMeasureCell({tr, myCell, row, colDefs, parameters});    // Further manipulate created td here ...    if( cell.value < 42 ) td.classList.add( "mySpecialClass" );  }}// Instantiate and bind your instance like thislet myHtmlBuilder = new MyHtmlBuilder();let myTransformer = myHtmlBuilder.transform.bind(myHtmlBuilder);// Provide your transformer to a chainlet renderer = new bcdui.core.Renderer({  myTargetHtml, inputModel: myModel,  chain: [myTransformer]});
  */
// @ts-ignore
export class GenericHtmlBuilder {
  /**
  @description Creates an HTML table from a Wrs document, use default it like `chain: bcdui.wrs.htmlBuilder`It can do row- and colspans for documents that have a grouping in the first n columns.It can sort rows and columns by domension valuesThe colspans require that the header columns have pipe-separated captions for each column dimension.Additionally, it formats numeric values by applying scale and unit, especially %.All parameters are defined in xsltParams-1.0.0.xsd and at transform() method and can be provided per XML or JavaScript.Extension point: Rendering of wrs:R/wrs:C can be overwritten bya) deriving class HtmlBuilder and overriding the createMeasureCell() methodb) then providing the transform() method bound to the instance as a transformer
  @description Only needed when subclassing. Simply use global singleton `bcdui.wrs.htmlBuilder` in other cases.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.GenericHtmlBuilder)
  
  @example
  // Create your specialized HtmlBuilder by overwriting createMeasureCell()class MyHtmlBuilder extends bcdui.wrs.HtmlBuilder {  createMeasureCell({tr, cell, row, colDefs, parameters}) {    // Locally overwrite values here ...    let myCell = { value: 42, colDef: cell.colDef };    let td = super.createMeasureCell({tr, myCell, row, colDefs, parameters});    // Further manipulate created td here ...    if( cell.value < 42 ) td.classList.add( "mySpecialClass" );  }}// Instantiate and bind your instance like thislet myHtmlBuilder = new MyHtmlBuilder();let myTransformer = myHtmlBuilder.transform.bind(myHtmlBuilder);// Provide your transformer to a chainlet renderer = new bcdui.core.Renderer({  myTargetHtml, inputModel: myModel,  chain: [myTransformer]});
    */
  constructor() {}
  
/**
  @typedef {Object} Type_GenericHtmlBuilderCreateMeasureCell_Args
  @property {HTMLTableRowElement} tr   the row to append the cell to
  @property {Object} cell   the cell data. .value is the content, .colDef is the colHead and all attributes become properties
  @property {Object} row   the row data, cells is an array of cells, all attributes become properties
  @property {Object} colDefs   the column definitions, array of all colHeads
  @property {Object} parameters   the parameters of transform()
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.GenericHtmlBuilder?id=createmeasurecell)
  @description   Only needed as an extension point for overwriting.Creates a measure cell
  @param {Type_GenericHtmlBuilderCreateMeasureCell_Args} args 
    ````js
    { tr, cell, row, colDefs, parameters }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  // Usage
var ret = myGHB.createMeasureCell({ tr, cell, row, colDefs, parameters });

@return {HTMLTableCellElement} td - created td
  */
  createMeasureCell(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


