/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {bcdui.core.DataProvider} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {(DomElement|string)} row   Row element or row-id to be duplicated
  @param {boolean} [propagateUpdate=true]   If false, model is not fired
  @param {function} [fn]   Callback function called after operation
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.duplicateRow)
  @description 
  @method duplicateRow

  @example
  // Usage
bcdui.wrs.wrsUtil.duplicateRow( model, row );

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function duplicateRow(model, row, propagateUpdate, fn) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
