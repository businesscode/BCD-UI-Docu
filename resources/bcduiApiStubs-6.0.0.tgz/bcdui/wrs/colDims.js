/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.colDims)
  @description   Pivots a WRS by turning some dimension columns into column headers (cross-tab).JavaScript equivalent of the colDims.xslt + colDimsTemplate.xslt XSLT pair.Parameters:  paramModel        - DOM or DataProvider with xp:ColDims parameter sets  paramSetId        - optional id selecting the parameter set  colDimNrOfColDims - simple mode: last N dim columns become col headersReturns a new WRS document, or undefined if there is nothing to do.Intentional deviations from the XSLT pair: - Sorting (@sort / &commat;total on LevelRef) is not applied; column order follows   document order of the first occurrence of each col-dim key, same as the   XSLT when no ColSorting is active. - The row full-key uses \x00 as separator between row-dim key and col-dim key   (the XSLT has none), which avoids ambiguity when values contain "|".
  @method colDims
@return {void}
  @memberOf bcdui.wrs
 */
export function colDims() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
