/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.orderRowsAndCols)
  @description   Sorts/reorders rows and columns of a WRS according to xp:OrderRowsAndCols parameters defined in xsltParams-1.0.0.xsdCompared to orderRowsAndCols.xslt the filter is not present but handled in filterRowsAndColumns.jsBut cols not listed in xp:ColsOrder are still droppedParameters (via params object):  paramModel - DOM or DataProvider containing xp:OrderRowsAndCols  paramSetId - optional id selecting the parameter setThree ordering mechanisms, all optional and combinable:  xp:RowsOrder/Columns/C[&commat;id, &commat;sort, &commat;total, &commat;sortBy]    Sorts data rows. &commat;sort = "ascending"|"descending". &commat;total = "leading"|"trailing" places    rows with &commat;bcdGr='1' at the front or back, winning over value sort.
  @method orderRowsAndCols
@return {void}
  @memberOf bcdui.wrs
 */
export function orderRowsAndCols() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
