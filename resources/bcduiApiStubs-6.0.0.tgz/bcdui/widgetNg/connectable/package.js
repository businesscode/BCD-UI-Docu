/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.connectable)
 * @description   A namespace for the BCD-UI connectable widget. For creation &commat;see {@link bcdui.widgetNg.createConnectable}
 * @namespace bcdui.widgetNg.connectable
 */

/**
 * onBeforeChange dir attribute value, can be used to identify the direction of the item move
 */
export const CHANGE_DIRECTION = {};
