/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} id   targetHtml of widget
  @param {function} callback   to be called with generated caption
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.login.getNavPath)
  @description 
  @method getNavPath

  @example
  // Usage
var ret = bcdui.widgetNg.login.getNavPath( id, callback );

@return {string}  NavPath information via callback for widget
@memberOf bcdui.widgetNg.login
 */
export function getNavPath(id, callback) { return ""; };
