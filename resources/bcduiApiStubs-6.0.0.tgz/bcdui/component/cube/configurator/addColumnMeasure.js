/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@param {targetHtmlRef} targetModelId 
  @param {string} cubeId 
  @param {Object} args   { row, col }
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.addColumnMeasure)
  @description   adding column measure for cube (opening calcNode editor and put formula to cube model)
  @method addColumnMeasure

  @example
  // Usage
var ret = bcdui.component.cube.configurator.addColumnMeasure( targetModelId, cubeId, args );

@return {boolean}  false
@memberOf bcdui.component.cube.configurator
 */
export function addColumnMeasure(targetModelId, cubeId, args) { return false; };
