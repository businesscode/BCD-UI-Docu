/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@param {targetHtmlRef} targetModelId 
  @param {string} cubeId 
  @param {Object} args 
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.deleteUserMeasure)
  @description   deleting userCalc node from measures
  @method deleteUserMeasure

  @example
  // Usage
var ret = bcdui.component.cube.configurator.deleteUserMeasure( targetModelId, cubeId, args );

@return {boolean}  false
@memberOf bcdui.component.cube.configurator
 */
export function deleteUserMeasure(targetModelId, cubeId, args) { return false; };
