/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ChartEchartConstructor_Args
  @property {targetHtmlRef} targetHtml   Where to place the chart
  @property {bcdui.core.DataProvider} config   Definition if the chart according to Model with the chart definition according to XSD http://www.businesscode.de/schema/bcdui/charts-1.0.0
  @property {Object} options   Options of ECharts, extending / being merged with the options deried from config
  */
  
/**
  @class bcdui.component.chart.ChartEchart
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart)
  @description Create a chart based on http://www.businesscode.de/schema/bcdui/charts-1.0.0 XML
  
  @example
  // Usage
var myCE = new bcdui.component.chart.ChartEchart({ targetHtml: "#myDiv", config, options });

@extends bcdui.core.Renderer
*/
// @ts-ignore
export class ChartEchart extends bcdui.core.Renderer {
  /**
  @description Create a chart based on http://www.businesscode.de/schema/bcdui/charts-1.0.0 XML
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart)
  
  @example
  // Usage
var myCE = new bcdui.component.chart.ChartEchart({ targetHtml: "#myDiv", config, options });

@param {Type_ChartEchartConstructor_Args} args   Parameter object:
    ````js
    { targetHtml, config, options }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getclassname)
  @description   Get className
  @overrides bcdui.core.Renderer#getClassName
  @public
  @return {string} className
  */
  getClassName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getdata)
  @description   A getter for the document produced by the transformation chain.
  @overrides bcdui.core.Renderer#getData
  @public
  @return {document} DOM document
  */
  getData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=.saveasimage)
  @description   Export an EChart as PNG
  @param {targetHtmlRef} targetHtml   Html element where the chart is found
  @param {string} name   File name: name+".png"
  @public
  
  @example
  // Usage
bcdui.component.chart.ChartEchart.saveAsImage( targetHtml, name );

@return {void}
  */
  saveAsImage(targetHtml,name) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=adddataprovider)
  @description   Adds a new data provider to the transformation chain. If there is already a data providerwith the given name it is replaced.
  @param {Object} newDataProvider   the new dataprovider which should be added
  @param {string} [newName]   an optional new name for the provider. if given an alias will be created
  @inherits bcdui.core.TransformationChain#addDataProvider
  @return {bcdui.core.DataProvider} The old data provider registered under the name ornull if there has not been any.
  */
  addDataProvider(newDataProvider,newName) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=addstatuslistener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args   Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @inherits bcdui.core.AbstractExecutable#addStatusListener
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=debugiswaitingfor)
  @inherits bcdui.core.DataProvider#debugIsWaitingFor
  @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
  */
  debugIsWaitingFor() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=debugstatus)
  @inherits bcdui.core.DataProvider#debugStatus
  @return {string} Human readable message about the current state state
  */
  debugStatus() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=execute)
  @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/>Executes the process implemented by the concrete sub-classThis method is called by the Renderer when it is ready to render the modelIt is often asynchronous.Note, Renderer and sub-classes execute all input models recursively automatically.This means, usually you do not need to call this method directly. Note: it is asynchronous.Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
  @param {(boolean|Type_RendererExecute_Args)} args   either true for forced or parameter map
  @inherits bcdui.core.Renderer#execute
  @return {void}
  */
  execute(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=fetchdata)
  @description   asynchronously fetch data for this data provider.
  @inherits bcdui.core.DataProvider#fetchData
  @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
  */
  fetchData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=fire)
  @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completedand data is consistent again.
  @inherits bcdui.core.DataProvider#fire
  @return {void}
  */
  fire() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getdataproviderbyname)
  @param {string} name 
  @inherits bcdui.core.TransformationChain#getDataProviderByName
  @return {bcdui.core.DataProvider} returns the parameter of the given name
  */
  getDataProviderByName(name) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getfailedstatus)
  @description   Getter for the list of error statuses of this class. This implementation returns anempty list.
  @inherits bcdui.core.TransformationChain#getFailedStatus
  @return {Array.<bcdui.core.Status>} Returns all statuses indicating a failure
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getname)
  @description   Getter for the name of the data provider. This name is for example usedto set parameters names of a {@link bcdui.core.TransformationChain}.
  @inherits bcdui.core.DataProvider#getName
  @return {string} The name of the data provider. This name should be uniquewithin the scope it is used and is usually not globally unique (as the id).
  */
  getName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getprimarymodel)
  @description   Getter for the primary model of the chain. The first transformation ofthe chain takes a document as input. This document comes from theprimary model.
  @inherits bcdui.core.TransformationChain#getPrimaryModel
  @return {bcdui.core.DataProvider} The model the first transformation inthe chain is running on.
  */
  getPrimaryModel() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getreadystatus)
  @description   The ready status for the transformation chain is reached as soon as alltransformations are finished.<p> The status transitions of the class are as follows:          </p>                                                              <p style="padding-left: 10px"><table><tr><td style="border: 3px double black; text-align: center" colspan="2">     Initialized                                              </td><td style="padding-left: 20px">         All variables have been initialized.                                                              </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2">     Loading                                                  </td><td style="padding-left: 20px">         Start loading chain document.                                                              </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2">     ChainLoaded                                              </td><td style="padding-left: 20px">         The chain document has been loaded. Start         loading chain stylesheets.                                                              </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2"> <i> WaitingForParameters </i>                                </td><td style="padding-left: 20px">         Chain stylesheets loaded. Waiting for         parameter data providers (<i>execute</i>).                                                              </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2">     Transforming                                             </td><td style="padding-left: 20px">         The chain stylesheets are running.                                                              </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 3px double black; text-align: center" colspan="2"> <b> Transformed </b>                                         </td><td style="padding-left: 20px">         The output has been generated. (<b>ready</b>)</td></tr></table></p>
  @inherits bcdui.core.TransformationChain#getReadyStatus
  @return {bcdui.core.Status} The transformed status.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getstatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @inherits bcdui.core.AbstractExecutable#getStatus
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=gettargethtml)
  @description   Return the target html element where the renderer places its output
  @inherits bcdui.core.Renderer#getTargetHtml
  @return {void}
  */
  getTargetHtml() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=hasfailed)
  @description   Tests if the object has reached a failure status. These status codes arereturned by the "getFailedStatus" method.
  @inherits bcdui.core.AbstractExecutable#hasFailed
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=isclean)
  @description   True, if DataProvider is ready and there are no uncommitted write transactions,see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
  @inherits bcdui.core.DataProvider#isClean
  @return {boolean}
  */
  isClean() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=isready)
  @description   Tests if the current state is the readyStatus. This status is the samestatus as returned by "getReadyStatus".
  @inherits bcdui.core.AbstractExecutable#isReady
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=onceready)
  @param {(function|OnceReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onceReady
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=onchange)
  @param {(function|OnChangeParam)} listenerObject   Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
  @param {string} [trackingXPath]   xPath to monitor to monitor for changes
  @inherits bcdui.core.DataProvider#onChange
  @return {void}
  */
  onChange(listenerObject,trackingXPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=onready)
  @param {(function|OnReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onReady
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=promptdata)
  @description   Convenience method for debugging showing data in a prompt for copy-and-paste
  @inherits bcdui.core.DataProvider#promptData
  @return {void}
  */
  promptData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=query)
  @description   Reads a single node from a given xPath
  @param {string} xPath   xPath to query
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @inherits bcdui.core.DataProvider#query
  @return {(DomNode|null)} single node or null if query fails
  */
  query(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=querynodes)
  @description   Get node list from a given xPath
  @param {string} xPath   xPath to query
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @inherits bcdui.core.DataProvider#queryNodes
  @return {Array.<DomNode>} node list or empty list if query fails
  */
  queryNodes(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=read)
  @description   Reads the string value from a given xPath (or optionally return default value).
  @param {string} xPath   xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [defaultValue]   default value in case xPath value does not exist
  @inherits bcdui.core.DataProvider#read
  @return {string} text value stored at xPath (or null if no text was found and no defaultValue supplied)
  */
  read(xPath,fillParams,defaultValue) { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=reloadstylesheets)
  @description   Start the loading process of the stylesheets and executes the transformationsagain.
  @inherits bcdui.core.TransformationChain#reloadStylesheets
  @return {void}
  */
  reloadStylesheets() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=remove)
  @description   Deletes data at a given xPath from the model
  @param {string} xPath   xPath pointing to the value
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {boolean} [fire]   if true a fire is triggered to notify data modification listener
  @inherits bcdui.core.DataProvider#remove
  @return {void}
  */
  remove(xPath,fillParams,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=removedatalistener)
  @param {(string|function|RemoveDataListenerParam)} listenerObject   Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
  @inherits bcdui.core.DataProvider#removeDataListener
  @return {void}
  */
  removeDataListener(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=removestatuslistener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args   The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @inherits bcdui.core.AbstractExecutable#removeStatusListener
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=senddata)
  @description   Sends the current data to the original URL
  @inherits bcdui.core.DataProvider#sendData
  @return {void}
  */
  sendData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=serialize)
  @description   Serialize dataprovider's data if available
  @inherits bcdui.core.DataProvider#serialize
  @return {string} String containing the serialized data
  */
  serialize() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=setprimarymodel)
  @description   Adds a new data provider to the list which becomes the new primary modelof the transformation chain.
  @param {bcdui.core.DataProvider} primaryModel   the new primary model of the transformation chain.
  @inherits bcdui.core.TransformationChain#setPrimaryModel
  @return {void}
  */
  setPrimaryModel(primaryModel) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=setstatus)
  @description   Makes a transition from the current status to the new status if theyare not equal. After the status is changed it fires the status eventto the registered listeners.<p/>Usually this method will only be called by the library but you can use it to re-trigger an action. For available statuses and their effect, see the concrete class,
  @param {bcdui.core.Status} args 
  @inherits bcdui.core.DataProvider#setStatus
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=settargethtml)
  @description   Sets the target html element where the renderer places its output
  @param {HtmlElement} targetHtmlElement   target html element
  @inherits bcdui.core.Renderer#setTargetHtml
  @return {void}
  */
  setTargetHtml(targetHtmlElement) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_ChartEchartTblDelete_Args
  @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
  @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  @property {string} [rowId]   id specifying row which should be deleted (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tbldelete)
  @description   Delete Wrs rows. Either a single row (via rowId) or single/multiple ones via filterThe filter's property names refer to the columns ids.
  @param {Type_ChartEchartTblDelete_Args} args   parameter bag
    ````js
    { filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblDelete
  @return {number} count of removed rows
  */
  tblDelete(args) { return 0; }
/**
  @typedef {Object} Type_ChartEchartTblGetColumnMetadata_Args
  @property {Array.<string>} [columns]   Limit to these column ids
  @property {boolean} [doSort]   Sort the columns according to the given columns list. If not given, the columns are returned in the order they are defined in the WRS.
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblgetcolumnmetadata)
  @description   Returns an array of columns of a Wrs with their metadata attributes like id, caption, type-name etc.Includes id, caption, pos, type-name, display-size, scale, isKey, nullable, references etc.For example: `[{id: 'ctr', caption: 'Country', pos: '1'}, {id: 'state', caption: 'State', pos: '2', references: [ {value: '#e00', caption: 'Red'}, {value: '#0e0', caption: 'Green'} ]}]`
  @param {Type_ChartEchartTblGetColumnMetadata_Args} [args] 
    ````js
    { columns?, doSort? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblGetColumnMetadata
  @return {Array.<Object>} column metadata
  */
  tblGetColumnMetadata(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_ChartEchartTblGetRowIds_Args
  @property {object} [filter]   object holding requested filter conditions, e.g. `{ country: 'DE', flag: true }`
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblgetrowids)
  @description   Returns an array of row ids (wrs:R/&commat;id) of the rows matching the filter.If no filter is given, all row ids are returned.The order of ids matches the order of the rows in the Wrs.
  @param {Type_ChartEchartTblGetRowIds_Args} args 
    ````js
    { filter? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblGetRowIds
  @return {Array.<string>} row ids
  */
  tblGetRowIds(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_ChartEchartTblInsert_Args
  @property {Object} values   object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true]  default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblinsert)
  @description   Inserts a new row in the Wrs. The property names match the Wrs header ids.
  @param {Type_ChartEchartTblInsert_Args} args   parameter bag
    ````js
    { values, rmi?, fire? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblInsert
  
  @example
  // Usage
var ret = myCE.tblInsert({ values });

@return {string} row id of newly inserted row
  */
  tblInsert(args) { return ""; }
/**
  @typedef {Object} Type_ChartEchartTblSelect_Args
  @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblselect)
  @description   Selects an array of row values like `[{ctr: 'DE', site: 'HAM', flag: true}, {ctr: 'DE', site: 'BER', flag: false}];` for a given filter.The filter's and the returned property names match the column ids.
  @param {Type_ChartEchartTblSelect_Args} args   parameter bag
    ````js
    { filter?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelect
  @return {Array.<Object>} Array of objects holding the requested data
  */
  tblSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_ChartEchartTblSelectRow_Args
  @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {string} [rowId]   rowId of row which should be queried (or use filter)
  @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblselectrow)
  @description   Get the values of a single row, identified either by its `wrs:/&commat;id`, or the first one matching the filter.The filter's and the returned property names match the column ids.
  @param {Type_ChartEchartTblSelectRow_Args} args   parameter bag
    ````js
    { filter?, rowId?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelectRow
  @return {Object} Array  of objects holding the requested data
  */
  tblSelectRow(args) { return {}; }
/**
  @typedef {Object} Type_ChartEchartTblUpdate_Args
  @property {Object} values   columns and values to be updated. This sets 2 columns { country: 'DE', flag: true }
  @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
  @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  @property {string} [rowId]   id specifying row which should be updated (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblupdate)
  @description   Updates one or multiple Wrs rows with given data.Either a single row (via rowId) or single/multiple ones (via filter)The filter's and the given values' property names refer to the columns ids.
  @param {Type_ChartEchartTblUpdate_Args} args   parameter bag
    ````js
    { values, filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblUpdate
  
  @example
  // Usage
var ret = myCE.tblUpdate({ values });

@return {number} count of updated rows
  */
  tblUpdate(args) { return 0; }
/**
  @typedef {Object} Type_ChartEchartTblValidateRowChange_Args
  @property {Object} values   { colId: value } map of values to validate
  @property {string} [rowId]   only needed for key uniqueness: identifies the row being validated so it is excluded from the duplicate check. If not given values is treated like a new row to be inserted
  @property {Object} [filter]   alternative to rowId, only needed for key uniqueness exclusion; first matching row is used
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tblvalidaterowchange)
  @description   Validates a set of column values against the WRS header constraints of this DataProvider.The check is purely client-side (no server round-trip): type, scale, display-size, nullable,embedded header References, and key uniqueness within the loaded data are all covered.Only columns present in args.values are validated.For a planned tblUpdate, provide rowId or filter to exclude the changed row from uniqueness check.For a planned tblInsert, rowId is not needed as the uniqueness check is performed against all current loaded data.
  @param {Type_ChartEchartTblValidateRowChange_Args} args   parameter bag
    ````js
    { values, rowId?, filter? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblValidateRowChange
  
  @example
  // Usage
var ret = myCE.tblValidateRowChange({ values });

@return {Array.<{colId: string, errorCode: string}>} list of validation errors
  */
  tblValidateRowChange(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=tostring)
  @description   Useful for debugging.
  @inherits bcdui.core.TransformationChain#toString
  @return {string} String representation of the chain.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=write)
  @description   Set a value to on a certain xPath and create the xPath where necessary.This combines Element.evaluate() for a single node with creating the path where necessary. It will prefer extending an existing start-part over creating a second one.After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
  @param {string} xPath   xPath pointing to the node which is to be modified. Only the first match will be modified.   If it does not exist, it will be created.   For example, if you provide `/n:Root/n:MyElem/&commat;attr2` and there is already `/n:Root/n:MyElem/&commat;attr1`, then `/n:Root/n:MyElem` will be "re-used" and get an additional attribute attr2.   Even complex expressions are allowed, like predicates `/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem`.   Ambiguous xPaths are not allowed, for example, using `//` or `/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem`, and will throw an error.   The method is Wrs aware, for Wrs it turns wrs:R into wrs:M etc., see Wrs format.   Using {{=it[0]}} templates makes sure values are escaped correctly.
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions    Example: `bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])`
  @param {string} [value]   Optional value which should be written, for example to `/n:Root/n:MyElem/&commat;attr` or with `/n:Root/n:MyElem` as the element's text content.   If not provided, the xPath contains all values and either there is a full match or it will be created.
  @param {boolean} [fire]   If true a fire is triggered to inform data modification listeners
  @inherits bcdui.core.DataProvider#write
  @return {DomNode} The xPath's node or null if dataProvider isn't ready
  */
  write(xPath,fillParams,value,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
   * A status reached when the chain model is ready.
   * @type {bcdui.core.status.ChainLoadedStatus}
   */
  chainLoadedStatus= null;
  
/**
   * This (final) status is reached when the chain model could not be loaded.
   * @type {bcdui.core.status.ChainStylesheetLoadingFailed}
   */
  chainLoadingFailed= null;
  
/**
   * This (final) status is reached when the loading of a chain stylesheet hasfailed.
   * @type {bcdui.core.status.ChainStylesheetLoadingFailed}
   */
  chainStylesheetLoadingFailed= null;
  
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
/**
   * This status is set when the constructor has set all parameters.
   * @type {bcdui.core.status.InitializedStatus}
   */
  initializedStatus= null;
  
/**
   * This (final) status is reached when an error occurs during the loading ortransformation process.
   * @type {bcdui.core.status.LoadFailedStatus}
   */
  loadFailedStatus= null;
  
/**
   * The status code activated as soon as the loading begins.
   * @type {bcdui.core.status.LoadingStatus}
   */
  loadingStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       * @example
       * if( model.getStatus() === model.savedStatus )
       *   ...
       */
  savedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       */
  saveFailedStatus= null;
  
/**
   * The status code is reached when everything is finished and the transformationresult is available. This is the final state of the TransformationChain processif no error occurs.
   * @type {bcdui.core.status.TransformedStatus}
   */
  transformedStatus= null;
  
/**
   * The status code is reached when a transformation failed and operation cannot proceed
   * @type {bcdui.core.status.TransformFailedStatus}
   */
  transformFailedStatus= null;
  
/**
   * As long as this status is active the XSLT transformations are running.
   * @type {bcdui.core.status.TransformingStatus}
   */
  transformingStatus= null;
  
/**
   * This status is kept as long as the transformation chain is waitingfor parameters to load and when the chain has already loaded.
   * @type {bcdui.core.status.WaitingForParametersStatus}
   */
  waitingForParametersStatus= null;
  
}


