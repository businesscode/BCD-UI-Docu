/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ScorecardCreateScorecardConfigurator_Args
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [applyFunction]   Function name which is used for the apply button in isDefaultHtmlLayout=true mode. Default is bcdui.core.lifecycle.applyAction.
  @property {boolean} [autofocus]   requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {bcdui.core.DataProvider} [config]   Model containing the configuration for the scorecard configurator. By default this is taken from dimensionsAndKpis.xml.
  @property {boolean} [disabled]   All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [displayBalloon]   hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [enableNavPath]   Set to true if widget should be added to navpath handling.
  @property {boolean} [hasUserEditRole]   Template Editor also has edit capability. If not given, bcdui.config.clientRights.bcdScorecardTemplateEdit is used to determine state (either *(any) or scorecardId to enable).
  @property {i18nToken} [hint]   A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id]   Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {boolean} [isDefaultHtmlLayout]   If true, a standard layout for dnd area is created. If false, you need to provide containers with classes: bcdCurrentKpiList, bcdCurrentScRowDimensionList, bcdCurrentAspectList, bcdKpiList, bcdScDimensionList, bcdAspectList within an outer bcdScorecardDndMatrix container. if your targetHtml got classes bcdDndBlindOpen or bcdDndBlindClosed, the actual dnd area is also put in collapsable boxes (either open or closed by default).
  @property {boolean} [isRanking]   Enable the ranking feature. This is an Enterprise Edition only feature.
  @property {boolean} [isTemplate]   Enable the template feature. This is an Enterprise Edition only feature.
  @property {string} [rankingTargetHtmlElementId]   If isRanking is true then this attribute can be used to control the div where the ranking editor is placed.
  @property {string} [reportName]   Name of the report is used to access the persistent layouts.
  @property {boolean} [rowAspect]   Enables another drag'n drop box for aspects (marked with rowAspect='true') which are put in front of all aspects. KPI dimensions needs to be a row dimension in this case.
  @property {bcdui.core.DataProvider} [scorecard]   Id of the scorecardRenderer the configurator belongs to. If not given, the surrounding renderer is assumed to be a cmp:scorecard.
  @property {boolean} [showSummary]   Enable the summary feature.
  @property {string} [summaryTargetHtmlElementId]   If showSummary is true then this attribute can be used to control the div where the summary is placed.
  @property {integer} [tabindex]   the HTML compliant tabIndex
  @property {bcdui.core.DataProvider} [targetModel]   The configuration is written to $guiStatus/guiStatus:Status/scc:Layout[scorecardId='scorecardId'] by default. While the xpath /RootNode/scc:Layout[scorecardId='scorecardId'] is fixed, you can specify an own targetModel if needed.
  @property {string} [templateTargetHtmlElementId]   If isTemplate is true then this attribute can be used to control the div where the template editor is placed.
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  */
  /**
@param {Type_ScorecardCreateScorecardConfigurator_Args} args   The parameter map contains the following properties.
    ````js
    { targetHtml, applyFunction?, autofocus?, config?, disabled?, displayBalloon?, enableNavPath?, hasUserEditRole?, hint?, id?, isDefaultHtmlLayout?, isRanking?, isTemplate?, rankingTargetHtmlElementId?, reportName?, rowAspect?, scorecard?, showSummary?, summaryTargetHtmlElementId?, tabindex?, targetModel?, templateTargetHtmlElementId?, widgetCaption? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecard.createScorecardConfigurator)
  @description   Creates a scorecard configurator, providing the scc:Layout section of the scorecard configuration, able of showing the drag and drop area for the dimensions and kpis and aspects.
  @method createScorecardConfigurator

  @example
  // Usage
bcdui.component.scorecard.createScorecardConfigurator({ targetHtml: "#myDiv" });

@return {void}
  @memberOf bcdui.component.scorecard
 */
export function createScorecardConfigurator(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
