/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "./exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui)
 * @namespace bcdui
 */

/**
 * Context path of the current webapp. Use getContextPath()
 */
export const contextPath = "/";

/**
 * Is debug mode enabled?
 */
export const isDebug = {};

/**
 * set up logger, we maintain only one logger
 */
export const log = {};

/**
 * BCD-UI works with several Well-Known-Models, they can be found here like `bcdui.wkModels.guiStatus.getData()`- guiStatus: Default targetModel for widgets and in general default place for client status- guiStatusEstablished: Reflects the guiStatus as it was on page entry- bcdI18nModel: I18n-key translation model- bcdNavPath: If defined by widgets, a summary of filter settings- bcdRowIdent, bcdColIdent: Latest pos of cursor in table in case of right click
 */
export const wkModels = {};
