/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_DataProviderAliasConstructor_Args
  @property {bcdui.core.DataProvider} source   The data provider to be wrapped
  @property {string} name   The new name of the data provider
  */
  
/**
  @class bcdui.core.DataProviderAlias
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias)
  @description This class is a wrapper for a DataProvider giving it a new name (not id) andreducing its states to only initialized and loaded. It is useful forrenaming a DataProvider before passing it to a TransformationChain sothat a DataProvider can be mapped to an arbitrary xsl:param element.where the bcdui.core.DataProviderAlias' name is used as the xsl:param's name
  
  @example
  // Usage
var myDPA = new bcdui.core.DataProviderAlias({ source, name });

@extends bcdui.core.DataProviderHolder
*/
// @ts-ignore
export class DataProviderAlias extends bcdui.core.DataProviderHolder {
  /**
  @description This class is a wrapper for a DataProvider giving it a new name (not id) andreducing its states to only initialized and loaded. It is useful forrenaming a DataProvider before passing it to a TransformationChain sothat a DataProvider can be mapped to an arbitrary xsl:param element.where the bcdui.core.DataProviderAlias' name is used as the xsl:param's name
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias)
  
  @example
  // Usage
var myDPA = new bcdui.core.DataProviderAlias({ source, name });

@param {Type_DataProviderAliasConstructor_Args} args   The argument map taking two mandatory parameters:
    ````js
    { source, name }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=getclassname)
  @description   Get className
  @overrides bcdui.core.DataProviderHolder#getClassName
  @public
  @return {string} className
  */
  getClassName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=addstatuslistener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args   Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @inherits bcdui.core.AbstractExecutable#addStatusListener
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=debugiswaitingfor)
  @inherits bcdui.core.DataProvider#debugIsWaitingFor
  @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
  */
  debugIsWaitingFor() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=debugstatus)
  @inherits bcdui.core.DataProvider#debugStatus
  @return {string} Human readable message about the current state state
  */
  debugStatus() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=execute)
  @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/>Executes the process implemented by the concrete sub-classThis method is called by the Renderer when it is ready to render the modelIt is often asynchronous.Note, Renderer and sub-classes execute all input models recursively automatically.This means, usually you do not need to call this method directly. Note: it is asynchronous.Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
  @param {boolean} [doesRefresh=true]   Set this parameter to "false" if this method should donothing when the object is already in the ready status. The default is "true"meaning that the process is re-started when it is currently ready.
  @inherits bcdui.core.AbstractExecutable#execute
  @return {void}
  */
  execute(doesRefresh) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=fetchdata)
  @description   asynchronously fetch data for this data provider.
  @inherits bcdui.core.DataProvider#fetchData
  @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
  */
  fetchData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=fire)
  @description   Informs listeners that data was modified
  @inherits bcdui.core.DataProviderHolder#fire
  @return {void}
  */
  fire() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=getdata)
  @description   Access to the data of this DataProvider for read and modification access
  @inherits bcdui.core.DataProvider#getData
  @return {*} The data provided by the specific sub-class.
  */
  getData() { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=getfailedstatus)
  @description   Getter for the list of error statuses of this class. This implementation returns anempty list.
  @inherits bcdui.core.AbstractExecutable#getFailedStatus
  @return {Array.<bcdui.core.Status>} The status objects corresponding to failures in the object'sprocess.
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=getname)
  @description   Getter for the name of the data provider. This name is for example usedto set parameters names of a {@link bcdui.core.TransformationChain}.
  @inherits bcdui.core.DataProvider#getName
  @return {string} The name of the data provider. This name should be uniquewithin the scope it is used and is usually not globally unique (as the id).
  */
  getName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=getreadystatus)
  @description   Getter for the ready status of the instance. This status is a final statedefined by each sub-class which is reached when the process has finishednormally.
  @inherits bcdui.core.DataProviderHolder#getReadyStatus
  @return {bcdui.core.Status} Returns the final state indicating the the value is available.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=getstatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @inherits bcdui.core.AbstractExecutable#getStatus
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=hasfailed)
  @description   Tests if the object has reached a failure status. These status codes arereturned by the "getFailedStatus" method.
  @inherits bcdui.core.AbstractExecutable#hasFailed
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=isclean)
  @description   True, if DataProvider is ready and there are no uncommitted write transactions,see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
  @inherits bcdui.core.DataProvider#isClean
  @return {boolean}
  */
  isClean() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=isready)
  @description   Tests if the current state is the readyStatus. This status is the samestatus as returned by "getReadyStatus".
  @inherits bcdui.core.AbstractExecutable#isReady
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=onceready)
  @param {(function|OnceReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onceReady
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=onchange)
  @param {(function|OnChangeParam)} listenerObject   Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
  @param {string} [trackingXPath]   xPath to monitor to monitor for changes
  @inherits bcdui.core.DataProvider#onChange
  @return {void}
  */
  onChange(listenerObject,trackingXPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=onready)
  @param {(function|OnReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onReady
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=promptdata)
  @description   Convenience method for debugging showing data in a prompt for copy-and-paste
  @inherits bcdui.core.DataProvider#promptData
  @return {void}
  */
  promptData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=query)
  @description   Reads a single node from a given xPath
  @param {string} xPath   xPath to query
  @inherits bcdui.core.DataProviderHolder#query
  @return {(DomNode|null)} single node or null if query fails or source isn't set yet
  */
  query(xPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=querynodes)
  @description   Get node list from a given xPath
  @param {string} xPath   xPath to query
  @inherits bcdui.core.DataProviderHolder#queryNodes
  @return {Array.<DomNode>} node list or empty list if query fails or source isn't set yet
  */
  queryNodes(xPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=read)
  @description   Reads value from a given xPath (or optionally return default value)
  @param {string} xPath   xPath pointing to value
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [defaultValue]   default value in case xPath value does not exist
  @inherits bcdui.core.DataProviderHolder#read
  @return {string} text value stored at xPath (or null if nothing found and no defaultValue supplied or when source isn't set yet)
  */
  read(xPath,fillParams,defaultValue) { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=remove)
  @description   removes given xPath
  @param {string} xPath   xPath pointing to value
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {boolean} [fire]   if true a fire is triggered to notify data modification listener
  @inherits bcdui.core.DataProviderHolder#remove
  @return {void}
  */
  remove(xPath,fillParams,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=removedatalistener)
  @param {(string|function|RemoveDataListenerParam)} listenerObject   Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
  @inherits bcdui.core.DataProvider#removeDataListener
  @return {void}
  */
  removeDataListener(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=removestatuslistener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args   The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @inherits bcdui.core.AbstractExecutable#removeStatusListener
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=senddata)
  @description   Sends the current data to the original URL
  @inherits bcdui.core.DataProvider#sendData
  @return {void}
  */
  sendData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=serialize)
  @description   Serialize dataprovider's data if available
  @inherits bcdui.core.DataProvider#serialize
  @return {string} String containing the serialized data
  */
  serialize() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=setsource)
  @description   Set the underlying source delayed instead of via the constructor.The DataProviderHolder does only become ready after the source was set and is or becomes ready.
  @inherits bcdui.core.DataProviderHolder#setSource
  @return {void}
  */
  setSource() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=setstatus)
  @description   Makes a transition from the current status to the new status if theyare not equal. After the status is changed it fires the status eventto the registered listeners.<p/>Usually this method will only be called by the library but you can use it to re-trigger an action. For available statuses and their effect, see the concrete class,
  @param {bcdui.core.Status} args 
  @inherits bcdui.core.DataProvider#setStatus
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_DataProviderAliasTblDelete_Args
  @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
  @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  @property {string} [rowId]   id specifying row which should be deleted (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tbldelete)
  @description   Delete Wrs rows. Either a single row (via rowId) or single/multiple ones via filterThe filter's property names refer to the columns ids.
  @param {Type_DataProviderAliasTblDelete_Args} args   parameter bag
    ````js
    { filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblDelete
  @return {number} count of removed rows
  */
  tblDelete(args) { return 0; }
/**
  @typedef {Object} Type_DataProviderAliasTblGetColumnMetadata_Args
  @property {Array.<string>} [columns]   Limit to these column ids
  @property {boolean} [doSort]   Sort the columns according to the given columns list. If not given, the columns are returned in the order they are defined in the WRS.
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblgetcolumnmetadata)
  @description   Returns an array of columns of a Wrs with their metadata attributes like id, caption, type-name etc.Includes id, caption, pos, type-name, display-size, scale, isKey, nullable, references etc.For example: `[{id: 'ctr', caption: 'Country', pos: '1'}, {id: 'state', caption: 'State', pos: '2', references: [ {value: '#e00', caption: 'Red'}, {value: '#0e0', caption: 'Green'} ]}]`
  @param {Type_DataProviderAliasTblGetColumnMetadata_Args} [args] 
    ````js
    { columns?, doSort? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblGetColumnMetadata
  @return {Array.<Object>} column metadata
  */
  tblGetColumnMetadata(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_DataProviderAliasTblGetRowIds_Args
  @property {object} [filter]   object holding requested filter conditions, e.g. `{ country: 'DE', flag: true }`
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblgetrowids)
  @description   Returns an array of row ids (wrs:R/&commat;id) of the rows matching the filter.If no filter is given, all row ids are returned.The order of ids matches the order of the rows in the Wrs.
  @param {Type_DataProviderAliasTblGetRowIds_Args} args 
    ````js
    { filter? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblGetRowIds
  @return {Array.<string>} row ids
  */
  tblGetRowIds(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_DataProviderAliasTblInsert_Args
  @property {Object} values   object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true]  default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblinsert)
  @description   Inserts a new row in the Wrs. The property names match the Wrs header ids.
  @param {Type_DataProviderAliasTblInsert_Args} args   parameter bag
    ````js
    { values, rmi?, fire? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblInsert
  
  @example
  // Usage
var ret = myDPA.tblInsert({ values });

@return {string} row id of newly inserted row
  */
  tblInsert(args) { return ""; }
/**
  @typedef {Object} Type_DataProviderAliasTblSelect_Args
  @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblselect)
  @description   Selects an array of row values like `[{ctr: 'DE', site: 'HAM', flag: true}, {ctr: 'DE', site: 'BER', flag: false}];` for a given filter.The filter's and the returned property names match the column ids.
  @param {Type_DataProviderAliasTblSelect_Args} args   parameter bag
    ````js
    { filter?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelect
  @return {Array.<Object>} Array of objects holding the requested data
  */
  tblSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_DataProviderAliasTblSelectRow_Args
  @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {string} [rowId]   rowId of row which should be queried (or use filter)
  @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblselectrow)
  @description   Get the values of a single row, identified either by its `wrs:/&commat;id`, or the first one matching the filter.The filter's and the returned property names match the column ids.
  @param {Type_DataProviderAliasTblSelectRow_Args} args   parameter bag
    ````js
    { filter?, rowId?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelectRow
  @return {Object} Array  of objects holding the requested data
  */
  tblSelectRow(args) { return {}; }
/**
  @typedef {Object} Type_DataProviderAliasTblUpdate_Args
  @property {Object} values   columns and values to be updated. This sets 2 columns { country: 'DE', flag: true }
  @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
  @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  @property {string} [rowId]   id specifying row which should be updated (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblupdate)
  @description   Updates one or multiple Wrs rows with given data.Either a single row (via rowId) or single/multiple ones (via filter)The filter's and the given values' property names refer to the columns ids.
  @param {Type_DataProviderAliasTblUpdate_Args} args   parameter bag
    ````js
    { values, filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblUpdate
  
  @example
  // Usage
var ret = myDPA.tblUpdate({ values });

@return {number} count of updated rows
  */
  tblUpdate(args) { return 0; }
/**
  @typedef {Object} Type_DataProviderAliasTblValidateRowChange_Args
  @property {Object} values   { colId: value } map of values to validate
  @property {string} [rowId]   only needed for key uniqueness: identifies the row being validated so it is excluded from the duplicate check. If not given values is treated like a new row to be inserted
  @property {Object} [filter]   alternative to rowId, only needed for key uniqueness exclusion; first matching row is used
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tblvalidaterowchange)
  @description   Validates a set of column values against the WRS header constraints of this DataProvider.The check is purely client-side (no server round-trip): type, scale, display-size, nullable,embedded header References, and key uniqueness within the loaded data are all covered.Only columns present in args.values are validated.For a planned tblUpdate, provide rowId or filter to exclude the changed row from uniqueness check.For a planned tblInsert, rowId is not needed as the uniqueness check is performed against all current loaded data.
  @param {Type_DataProviderAliasTblValidateRowChange_Args} args   parameter bag
    ````js
    { values, rowId?, filter? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblValidateRowChange
  
  @example
  // Usage
var ret = myDPA.tblValidateRowChange({ values });

@return {Array.<{colId: string, errorCode: string}>} list of validation errors
  */
  tblValidateRowChange(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=tostring)
  @description   Useful for debugging.
  @inherits bcdui.core.DataProviderHolder#toString
  @return {string} Human readable summary of this class.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias?id=write)
  @description   Set a value to on a certain xPath and create the xPath where necessary. This combines Element.evaluate() for a single node with creating the path where necessary. It will prefer extending an existing start-part over creating a second one.After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
  @param {string} xPath   xPath pointing to the node which is set to the value value or plain xPath to be created if not there.    It tries to reuse all matching parts that are already there. If you provide for example "/n:Root/n:MyElem/&commat;attr1" and there is already "/n:Root/n:MyElem@attr1", then ""/n:Root/n:MyElem" will be "re-used" and get a second attribute attr1.   Many expressions are allowed, for example "/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem" is also ok.   By nature, some xPath expressions are not allowed, for example using '//' or "/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem" is obviously not unambiguous enough and will throw an error.   This method is Wrs aware, use for example '/wrs:Wrs/wrs:Data/wrs:*[2]/wrs:C[3]' as xPath and it will turn wrs:R[wrs:C] into wrs:M[wrs:C and wrs:O], see Wrs format.
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [value]   Optional value which should be written, for example to "/n:Root/n:MyElem/&commat;attr" or with "/n:Root/n:MyElem" as the element's text content.    If not provided, the xPath contains all values like in "/n:Root/n:MyElem[&commat;attr='a' and &commat;attr1='b']" or needs none like "/n:Root/n:MyElem"
  @param {boolean} [fire]   If true a fire is triggered to inform data modification listeners
  @inherits bcdui.core.DataProviderHolder#write
  @return {(DomNode|null)} The xPath's node (can be null if source isn't set yet or dataProvider isn't ready)
  */
  write(xPath,fillParams,value,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       * @example
       * if( model.getStatus() === model.savedStatus )
       *   ...
       */
  savedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       */
  saveFailedStatus= null;
  
}


