/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @class bcdui.core.status.LoadedStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadedStatus)
  @description This status indicates that the main data document of the executable object finished loading.
  @extends bcdui.core.Status
*/
// @ts-ignore
export class LoadedStatus extends bcdui.core.Status {
  /**
  @description This status indicates that the main data document of the executable object finished loading.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadedStatus)
    */
  constructor() {
    // @ts-ignore (ignore wrong param list)
    super(); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadedStatus?id=equals)
  @description   Test the status for logical equivalence to another status object. Usuallythis function should test if the target status is of the same class asthis status.
  @overrides bcdui.core.Status#equals
  @public
  @return {boolean} True, if the specified status object represents the samelogical status as the current one.
  */
  equals() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadedStatus?id=getcode)
  @overrides bcdui.core.Status#getCode
  @public
  @return {string} A short code for the Status which can be used for debugging.
  */
  getCode() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadedStatus?id=getdescription)
  @overrides bcdui.core.Status#getDescription
  @public
  @return {string} A longer description of the Status.
  */
  getDescription() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadedStatus?id=tostring)
  @inherits bcdui.core.Status#toString
  @return {string} A debug string summarizing this status object.
  */
  toString() { return ""; }
}


