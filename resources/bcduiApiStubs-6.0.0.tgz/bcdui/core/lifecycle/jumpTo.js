/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} href   target URL to jump to.
  @param {DomDocument} [statusDocument]   status document to pass as guiStatusGZ parameter to href.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.lifecycle.jumpTo)
  @description   Jumps to another url optionally setting status document, this function is executed asynchronously.
  @method jumpTo
@return {void}
  @memberOf bcdui.core.lifecycle
 */
export function jumpTo(href, statusDocument) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
