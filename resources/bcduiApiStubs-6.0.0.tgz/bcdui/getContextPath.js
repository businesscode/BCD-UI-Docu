/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "./exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.getContextPath)
  @description   Context path of the current webapp
  @method getContextPath
@return {string}  Context path of the current webapp to resolve relative URLs
@memberOf bcdui
 */
export function getContextPath() { return ""; };
