/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.getContextPath)
  @description   Context path of the current webapp
  @method getContextPath
@return {string}  Context path of the current webapp to resolve relative URLs
@memberOf bcdui
 */
export function getContextPath(): string;
