/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.exports._clickActionSave)
  @description
  @method _clickActionSave
@return {void}
  @memberOf bcdui.component.exports
 */
export function _clickActionSave(): void;
