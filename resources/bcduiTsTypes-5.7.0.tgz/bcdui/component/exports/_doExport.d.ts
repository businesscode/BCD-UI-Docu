/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.exports._doExport)
  @description
  @method _doExport
@return {void}
  @memberOf bcdui.component.exports
 */
export function _doExport(): void;
