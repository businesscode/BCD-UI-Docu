/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.exports._clickActionCancel)
  @description
  @method _clickActionCancel
@return {void}
  @memberOf bcdui.component.exports
 */
export function _clickActionCancel(): void;
