/**
  @typedef {Object} Type_ExportsExportWysiwygAsExcel_Args
  @property {(string|HtmlElement)} rootElement   The id of or the root element itself
  @property {string} [fileName="export(_timestamp).xsl"]  default="export(_timestamp).xsl"  The name of the returned Excel document
  */
/**
@param {Type_ExportsExportWysiwygAsExcel_Args} args   The parameter map contains the following properties:
  ````js
  { rootElement, fileName? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.exports.exportWysiwygAsExcel)
@description   Produces a WYSIWYG Excel export of a windows.document subtree
@method exportWysiwygAsExcel

@example
// Usage
bcdui.component.exports.exportWysiwygAsExcel({ rootElement });

@return {void}
@memberOf bcdui.component.exports
*/
export function exportWysiwygAsExcel(args: Type_ExportsExportWysiwygAsExcel_Args): void;
export type Type_ExportsExportWysiwygAsExcel_Args = {
    /**
     * The id of or the root element itself
     */
    rootElement: (string | HtmlElement);
    /**
     * default="export(_timestamp).xsl"  The name of the returned Excel document
     */
    fileName?: string;
};
