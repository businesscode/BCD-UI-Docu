/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.exports._clickActionExport)
  @description
  @method _clickActionExport
@return {void}
  @memberOf bcdui.component.exports
 */
export function _clickActionExport(): void;
