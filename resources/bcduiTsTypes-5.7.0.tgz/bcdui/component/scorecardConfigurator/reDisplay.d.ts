/**
@param {string} scorecardId   The id of the linked scorecard
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecardConfigurator.reDisplay)
  @description   Refreshes the scorecard drag'n drop area
This is e.g. necessary when a template is applied or the layout is cleaned
  @method reDisplay
@return {void}
  @memberOf bcdui.component.scorecardConfigurator
 */
export function reDisplay(scorecardId: string): void;
