/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecardConfigurator._itemRendererAspects)
  @description
  @method _itemRendererAspects
@return {void}
  @memberOf bcdui.component.scorecardConfigurator
 */
export function _itemRendererAspects(): void;
