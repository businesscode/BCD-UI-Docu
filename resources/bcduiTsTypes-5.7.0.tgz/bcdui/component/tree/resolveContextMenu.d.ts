/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.tree.resolveContextMenu)
  @description
  @method resolveContextMenu
@return {void}
  @memberOf bcdui.component.tree
 */
export function resolveContextMenu(): void;
