/**
  @typedef {Object} Type_TreeConstructor_Args
  @property {targetHtmlRef} targetHtml   A reference to the HTML DOM Element where to put the output
  @property {bcdui.core.DataProvider} [config="./treeConfiguration"]  default="./treeConfiguration"  The model containing the tree configuration data. If it is not present a SimpleModel with the url  './treeConfiguration.xml' is created.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatus]  default=bcdui.wkModels.guiStatus  StatusModel (default is 'guiStatus'), containing the filters as /SomeRoot/f:Filter and used to store tree expand/collapse status
  @property {string} [id]   The object's id, needed only when later accessing via id.
  @property {boolean} [persistent=true]  default=true  Tree expand/collapse status is stored
  @property {(boolean|string)} [contextMenu]   If true, tree's default context menu is used, otherwise provide the url to your context menu xslt here.
  @property {(function|string)} [contextMenuResolver]   Function which gets a parameter bag with well known attributes and the dataset of the selected context menu entry. Should return false if action is not provided so that default functions are called.
  @property {Object} [parameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  */
/**
  @class bcdui.component.tree.Tree
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.tree.Tree)
  @description Creates a tree front end based on a configuration
  
  @example
  // Usage
var myTr = new bcdui.component.tree.Tree({ targetHtml: "#myDiv" });

@extends bcdui.core.Renderer
*/
export class Tree extends bcdui.core.Renderer {
    /**
    @description Creates a tree front end based on a configuration
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.tree.Tree)
    
    @example
    // Usage
  var myTr = new bcdui.component.tree.Tree({ targetHtml: "#myDiv" });
  
  @param {Type_TreeConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { targetHtml, config?, statusModel?, id?, persistent?, contextMenu?, contextMenuResolver?, parameters? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_TreeConstructor_Args);
}
export type Type_TreeConstructor_Args = {
    /**
     * A reference to the HTML DOM Element where to put the output
     */
    targetHtml: targetHtmlRef;
    /**
     * default="./treeConfiguration"  The model containing the tree configuration data. If it is not present a SimpleModel with the url  './treeConfiguration.xml' is created.
     */
    config?: bcdui.core.DataProvider;
    /**
     * default=bcdui.wkModels.guiStatus  StatusModel (default is 'guiStatus'), containing the filters as /SomeRoot/f:Filter and used to store tree expand/collapse status
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * The object's id, needed only when later accessing via id.
     */
    id?: string;
    /**
     * default=true  Tree expand/collapse status is stored
     */
    persistent?: boolean;
    /**
     * If true, tree's default context menu is used, otherwise provide the url to your context menu xslt here.
     */
    contextMenu?: (boolean | string);
    /**
     * Function which gets a parameter bag with well known attributes and the dataset of the selected context menu entry. Should return false if action is not provided so that default functions are called.
     */
    contextMenuResolver?: (Function | string);
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    parameters?: Object;
};
import * as bcdui from "../../exports.js";
