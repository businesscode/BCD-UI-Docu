/**
  @typedef {Object} Type_TextNavigationConstructor_Args
  @property {targetHtmlRef} targetHtml   Where to place the microphone and text field
  @property {function} customPreEvaluator   Called before the standard evaluation, can remove words by returning a shorter array
  @property {function} customPostEvaluator   Called after the standard evaluation, can trigger page switches for example
  @property {bcdui.core.DataProvider} config   Definition if the chat according to Model with the chart definition according to XSD http://www.businesscode.de/schema/bcdui/textnavigation-1.0.0
  */
/**
  @class bcdui.component.textnavigation.TextNavigation
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.textnavigation.TextNavigation)
  @description Create a text navigation based on http://www.businesscode.de/schema/bcdui/textnavigation-1.0.0 XSD
  
  @example
  // Usage
var myTN = new bcdui.component.textnavigation.TextNavigation({ targetHtml: "#myDiv", customPreEvaluator, customPostEvaluator, config });

@extends bcdui.core.Renderer
*/
export class TextNavigation extends bcdui.core.Renderer {
    /**
    @description Create a text navigation based on http://www.businesscode.de/schema/bcdui/textnavigation-1.0.0 XSD
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.textnavigation.TextNavigation)
    
    @example
    // Usage
  var myTN = new bcdui.component.textnavigation.TextNavigation({ targetHtml: "#myDiv", customPreEvaluator, customPostEvaluator, config });
  
  @param {Type_TextNavigationConstructor_Args} args   Parameter object:
      ````js
      { targetHtml, customPreEvaluator, customPostEvaluator, config }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_TextNavigationConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.textnavigation.TextNavigation?id=singledigittoword)
    @description   Replace all single-digits in the text be the corresponding English word "1" -> "one"
    @param {string} text   Text in which to replace single digit words representing numbers
    @param {string} prefix   Optional prefix to make the words longer and less ambiguous in conains relations
    @public
    
    @example
    // Usage
  var ret = myTN.singleDigitToWord( text, prefix );
  
  @return {string} transformed text
    */
    public singleDigitToWord(text: string, prefix: string): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.textnavigation.TextNavigation?id=startvoicerecognition)
    @description   Start voice recognition
    @public
    @return {void}
    */
    public startVoiceRecognition(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.textnavigation.TextNavigation?id=stopvoicerecognition)
    @description   Stop voice recognition
    @public
    @return {void}
    */
    public stopVoiceRecognition(): void;
}
export type Type_TextNavigationConstructor_Args = {
    /**
     * Where to place the microphone and text field
     */
    targetHtml: targetHtmlRef;
    /**
     * Called before the standard evaluation, can remove words by returning a shorter array
     */
    customPreEvaluator: Function;
    /**
     * Called after the standard evaluation, can trigger page switches for example
     */
    customPostEvaluator: Function;
    /**
     * Definition if the chat according to Model with the chart definition according to XSD http://www.businesscode.de/schema/bcdui/textnavigation-1.0.0
     */
    config: bcdui.core.DataProvider;
};
import * as bcdui from "../../exports.js";
