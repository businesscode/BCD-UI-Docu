/**
  @typedef {Object} Type_UploaderConstructor_Args
  @property {targetHtmlRef} targetHtml   A reference to the HTML DOM Element where to put the output
  @property {string} scope   The scope identifier, can be a space separated string when you want to map multiple scopeId and instanceId
  @property {string} instance   The instance identifier, can be a space separated string when you want to map multiple scopeId and instanceId
  @property {string} [id]   The object's id, needed only when later accessing via id. If given the docUpload registers itself at {@link bcdui.factory.objectRegistry}
  @property {Object} [map]   scope/instance map, alternative way to specify multiple scope/instances
  @property {string} [addBRefs]   Space separated list of additional bRefs you want to load
  @property {string} [bindingSetId=bcd_docUpload]  default=bcd_docUpload  Optional binding set id used for document storage, by default bcd_docUpload is used
  @property {string} [doAcknowledge]   Set to true if acknowledge mode is required
  @property {string} [downloadAll]   Set to true if you want to be able to download/zip all documents
  @property {function} [onBeforeSave]   Function which is called before each save operation. Parameter holds current wrs dataprovider. Function needs to return true to save or false for skipping save process and resetting data
  @property {string} [filterBRefs]   The space separated list of binding Refs that will be used in filter clause of request document
  @property {string} [zipName=documents.zip]  default=documents.zip  The filename for the generated zip, ensure it ends with .zip
  @property {targetHtmlRef} [zipDownloadTargetHtml]   optional targetHml htmlElement or jQuery object for zip download button, if not present, it's rendered to its default place
  @property {chainDef} [renderChain]   A custom renderer chain
  @property {Object} [renderParameters]   Renderer parameters. Will be enrichted with docUploader default parameters
  @property {bcdui.core.DataProvider} [config=bcdui.wkModels.bcdDocUpload]  default=bcdui.wkModels.bcdDocUpload  The model containing the docUpload configuration data. If it is not present the well known bcdui.wkModels.bcdDocUpload is used
  */
/**
  @class bcdui.component.docUpload.Uploader
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.docUpload.Uploader)
  @description Creates an Uploader
  
  @example
  // Usage
var myUpl = new bcdui.component.docUpload.Uploader({ targetHtml: "#myDiv", scope, instance });

@extends bcdui.core.Renderer
*/
export class Uploader extends bcdui.core.Renderer {
    /**
    @description Creates an Uploader
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.docUpload.Uploader)
    
    @example
    // Usage
  var myUpl = new bcdui.component.docUpload.Uploader({ targetHtml: "#myDiv", scope, instance });
  
  @param {Type_UploaderConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { targetHtml, scope, instance, id?, map?, addBRefs?, bindingSetId?, doAcknowledge?, downloadAll?, onBeforeSave?, filterBRefs?, zipName?, zipDownloadTargetHtml?, renderChain?, renderParameters?, config? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_UploaderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.docUpload.Uploader?id=getuploadinfo)
    @description   returns an array with objects for each category of the current scope.
  in case of uploaded data it holds additional information like filename, size, url, comment, etc
    @public
    @return {void}
    */
    public getUploadInfo(): void;
}
export type Type_UploaderConstructor_Args = {
    /**
     * A reference to the HTML DOM Element where to put the output
     */
    targetHtml: targetHtmlRef;
    /**
     * The scope identifier, can be a space separated string when you want to map multiple scopeId and instanceId
     */
    scope: string;
    /**
     * The instance identifier, can be a space separated string when you want to map multiple scopeId and instanceId
     */
    instance: string;
    /**
     * The object's id, needed only when later accessing via id. If given the docUpload registers itself at {@link bcdui.factory.objectRegistry}
     */
    id?: string;
    /**
     * scope/instance map, alternative way to specify multiple scope/instances
     */
    map?: Object;
    /**
     * Space separated list of additional bRefs you want to load
     */
    addBRefs?: string;
    /**
     * default=bcd_docUpload  Optional binding set id used for document storage, by default bcd_docUpload is used
     */
    bindingSetId?: string;
    /**
     * Set to true if acknowledge mode is required
     */
    doAcknowledge?: string;
    /**
     * Set to true if you want to be able to download/zip all documents
     */
    downloadAll?: string;
    /**
     * Function which is called before each save operation. Parameter holds current wrs dataprovider. Function needs to return true to save or false for skipping save process and resetting data
     */
    onBeforeSave?: Function;
    /**
     * The space separated list of binding Refs that will be used in filter clause of request document
     */
    filterBRefs?: string;
    /**
     * default=documents.zip  The filename for the generated zip, ensure it ends with .zip
     */
    zipName?: string;
    /**
     * optional targetHml htmlElement or jQuery object for zip download button, if not present, it's rendered to its default place
     */
    zipDownloadTargetHtml?: targetHtmlRef;
    /**
     * A custom renderer chain
     */
    renderChain?: chainDef;
    /**
     * Renderer parameters. Will be enrichted with docUploader default parameters
     */
    renderParameters?: Object;
    /**
     * default=bcdui.wkModels.bcdDocUpload  The model containing the docUpload configuration data. If it is not present the well known bcdui.wkModels.bcdDocUpload is used
     */
    config?: bcdui.core.DataProvider;
};
import * as bcdui from "../../exports.js";
