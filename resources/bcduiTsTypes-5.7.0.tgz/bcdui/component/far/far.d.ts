/**
  @typedef {Object} Type_FarConstructor_Args
  @property {targetHtmlRef} targetHtml   A reference to the HTML DOM Element where to render the output.
  @property {bcdui.core.DataProvider} config   Configuration document from http://www.businesscode.de/schema/bcdui/far-1.0.0
  @property {string} [componentId="far"]  default="far"  An ID for the component, 'far' is the default. This is not the data provider's technical identifier,
                                                           this ID is used as component identifier to support multiple components on single page, i.e. reuse same configuration.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  The StatusModel, containing the filters at /SomeRoot/f:Filter
  */
/**
  @class bcdui.component.far.Far
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.far.Far)
  @description A FAR component
  
  @example
  // Usage
var myFr = new bcdui.component.far.Far({ targetHtml: "#myDiv", config });

*/
export class Far {
    /**
    @description A FAR component
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.far.Far)
    
    @example
    // Usage
  var myFr = new bcdui.component.far.Far({ targetHtml: "#myDiv", config });
  
  @param {Type_FarConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { targetHtml, config, componentId?, statusModel? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_FarConstructor_Args);
}
export type Type_FarConstructor_Args = {
    /**
     * A reference to the HTML DOM Element where to render the output.
     */
    targetHtml: targetHtmlRef;
    /**
     * Configuration document from http://www.businesscode.de/schema/bcdui/far-1.0.0
     */
    config: bcdui.core.DataProvider;
    /**
     * default="far"  An ID for the component, 'far' is the default. This is not the data provider's technical identifier,
                       this ID is used as component identifier to support multiple components on single page, i.e. reuse same configuration.
     */
    componentId?: string;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  The StatusModel, containing the filters at /SomeRoot/f:Filter
     */
    statusModel?: bcdui.core.DataProvider;
};
import * as bcdui from "../../exports.js";
