/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.far.resolveContextMenu)
  @description
  @method resolveContextMenu
@return {void}
  @memberOf bcdui.component.far
 */
export function resolveContextMenu(): void;
