/**
  @typedef {Object} Type_FarModelConstructor_Args
  @property {bcdui.core.DataProvider} config   Configuration document from http://www.businesscode.de/schema/bcdui/far-1.0.0
  @property {string} [componentId="far"]  default="far"  An ID for the component, 'far' is the default. This is not the data provider's technical identifier,
                                                           this ID is used as component identifer to support multiple components on single page, i.e. reuse same configuration.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  The StatusModel, containing the filters at /SomeRoot/f:Filter
  */
/**
  @class bcdui.component.far.FarModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.far.FarModel)
  @description DataProvider for Far if you need more fine-grained control.
Implementation reading far:Configuration document and providing data according to it,
you can use this model if you solely want to read data using far:Configuration.
  
  @example
  // Usage
var myFM = new bcdui.component.far.FarModel({ config });

@extends bcdui.core.AsyncJsDataProvider
*/
export class FarModel extends bcdui.core.AsyncJsDataProvider {
    /**
    @description DataProvider for Far if you need more fine-grained control.
  Implementation reading far:Configuration document and providing data according to it,
  you can use this model if you solely want to read data using far:Configuration.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.far.FarModel)
    
    @example
    // Usage
  var myFM = new bcdui.component.far.FarModel({ config });
  
  @param {Type_FarModelConstructor_Args} args   Parameter map contains the following properties:
      ````js
      { config, componentId?, statusModel? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_FarModelConstructor_Args);
}
export type Type_FarModelConstructor_Args = {
    /**
     * Configuration document from http://www.businesscode.de/schema/bcdui/far-1.0.0
     */
    config: bcdui.core.DataProvider;
    /**
     * default="far"  An ID for the component, 'far' is the default. This is not the data provider's technical identifier,
                       this ID is used as component identifer to support multiple components on single page, i.e. reuse same configuration.
     */
    componentId?: string;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  The StatusModel, containing the filters at /SomeRoot/f:Filter
     */
    statusModel?: bcdui.core.DataProvider;
};
import * as bcdui from "../../exports.js";
