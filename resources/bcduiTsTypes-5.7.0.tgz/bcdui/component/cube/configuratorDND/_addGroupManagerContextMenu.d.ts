/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configuratorDND._addGroupManagerContextMenu)
  @description
  @method _addGroupManagerContextMenu
@return {void}
  @memberOf bcdui.component.cube.configuratorDND
 */
export function _addGroupManagerContextMenu(): void;
