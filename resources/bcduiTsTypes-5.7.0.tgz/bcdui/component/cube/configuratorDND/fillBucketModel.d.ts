/**
@param {string} cubeBucketModelId   The id of the cubeBucketModel
  @param {string} configId   The id of the used configuration
  @param {boolean} [noClear]   true if current selection should not get changed
  @param {function} [callback]   callback function which is called as soon as bucketModel is fully filled
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configuratorDND.fillBucketModel)
  @description   Used for initial filling but can also be used to reinitialize bucket model (e.g. after hiding selectable measures)
  @method fillBucketModel

  @example
  // Usage
bcdui.component.cube.configuratorDND.fillBucketModel( cubeBucketModelId, configId );

@return {void}
  @memberOf bcdui.component.cube.configuratorDND
 */
export function fillBucketModel(cubeBucketModelId: string, configId: string, noClear?: boolean, callback?: Function): void;
