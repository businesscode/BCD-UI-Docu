/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configuratorDND.init)
  @description
  @method init
@return {void}
  @memberOf bcdui.component.cube.configuratorDND
 */
export function init(): void;
