/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configuratorDND._markGroupingDimensions)
  @description
  @method _markGroupingDimensions
@return {void}
  @memberOf bcdui.component.cube.configuratorDND
 */
export function _markGroupingDimensions(): void;
