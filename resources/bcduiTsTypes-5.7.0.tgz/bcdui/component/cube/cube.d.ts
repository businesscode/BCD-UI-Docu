/**
  @typedef {Object} Type_CubeConstructor_Args
  @property {targetHtmlRef} targetHtml   A reference to the HTML DOM Element where to put the output
  @property {bcdui.core.DataProvider} [config]   The model containing the cube's configuration (see cube-2.0.0.xsd). If it is not present, the configuration at './cubeConfiguration.xml' is used
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  StatusModel (default is 'guiStatusEstablished'), containing the filters as /SomeRoot/f:Filter and the layout definition at /SomeRoot//cube:Layout[&commat;cubeId=args.cubeId]
  @property {bcdui.core.DataProvider} [detailExportFilterModel]   Use this to overwrite filters found in args.statusModel, default set to args.statusModel
  @property {string} [id]   The object's id, needed only when later accessing via id. If given the Cube registers itself at {@link bcdui.factory.objectRegistry}
  @property {chainDef} [chain]   An alternative rendering chain, See {@link bcdui.core.Renderer}. Default here is HtmlBuilder.
  @property {Object} [parameters]   An object, where each property holds a DataProvider being a renderer parameter used in custom chains
  @property {chainDef} [requestChain]   An alternative request building chain. Default here is /bcdui/js/component/cube/request.xslt.
  @property {Object} [requestParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  @property {bcdui.core.DataProvider} [inputModel]   CubeModel to work with. If not given, Cube creates a CubeModel in the background from the config
  */
/**
  @class bcdui.component.cube.Cube
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.Cube)
  @description Creates a Cube, i.e. pivot-like front end based on given data or a configuration.
This class will create in implicit CubeModel if not provided as inputModel parameter.
See {@link bcdui.component.cube.CubeModel} for an example of a cube:CubeConfiguration
To use Cube or CubeModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiCube`
  
  @example
  // Usage
var myCb = new bcdui.component.cube.Cube({ targetHtml: "#myDiv" });

@extends bcdui.core.Renderer
*/
export class Cube extends bcdui.core.Renderer {
    /**
    @description Creates a Cube, i.e. pivot-like front end based on given data or a configuration.
  This class will create in implicit CubeModel if not provided as inputModel parameter.
  See {@link bcdui.component.cube.CubeModel} for an example of a cube:CubeConfiguration
  To use Cube or CubeModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiCube`
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.Cube)
    
    @example
    // Usage
  var myCb = new bcdui.component.cube.Cube({ targetHtml: "#myDiv" });
  
  @param {Type_CubeConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { targetHtml, config?, statusModel?, detailExportFilterModel?, id?, chain?, parameters?, requestChain?, requestParameters?, inputModel? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_CubeConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.Cube?id=getconfigmodel)
    @public
    @return {bcdui.core.DataProvider} configuration model of the cube
    */
    public getConfigModel(): bcdui.core.DataProvider;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.Cube?id=getenhancedconfiguration)
    @public
    @return {bcdui.core.DataProvider} Enhanced configuration model of the cube
    */
    public getEnhancedConfiguration(): bcdui.core.DataProvider;
}
export type Type_CubeConstructor_Args = {
    /**
     * A reference to the HTML DOM Element where to put the output
     */
    targetHtml: targetHtmlRef;
    /**
     * The model containing the cube's configuration (see cube-2.0.0.xsd). If it is not present, the configuration at './cubeConfiguration.xml' is used
     */
    config?: bcdui.core.DataProvider;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  StatusModel (default is 'guiStatusEstablished'), containing the filters as /SomeRoot/f:Filter and the layout definition at /SomeRoot//cube:Layout[&commat;cubeId=args.cubeId]
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * Use this to overwrite filters found in args.statusModel, default set to args.statusModel
     */
    detailExportFilterModel?: bcdui.core.DataProvider;
    /**
     * The object's id, needed only when later accessing via id. If given the Cube registers itself at {@link bcdui.factory.objectRegistry}
     */
    id?: string;
    /**
     * An alternative rendering chain, See {@link bcdui.core.Renderer}. Default here is HtmlBuilder.
     */
    chain?: chainDef;
    /**
     * An object, where each property holds a DataProvider being a renderer parameter used in custom chains
     */
    parameters?: Object;
    /**
     * An alternative request building chain. Default here is /bcdui/js/component/cube/request.xslt.
     */
    requestChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    requestParameters?: Object;
    /**
     * CubeModel to work with. If not given, Cube creates a CubeModel in the background from the config
     */
    inputModel?: bcdui.core.DataProvider;
};
import * as bcdui from "../../exports.js";
