/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.hideDimMember)
  @description   Hides (client side filter) the occurrences of a selected dimension member, i.e. for example all values for a country
Results in cube:Layout/cube:Hide/f:Filter expressions
  @method hideDimMember
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function hideDimMember(): void;
