/**
@param {targetHtmlRef} targetModelId
  @param {string} cubeId
  @param {Object} args   { row, col }
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.addRowMeasure)
  @description   adding row measure for cube (opening calcNode editor and put formula to cube model)
  @method addRowMeasure

  @example
  // Usage
var ret = bcdui.component.cube.configurator.addRowMeasure( targetModelId, cubeId, args );

@return {boolean}  false
@memberOf bcdui.component.cube.configurator
 */
export function addRowMeasure(targetModelId: targetHtmlRef, cubeId: string, args: Object): boolean;
