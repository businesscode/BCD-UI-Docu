/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.toggleHideTotals)
  @description
  @method toggleHideTotals
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function toggleHideTotals(): void;
