/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.showTotals)
  @description
  @method showTotals
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function showTotals(): void;
