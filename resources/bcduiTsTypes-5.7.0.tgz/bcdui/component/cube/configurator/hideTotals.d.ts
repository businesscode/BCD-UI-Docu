/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.hideTotals)
  @description
  @method hideTotals
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function hideTotals(): void;
