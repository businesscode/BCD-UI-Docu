/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.setSortMeasure)
  @description
  @method setSortMeasure
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function setSortMeasure(): void;
