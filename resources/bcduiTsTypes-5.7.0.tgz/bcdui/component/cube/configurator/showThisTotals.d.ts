/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.showThisTotals)
  @description
  @method showThisTotals
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function showThisTotals(): void;
