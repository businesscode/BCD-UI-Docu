/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.setCumulate)
  @description
  @method setCumulate
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function setCumulate(): void;
