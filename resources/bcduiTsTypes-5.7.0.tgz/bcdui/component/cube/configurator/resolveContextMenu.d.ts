/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.resolveContextMenu)
  @description
  @method resolveContextMenu
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function resolveContextMenu(): void;
