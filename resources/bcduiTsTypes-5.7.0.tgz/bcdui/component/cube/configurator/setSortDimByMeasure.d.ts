/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.setSortDimByMeasure)
  @description
  @method setSortDimByMeasure
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function setSortDimByMeasure(): void;
