/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.setColumnSort)
  @description
  @method setColumnSort
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function setColumnSort(): void;
