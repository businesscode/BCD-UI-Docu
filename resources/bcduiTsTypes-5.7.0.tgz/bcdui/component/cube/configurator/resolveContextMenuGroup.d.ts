/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.resolveContextMenuGroup)
  @description
  @method resolveContextMenuGroup
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function resolveContextMenuGroup(): void;
