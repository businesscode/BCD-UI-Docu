/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.excludeDimMember)
  @description   Excludes (server side filter) the occurrences of a selected dimension member, i.e. for example all values for a country
Results in f:Filter expressions
  @method excludeDimMember
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function excludeDimMember(): void;
