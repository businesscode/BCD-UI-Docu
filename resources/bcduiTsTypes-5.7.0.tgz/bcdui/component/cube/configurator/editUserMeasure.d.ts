/**
@param {targetHtmlRef} targetModelId
  @param {string} cubeId
  @param {Object} args
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.editUserMeasure)
  @description   opening calcNode editor for edit current formula
  @method editUserMeasure

  @example
  // Usage
var ret = bcdui.component.cube.configurator.editUserMeasure( targetModelId, cubeId, args );

@return {boolean}  false
@memberOf bcdui.component.cube.configurator
 */
export function editUserMeasure(targetModelId: targetHtmlRef, cubeId: string, args: Object): boolean;
