/**
@param {targetHtmlRef} targetModelId
  @param {string} cubeId
  @param {Object} args
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.deleteUserMeasure)
  @description   deleting userCalc node from measures
  @method deleteUserMeasure

  @example
  // Usage
var ret = bcdui.component.cube.configurator.deleteUserMeasure( targetModelId, cubeId, args );

@return {boolean}  false
@memberOf bcdui.component.cube.configurator
 */
export function deleteUserMeasure(targetModelId: targetHtmlRef, cubeId: string, args: Object): boolean;
