/**
  @typedef {Object} Type_CubeModelConstructor_Args
  @property {bcdui.core.DataProvider} [config]   The model containing the cube meta data (see cube-2.0.0.xsd). If it is not present, the configuration at './cubeConfiguration.xml' is used
  @property {string} [cubeId]   When settings are to be derived from status model, this is the id in <cube:Layout cubeId="myCube">
  @property {string} [id]   The object's id, needed only when later accessing via id. If given the CubeModel registers itself at {@link bcdui.factory.objectRegistry}
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  StatusModel, containing the filters as /SomeRoot/f:Filter and the layout definition at /SomeRoot//cube:Layout[&commat;cubeId=args.cubeId]
  @property {chainDef} [requestChain]   An alternative request building chain. Default here is /bcdui/js/component/cube/request.xslt.
  @property {Object} [requestParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  */
/**
  @class bcdui.component.cube.CubeModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.CubeModel)
  @description Creates a CubeModel for use by Cube, if you need more fine-grained control or only want the data.
Provides data with calculations and col dimensions applied.
To use Cube or CubeModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiCube`
  
  @example
  ````xml
      <cube:CubeConfiguration xmlns:cube="http://www.businesscode.de/schema/bcdui/cube-2.0.0"
                              xmlns:calc="http://www.businesscode.de/schema/bcdui/calc-1.0.0"
                              xmlns:dm="http://www.businesscode.de/schema/bcdui/dimmeas-1.0.0"
                              xmlns:wrq="http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0">

        <cube:Layout>

          <!-- Row and column dimensions -->
          <cube:Dimensions hideTotals="false">
            <cube:Rows>
              <dm:LevelRef total="trailing" bRef="orig_country"/>
              <dm:LevelRef total="trailing" bRef="orig_area"/>
            </cube:Rows>
            <cube:Columns>
              <dm:LevelRef total="trailing" bRef="product_code"/>
            </cube:Columns>
          </cube:Dimensions>

          <cube:Measures>
            <!-- Broken down by row dimension, showing total for col dimensions -->
            <cube:RowDims/>
              <dm:MeasureRef idRef="cost"/>
            <!-- Broken down by row and columns dimensions -->
            <cube:AllDims>
              <dm:MeasureRef idRef="weight"/>
            </cube:AllDims>
          </cube:Measures>

        </cube:Layout>

        <wrq:BindingSet>myReportData1</wrq:BindingSet>

        <!-- Definition of available dimensions, also used by optional cubeConfigurator it -->
        <dm:Dimensions>
          <dm:LevelRef bRef="orig_country" total="trailing" caption="Origin Country"/>
          <dm:LevelRef bRef="orig_area"    total="trailing" caption="Origin Area"/>
          <dm:LevelRef bRef="dest_country" total="trailing" caption="Destination Country"/>
          <dm:LevelRef bRef="dest_area"    total="trailing" caption="Destination Area"/>
          <dm:LevelRef bRef="product_code" total="trailing" caption="Product Code"/>
          <dm:LevelRef bRef="dy"           total="trailing" caption="Day"/>
        </dm:Dimensions>

        <!- Actual values to be shown ->
        <dm:Measures>
          <dm:Measure id="cost" caption="Cost">
            <calc:Calc type-name="NUMERIC" scale="1">
              <calc:ValueRef idRef="cost" aggr="sum"/>
            </calc:Calc>
          </dm:Measure>
          <dm:Measure id="weight" caption="Weight">
            <calc:Calc type-name="NUMERIC" unit="kg">
              <calc:ValueRef idRef="weight" aggr="sum"/>
            </calc:Calc>
          </dm:Measure>
          <!-- A measure with a values who is client-calculated by the quotient of two values -->
          <dm:Measure id="weightPerVolume" caption="Weight/Vol.">
            <calc:Calc type-name="NUMERIC" scale="3">
              <calc:Div>
                <calc:ValueRef idRef="weight" aggr="sum"/>
                <calc:ValueRef idRef="volume" aggr="sum"/>
              </calc:Div>
            </calc:Calc>
          </dm:Measure>
        </dm:Measures>

      </cube:CubeConfiguration>
     ````
  @extends bcdui.core.ModelWrapper
*/
export class CubeModel extends bcdui.core.ModelWrapper {
    /**
    @description Creates a CubeModel for use by Cube, if you need more fine-grained control or only want the data.
  Provides data with calculations and col dimensions applied.
  To use Cube or CubeModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiCube`
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.CubeModel)
    
    @example
    ````xml
        <cube:CubeConfiguration xmlns:cube="http://www.businesscode.de/schema/bcdui/cube-2.0.0"
                                xmlns:calc="http://www.businesscode.de/schema/bcdui/calc-1.0.0"
                                xmlns:dm="http://www.businesscode.de/schema/bcdui/dimmeas-1.0.0"
                                xmlns:wrq="http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0">
  
          <cube:Layout>
  
            <!-- Row and column dimensions -->
            <cube:Dimensions hideTotals="false">
              <cube:Rows>
                <dm:LevelRef total="trailing" bRef="orig_country"/>
                <dm:LevelRef total="trailing" bRef="orig_area"/>
              </cube:Rows>
              <cube:Columns>
                <dm:LevelRef total="trailing" bRef="product_code"/>
              </cube:Columns>
            </cube:Dimensions>
  
            <cube:Measures>
              <!-- Broken down by row dimension, showing total for col dimensions -->
              <cube:RowDims/>
                <dm:MeasureRef idRef="cost"/>
              <!-- Broken down by row and columns dimensions -->
              <cube:AllDims>
                <dm:MeasureRef idRef="weight"/>
              </cube:AllDims>
            </cube:Measures>
  
          </cube:Layout>
  
          <wrq:BindingSet>myReportData1</wrq:BindingSet>
  
          <!-- Definition of available dimensions, also used by optional cubeConfigurator it -->
          <dm:Dimensions>
            <dm:LevelRef bRef="orig_country" total="trailing" caption="Origin Country"/>
            <dm:LevelRef bRef="orig_area"    total="trailing" caption="Origin Area"/>
            <dm:LevelRef bRef="dest_country" total="trailing" caption="Destination Country"/>
            <dm:LevelRef bRef="dest_area"    total="trailing" caption="Destination Area"/>
            <dm:LevelRef bRef="product_code" total="trailing" caption="Product Code"/>
            <dm:LevelRef bRef="dy"           total="trailing" caption="Day"/>
          </dm:Dimensions>
  
          <!- Actual values to be shown ->
          <dm:Measures>
            <dm:Measure id="cost" caption="Cost">
              <calc:Calc type-name="NUMERIC" scale="1">
                <calc:ValueRef idRef="cost" aggr="sum"/>
              </calc:Calc>
            </dm:Measure>
            <dm:Measure id="weight" caption="Weight">
              <calc:Calc type-name="NUMERIC" unit="kg">
                <calc:ValueRef idRef="weight" aggr="sum"/>
              </calc:Calc>
            </dm:Measure>
            <!-- A measure with a values who is client-calculated by the quotient of two values -->
            <dm:Measure id="weightPerVolume" caption="Weight/Vol.">
              <calc:Calc type-name="NUMERIC" scale="3">
                <calc:Div>
                  <calc:ValueRef idRef="weight" aggr="sum"/>
                  <calc:ValueRef idRef="volume" aggr="sum"/>
                </calc:Div>
              </calc:Calc>
            </dm:Measure>
          </dm:Measures>
  
        </cube:CubeConfiguration>
       ````
    @param {Type_CubeModelConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { config?, cubeId?, id?, statusModel?, requestChain?, requestParameters? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_CubeModelConstructor_Args);
}
export type Type_CubeModelConstructor_Args = {
    /**
     * The model containing the cube meta data (see cube-2.0.0.xsd). If it is not present, the configuration at './cubeConfiguration.xml' is used
     */
    config?: bcdui.core.DataProvider;
    /**
     * When settings are to be derived from status model, this is the id in <cube:Layout cubeId="myCube">
     */
    cubeId?: string;
    /**
     * The object's id, needed only when later accessing via id. If given the CubeModel registers itself at {@link bcdui.factory.objectRegistry}
     */
    id?: string;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  StatusModel, containing the filters as /SomeRoot/f:Filter and the layout definition at /SomeRoot//cube:Layout[&commat;cubeId=args.cubeId]
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * An alternative request building chain. Default here is /bcdui/js/component/cube/request.xslt.
     */
    requestChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    requestParameters?: Object;
};
import * as bcdui from "../../exports.js";
