/**
@param {string} objectId   The id of the linked object (cube or scorecard)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.templateManager.clearLayout)
  @description   Removes the current layout
  @method clearLayout
@return {void}
  @memberOf bcdui.component.cube.templateManager
 */
export function clearLayout(objectId: string): void;
