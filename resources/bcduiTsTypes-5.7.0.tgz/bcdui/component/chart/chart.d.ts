/**
  @typedef {Object} Type_ChartConstructor_Args
  @property {targetHtmlRef} targetHtml   Where to place the chart
  @property {boolean} [suppressInitialRendering]   If true, the renderer does not initially auto execute but waits for an explicit execute
  @property {string} [id]   Page unique id for used in declarative contexts. If provided, the chart will register itself
  @property {boolean} [showAxes=true]  default=true  If false, no axes will be shown
  @property {string} [title]   Title
  @property {number} [width]   Overwrite the chart's auto-width derived from targetHtml
  @property {number} [height]   Overwrite the chart's auto-height derived from targetHtml
  */
/**
  @class bcdui.component.chart.Chart
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart)
  @description This class represents a chart.
In many cases you use {@link bcdui.component.chart.XmlChart} and you have a config for the chart
  
  @example
  // Usage
var myChr = new bcdui.component.chart.Chart({ targetHtml: "#myDiv" });

@extends bcdui.core.DataProvider
*/
export class Chart extends bcdui.core.DataProvider {
    /**
    @description This class represents a chart.
  In many cases you use {@link bcdui.component.chart.XmlChart} and you have a config for the chart
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart)
    
    @example
    // Usage
  var myChr = new bcdui.component.chart.Chart({ targetHtml: "#myDiv" });
  
  @param {Type_ChartConstructor_Args} args   Parameter object:
      ````js
      { targetHtml, suppressInitialRendering?, id?, showAxes?, title?, width?, height? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ChartConstructor_Args);
    /**
      @typedef {Object} Type_ChartAddSeries_Args
      @property {integer} [yAxis1Or2]   1 for left and 2 for right axis
      @property {Array.<number>} [yData]   Data array or provide yDataInfo
      @property {DomNodeSet} [yDataInfo]   XML nodeset with data
      @property {Array.<number>} [sizeData]   The 2nd value for scattered charts
      @property {Array.<number>} [xValues]   For x-y charts
      @property {(integer|string)} [chartType]   Either name or numeric value for chart type
      @property {string} [rgb]   Color
      @property {string} [dashstyle]   Dash style
      @property {Array.<string>} [baseColors]   Colors defining the tones of the generated colors, for example in case of a pie chart
      @property {string} [caption]   Series caption
      @property {number} [width]   Line width</li>
      @property {(function|string)} [onClick]   Either a function or the name of a function
      @property {boolean} [toSeriesPercentage]   If true, each value is represented by its percentage value of the full series.
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=addseries)
    @description   Adds a data series to the chart
    @param {Type_ChartAddSeries_Args} args   Parameter object
      ````js
      { yAxis1Or2?, yData?, yDataInfo?, sizeData?, xValues?, chartType?, rgb?, dashstyle?, baseColors?, caption?, width?, onClick?, toSeriesPercentage? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {void}
    */
    public addSeries(args: {
        /**
         * 1 for left and 2 for right axis
         */
        yAxis1Or2?: integer;
        /**
         * Data array or provide yDataInfo
         */
        yData?: Array<number>;
        /**
         * XML nodeset with data
         */
        yDataInfo?: DomNodeSet;
        /**
         * The 2nd value for scattered charts
         */
        sizeData?: Array<number>;
        /**
         * For x-y charts
         */
        xValues?: Array<number>;
        /**
         * Either name or numeric value for chart type
         */
        chartType?: (integer | string);
        /**
         * Color
         */
        rgb?: string;
        /**
         * Dash style
         */
        dashstyle?: string;
        /**
         * Colors defining the tones of the generated colors, for example in case of a pie chart
         */
        baseColors?: Array<string>;
        /**
         * Series caption
         */
        caption?: string;
        /**
         * Line width</li>
         */
        width?: number;
        /**
         * Either a function or the name of a function
         */
        onClick?: (Function | string);
        /**
         * If true, each value is represented by its percentage value of the full series.
         */
        toSeriesPercentage?: boolean;
    }): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=getdata)
    @description   Not implemented for Chart
    @overrides bcdui.core.DataProvider#getData
    @public
    @return {document} will always be null
    */
    public getData(): Document;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=getprimarymodel)
    @description   Not implemented for Chart
    @public
    @return {bcdui.core.DataProvider} will always be null
    */
    public getPrimaryModel(): bcdui.core.DataProvider;
    /**
      @typedef {Object} Type_ChartSetStacked_Args
      @property {integer} axis   1 for left axis 2 for right one</li>
      @property {(integer|string)} chartType   Either name or numeric value for chart type
      @property {boolean} [asPercent]   Each series is calculated to its percentage of the sum if all series and shown as *100'%'
      @property {boolean} [isStacked=true]  default=true  Whether to stack or not
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=setstacked)
    @description   Define series as being stacked
    @param {Type_ChartSetStacked_Args} args   map with
      ````js
      { axis, chartType, asPercent?, isStacked? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  myChr.setStacked({ axis, chartType });
  
  @return {void}
    */
    public setStacked(args: {
        /**
         * 1 for left axis 2 for right one</li>
         */
        axis: integer;
        /**
         * Either name or numeric value for chart type
         */
        chartType: (integer | string);
        /**
         * Each series is calculated to its percentage of the sum if all series and shown as *100'%'
         */
        asPercent?: boolean;
        /**
         * default=true  Whether to stack or not
         */
        isStacked?: boolean;
    }): void;
    /**
      @typedef {Object} Type_ChartSetXAxis_Args
      @property {Array.<number>} [categories]   Distinct values, provide this or xValues
      @property {Array.<number>} [xValues]   Values for continuous axis for x-y charts
      @property {string} [caption]   Axis caption
      @property {string} [unit]   Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
      @property {string} [layoutFlow]   css value
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=setxaxis)
    @description   Defines x (horizontal) axis
    @param {Type_ChartSetXAxis_Args} args   Parameter object
      ````js
      { categories?, xValues?, caption?, unit?, layoutFlow? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {void}
    */
    public setXAxis(args: {
        /**
         * Distinct values, provide this or xValues
         */
        categories?: Array<number>;
        /**
         * Values for continuous axis for x-y charts
         */
        xValues?: Array<number>;
        /**
         * Axis caption
         */
        caption?: string;
        /**
         * Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
         */
        unit?: string;
        /**
         * css value
         */
        layoutFlow?: string;
    }): void;
    /**
      @typedef {Object} Type_ChartSetYAxis1_Args
      @property {string} [caption]   Axis caption
      @property {string} [unit]   Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
      @property {string} [layoutFlow]   css value
      @property {number} [minValueUser]   User set axis min value. Only used when below lowest actual value
      @property {number} [maxValueUser]   User set axis max value. Only used when above highest actual value
      @property {boolean} [showGrid=true]  default=true  If false, no horizontal grid is shown but only small lines next to the y-axis values
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=setyaxis1)
    @description   Defines left y axis
    @param {Type_ChartSetYAxis1_Args} args   Parameter object
      ````js
      { caption?, unit?, layoutFlow?, minValueUser?, maxValueUser?, showGrid? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {void}
    */
    public setYAxis1(args: {
        /**
         * Axis caption
         */
        caption?: string;
        /**
         * Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
         */
        unit?: string;
        /**
         * css value
         */
        layoutFlow?: string;
        /**
         * User set axis min value. Only used when below lowest actual value
         */
        minValueUser?: number;
        /**
         * User set axis max value. Only used when above highest actual value
         */
        maxValueUser?: number;
        /**
         * default=true  If false, no horizontal grid is shown but only small lines next to the y-axis values
         */
        showGrid?: boolean;
    }): void;
    /**
      @typedef {Object} Type_ChartSetYAxis2_Args
      @property {string} [caption]   Axis caption
      @property {string} [unit]   Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
      @property {string} [layoutFlow]   css value
      @property {number} [minValueUser]   User set axis min value. Only used when below lowest actual value
      @property {number} [maxValueUser]   User set axis max value. Only used when above highest actual value
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.Chart?id=setyaxis2)
    @description   Defines right y axis
    @param {Type_ChartSetYAxis2_Args} args   Parameter object
      ````js
      { caption?, unit?, layoutFlow?, minValueUser?, maxValueUser? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {void}
    */
    public setYAxis2(args: {
        /**
         * Axis caption
         */
        caption?: string;
        /**
         * Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
         */
        unit?: string;
        /**
         * css value
         */
        layoutFlow?: string;
        /**
         * User set axis min value. Only used when below lowest actual value
         */
        minValueUser?: number;
        /**
         * User set axis max value. Only used when above highest actual value
         */
        maxValueUser?: number;
    }): void;
    /**
       * @constant
       * @type {integer}
       */
    AREACHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    BARCHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    GAUGECHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    LINECHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    MARIMEKKOCHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    PIECHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    POINTCHART: integer;
    /**
       * @constant
       * @type {integer}
       */
    SCATTEREDCHART: integer;
}
export type Type_ChartConstructor_Args = {
    /**
     * Where to place the chart
     */
    targetHtml: targetHtmlRef;
    /**
     * If true, the renderer does not initially auto execute but waits for an explicit execute
     */
    suppressInitialRendering?: boolean;
    /**
     * Page unique id for used in declarative contexts. If provided, the chart will register itself
     */
    id?: string;
    /**
     * default=true  If false, no axes will be shown
     */
    showAxes?: boolean;
    /**
     * Title
     */
    title?: string;
    /**
     * Overwrite the chart's auto-width derived from targetHtml
     */
    width?: number;
    /**
     * Overwrite the chart's auto-height derived from targetHtml
     */
    height?: number;
};
import * as bcdui from "../../exports.js";
