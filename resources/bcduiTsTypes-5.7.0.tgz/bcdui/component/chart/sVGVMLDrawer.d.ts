/**
  @typedef {Object} Type_SVGVMLDrawerConstructor_Args
  @property {Object} [scale={x:1,y:1}]  default={x:1,y:1}  Default is no scaling { x: 1, y: 1 }
  @property {Object} [transform]   Default is no shifting { x: 0, y: 0 }
  */
/**
  @class bcdui.component.chart.SVGVMLDrawer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGVMLDrawer)
  @description This class represents a base class for SVG and VML Drawers, which have the same interface.
  @description Constructor of bcdui.component.chart.SVGVMLDrawer, called by prototype.
Instantiate {@link bcdui.component.chart.SVGDrawer} concrete subclass
  */
export class SVGVMLDrawer {
    /**
    @description This class represents a base class for SVG and VML Drawers, which have the same interface.
    @description Constructor of bcdui.component.chart.SVGVMLDrawer, called by prototype.
  Instantiate {@link bcdui.component.chart.SVGDrawer} concrete subclass
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGVMLDrawer)
    @param {Type_SVGVMLDrawerConstructor_Args} args   parameter Object
      ````js
      { scale?, transform? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_SVGVMLDrawerConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGVMLDrawer?id=getresult)
    @description   Returns the a DOM element containing the SVG drawing
    @public
    @return {DomElement} Returns the a DOM element containing the VML or SVG drawing
    */
    public getResult(): DomElement;
    /**
      @typedef {Object} Type_SVGVMLDrawerSetTransScale_Args
      @property {Object} [scale={x:1,y:1}]  default={x:1,y:1}  Default is no scaling \{ x: 1, y: 1\}
      @property {Object} [transform]   Default is no shifting \{ x: 0, y: 0 \}
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGVMLDrawer?id=settransscale)
    @description   Set transform and scale
    @param {Type_SVGVMLDrawerSetTransScale_Args} args   parameter Object
      ````js
      { scale?, transform? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {void}
    */
    public setTransScale(args: {
        /**
         * default={x:1,y:1}  Default is no scaling \{ x: 1, y: 1\}
         */
        scale?: Object;
        /**
         * Default is no shifting \{ x: 0, y: 0 \}
         */
        transform?: Object;
    }): void;
}
export type Type_SVGVMLDrawerConstructor_Args = {
    /**
     * default={x:1,y:1}  Default is no scaling { x: 1, y: 1 }
     */
    scale?: Object;
    /**
     * Default is no shifting { x: 0, y: 0 }
     */
    transform?: Object;
};
