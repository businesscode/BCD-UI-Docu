/**
  @typedef {Object} Type_XmlChartConstructor_Args
  @property {targetHtmlRef} targetHtml   Where to place the chart
  @property {bcdui.core.DataProvider} config   Definition of the chart according to XSD http://www.businesscode.de/schema/bcdui/charts-1.0.0
  @property {boolean} [suppressInitialRendering]   If true, the renderer does not initially auto execute but waits for an explicit execute
  @property {string} [id]   Page unique id for used in declarative contexts. If provided, the chart will register itself
  @property {boolean} [showAxes=true]  default=true  If false, no axes will be shown
  @property {string} [title]   Title
  @property {boolean} [suppressInitialRendering]   As every renderer, charts will execute and output itself automatically and their parameters after creation. This can be suppressed here.
  @property {number} [width]   Overwrite the chart's auto-width derived from targetHtml
  @property {number} [height]   Overwrite the chart's auto-height derived from targetHtml
  */
/**
  @class bcdui.component.chart.XmlChart
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.XmlChart)
  @description Implements XML-definition interface. Extends the JS implementation of the
Chart class allowing an XML definition model as input.
  @description Constructor of bcdui.component.XmlChart, called by prototype.
  
  @example
  // Usage
var myXC = new bcdui.component.chart.XmlChart({ targetHtml: "#myDiv", config });

@extends bcdui.component.chart.Chart
*/
export class XmlChart extends bcdui.component.chart.Chart {
    /**
    @description Implements XML-definition interface. Extends the JS implementation of the
  Chart class allowing an XML definition model as input.
    @description Constructor of bcdui.component.XmlChart, called by prototype.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.XmlChart)
    
    @example
    // Usage
  var myXC = new bcdui.component.chart.XmlChart({ targetHtml: "#myDiv", config });
  
  @param {Type_XmlChartConstructor_Args} args   Parameter object
      ````js
      { targetHtml, config, suppressInitialRendering?, id?, showAxes?, title?, suppressInitialRendering?, width?, height? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_XmlChartConstructor_Args);
}
export type Type_XmlChartConstructor_Args = {
    /**
     * Where to place the chart
     */
    targetHtml: targetHtmlRef;
    /**
     * Definition of the chart according to XSD http://www.businesscode.de/schema/bcdui/charts-1.0.0
     */
    config: bcdui.core.DataProvider;
    /**
     * If true, the renderer does not initially auto execute but waits for an explicit execute
     */
    suppressInitialRendering?: boolean;
    /**
     * Page unique id for used in declarative contexts. If provided, the chart will register itself
     */
    id?: string;
    /**
     * default=true  If false, no axes will be shown
     */
    showAxes?: boolean;
    /**
     * Title
     */
    title?: string;
    /**
     * Overwrite the chart's auto-width derived from targetHtml
     */
    width?: number;
    /**
     * Overwrite the chart's auto-height derived from targetHtml
     */
    height?: number;
};
import * as bcdui from "../../exports.js";
