/**
  @typedef {Object} Type_SVGDrawerConstructor_Args
  @property {DomDocument} doc   Document for creating the SVG drawing
  @property {Object} [scale={x:1,y:1}]  default={x:1,y:1}  Default is no scaling { x: 1, y: 1}
  @property {Object} [transform]   Default is no shifting { x: 0, y: 0 }
  @property {function} [createToolTipCb]   Call back getting the source element, returning the tool tip HTML</li>
  @property {Object} [addAttr]   A set of additional string attributes to be attached to the root element</li>
  */
/**
  @class bcdui.component.chart.SVGDrawer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer)
  @description A SVG drawer, drawing basic geometries
  @extends bcdui.component.chart.SVGVMLDrawer
*/
export class SVGDrawer extends bcdui.component.chart.SVGVMLDrawer {
    /**
    @description A SVG drawer, drawing basic geometries
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer)
    @param {Type_SVGDrawerConstructor_Args} args   Parameter object
      ````js
      { doc, scale?, transform?, createToolTipCb?, addAttr? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_SVGDrawerConstructor_Args);
    /**
      @typedef {Object} Type_SVGDrawerArc_Args
      @property {number} x   Center
      @property {number} y   Center
      @property {number} radius   Radius
      @property {number} start   Start
      @property {number} end   End
      @property {string} [effect]   An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
      @property {number} [percWidth]   Inner radius
      @property {string} [rgb="black"]  default="black"  Fill color
      @property {string} [stroke="black"]  default="black"  Border color
      @property {boolean} [isFilled]   Fill area
      @property {function} [onClick]   On click callback
      @property {Object} [addAttr]   A set of additional string attributes to be attached to the root element</li>
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer?id=arc)
    @description   Draw a SVG arc
    @param {Type_SVGDrawerArc_Args} args   Parameter object
      ````js
      { x, y, radius, start, end, effect?, percWidth?, rgb?, stroke?, isFilled?, onClick?, addAttr? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  mySVGD.arc({ x, y, radius, start, end });
  
  @return {void}
    */
    public arc(args: {
        /**
         * Center
         */
        x: number;
        /**
         * Center
         */
        y: number;
        /**
         * Radius
         */
        radius: number;
        /**
         * Start
         */
        start: number;
        /**
         * End
         */
        end: number;
        /**
         * An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
         */
        effect?: string;
        /**
         * Inner radius
         */
        percWidth?: number;
        /**
         * default="black"  Fill color
         */
        rgb?: string;
        /**
         * default="black"  Border color
         */
        stroke?: string;
        /**
         * Fill area
         */
        isFilled?: boolean;
        /**
         * On click callback
         */
        onClick?: Function;
        /**
         * A set of additional string attributes to be attached to the root element</li>
         */
        addAttr?: Object;
    }): void;
    /**
      @typedef {Object} Type_SVGDrawerBox_Args
      @property {number} x   Left
      @property {number} y   Top
      @property {number} width   Width
      @property {number} height   Height
      @property {string} [effect]   An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
      @property {string} [rgb="black"]  default="black"  Color
      @property {boolean} [isFilled]   Fill area
      @property {function} [onClick]   On click callback
      @property {Object} [addAttr]   A set of additional string attributes to be attached to the root element</li>
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer?id=box)
    @description   Draw a SVG box
    @param {Type_SVGDrawerBox_Args} args   Parameter object
      ````js
      { x, y, width, height, effect?, rgb?, isFilled?, onClick?, addAttr? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  mySVGD.box({ x, y, width, height });
  
  @return {void}
    */
    public box(args: {
        /**
         * Left
         */
        x: number;
        /**
         * Top
         */
        y: number;
        /**
         * Width
         */
        width: number;
        /**
         * Height
         */
        height: number;
        /**
         * An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
         */
        effect?: string;
        /**
         * default="black"  Color
         */
        rgb?: string;
        /**
         * Fill area
         */
        isFilled?: boolean;
        /**
         * On click callback
         */
        onClick?: Function;
        /**
         * A set of additional string attributes to be attached to the root element</li>
         */
        addAttr?: Object;
    }): void;
    /**
      @typedef {Object} Type_SVGDrawerCircle_Args
      @property {number} x   Center
      @property {number} y   Center
      @property {number} radius   Radius
      @property {string} [effect]   An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
      @property {string} [rgb="black"]  default="black"  Color
      @property {boolean} [isFilled]   Fill area
      @property {function} [onClick]   On click callback
      @property {Object} [addAttr]   A set of additional string attributes to be attached to the root element</li>
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer?id=circle)
    @description   Draw a SVG circle
    @param {Type_SVGDrawerCircle_Args} args   Parameter object
      ````js
      { x, y, radius, effect?, rgb?, isFilled?, onClick?, addAttr? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  mySVGD.circle({ x, y, radius });
  
  @return {void}
    */
    public circle(args: {
        /**
         * Center
         */
        x: number;
        /**
         * Center
         */
        y: number;
        /**
         * Radius
         */
        radius: number;
        /**
         * An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
         */
        effect?: string;
        /**
         * default="black"  Color
         */
        rgb?: string;
        /**
         * Fill area
         */
        isFilled?: boolean;
        /**
         * On click callback
         */
        onClick?: Function;
        /**
         * A set of additional string attributes to be attached to the root element</li>
         */
        addAttr?: Object;
    }): void;
    /**
      @typedef {Object} Type_SVGDrawerImage_Args
      @property {number} x   Left
      @property {number} y   Top
      @property {number} width   Width
      @property {number} height   Height
      @property {string} [href]   The image
      @property {function} [onClick]   On click callback
      @property {Object} [addAttr]   A set of additional string attributes to be attached to the root element</li>
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer?id=image)
    @description   Draw an SVG image element
    @param {Type_SVGDrawerImage_Args} args   Parameter object
      ````js
      { x, y, width, height, href?, onClick?, addAttr? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  mySVGD.image({ x, y, width, height });
  
  @return {void}
    */
    public image(args: {
        /**
         * Left
         */
        x: number;
        /**
         * Top
         */
        y: number;
        /**
         * Width
         */
        width: number;
        /**
         * Height
         */
        height: number;
        /**
         * The image
         */
        href?: string;
        /**
         * On click callback
         */
        onClick?: Function;
        /**
         * A set of additional string attributes to be attached to the root element</li>
         */
        addAttr?: Object;
    }): void;
    /**
      @typedef {Object} Type_SVGDrawerLine_Args
      @property {Array.<Array.<number>>} points   2 dimensional array with x,y points, args.points[0][0] being the first one</li>
      @property {string} [effect]   An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
      @property {string} [rgb="black"]  default="black"  Line color
      @property {number} [width=1]  default=1  Line width
      @property {boolean} [isFilled]   Fill area
      @property {function} [onClick]   On click callback
      @property {Object} [addAttr]   A set of additional string attributes to be attached to the root element</li>
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer?id=line)
    @description   Draw a SVG line
    @param {Type_SVGDrawerLine_Args} args   Parameter object
      ````js
      { points, effect?, rgb?, width?, isFilled?, onClick?, addAttr? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  mySVGD.line({ points });
  
  @return {void}
    */
    public line(args: {
        /**
         * 2 dimensional array with x,y points, args.points[0][0] being the first one</li>
         */
        points: Array<Array<number>>;
        /**
         * An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
         */
        effect?: string;
        /**
         * default="black"  Line color
         */
        rgb?: string;
        /**
         * default=1  Line width
         */
        width?: number;
        /**
         * Fill area
         */
        isFilled?: boolean;
        /**
         * On click callback
         */
        onClick?: Function;
        /**
         * A set of additional string attributes to be attached to the root element</li>
         */
        addAttr?: Object;
    }): void;
    /**
      @typedef {Object} Type_SVGDrawerText_Args
      @property {number} x   Position
      @property {number} y   Position
      @property {string} text   The text
      @property {string} [cssClass]   A css class to be used
      @property {string} [align]   Possible values middle, end
      @property {string} [layoutFlow]   A css value lie vertical-ideographic
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.SVGDrawer?id=text)
    @description   Draw a SVG text
    @param {Type_SVGDrawerText_Args} args   Parameter object
      ````js
      { x, y, text, cssClass?, align?, layoutFlow? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  mySVGD.text({ x, y, text });
  
  @return {void}
    */
    public text(args: {
        /**
         * Position
         */
        x: number;
        /**
         * Position
         */
        y: number;
        /**
         * The text
         */
        text: string;
        /**
         * A css class to be used
         */
        cssClass?: string;
        /**
         * Possible values middle, end
         */
        align?: string;
        /**
         * A css value lie vertical-ideographic
         */
        layoutFlow?: string;
    }): void;
}
export type Type_SVGDrawerConstructor_Args = {
    /**
     * Document for creating the SVG drawing
     */
    doc: DomDocument;
    /**
     * default={x:1,y:1}  Default is no scaling { x: 1, y: 1}
     */
    scale?: Object;
    /**
     * Default is no shifting { x: 0, y: 0 }
     */
    transform?: Object;
    /**
     * Call back getting the source element, returning the tool tip HTML</li>
     */
    createToolTipCb?: Function;
    /**
     * A set of additional string attributes to be attached to the root element</li>
     */
    addAttr?: Object;
};
import * as bcdui from "../../exports.js";
