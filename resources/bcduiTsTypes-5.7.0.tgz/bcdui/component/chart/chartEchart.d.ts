/**
  @typedef {Object} Type_ChartEchartConstructor_Args
  @property {targetHtmlRef} targetHtml   Where to place the chart
  @property {bcdui.core.DataProvider} config   Definition if the chart according to Model with the chart definition according to XSD http://www.businesscode.de/schema/bcdui/charts-1.0.0
  @property {Object} options   Options of ECharts, extending / being merged with the options deried from config
  */
/**
  @class bcdui.component.chart.ChartEchart
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart)
  @description Create a chart based on http://www.businesscode.de/schema/bcdui/charts-1.0.0 XML
  
  @example
  // Usage
var myCE = new bcdui.component.chart.ChartEchart({ targetHtml: "#myDiv", config, options });

@extends bcdui.core.Renderer
*/
export class ChartEchart extends bcdui.core.Renderer {
    /**
    @description Create a chart based on http://www.businesscode.de/schema/bcdui/charts-1.0.0 XML
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart)
    
    @example
    // Usage
  var myCE = new bcdui.component.chart.ChartEchart({ targetHtml: "#myDiv", config, options });
  
  @param {Type_ChartEchartConstructor_Args} args   Parameter object:
      ````js
      { targetHtml, config, options }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ChartEchartConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=getdata)
    @description   A getter for the document produced by the transformation chain.
    @overrides bcdui.core.Renderer#getData
    @public
    @return {document} DOM document
    */
    public getData(): Document;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.ChartEchart?id=.saveasimage)
    @description   Export an EChart as PNG
    @param {targetHtmlRef} targetHtml   Html element where the chart is found
    @param {string} name   File name: name+".png"
    @public
    
    @example
    // Usage
  bcdui.component.chart.ChartEchart.saveAsImage( targetHtml, name );
  
  @return {void}
    */
    public saveAsImage(targetHtml: targetHtmlRef, name: string): void;
}
export type Type_ChartEchartConstructor_Args = {
    /**
     * Where to place the chart
     */
    targetHtml: targetHtmlRef;
    /**
     * Definition if the chart according to Model with the chart definition according to XSD http://www.businesscode.de/schema/bcdui/charts-1.0.0
     */
    config: bcdui.core.DataProvider;
    /**
     * Options of ECharts, extending / being merged with the options deried from config
     */
    options: Object;
};
import * as bcdui from "../../exports.js";
