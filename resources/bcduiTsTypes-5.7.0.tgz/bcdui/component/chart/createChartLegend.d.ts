/**
  @typedef {Object} Type_ChartCreateChartLegend_Args
  @property {bcdui.core.DataProvider} inputModel   Input model to renderer
  @property {string} targetHtmlElementId   Target HTML element ID
  @property {string} [id]   Renderer ID
  @property {string} [chartRendererId]   ID of chart renderer
  @property {string} [elementStyle]   Style for legend HTML element
  */
/**
@param {Type_ChartCreateChartLegend_Args} args   Paramater object
  ````js
  { inputModel, targetHtmlElementId, id?, chartRendererId?, elementStyle? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.chart.createChartLegend)
@description   Create a legend for the chart, listing all series
@method createChartLegend

@example
// Usage
var ret = bcdui.component.chart.createChartLegend({ inputModel: myModel, targetHtmlElementId });

@return {bcdui.core.Renderer}  renderer that creates legend renderer
@memberOf bcdui.component.chart
*/
export function createChartLegend(args: Type_ChartCreateChartLegend_Args): bcdui.core.Renderer;
export type Type_ChartCreateChartLegend_Args = {
    /**
     * Input model to renderer
     */
    inputModel: bcdui.core.DataProvider;
    /**
     * Target HTML element ID
     */
    targetHtmlElementId: string;
    /**
     * Renderer ID
     */
    id?: string;
    /**
     * ID of chart renderer
     */
    chartRendererId?: string;
    /**
     * Style for legend HTML element
     */
    elementStyle?: string;
};
import * as bcdui from "../../exports.js";
