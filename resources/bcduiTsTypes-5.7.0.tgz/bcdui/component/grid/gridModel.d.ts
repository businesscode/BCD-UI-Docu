/**
  @typedef {Object} Type_GridModelConstructor_Args
  @property {bcdui.core.DataProvider} [config="./gridConfiguration.xml"]  default="./gridConfiguration.xml"  The model containing the grid configuration data. If it is not present a SimpleModel with the url  './gridConfiguration.xml' is created.
  @property {string} [id]   The object's id, needed only when later accessing via id. If given the GridModel registers itself at {@link bcdui.factory.objectRegistry}
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  StatusModel, containing the filters as /SomeRoot/f:Filter
  @property {chainDef} [saveChain]   The definition of the transformation chain
  @property {Object} [saveParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  @property {chainDef} [validationChain]   The definition of the transformation chain
  @property {Object} [validationParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  @property {chainDef} [loadChain]   The definition of the transformation chain
  @property {Object} [loadParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  @property {Object} [serverSidedPagination]   Set to true if you want to enable server sided pagination
  @property {bcdui.core.DataProvider} [pagerModel=bcdui.wkModels.guiStatus]  default=bcdui.wkModels.guiStatus  StatusModel of the pagination information
  @property {chainDef} [requestPostChain]   The definition of the transformation chain
  @property {(string|bcdui.core.DataProvider)} [modelUrl='WrsServlet']  default='WrsServlet'  This is a string or string- DataProvider with the URL which to send the requestModel result to
  */
/**
  @class bcdui.component.grid.GridModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.GridModel)
  @description Creates a GridModel for use by Grid if you need more fine-grained control.
To use Grid or GridModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiGrid`
  
  @example
  <grid:GridConfiguration
    xmlns:grid="http://www.businesscode.de/schema/bcdui/grid-1.0.0"
    xmlns:wrq="http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0">

  <wrq:BindingSet>mdStation</wrq:BindingSet>

  <grid:SelectColumns>
    <grid:C bRef="lastUpdate" isReadOnly="true"/>
    <grid:C bRef="country" isKey="true"/>
    <grid:C bRef="station" isKey="true"/>
    <grid:C bRef="isGateway" isCheckbox="1|0" class='bcdCheckbox'/>
  </grid:SelectColumns>

  <grid:OrderColumns>
    <grid:C bRef="lastUpdate" order="desc"/>
  </grid:OrderColumns>

</grid:GridConfiguration>
  @extends bcdui.core.SimpleModel
*/
export class GridModel extends bcdui.core.SimpleModel {
    /**
    @description Creates a GridModel for use by Grid if you need more fine-grained control.
  To use Grid or GridModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiGrid`
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.GridModel)
    
    @example
    <grid:GridConfiguration
      xmlns:grid="http://www.businesscode.de/schema/bcdui/grid-1.0.0"
      xmlns:wrq="http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0">
  
    <wrq:BindingSet>mdStation</wrq:BindingSet>
  
    <grid:SelectColumns>
      <grid:C bRef="lastUpdate" isReadOnly="true"/>
      <grid:C bRef="country" isKey="true"/>
      <grid:C bRef="station" isKey="true"/>
      <grid:C bRef="isGateway" isCheckbox="1|0" class='bcdCheckbox'/>
    </grid:SelectColumns>
  
    <grid:OrderColumns>
      <grid:C bRef="lastUpdate" order="desc"/>
    </grid:OrderColumns>
  
  </grid:GridConfiguration>
    @param {Type_GridModelConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { config?, id?, statusModel?, saveChain?, saveParameters?, validationChain?, validationParameters?, loadChain?, loadParameters?, serverSidedPagination?, pagerModel?, requestPostChain?, modelUrl? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_GridModelConstructor_Args);
}
export type Type_GridModelConstructor_Args = {
    /**
     * default="./gridConfiguration.xml"  The model containing the grid configuration data. If it is not present a SimpleModel with the url  './gridConfiguration.xml' is created.
     */
    config?: bcdui.core.DataProvider;
    /**
     * The object's id, needed only when later accessing via id. If given the GridModel registers itself at {@link bcdui.factory.objectRegistry}
     */
    id?: string;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  StatusModel, containing the filters as /SomeRoot/f:Filter
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * The definition of the transformation chain
     */
    saveChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    saveParameters?: Object;
    /**
     * The definition of the transformation chain
     */
    validationChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    validationParameters?: Object;
    /**
     * The definition of the transformation chain
     */
    loadChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    loadParameters?: Object;
    /**
     * Set to true if you want to enable server sided pagination
     */
    serverSidedPagination?: Object;
    /**
     * default=bcdui.wkModels.guiStatus  StatusModel of the pagination information
     */
    pagerModel?: bcdui.core.DataProvider;
    /**
     * The definition of the transformation chain
     */
    requestPostChain?: chainDef;
    /**
     * default='WrsServlet'  This is a string or string- DataProvider with the URL which to send the requestModel result to
     */
    modelUrl?: (string | bcdui.core.DataProvider);
};
import * as bcdui from "../../exports.js";
