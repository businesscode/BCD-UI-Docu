/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.gridButtonAction)
  @description
  @method gridButtonAction
@return {void}
  @memberOf bcdui.component.grid
 */
export function gridButtonAction(): void;
