/**
  @typedef {Object} Type_GridConstructor_Args
  @property {targetHtmlRef} targetHtml   A reference to the HTML DOM Element where to put the output
  @property {bcdui.core.DataProvider} [config="./gridConfiguration.xml"]  default="./gridConfiguration.xml"  The model containing the grid configuration data, default is './gridConfiguration.xml', which must be present then.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  StatusModel (default is 'guiStatusEstablished'), containing the filters as /SomeRoot/f:Filter
  @property {bcdui.core.DataProvider} [inputModel]   WRS or GridModel which is used. If not provided, it is generated based on the config. If provided, config is ignored unless it is set explicitly
  @property {string} [id]   The object's id, needed only when later accessing via id. If given the Grid registers itself at {@link bcdui.factory.objectRegistry}
  @property {Object} [hotArgs]   Arguments which are extended to handsontable creation
  @property {(string|chainDef)} [tooltipChain]   To overwrite default tooltip chain. An empty string will disable tooltips, otherwise the default gridTooltip.xslt is used
  @property {(boolean|string)} [contextMenu]   If true, grid's default context menu is used, otherwise provide the url to your context menu xslt here.
  @property {(function|string)} [contextMenuResolver]   Function which gets a parameter bag with well known attributes and the dataset of the selected context menu entry. Should return false if action is not provided so that default functions are called.
  @property {function} [customSave]   Custom save function
  @property {function} [afterAddRow]   Custom function(args) which is called after a row was added (args.rowNode, wrs row node which was added, args.headerMeta wrs header object)
  @property {chainDef} [saveChain]   A chain definition which is used for the grid saving operation
  @property {Object} [saveParameters]   Parameters for the saving chain
  @property {chainDef} [loadChain]   A chain definition which is used for the grid loading operation
  @property {Object} [loadParameters]   Parameters for the loading chain
  @property {chainDef} [validationChain]   A chain definition which is used for the validation operation. basic wrs and reference validation is given by default
  @property {Object} [validationParameters]   Parameters for the validation chain
  @property {boolean} [allowNewRows=true]  default=true  Allows inserting new rows via default contextMenu or drag/paste
  @property {boolean} [columnFilters]   Enable basic column filter input fields
  @property {integer} [maxHeight]   Set a maximum vertical size in pixel (only used when no handsontable height is set)
  @property {boolean} [isReadOnly]   Turn on viewer-only mode
  @property {boolean} [topMode]   Add/save/restore buttons appear at the top, pagination at bottom, insert row at top
  @property {boolean} [forceAddAtBottom]   Always add a new row at the bottom, no matter if topMode or pagination
  @property {boolean} [disableDeepKeyCheck]   Set this to true if you really want to disable the deep key check which is active if your grid is only a subset of the underlying table
  @property {boolean} [ignoreKeyCase]   Set this to true if the key test should not be case sensitive
  @property {function} [isReadOnlyCell]   Custom check function if a given cell is read only or not. Function gets gridModel, wrsHeaderMeta, rowId, colId and value as input and returns true if the cell becomes readonly
  @property {function} [columnFiltersGetCaptionForColumnValue]   Function which is used to determine the caption values for column filters. You need to customize this when you're e.g. using XML data in cells.
  @property {Object} [columnFiltersCustomFilter]   CustomColumnFilter functions passed to column filter
  @property {boolean} [defaultButtons=true]  default=true  Set to false if you want to hide the default buttons reset/delete/save
  @property {boolean} [serverSidedPagination]   Set to true if you want to enable server sided pagination
  @property {integer} [paginationSize=20]  default=20  Set pagination page size (and enable pagination)
  @property {boolean} [paginationAllPages]   Set pagination show all option (and enable pagination)
  @property {chainDef} [requestPostChain]   The definition of the transformation chain
  @property {(string|bcdui.core.DataProvider)} [modelUrl='WrsServlet']  default='WrsServlet'  This is a string or string- DataProvider with the URL which to send the requestModel result to
  @property {string} [exportFileName]   Filename for grid export
  @property {boolean} [disableExport]   Disable export functionality.
  */
/**
  @class bcdui.component.grid.Grid
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid)
  @description Creates a Grid-UI for editing tabular data, complete with range copy-paste and validation.
It creates its GridModel in the background, if none is provided
To use Grid or GridModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiGrid`
  
  @example
  // Usage
var myGrd = new bcdui.component.grid.Grid({ targetHtml: "#myDiv" });


  @example
  <grid:GridConfiguration
    xmlns:grid="http://www.businesscode.de/schema/bcdui/grid-1.0.0"
    xmlns:wrq="http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0">

  <wrq:BindingSet>mdStation</wrq:BindingSet>

  <grid:SelectColumns>
    <grid:C bRef="lastUpdate" isReadOnly="true"/>
    <grid:C bRef="country" isKey="true"/>
    <grid:C bRef="station" isKey="true"/>
    <grid:C bRef="isGateway" isCheckbox="1|0" class='bcdCheckbox'/>
  </grid:SelectColumns>

  <grid:OrderColumns>
    <grid:C bRef="lastUpdate" order="desc"/>
  </grid:OrderColumns>

</grid:GridConfiguration>
  @extends bcdui.core.Renderer
*/
export class Grid extends bcdui.core.Renderer {
    /**
    @description Creates a Grid-UI for editing tabular data, complete with range copy-paste and validation.
  It creates its GridModel in the background, if none is provided
  To use Grid or GridModel, make sure to load `bcdui.js?bcduiLoadFiles=bcduiGrid`
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid)
    
    @example
    // Usage
  var myGrd = new bcdui.component.grid.Grid({ targetHtml: "#myDiv" });
  
  
    @example
    <grid:GridConfiguration
      xmlns:grid="http://www.businesscode.de/schema/bcdui/grid-1.0.0"
      xmlns:wrq="http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0">
  
    <wrq:BindingSet>mdStation</wrq:BindingSet>
  
    <grid:SelectColumns>
      <grid:C bRef="lastUpdate" isReadOnly="true"/>
      <grid:C bRef="country" isKey="true"/>
      <grid:C bRef="station" isKey="true"/>
      <grid:C bRef="isGateway" isCheckbox="1|0" class='bcdCheckbox'/>
    </grid:SelectColumns>
  
    <grid:OrderColumns>
      <grid:C bRef="lastUpdate" order="desc"/>
    </grid:OrderColumns>
  
  </grid:GridConfiguration>
    @param {Type_GridConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { targetHtml, config?, statusModel?, inputModel?, id?, hotArgs?, tooltipChain?, contextMenu?, contextMenuResolver?, customSave?, afterAddRow?, saveChain?, saveParameters?, loadChain?, loadParameters?, validationChain?, validationParameters?, allowNewRows?, columnFilters?, maxHeight?, isReadOnly?, topMode?, forceAddAtBottom?, disableDeepKeyCheck?, ignoreKeyCase?, isReadOnlyCell?, columnFiltersGetCaptionForColumnValue?, columnFiltersCustomFilter?, defaultButtons?, serverSidedPagination?, paginationSize?, paginationAllPages?, requestPostChain?, modelUrl?, exportFileName?, disableExport? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_GridConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid?id=actionreset)
    @description   Drop all changes and load fresh data
    @public
    @return {void}
    */
    public actionReset(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid?id=getconfigmodel)
    @public
    @return {bcdui.core.DataProvider} configuration model of the grid
    */
    public getConfigModel(): bcdui.core.DataProvider;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid?id=getenhancedconfiguration)
    @public
    @return {bcdui.core.DataProvider} Enhanced configuration model of the grid
    */
    public getEnhancedConfiguration(): bcdui.core.DataProvider;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid?id=jumptoerror)
    @description   Jumps to the first error
    @public
    @return {void}
    */
    public jumpToError(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid?id=jumptorow)
    @description   Jumps to given row/col
    @public
    @return {void}
    */
    public jumpToRow(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.Grid?id=save)
    @description   Save the modified data to the database
    @public
    @return {void}
    */
    public save(): void;
}
export type Type_GridConstructor_Args = {
    /**
     * A reference to the HTML DOM Element where to put the output
     */
    targetHtml: targetHtmlRef;
    /**
     * default="./gridConfiguration.xml"  The model containing the grid configuration data, default is './gridConfiguration.xml', which must be present then.
     */
    config?: bcdui.core.DataProvider;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  StatusModel (default is 'guiStatusEstablished'), containing the filters as /SomeRoot/f:Filter
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * WRS or GridModel which is used. If not provided, it is generated based on the config. If provided, config is ignored unless it is set explicitly
     */
    inputModel?: bcdui.core.DataProvider;
    /**
     * The object's id, needed only when later accessing via id. If given the Grid registers itself at {@link bcdui.factory.objectRegistry}
     */
    id?: string;
    /**
     * Arguments which are extended to handsontable creation
     */
    hotArgs?: Object;
    /**
     * To overwrite default tooltip chain. An empty string will disable tooltips, otherwise the default gridTooltip.xslt is used
     */
    tooltipChain?: (string | chainDef);
    /**
     * If true, grid's default context menu is used, otherwise provide the url to your context menu xslt here.
     */
    contextMenu?: (boolean | string);
    /**
     * Function which gets a parameter bag with well known attributes and the dataset of the selected context menu entry. Should return false if action is not provided so that default functions are called.
     */
    contextMenuResolver?: (Function | string);
    /**
     * Custom save function
     */
    customSave?: Function;
    /**
     * Custom function(args) which is called after a row was added (args.rowNode, wrs row node which was added, args.headerMeta wrs header object)
     */
    afterAddRow?: Function;
    /**
     * A chain definition which is used for the grid saving operation
     */
    saveChain?: chainDef;
    /**
     * Parameters for the saving chain
     */
    saveParameters?: Object;
    /**
     * A chain definition which is used for the grid loading operation
     */
    loadChain?: chainDef;
    /**
     * Parameters for the loading chain
     */
    loadParameters?: Object;
    /**
     * A chain definition which is used for the validation operation. basic wrs and reference validation is given by default
     */
    validationChain?: chainDef;
    /**
     * Parameters for the validation chain
     */
    validationParameters?: Object;
    /**
     * default=true  Allows inserting new rows via default contextMenu or drag/paste
     */
    allowNewRows?: boolean;
    /**
     * Enable basic column filter input fields
     */
    columnFilters?: boolean;
    /**
     * Set a maximum vertical size in pixel (only used when no handsontable height is set)
     */
    maxHeight?: integer;
    /**
     * Turn on viewer-only mode
     */
    isReadOnly?: boolean;
    /**
     * Add/save/restore buttons appear at the top, pagination at bottom, insert row at top
     */
    topMode?: boolean;
    /**
     * Always add a new row at the bottom, no matter if topMode or pagination
     */
    forceAddAtBottom?: boolean;
    /**
     * Set this to true if you really want to disable the deep key check which is active if your grid is only a subset of the underlying table
     */
    disableDeepKeyCheck?: boolean;
    /**
     * Set this to true if the key test should not be case sensitive
     */
    ignoreKeyCase?: boolean;
    /**
     * Custom check function if a given cell is read only or not. Function gets gridModel, wrsHeaderMeta, rowId, colId and value as input and returns true if the cell becomes readonly
     */
    isReadOnlyCell?: Function;
    /**
     * Function which is used to determine the caption values for column filters. You need to customize this when you're e.g. using XML data in cells.
     */
    columnFiltersGetCaptionForColumnValue?: Function;
    /**
     * CustomColumnFilter functions passed to column filter
     */
    columnFiltersCustomFilter?: Object;
    /**
     * default=true  Set to false if you want to hide the default buttons reset/delete/save
     */
    defaultButtons?: boolean;
    /**
     * Set to true if you want to enable server sided pagination
     */
    serverSidedPagination?: boolean;
    /**
     * default=20  Set pagination page size (and enable pagination)
     */
    paginationSize?: integer;
    /**
     * Set pagination show all option (and enable pagination)
     */
    paginationAllPages?: boolean;
    /**
     * The definition of the transformation chain
     */
    requestPostChain?: chainDef;
    /**
     * default='WrsServlet'  This is a string or string- DataProvider with the URL which to send the requestModel result to
     */
    modelUrl?: (string | bcdui.core.DataProvider);
    /**
     * Filename for grid export
     */
    exportFileName?: string;
    /**
     * Disable export functionality.
     */
    disableExport?: boolean;
};
import * as bcdui from "../../exports.js";
