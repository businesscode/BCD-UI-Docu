/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.grid.resolveContextMenu)
  @description
  @method resolveContextMenu
@return {void}
  @memberOf bcdui.component.grid
 */
export function resolveContextMenu(): void;
