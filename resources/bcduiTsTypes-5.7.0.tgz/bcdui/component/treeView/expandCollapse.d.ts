/**
@param {string} rendererId   Id of the treeView's renderer
  @param {string} levelId   Which level to change
  @param {boolean} isExpand   True for expand, false for collapse
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.treeView.expandCollapse)
  @description   Expand or collapse a level for a treeView renderer
  @method expandCollapse

  @example
  // Usage
bcdui.component.treeView.expandCollapse( rendererId, levelId, isExpand );

@return {void}
  @memberOf bcdui.component.treeView
 */
export function expandCollapse(rendererId: string, levelId: string, isExpand: boolean): void;
