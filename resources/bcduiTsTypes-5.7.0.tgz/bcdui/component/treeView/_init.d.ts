/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.treeView._init)
  @description
  @method _init
@return {void}
  @memberOf bcdui.component.treeView
 */
export function _init(): void;
