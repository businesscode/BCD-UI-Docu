/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.treeView._toggleAction)
  @description
  @method _toggleAction
@return {void}
  @memberOf bcdui.component.treeView
 */
export function _toggleAction(): void;
