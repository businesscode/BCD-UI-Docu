/**
  @typedef {Object} Type_TreeViewExpandCollapseAll_Args
  @property {string} rendererId   Id of the treeView's renderer
  @property {boolean} isExpand   True for expand, false for collapse
  */
/**
@param {Type_TreeViewExpandCollapseAll_Args} args   The argument map containing the following elements:
  ````js
  { rendererId, isExpand }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.treeView.expandCollapseAll)
@description   This function expands or collapses all levels of a treeView.
It relies on the &commat;dimId and wrs:Data of the primary model of the renderer to calculate all levels
and sets the guiStatus accordingly.
@method expandCollapseAll

@example
// Usage
bcdui.component.treeView.expandCollapseAll({ rendererId, isExpand });

@return {void}
@memberOf bcdui.component.treeView
*/
export function expandCollapseAll(args: Type_TreeViewExpandCollapseAll_Args): void;
export type Type_TreeViewExpandCollapseAll_Args = {
    /**
     * Id of the treeView's renderer
     */
    rendererId: string;
    /**
     * True for expand, false for collapse
     */
    isExpand: boolean;
};
