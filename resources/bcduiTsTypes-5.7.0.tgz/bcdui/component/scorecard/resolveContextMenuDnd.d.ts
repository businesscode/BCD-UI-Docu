/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecard.resolveContextMenuDnd)
  @description
  @method resolveContextMenuDnd
@return {void}
  @memberOf bcdui.component.scorecard
 */
export function resolveContextMenuDnd(): void;
