/**
  @typedef {Object} Type_ScorecardConstructor_Args
  @property {targetHtmlRef} targetHtml   The socrecard renderer's target html element.
  @property {bcdui.core.DataProvider} [inputModel]   The data of the scorecard model {@link bcdui.component.scorecard.ScorecardModel}. Provide args.config or args.inputModel
  @property {bcdui.core.DataProvider} [config]   The data of the scorecard configuration model according to XSD http://www.businesscode.de/schema/bcdui/scorecard-1.0.0
   If given, an internal ScorecardModel based on the configuration data will be created. args.config it will be provided as 'scConfig' to the renderer chain. Provide args.config or args.inputModel
  @property {string} [id]   The id of the new object. If omitted the id is automatically generated.
  @property {chainDef} chain   An alternative rendering chain, See {@link bcdui.core.Renderer}. Default here is HtmlBuilder.
  @property {string} [tooltipUrl]   To overwrite default renderer xslt of the tooltip. An empty string will disable tooltips.
   Default is BCD-UI's default sc tooltip, which shows all attributes of a cell. To give a KPI an attribute, nest an scc:AspectRef into scc:AspectKpi in the scorecard definition.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  StatusModel, containing the filters at /SomeRoot/f:Filter, default is 'guiStatusEstablished'
  @property {bcdui.core.DataProvider} [customParameter]   Custom parameters for usage in custom aggregators, aspects and renderer as 'customParameter' parameter.</li>
  @property {Object} [parameters]   An object, where each property holds a DataProvider being a renderer parameter used in custom chains
  @property {(boolean|string)} [contextMenu]   If true, scorecard's default context menu is used, otherwise provide the url to your context menu xslt here.
  @property {(function|string)} [contextMenuResolver]   Function which gets a parameter bag with well known attributes and the dataset of the selected context menu entry. Should return false if action is not provided so that default functions are called.
  */
/**
  @class bcdui.component.scorecard.Scorecard
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecard.Scorecard)
  @description Creates a convenience standard scorecard renderer.
You can create this with a configuration args.config or a {@link bcdui.component.scorecard.ScorecardModel} as args.input.
This renderer provides a default tooltip and supports default actions for detail-export, WSYIWYG export and detail-drill-over for a context menu
Call these by triggering scorecardActions:[detailExport|reportExcelExport|drillToAnalysis] at the cell,
you may provide them with a custom 'chain' and 'chainParameters', see bcdRowIdent in default context menu as samples.
  
  @example
  // Usage
var myScr = new bcdui.component.scorecard.Scorecard({ targetHtml: "#myDiv", chain: ["myRenderer.xslt", finalCleanupFunc] });

@extends bcdui.core.Renderer
*/
export class Scorecard extends bcdui.core.Renderer {
    /**
    @description Creates a convenience standard scorecard renderer.
  You can create this with a configuration args.config or a {@link bcdui.component.scorecard.ScorecardModel} as args.input.
  This renderer provides a default tooltip and supports default actions for detail-export, WSYIWYG export and detail-drill-over for a context menu
  Call these by triggering scorecardActions:[detailExport|reportExcelExport|drillToAnalysis] at the cell,
  you may provide them with a custom 'chain' and 'chainParameters', see bcdRowIdent in default context menu as samples.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecard.Scorecard)
    
    @example
    // Usage
  var myScr = new bcdui.component.scorecard.Scorecard({ targetHtml: "#myDiv", chain: ["myRenderer.xslt", finalCleanupFunc] });
  
  @param {Type_ScorecardConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { targetHtml, inputModel?, config?, id?, chain, tooltipUrl?, statusModel?, customParameter?, parameters?, contextMenu?, contextMenuResolver? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ScorecardConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecard.Scorecard?id=getconfigmodel)
    @public
    @return {bcdui.core.DataProvider} configuration model of the scorecard
    */
    public getConfigModel(): bcdui.core.DataProvider;
}
export type Type_ScorecardConstructor_Args = {
    /**
     * The socrecard renderer's target html element.
     */
    targetHtml: targetHtmlRef;
    /**
     * The data of the scorecard model {@link bcdui.component.scorecard.ScorecardModel}. Provide args.config or args.inputModel
     */
    inputModel?: bcdui.core.DataProvider;
    /**
     * The data of the scorecard configuration model according to XSD http://www.businesscode.de/schema/bcdui/scorecard-1.0.0
    If given, an internal ScorecardModel based on the configuration data will be created. args.config it will be provided as 'scConfig' to the renderer chain. Provide args.config or args.inputModel
     */
    config?: bcdui.core.DataProvider;
    /**
     * The id of the new object. If omitted the id is automatically generated.
     */
    id?: string;
    /**
     * An alternative rendering chain, See {@link bcdui.core.Renderer}. Default here is HtmlBuilder.
     */
    chain: chainDef;
    /**
     * To overwrite default renderer xslt of the tooltip. An empty string will disable tooltips.
    Default is BCD-UI's default sc tooltip, which shows all attributes of a cell. To give a KPI an attribute, nest an scc:AspectRef into scc:AspectKpi in the scorecard definition.
     */
    tooltipUrl?: string;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  StatusModel, containing the filters at /SomeRoot/f:Filter, default is 'guiStatusEstablished'
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * Custom parameters for usage in custom aggregators, aspects and renderer as 'customParameter' parameter.</li>
     */
    customParameter?: bcdui.core.DataProvider;
    /**
     * An object, where each property holds a DataProvider being a renderer parameter used in custom chains
     */
    parameters?: Object;
    /**
     * If true, scorecard's default context menu is used, otherwise provide the url to your context menu xslt here.
     */
    contextMenu?: (boolean | string);
    /**
     * Function which gets a parameter bag with well known attributes and the dataset of the selected context menu entry. Should return false if action is not provided so that default functions are called.
     */
    contextMenuResolver?: (Function | string);
};
import * as bcdui from "../../exports.js";
