/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.scorecard.resolveContextMenu)
  @description
  @method resolveContextMenu
@return {void}
  @memberOf bcdui.component.scorecard
 */
export function resolveContextMenu(): void;
