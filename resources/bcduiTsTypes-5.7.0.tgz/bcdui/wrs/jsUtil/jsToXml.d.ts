/**
@param {Object} arg   The JavaScript object following Wrs conventions, from which the XML document is to be created
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.jsUtil.jsToXml)
  @description   Converts a js object created with domToJs to an XML document
  @method jsToXml
@return {void}
  @memberOf bcdui.wrs.jsUtil
 */
export function jsToXml(arg: Object): void;
