/**
@param {(string|bcdui.core.DataProvider)} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {string} rowId   Id of row to be deleted
  @param {boolean} [propagateUpdate]   If true, fire after change
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.restoreRow)
  @description   Restores a wrs:D, wrs:M identified by id, also see {@link bcdui.wrs.wrsUtil.restore restore()}
  @method restoreRow

  @example
  // Usage
var ret = bcdui.wrs.wrsUtil.restoreRow( model, rowId );

@return {boolean}  true if given row has been restored or false if row is not wrs:M nor wrs:D
@memberOf bcdui.wrs.wrsUtil
 */
export function restoreRow(model: (string | bcdui.core.DataProvider), rowId: string, propagateUpdate?: boolean): boolean;
import * as bcdui from "../../exports.js";
