/**
@param {DomElement} wrs   WRSRootNode: Pointing to wrs:Wrs
  @param {Array.<string>} colIdArray   Array of column-ids to remove
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.deleteColumns)
  @description   Phsyically drops columns from Wrs
  @method deleteColumns

  @example
  // Usage
bcdui.wrs.wrsUtil.deleteColumns( wrs, colIdArray );

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function deleteColumns(wrs: DomElement, colIdArray: Array<string>): void;
