/**
  @typedef {Object} Type_WrsUtilValidateModel_Args
  @property {(string|bcdui.core.DataProvider)} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {string} [stylesheetUrl="defauldValidation-stypesheet"]  default="defauldValidation-stypesheet"  URL to validation stylesheet, defaults to 'xslt/validate/validateWrs.xslt'
  @property {Array.<bcdui.core.DataProvider>} dataProviders   additional data providers as parameters
  @property {function} [fn]   callback function called after validation done, gets object as parameter, containig properties: validationResult: the wrs:ValidationResult node of resulting transformation, may be null
  */
/**
@param {Type_WrsUtilValidateModel_Args} args   Parameter object with the following properties
  ````js
  { model, stylesheetUrl?, dataProviders, fn? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@param {string} validationId   'bcdValidationId' attribute in ValidationResult/Wrs yields this value
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.validateModel)
@description   runs validation xslt against given model, you can access the result via returned trafo, see return section.
for one-time validation you can supply the callback function (fn parameter)
@method validateModel

@example
// Usage
var ret = bcdui.wrs.wrsUtil.validateModel({ model, dataProviders });

@return {bcdui.core.TransformationChain}  created transformation chain for the validation, it can be reused via bcdui.core.reExecute(_validatorTrafo, callBackFn);
       the data can be accessed via _validatorTrafo.getData() which returns wrs:ValidationResult or null or ValidationResult with empty wrs:Data
@memberOf bcdui.wrs.wrsUtil
*/
export function validateModel(args: Type_WrsUtilValidateModel_Args, validationId: string): bcdui.core.TransformationChain;
export type Type_WrsUtilValidateModel_Args = {
    /**
     * Id of a DataProvider or the DataProvider itself (dp must be ready)
     */
    model: (string | bcdui.core.DataProvider);
    /**
     * default="defauldValidation-stypesheet"  URL to validation stylesheet, defaults to 'xslt/validate/validateWrs.xslt'
     */
    stylesheetUrl?: string;
    /**
     * additional data providers as parameters
     */
    dataProviders: Array<bcdui.core.DataProvider>;
    /**
     * callback function called after validation done, gets object as parameter, containig properties: validationResult: the wrs:ValidationResult node of resulting transformation, may be null
     */
    fn?: Function;
};
import * as bcdui from "../../exports.js";
