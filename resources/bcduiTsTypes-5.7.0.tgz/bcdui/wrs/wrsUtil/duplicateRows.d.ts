/**
  @typedef {Object} Type_WrsUtilDuplicateRows_Args
  @property {bcdui.core.DataProvider} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} [rowStartPos]   First row to be duplicated
  @property {integer} [rowEndPos=rowStartPos]  default=rowStartPos  Last row to be duplicated
  @property {function} [fn]   Callback function called after operation
  @property {boolean} [insertBeforeSelection=true]  default=true
  @property {boolean} [propagateUpdate=true]  default=true  If false, model is not fired
  */
/**
@param {Type_WrsUtilDuplicateRows_Args} args   Parameter object with the following properties
  ````js
  { model, rowStartPos?, rowEndPos?, fn?, insertBeforeSelection?, propagateUpdate? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.duplicateRows)
@description   Duplicate rows in Wrs. Fires fire
@method duplicateRows

@example
// Usage
bcdui.wrs.wrsUtil.duplicateRows({ model });

@return {void}
@memberOf bcdui.wrs.wrsUtil
*/
export function duplicateRows(args: Type_WrsUtilDuplicateRows_Args): void;
export type Type_WrsUtilDuplicateRows_Args = {
    /**
     * Id of a DataProvider or the DataProvider itself (dp must be ready)
     */
    model: bcdui.core.DataProvider;
    /**
     * First row to be duplicated
     */
    rowStartPos?: integer;
    /**
     * default=rowStartPos  Last row to be duplicated
     */
    rowEndPos?: integer;
    /**
     * Callback function called after operation
     */
    fn?: Function;
    /**
     * default=true
     */
    insertBeforeSelection?: boolean;
    /**
     * default=true  If false, model is not fired
     */
    propagateUpdate?: boolean;
};
import * as bcdui from "../../exports.js";
