/**
@param {(PostWrsParam|XMLDocument|Array.<XMLDocument>|bcdui.core.DataProvider|Array.<bcdui.core.DataProvider>)} args   DataProvider(s), Document(s) or a parameter object
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.postWrs)
  @description
  @method postWrs
@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function postWrs(args: (PostWrsParam | XMLDocument | Array<XMLDocument> | bcdui.core.DataProvider | Array<bcdui.core.DataProvider>)): void;
import * as bcdui from "../../exports.js";
