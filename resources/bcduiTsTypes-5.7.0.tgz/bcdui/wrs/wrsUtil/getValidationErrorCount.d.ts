/**
@param {(string|bcdui.core.DataProvider)} wrs   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.getValidationErrorCount)
  @description   Convenience method to return error count in current document (possibly validated by validateWrs.xml)
  @method getValidationErrorCount
@return {integer}  -2: if no validation has been performed, -1: if the data provider is not ready yet, otherwise the number of errors found is returned
@memberOf bcdui.wrs.wrsUtil
 */
export function getValidationErrorCount(wrs: (string | bcdui.core.DataProvider)): integer;
import * as bcdui from "../../exports.js";
