/**
@param {bcdui.core.DataProvider} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {(DomElement|string)} row   Row element or row-id to be duplicated
  @param {boolean} [propagateUpdate=true]   If false, model is not fired
  @param {function} [fn]   Callback function called after operation
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.duplicateRow)
  @description
  @method duplicateRow

  @example
  // Usage
bcdui.wrs.wrsUtil.duplicateRow( model, row );

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function duplicateRow(model: bcdui.core.DataProvider, row: (DomElement | string), propagateUpdate?: boolean, fn?: Function): void;
import * as bcdui from "../../exports.js";
