/**
@param {DomDocument} wrsDoc   WRS Document to build a header from
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.generateWrsHeaderMeta)
  @description   Generates metadata JS object from a Wrs document
  @method generateWrsHeaderMeta
@return {object}  with { [column-id] : {object-with-attrs from wrs:Column/wrs:C} }
@memberOf bcdui.wrs.wrsUtil
 */
export function generateWrsHeaderMeta(wrsDoc: DomDocument): object;
