/**
@param {DomDocument} wrsDoc   the Wrs document to apply changes on
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.applyScale)
  @description   applies number rounding at defined wrs:Header/wrs:Columns/wrs:C/&commat;scale
  @method applyScale
@return {DomDocument}  wrsDoc
@memberOf bcdui.wrs.wrsUtil
 */
export function applyScale(wrsDoc: DomDocument): DomDocument;
