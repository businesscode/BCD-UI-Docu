/**
@param {(string|bcdui.core.DataProvider)} input   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.transposeGrouping)
  @description   This transposes the inner-most &commat;dim column column of a WRS from rows to columns.
This is faster using the XLST with the same name except for Webkit, where this is faster
  @method transposeGrouping
@return {DomDocument}  The transposed document
@memberOf bcdui.wrs.wrsUtil
 */
export function transposeGrouping(input: (string | bcdui.core.DataProvider)): DomDocument;
import * as bcdui from "../../exports.js";
