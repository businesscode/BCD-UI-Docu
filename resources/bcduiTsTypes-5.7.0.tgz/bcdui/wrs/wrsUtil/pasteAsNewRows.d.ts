/**
  @typedef {Object} Type_WrsUtilPasteAsNewRows_Args
  @property {bcdui.core.DataProvider} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} rowStartPos   Restore rows from
  @property {integer} [rowEndPos=rowStartPos]  default=rowStartPos  Restore rows including to.
  @property {integer} [colStartPos=1]  default=1  Restore cols from
  @property {integer} [colEndPos=1]  default=1  Restore cols including to.
  @property {function} [fn]   Callback function called after operation
  @property {boolean} [propagateUpdate=true]  default=true  If false, model is not fired
  */
/**
@param {Type_WrsUtilPasteAsNewRows_Args} args   Parameter object with the following properties
  ````js
  { model, rowStartPos, rowEndPos?, colStartPos?, colEndPos?, fn?, propagateUpdate? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.pasteAsNewRows)
@description   Paste data from clipboard as new rows. Changes source model
@method pasteAsNewRows

@example
// Usage
bcdui.wrs.wrsUtil.pasteAsNewRows({ model, rowStartPos });

@return {void}
@memberOf bcdui.wrs.wrsUtil
*/
export function pasteAsNewRows(args: Type_WrsUtilPasteAsNewRows_Args): void;
export type Type_WrsUtilPasteAsNewRows_Args = {
    /**
     * Id of a DataProvider or the DataProvider itself (dp must be ready)
     */
    model: bcdui.core.DataProvider;
    /**
     * Restore rows from
     */
    rowStartPos: integer;
    /**
     * default=rowStartPos  Restore rows including to.
     */
    rowEndPos?: integer;
    /**
     * default=1  Restore cols from
     */
    colStartPos?: integer;
    /**
     * default=1  Restore cols including to.
     */
    colEndPos?: integer;
    /**
     * Callback function called after operation
     */
    fn?: Function;
    /**
     * default=true  If false, model is not fired
     */
    propagateUpdate?: boolean;
};
import * as bcdui from "../../exports.js";
