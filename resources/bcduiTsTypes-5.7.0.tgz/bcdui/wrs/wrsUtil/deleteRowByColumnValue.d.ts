/**
@param {(DomDocument|DomElement)} wrs   the Wrs document
  @param {(number|string)} colIdOrPos   column id or position
  @param {Array.<string>} values   array of string values to lookup
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.deleteRowByColumnValue)
  @description   delete rows identified by the column value(s)
  @method deleteRowByColumnValue

  @example
  // Usage
bcdui.wrs.wrsUtil.deleteRowByColumnValue( wrs, colIdOrPos, values );

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function deleteRowByColumnValue(wrs: (DomDocument | DomElement), colIdOrPos: (number | string), values: Array<string>): void;
