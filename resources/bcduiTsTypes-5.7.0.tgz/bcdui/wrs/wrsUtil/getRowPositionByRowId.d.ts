/**
  @typedef {Object} Type_WrsUtilGetRowPositionByRowId_Args
  @property {(string|bcdui.core.DataProvider)} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {string} rowId   Row id of which to get the position
  */
/**
@param {Type_WrsUtilGetRowPositionByRowId_Args} args   Parameter object with the following properties
  ````js
  { model, rowId }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.getRowPositionByRowId)
@description   1-based position of a row which is identified by its row-id
@method getRowPositionByRowId

@example
// Usage
var ret = bcdui.wrs.wrsUtil.getRowPositionByRowId({ model, rowId });

@return {integer}  Either position of a row in the document or -1 if no such row was found
@memberOf bcdui.wrs.wrsUtil
*/
export function getRowPositionByRowId(args: Type_WrsUtilGetRowPositionByRowId_Args): integer;
export type Type_WrsUtilGetRowPositionByRowId_Args = {
    /**
     * Id of a DataProvider or the DataProvider itself (dp must be ready)
     */
    model: (string | bcdui.core.DataProvider);
    /**
     * Row id of which to get the position
     */
    rowId: string;
};
import * as bcdui from "../../exports.js";
