/**
@param {boolean} isDebugEnabled
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui._setIsDebug)
  @description   Sets debug mode flag
  @method _setIsDebug
@return {void}
  @memberOf bcdui
 */
export function _setIsDebug(isDebugEnabled: boolean): void;
