/**
  @class bcdui.core.status.LoadingStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus)
  @description This class is active while the executable object is waiting for its document to be loaded.
As soon as the server response is complete, the status will switch.
  @extends bcdui.core.Status
*/
export class LoadingStatus extends bcdui.core.Status {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus?id=equals)
    @description   Test the status for logical equivalence to another status object. Usually
  this function should test if the target status is of the same class as
  this status.
    @overrides bcdui.core.Status#equals
    @public
    @return {boolean} True, if the specified status object represents the same
  logical status as the current one.
    */
    public equals(): boolean;
}
import * as bcdui from "../../exports.js";
