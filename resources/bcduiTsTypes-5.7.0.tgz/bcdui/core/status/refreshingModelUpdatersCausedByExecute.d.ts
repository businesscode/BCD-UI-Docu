/**
  @class bcdui.core.status.RefreshingModelUpdatersCausedByExecute
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.RefreshingModelUpdatersCausedByExecute)
  @description A status indicating that the model is executing the model updaters are auto-updating after
  their target model has been executed.
  @extends bcdui.core.Status
*/
export class RefreshingModelUpdatersCausedByExecute extends bcdui.core.Status {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.RefreshingModelUpdatersCausedByExecute?id=equals)
    @description   Test the status for logical equivalence to another status object. Usually
  this function should test if the target status is of the same class as
  this status.
    @overrides bcdui.core.Status#equals
    @public
    @return {boolean} True, if the specified status object represents the same
  logical status as the current one.
    */
    public equals(): boolean;
}
import * as bcdui from "../../exports.js";
