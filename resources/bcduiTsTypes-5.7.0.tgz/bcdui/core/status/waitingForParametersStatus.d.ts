/**
  @class bcdui.core.status.WaitingForParametersStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus)
  @description A status which is active as long as a transformation is waiting for its parameter DataProviders to become ready.
If a transformation remains too long in this status, one of its, check why its paramaters or input model did not become ready.
  @extends bcdui.core.Status
*/
export class WaitingForParametersStatus extends bcdui.core.Status {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus?id=equals)
    @description   Test the status for logical equivalence to another status object. Usually
  this function should test if the target status is of the same class as
  this status.
    @overrides bcdui.core.Status#equals
    @public
    @return {boolean} True, if the specified status object represents the same
  logical status as the current one.
    */
    public equals(): boolean;
}
import * as bcdui from "../../exports.js";
