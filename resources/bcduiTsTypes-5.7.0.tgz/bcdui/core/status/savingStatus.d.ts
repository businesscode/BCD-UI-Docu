/**
  @class bcdui.core.status.SavingStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.SavingStatus)
  @description This status is active while data is being sent to the server.
  @extends bcdui.core.Status
*/
export class SavingStatus extends bcdui.core.Status {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.SavingStatus?id=equals)
    @description   Test the status for logical equivalence to another status object. Usually
  this function should test if the target status is of the same class as
  this status.
    @overrides bcdui.core.Status#equals
    @public
    @return {boolean} True, if the specified status object represents the same
  logical status as the current one.
    */
    public equals(): boolean;
}
import * as bcdui from "../../exports.js";
