/**
  @class bcdui.core.status.ChainStylesheetLoadingFailed
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.ChainStylesheetLoadingFailed)
  @description This error state is activated when one of the style sheets referenced in the chain document could not be loaded.
  @extends bcdui.core.Status
*/
export class ChainStylesheetLoadingFailed extends bcdui.core.Status {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.ChainStylesheetLoadingFailed?id=equals)
    @description   Test the status for logical equivalence to another status object. Usually
  this function should test if the target status is of the same class as
  this status.
    @overrides bcdui.core.Status#equals
    @public
    @return {boolean} True, if the specified status object represents the same
  logical status as the current one.
    */
    public equals(): boolean;
}
import * as bcdui from "../../exports.js";
