/**
@param {string} compressedXmlString   The encoded and compressed XML document to
be reconstructed.
  @param {string} id   id the model will get, a random one i set otherwise
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.compression.uncompressDOMDocument)
  @description   This function decodes an encoded and compressed XML document passed as the
{@link bcdui.core.compression.compressDOMDocument compressedXmlString()} argument. It can either make the computations on the
client or on the server dependent on the encoding type.
  @method uncompressDOMDocument

  @example
  // Usage
var ret = bcdui.core.compression.uncompressDOMDocument( compressedXmlString, id );

@return {bcdui.core.DataProvider}  A DataProvider instance holding the
uncompressed data when it is in the Ready state.
@memberOf bcdui.core.compression
 */
export function uncompressDOMDocument(compressedXmlString: string, id: string): bcdui.core.DataProvider;
import * as bcdui from "../../exports.js";
