/**
  @typedef {Object} Type_OptionsDataProviderConstructor_Args
  @property {modelXPath} optionsModelXPath   Data xPath with model reference, like <code>"$modelId/guiStatus:MyNode/&commat;myAttr"</code>,
                                                                       is treated as value+caption in case args.optionsModelRelativeValueXPath is NOT DEFINED or
                                                                       is treated as value only in case args.optionsModelRelativeValueXPath IS DEFINED.
  @property {xPath} [optionsModelRelativeValueXPath]   optional xPath relative to args.optionsModelXPath
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation
  */
/**
  @class bcdui.core.OptionsDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.OptionsDataProvider)
  @description This class creates a static model with a top level element '&lt;cust:Options/>' and appends all
 the elements that are found by xpath as children (as element '&lt;cust:Option value="v" caption="x"/>').
 Useful for be passing data as parameter to transformators.
  
  @example
  // Usage
var myODP = new bcdui.core.OptionsDataProvider({ optionsModelXPath: "$myModel/wrs:Wrs/wrs:Data/wrs:R/wrs:C[1]" });

@extends bcdui.core.DataProviderHolder
*/
export class OptionsDataProvider extends bcdui.core.DataProviderHolder {
    /**
    @description This class creates a static model with a top level element '&lt;cust:Options/>' and appends all
   the elements that are found by xpath as children (as element '&lt;cust:Option value="v" caption="x"/>').
   Useful for be passing data as parameter to transformators.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.OptionsDataProvider)
    
    @example
    // Usage
  var myODP = new bcdui.core.OptionsDataProvider({ optionsModelXPath: "$myModel/wrs:Wrs/wrs:Data/wrs:R/wrs:C[1]" });
  
  @param {Type_OptionsDataProviderConstructor_Args} args
      ````js
      { optionsModelXPath, optionsModelRelativeValueXPath?, name? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_OptionsDataProviderConstructor_Args);
}
export type Type_OptionsDataProviderConstructor_Args = {
    /**
     * Data xPath with model reference, like <code>"$modelId/guiStatus:MyNode/&commat;myAttr"</code>,
                              is treated as value+caption in case args.optionsModelRelativeValueXPath is NOT DEFINED or
                              is treated as value only in case args.optionsModelRelativeValueXPath IS DEFINED.
     */
    optionsModelXPath: modelXPath;
    /**
     * optional xPath relative to args.optionsModelXPath
     */
    optionsModelRelativeValueXPath?: xPath;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation
     */
    name?: string;
};
import * as bcdui from "../exports.js";
