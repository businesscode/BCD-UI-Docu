/**
  @typedef {Object} Type_DataProviderWithXPathConstructor_Args
  @property {modelXPath} xPath   Data source like <code>"$modelId/guiStatus:MyNode/&commat;myAttr"</code>
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation
  */
/**
  @class bcdui.core.DataProviderWithXPath
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderWithXPath)
  @description Reading a single data item from an XPath on getData() as string.
See {@link bcdui.core.DataProviderWithXPathNodes DataProviderWithXPathNodes} for reading a full XML node-set
  
  @example
  // Usage
var myDPWXP = new bcdui.core.DataProviderWithXPath({ xPath });

@extends bcdui.core.DataProviderHolder
*/
export class DataProviderWithXPath extends bcdui.core.DataProviderHolder {
    /**
    @description Reading a single data item from an XPath on getData() as string.
  See {@link bcdui.core.DataProviderWithXPathNodes DataProviderWithXPathNodes} for reading a full XML node-set
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderWithXPath)
    
    @example
    // Usage
  var myDPWXP = new bcdui.core.DataProviderWithXPath({ xPath });
  
  @param {Type_DataProviderWithXPathConstructor_Args} args
      ````js
      { xPath, name? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_DataProviderWithXPathConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderWithXPath?id=getxpath)
    @public
    @return {string}
    */
    public getXPath(): string;
}
export type Type_DataProviderWithXPathConstructor_Args = {
    /**
     * Data source like <code>"$modelId/guiStatus:MyNode/&commat;myAttr"</code>
     */
    xPath: modelXPath;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation
     */
    name?: string;
};
import * as bcdui from "../exports.js";
