/**
@param {(string|document)} doc   The document (doc or string) which should be cleaned
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.removeObsoleteNS)
  @description   removes obsolete namespace declarations and moves used ones to the root element
  @method removeObsoleteNS
@return {string}  The serialized and namespace-cleaned representation of the doc
@memberOf bcdui.core.browserCompatibility
 */
export function removeObsoleteNS(doc: (string | Document)): string;
