/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.resolveNamespace)
  @description
  @method resolveNamespace
@return {string}  URI for a given prefix
@memberOf bcdui.core.browserCompatibility
 */
export function resolveNamespace(): string;
