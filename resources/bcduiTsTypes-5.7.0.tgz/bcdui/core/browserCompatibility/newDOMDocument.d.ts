/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.newDOMDocument)
  @description
  @method newDOMDocument
@return {DomDocument}  A new DOM document
@memberOf bcdui.core.browserCompatibility
 */
export function newDOMDocument(): DomDocument;
