/**
  @typedef {Object} Type_BrowserCompatibilityAsyncCreateXsltProcessor_Args
  @property {DomDocument} model   The XSLT document the XSLTProcessor instance should be
  @property {function} callBack   The callback function executed when the processor has been created. It takes the processor instance as argument
  @property {string} callerDebug   Additional (debug) information from the caller for logging
  */
/**
@param {Type_BrowserCompatibilityAsyncCreateXsltProcessor_Args} args   An argument map containing the following elements:
  ````js
  { model, callBack, callerDebug }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.asyncCreateXsltProcessor)
@description   Asynchronous creation of an XSLTProcessor object from a DOM document.
@method asyncCreateXsltProcessor

@example
// Usage
bcdui.core.browserCompatibility.asyncCreateXsltProcessor({ model, callBack, callerDebug });

@return {void}
@memberOf bcdui.core.browserCompatibility
*/
export function asyncCreateXsltProcessor(args: Type_BrowserCompatibilityAsyncCreateXsltProcessor_Args): void;
export type Type_BrowserCompatibilityAsyncCreateXsltProcessor_Args = {
    /**
     * The XSLT document the XSLTProcessor instance should be
     */
    model: DomDocument;
    /**
     * The callback function executed when the processor has been created. It takes the processor instance as argument
     */
    callBack: Function;
    /**
     * Additional (debug) information from the caller for logging
     */
    callerDebug: string;
};
