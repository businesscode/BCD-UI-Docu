/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.extractMetaDataFromStylesheetDoc)
  @description
  @method extractMetaDataFromStylesheetDoc
@return {void}
  @memberOf bcdui.core.browserCompatibility
 */
export function extractMetaDataFromStylesheetDoc(): void;
