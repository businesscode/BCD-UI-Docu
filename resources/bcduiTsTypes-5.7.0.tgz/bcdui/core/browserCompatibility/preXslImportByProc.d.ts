/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.preXslImportByProc)
  @description   Prepare for implementing xsl:import by replacing bcduicp: with the application's context
  @method preXslImportByProc
@return {void}
  @memberOf bcdui.core.browserCompatibility
 */
export function preXslImportByProc(): void;
