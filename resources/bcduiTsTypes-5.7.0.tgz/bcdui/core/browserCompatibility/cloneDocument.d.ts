/**
@param {DomDocument} doc   To be cloned
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.cloneDocument)
  @description
  @method cloneDocument
@return {DomDocument}  A clone of the given DOM document
@memberOf bcdui.core.browserCompatibility
 */
export function cloneDocument(doc: DomDocument): DomDocument;
