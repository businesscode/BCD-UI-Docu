/**
@param {string} serializedDoc   A serialized XML document.
  @param {string} msg   Optional for better error message.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.createDOMFromXmlString)
  @description   Parses given xml string and creates a DOMDocument out of it.
  @method createDOMFromXmlString

  @example
  // Usage
var ret = bcdui.core.browserCompatibility.createDOMFromXmlString( serializedDoc, msg );

@return {DomDocument}  The DOMDocument parsed from the serialized document string.
@memberOf bcdui.core.browserCompatibility
 */
export function createDOMFromXmlString(serializedDoc: string, msg: string): DomDocument;
