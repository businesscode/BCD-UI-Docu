/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.cleanupGeneratedXslt)
  @description
  @method cleanupGeneratedXslt
@return {void}
  @memberOf bcdui.core.browserCompatibility
 */
export function cleanupGeneratedXslt(): void;
