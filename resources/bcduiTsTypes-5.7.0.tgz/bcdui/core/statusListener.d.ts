/**
  @class bcdui.core.StatusListener
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusListener)
  @description An interface that status listeners must implement.
A StatusListener is informed by DataProviders (more precisely by {@link bcdui.core.AbstractExecutable AbstractExecutables}) about status changes, becoming ready is the most important.
  */
export class StatusListener {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusListener?id=handlestatusevent)
    @description   This method is called when the status transition the listener is registered
  for occurs.
    @param {bcdui.core.StatusEvent} statusEvent   The status event belonging to the status transition. This
  object must not be modified, because it is shared among all listeners.
    @public
    @return {void}
    */
    public handleStatusEvent(statusEvent: bcdui.core.StatusEvent): void;
}
import * as bcdui from "../exports.js";
