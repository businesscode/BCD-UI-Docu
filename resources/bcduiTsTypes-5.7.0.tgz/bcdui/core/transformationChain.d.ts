/**
  @class bcdui.core.TransformationChain
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain)
  @description A class representing one or more transformations applied on models with parameters. Transformators can be js functions, XSLTs or doTjs templates.
Use {@link bcdui.core.Renderer Renderer} or {@link bcdui.core.ModelWrapper ModelWrapper} as concrete sub classes
  @description The constructor for the TransformationChain class.
  @extends bcdui.core.DataProvider
*/
export class TransformationChain extends bcdui.core.DataProvider {
    /**
    @description A class representing one or more transformations applied on models with parameters. Transformators can be js functions, XSLTs or doTjs templates.
  Use {@link bcdui.core.Renderer Renderer} or {@link bcdui.core.ModelWrapper ModelWrapper} as concrete sub classes
    @description The constructor for the TransformationChain class.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain)
      */
    constructor();
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain?id=adddataprovider)
    @description   Adds a new data provider to the transformation chain. If there is already a data provider
  with the given name it is replaced.
    @param {Object} newDataProvider   the new dataprovider which should be added
    @param {string} [newName]   an optional new name for the provider. if given an alias will be created
    @public
    @return {bcdui.core.DataProvider} The old data provider registered under the name or
  null if there has not been any.
    */
    public addDataProvider(newDataProvider: Object, newName?: string): bcdui.core.DataProvider;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain?id=getdataproviderbyname)
    @param {string} name
    @public
    @return {bcdui.core.DataProvider} returns the parameter of the given name
    */
    public getDataProviderByName(name: string): bcdui.core.DataProvider;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain?id=getprimarymodel)
    @description   Getter for the primary model of the chain. The first transformation of
  the chain takes a document as input. This document comes from the
  primary model.
    @public
    @return {bcdui.core.DataProvider} The model the first transformation in
  the chain is running on.
    */
    public getPrimaryModel(): bcdui.core.DataProvider;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain?id=reloadstylesheets)
    @description   Start the loading process of the stylesheets and executes the transformations
  again.
    @public
    @return {void}
    */
    public reloadStylesheets(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.TransformationChain?id=setprimarymodel)
    @description   Adds a new data provider to the list which becomes the new primary model
  of the transformation chain.
    @param {bcdui.core.DataProvider} primaryModel   the new primary model of the transformation chain.
    @public
    @return {void}
    */
    public setPrimaryModel(primaryModel: bcdui.core.DataProvider): void;
    /**
       * A status reached when the chain model is ready.
       * @type {bcdui.core.status.ChainLoadedStatus}
       */
    chainLoadedStatus: bcdui.core.status.ChainLoadedStatus;
    /**
       * This (final) status is reached when the chain model could not be loaded.
       * @type {bcdui.core.status.ChainStylesheetLoadingFailed}
       */
    chainLoadingFailed: bcdui.core.status.ChainStylesheetLoadingFailed;
    /**
       * This (final) status is reached when the loading of a chain stylesheet has
    failed.
       * @type {bcdui.core.status.ChainStylesheetLoadingFailed}
       */
    chainStylesheetLoadingFailed: bcdui.core.status.ChainStylesheetLoadingFailed;
    /**
       * This status is set when the constructor has set all parameters.
       * @type {bcdui.core.status.InitializedStatus}
       */
    initializedStatus: bcdui.core.status.InitializedStatus;
    /**
       * This (final) status is reached when an error occurs during the loading or
    transformation process.
       * @type {bcdui.core.status.LoadFailedStatus}
       */
    loadFailedStatus: bcdui.core.status.LoadFailedStatus;
    /**
       * The status code activated as soon as the loading begins.
       * @type {bcdui.core.status.LoadingStatus}
       */
    loadingStatus: bcdui.core.status.LoadingStatus;
    /**
       * The status code is reached when everything is finished and the transformation
    result is available. This is the final state of the TransformationChain process
    if no error occurs.
       * @type {bcdui.core.status.TransformedStatus}
       */
    transformedStatus: bcdui.core.status.TransformedStatus;
    /**
       * The status code is reached when a transformation failed and operation cannot proceed
       * @type {bcdui.core.status.TransformFailedStatus}
       */
    transformFailedStatus: bcdui.core.status.TransformFailedStatus;
    /**
       * As long as this status is active the XSLT transformations are running.
       * @type {bcdui.core.status.TransformingStatus}
       */
    transformingStatus: bcdui.core.status.TransformingStatus;
    /**
       * This status is kept as long as the transformation chain is waiting
    for parameters to load and when the chain has already loaded.
       * @type {bcdui.core.status.WaitingForParametersStatus}
       */
    waitingForParametersStatus: bcdui.core.status.WaitingForParametersStatus;
}
import * as bcdui from "../exports.js";
