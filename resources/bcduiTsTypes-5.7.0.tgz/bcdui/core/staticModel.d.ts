/**
  @class bcdui.core.StaticModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StaticModel)
  @description Creates a model from fixed data without accessing the network.</p>
As opposed to most DataProviders, execute() of a StaticModel is guaranteed to be synchronous except when using model updaters.
Note that this implies that it is only static once the page is fully loaded {@link bcdui.core.ready()}
<ol>
  <li> execute() is called after {@link bcdui.core.ready()} was reached, because otherwise model updaters may still register themselves</li>
  <li> at the time of .execute() no model updaters were registered for this model, because model updaters operate asynchronously</li>
</ol>
  @description Create a StaticModel and provide the data.
  
  @example
  // Provide data as a {@link bcdui.core.DataProvider DataProvider} with an id or use in a declarative context by id
var m = new bcdui.core.StaticModel({ id: "dayModel", data: "<Values> <V>Mon</V> <V>Wed</V> </Values>" });
bcdui.widgetNg.createSingleSelect({ targetHtml: "selectDayHtml", optionsModelXPath: "$dayModel/Values/V", targetModelXPath: "$guiStatus/guiStatus:Status/guiStatus:SelectedDay/@value" });
  
  @example
  Provide data as a {@link bcdui.core.DataProvider DataProvider}
var myModel = new bcdui.core.StaticModel( "<Root myAttr='Test'></Root>" );
// Widgets and Renderers automatically execute and wait for the model to be ready. If using it in plain JavaScript, do it yourself.
myModel.onceReady({ executeIfNotReady: true, onSuccess: () => {
  var myAttr = myModel.getData().selectSingleNode("/Root/@myAttr").nodeValue;
  // ...
}});
  @extends bcdui.core.AbstractUpdatableModel
*/
export class StaticModel extends bcdui.core.AbstractUpdatableModel {
    /**
    @description Creates a model from fixed data without accessing the network.</p>
  As opposed to most DataProviders, execute() of a StaticModel is guaranteed to be synchronous except when using model updaters.
  Note that this implies that it is only static once the page is fully loaded {@link bcdui.core.ready()}
  <ol>
    <li> execute() is called after {@link bcdui.core.ready()} was reached, because otherwise model updaters may still register themselves</li>
    <li> at the time of .execute() no model updaters were registered for this model, because model updaters operate asynchronously</li>
  </ol>
    @description Create a StaticModel and provide the data.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StaticModel)
    
    @example
    // Provide data as a {@link bcdui.core.DataProvider DataProvider} with an id or use in a declarative context by id
  var m = new bcdui.core.StaticModel({ id: "dayModel", data: "<Values> <V>Mon</V> <V>Wed</V> </Values>" });
  bcdui.widgetNg.createSingleSelect({ targetHtml: "selectDayHtml", optionsModelXPath: "$dayModel/Values/V", targetModelXPath: "$guiStatus/guiStatus:Status/guiStatus:SelectedDay/@value" });
    
    @example
    Provide data as a {@link bcdui.core.DataProvider DataProvider}
  var myModel = new bcdui.core.StaticModel( "<Root myAttr='Test'></Root>" );
  // Widgets and Renderers automatically execute and wait for the model to be ready. If using it in plain JavaScript, do it yourself.
  myModel.onceReady({ executeIfNotReady: true, onSuccess: () => {
    var myAttr = myModel.getData().selectSingleNode("/Root/@myAttr").nodeValue;
    // ...
  }});
    @param {(string|StaticModelParam|DomDocument)} args   And XML string, which is parsed, an XML Document or a JSON object or any other kind of data
      */
    constructor(args: (string | StaticModelParam | DomDocument));
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StaticModel?id=getdata)
    @description   Access to the data of this DataProvider for read and modification access
    @overrides bcdui.core.AbstractUpdatableModel#getData
    @public
    @return {DomDocument} The data document provided in the constructor.
    */
    public getData(): DomDocument;
    /**
           * @type {bcdui.core.status.InitializedStatus}
           * @constant
           */
    initializedStatus: bcdui.core.status.InitializedStatus;
    /**
           * @type {bcdui.core.status.TransformedStatus}
           * @constant
           */
    transformedStatus: bcdui.core.status.TransformedStatus;
}
import * as bcdui from "../exports.js";
