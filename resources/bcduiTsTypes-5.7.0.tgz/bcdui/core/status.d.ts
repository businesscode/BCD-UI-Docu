/**
  @class bcdui.core.Status
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Status)
  @description An abstract base class, representing a Status.
See {@link bcdui.core.status} for concrete sub classes.
  */
export class Status {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Status?id=equals)
    @description   Test the status for logical equivalence to another status object. Usually
  this function should test if the target status is of the same class as
  this status.
    @param {bcdui.core.Status} status   The status object to compare with.
    @public
    @return {boolean} True, if the specified status object represents the same
  logical status as the current one.
    */
    public equals(status: bcdui.core.Status): boolean;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Status?id=getcode)
    @public
    @return {string} A short code for the Status which can be used for debugging.
    */
    public getCode(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Status?id=getdescription)
    @public
    @return {string} A longer description of the Status.
    */
    public getDescription(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Status?id=tostring)
    @public
    @return {string} A debug string summarizing this status object.
    */
    public toString(): string;
}
import * as bcdui from "../exports.js";
