/**
  @typedef {Object} Type_AbstractExecutableConstructor_Args
  @property {string} [id]   A unique id for declarative contexts
  @property {function} [bcdPreInit]   a function which can be used to execute code before any super code of derived classes
  */
/**
  @class bcdui.core.AbstractExecutable
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable)
  @description The abstract executable class is a base class for asynchronous operating status-based classes in BCD-UI library. It offers a basic set of
methods that these classes share. Most methods deal with status handling, transitions, listeners and synchronization.
<br/>Most common implementations are:
{@link bcdui.core.StaticModel} and {@link bcdui.core.SimpleModel}
  @description The constructor which must be called by all sub-classes. It initializes the listeners, status and id fields.
This class is abstract and not meant to be instantiated directly
  */
export class AbstractExecutable {
    /**
    @description The abstract executable class is a base class for asynchronous operating status-based classes in BCD-UI library. It offers a basic set of
  methods that these classes share. Most methods deal with status handling, transitions, listeners and synchronization.
  <br/>Most common implementations are:
  {@link bcdui.core.StaticModel} and {@link bcdui.core.SimpleModel}
    @description The constructor which must be called by all sub-classes. It initializes the listeners, status and id fields.
  This class is abstract and not meant to be instantiated directly
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable)
    @param {Type_AbstractExecutableConstructor_Args} [args]   Parameter object
      ````js
      { id?, bcdPreInit? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args?: Type_AbstractExecutableConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=addstatuslistener)
    @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
    @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args   Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
    @public
    @return {void}
    */
    public addStatusListener(args: (Function | bcdui.core.StatusListener | AddStatusListenerParam)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=execute)
    @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/>
  Executes the process implemented by the concrete sub-class
  This method is called by the Renderer when it is ready to render the model
  It is often asynchronous.
  Note, Renderer and sub-classes execute all input models recursively automatically.
  This means, usually you do not need to call this method directly. Note: it is asynchronous.
  Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
    @param {boolean} [doesRefresh=true]   Set this parameter to "false" if this method should do
  nothing when the object is already in the ready status. The default is "true"
  meaning that the process is re-started when it is currently ready.
    @public
    @return {void}
    */
    public execute(doesRefresh?: boolean): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=getclassname)
    @description   Get className
    @public
    @return {string} className
    */
    public getClassName(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=getfailedstatus)
    @description   Getter for the list of error statuses of this class. This implementation returns an
  empty list.
    @public
    @return {Array.<bcdui.core.Status>} The status objects corresponding to failures in the object's
  process.
    */
    public getFailedStatus(): Array<bcdui.core.Status>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=getreadystatus)
    @description   Getter for the ready status of the instance. This status is a final state
  defined by each sub-class which is reached when the process has finished
  normally.
    @public
    @return {bcdui.core.Status} The status object indicating that the process belonging
  to this class is finished.
    */
    public getReadyStatus(): bcdui.core.Status;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=getstatus)
    @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
    @public
    @return {bcdui.core.Status} The current status.
    */
    public getStatus(): bcdui.core.Status;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=hasfailed)
    @description   Tests if the object has reached a failure status. These status codes are
  returned by the "getFailedStatus" method.
    @public
    @return {boolean} True, if the object's process has failed.
    */
    public hasFailed(): boolean;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=isready)
    @description   Tests if the current state is the readyStatus. This status is the same
  status as returned by "getReadyStatus".
    @public
    @return {boolean} True, if the object is ready.
    */
    public isReady(): boolean;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=onceready)
    @param {(function|OnceReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
    @public
    @return {void}
    */
    public onceReady(listenerObject: (Function | OnceReadyParam)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=onready)
    @param {(function|OnReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
    @public
    @return {void}
    */
    public onReady(listenerObject: (Function | OnReadyParam)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=removestatuslistener)
    @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args   The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
    @public
    @return {void}
    */
    public removeStatusListener(args: (Function | bcdui.core.StatusListener | RemoveStatusListenerParam)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=setstatus)
    @description   Makes a transition from the current status to the new status if they
  are not equal. After the status is changed it fires the status event
  to the registered listeners.<p/>
  Usually this method will only be called by the library but you can use it to re-trigger an action. For available statuses and their effect, see the concrete class,
    @param {bcdui.core.Status} args   Either a Status object or a parameter map with a property
  "status" holding a Status object.
    @public
    @return {void}
    */
    public setStatus(args: bcdui.core.Status): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractExecutable?id=tostring)
    @public
    @return {string} Debug string with this class and its id.
    */
    public toString(): string;
    /**
       * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor.
    This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.
    If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
       * @type {string}
       */
    id: string;
}
export type Type_AbstractExecutableConstructor_Args = {
    /**
     * A unique id for declarative contexts
     */
    id?: string;
    /**
     * a function which can be used to execute code before any super code of derived classes
     */
    bcdPreInit?: Function;
};
import * as bcdui from "../exports.js";
