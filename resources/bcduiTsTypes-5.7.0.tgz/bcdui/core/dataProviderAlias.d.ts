/**
  @typedef {Object} Type_DataProviderAliasConstructor_Args
  @property {bcdui.core.DataProvider} source   The data provider to be wrapped
  @property {string} name   The new name of the data provider
  */
/**
  @class bcdui.core.DataProviderAlias
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias)
  @description This class is a wrapper for a DataProvider giving it a new name (not id) and
reducing its states to only initialized and loaded. It is useful for
renaming a DataProvider before passing it to a TransformationChain so
that a DataProvider can be mapped to an arbitrary xsl:param element.
where the bcdui.core.DataProviderAlias' name is used as the xsl:param's name
  
  @example
  // Usage
var myDPA = new bcdui.core.DataProviderAlias({ source, name });

@extends bcdui.core.DataProviderHolder
*/
export class DataProviderAlias extends bcdui.core.DataProviderHolder {
    /**
    @description This class is a wrapper for a DataProvider giving it a new name (not id) and
  reducing its states to only initialized and loaded. It is useful for
  renaming a DataProvider before passing it to a TransformationChain so
  that a DataProvider can be mapped to an arbitrary xsl:param element.
  where the bcdui.core.DataProviderAlias' name is used as the xsl:param's name
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderAlias)
    
    @example
    // Usage
  var myDPA = new bcdui.core.DataProviderAlias({ source, name });
  
  @param {Type_DataProviderAliasConstructor_Args} args   The argument map taking two mandatory parameters:
      ````js
      { source, name }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_DataProviderAliasConstructor_Args);
}
export type Type_DataProviderAliasConstructor_Args = {
    /**
     * The data provider to be wrapped
     */
    source: bcdui.core.DataProvider;
    /**
     * The new name of the data provider
     */
    name: string;
};
import * as bcdui from "../exports.js";
