/**
  @typedef {Object} Type_ModelWrapperConstructorSaveOptions_Args
  @property {chainDef} [saveChain]   The definition of the transformation chain
  @property {Object} [saveParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  @property {boolean} [reload]   Useful especially for models of type SimpleModel for refreshing from server after save
  @property {function} [onSuccess]   Callback after saving (and optionally reloading) was successfully finished
  @property {function} [onFailure]   Callback on failure, is called if error occurs
  @property {function} [onWrsValidationFailure]   Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
  @property {bcdui.core.DataProvider} [urlProvider]   dataprovider holding the request url, this is mandatory for saving
  */
/**
  @typedef {Object} Type_ModelWrapperConstructor_Args
  @property {chainDef} chain   The definition of the transformation chain
<ul>
  <li>a single string with the URL of the transformation XSLT or doTjs template</li>
  <li>or a JS transformator function</li>
  <li>or an array with a mixture of URLs and JS transformators</li>
  <li>or a DataProvider with an XML document following xsd http://www.businesscode.de/schema/bcdui/chain-1.0.0</li>
</ul>
  @property {bcdui.core.DataProvider} inputModel   The model with the data to be transformed
  @property {Object} [parameters]   An object, where each property holds a DataProvideras a transformation parameter
Once this ModelWapper is {@link bcdui.core.AbstractExecutable#execute executed}, it will check each parameter and execute it, if it is not {@link bcdui.core.AbstractExecutable .isReady()}
  @property {string} [id]   Globally unique id for use in declarative contexts
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatus]  default=bcdui.wkModels.guiStatus  custom model to use as 'guiStatus' parameter
  @property {bcdui.core.DataProvider} [statusModelEstablished=bcdui.wkModels.guiStatusEstablished]  default=bcdui.wkModels.guiStatusEstablished  custom model to use as 'guiStatusEstablished' parameter
  @property {Type_ModelWrapperConstructorSaveOptions_Args} [saveOptions]   An object, with the following elements
    ````js
    { saveChain?, saveParameters?, reload?, onSuccess?, onFailure?, onWrsValidationFailure?, urlProvider? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  */
/**
  @class bcdui.core.ModelWrapper
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ModelWrapper)
  @description A concrete subclass of {@link bcdui.core.TransformationChain TransformationChain}, being a DataProvider itself, providing the transformed input.
  
  @example
  // Usage
var myMW = new bcdui.core.ModelWrapper({ chain: ["myRenderer.xslt", finalCleanupFunc], inputModel: myModel });

@extends bcdui.core.TransformationChain
*/
export class ModelWrapper extends bcdui.core.TransformationChain {
    /**
    @description A concrete subclass of {@link bcdui.core.TransformationChain TransformationChain}, being a DataProvider itself, providing the transformed input.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ModelWrapper)
    
    @example
    // Usage
  var myMW = new bcdui.core.ModelWrapper({ chain: ["myRenderer.xslt", finalCleanupFunc], inputModel: myModel });
  
  @param {Type_ModelWrapperConstructor_Args} args   An argument object with the following properties:
      ````js
      { chain, inputModel, parameters?, id?, statusModel?, statusModelEstablished?, saveOptions? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ModelWrapperConstructor_Args);
}
export type Type_ModelWrapperConstructorSaveOptions_Args = {
    /**
     * The definition of the transformation chain
     */
    saveChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    saveParameters?: Object;
    /**
     * Useful especially for models of type SimpleModel for refreshing from server after save
     */
    reload?: boolean;
    /**
     * Callback after saving (and optionally reloading) was successfully finished
     */
    onSuccess?: Function;
    /**
     * Callback on failure, is called if error occurs
     */
    onFailure?: Function;
    /**
     * Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
     */
    onWrsValidationFailure?: Function;
    /**
     * dataprovider holding the request url, this is mandatory for saving
     */
    urlProvider?: bcdui.core.DataProvider;
};
export type Type_ModelWrapperConstructor_Args = {
    /**
     * The definition of the transformation chain
    <ul>
    <li>a single string with the URL of the transformation XSLT or doTjs template</li>
    <li>or a JS transformator function</li>
    <li>or an array with a mixture of URLs and JS transformators</li>
    <li>or a DataProvider with an XML document following xsd http://www.businesscode.de/schema/bcdui/chain-1.0.0</li>
    </ul>
     */
    chain: chainDef;
    /**
     * The model with the data to be transformed
     */
    inputModel: bcdui.core.DataProvider;
    /**
     * An object, where each property holds a DataProvideras a transformation parameter
    Once this ModelWapper is {@link bcdui.core.AbstractExecutable#execute executed}, it will check each parameter and execute it, if it is not {@link bcdui.core.AbstractExecutable.isReady ()}
     */
    parameters?: Object;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * default=bcdui.wkModels.guiStatus  custom model to use as 'guiStatus' parameter
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * default=bcdui.wkModels.guiStatusEstablished  custom model to use as 'guiStatusEstablished' parameter
     */
    statusModelEstablished?: bcdui.core.DataProvider;
    /**
     * An object, with the following elements
     * ````js
     * { saveChain?, saveParameters?, reload?, onSuccess?, onFailure?, onWrsValidationFailure?, urlProvider? }
     * ````
     * <br/>Use autocomplete in {} to get a full parameter description <br/>
     */
    saveOptions?: Type_ModelWrapperConstructorSaveOptions_Args;
};
import * as bcdui from "../exports.js";
