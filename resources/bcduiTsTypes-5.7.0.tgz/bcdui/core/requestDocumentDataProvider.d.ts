/**
  @typedef {Object} Type_RequestDocumentDataProviderConstructor_Args
  @property {bcdui.core.DataProvider} [requestModel]   A DataProvider providing a request, for example a wrs:WrsRequest
  @property {string} [url]   URL to load the data from, use this or args.requestModel.
  @property {(string|bcdui.core.DataProvider)} [modelUrl='WrsServlet']  default='WrsServlet'  When using args.requestModel, this is a string or string- DataProvider with the URL which to send the requestModel result to
  @property {string} [uri]   uri extension as a suffix to .url to tag requests, must not start with '/'. This parameter is ineffective if .modelUrl or .url is provided.
  @property {string} [id]   Globally unique id for use in declarative contexts
  @property {boolean} [isAutoRefresh]   If true, this DataProvider will always update itself when the requestDoc changes (without the need for execute) and fire a data modification event
                                                                         If used as a urlProvider from a {@link bcdui.core.SimpleModel SimpleModel}, it inherits its isAutoRefresh
  @property {boolean} [attachSessionHash]   Logical name of this DataProvider when used as a parameter in a transformation
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation, locally unique
  @property {string} [method="GET"]  default="GET"  Request method for SimpleModel, either "POST" or "GET"
  */
/**
  @class bcdui.core.RequestDocumentDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.RequestDocumentDataProvider)
  @description Turns a DataProvider into a URL provider for SimpleModel.<p/>
We do reflect the status of the requestModel transparently as we are just glueware.
If the requestModel becomes invalid or throws dataModification, we do also become not-ready and stay so.
Even if the requestModel becomes ready again, we stay until we are executed unless args.isAutoRefresh = true is set.
  
  @example
  // Load a SimpleModel from a static Wrs request
var requestString =
  "&lt;WrsRequest xmlns=\"http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0\" xmlns:f=\"http://www.businesscode.de/schema/bcdui/filter-1.0.0\">" +
  "  &lt;Select>"+
  "    &lt;Columns> &lt;C bRef='region'/> &lt;/Columns>"+
  "    &lt;From> &lt;BindingSet>md_geo</BindingSet> &lt;/From>"+
  "    &lt;f:Filter> &lt;f:Expression bRef='country' op='=' value='US'/> &lt;/f:Filter>"+
  "    &lt;Grouping> &lt;C bRef='region'/> &lt;/Grouping>"+
  "  &lt;/Select>"+
  "&lt;/WrsRequest>";
var myRequestModel = new bcdui.core.StaticModel( requestString );
var myUrlProvider  = new bcdui.core.RequestDocumentDataProvider({ requestModel: myRequestModel });
var geoModel       = new bcdui.core.SimpleModel({ url: myUrlProvider, isAutoRefresh: true});
geoModel.execute();
// Once geoModel.isReady() === true, it will hold region data for 'US'

// Somewhat later
myRequestModel.getData().selectSingleNode("/wrq:WrsRequest/wrq:Select/f:Filter/f:Expression[@bRef='country']/@value").nodeValue = "FR";
myRequestModel.fire();
// It will auto-reload and once geoModel.isReady() === true, it will hold region data for 'FR'
  @extends bcdui.core.DataProvider
*/
export class RequestDocumentDataProvider extends bcdui.core.DataProvider {
    /**
    @description Turns a DataProvider into a URL provider for SimpleModel.<p/>
  We do reflect the status of the requestModel transparently as we are just glueware.
  If the requestModel becomes invalid or throws dataModification, we do also become not-ready and stay so.
  Even if the requestModel becomes ready again, we stay until we are executed unless args.isAutoRefresh = true is set.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.RequestDocumentDataProvider)
    
    @example
    // Load a SimpleModel from a static Wrs request
  var requestString =
    "&lt;WrsRequest xmlns=\"http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0\" xmlns:f=\"http://www.businesscode.de/schema/bcdui/filter-1.0.0\">" +
    "  &lt;Select>"+
    "    &lt;Columns> &lt;C bRef='region'/> &lt;/Columns>"+
    "    &lt;From> &lt;BindingSet>md_geo</BindingSet> &lt;/From>"+
    "    &lt;f:Filter> &lt;f:Expression bRef='country' op='=' value='US'/> &lt;/f:Filter>"+
    "    &lt;Grouping> &lt;C bRef='region'/> &lt;/Grouping>"+
    "  &lt;/Select>"+
    "&lt;/WrsRequest>";
  var myRequestModel = new bcdui.core.StaticModel( requestString );
  var myUrlProvider  = new bcdui.core.RequestDocumentDataProvider({ requestModel: myRequestModel });
  var geoModel       = new bcdui.core.SimpleModel({ url: myUrlProvider, isAutoRefresh: true});
  geoModel.execute();
  // Once geoModel.isReady() === true, it will hold region data for 'US'
  
  // Somewhat later
  myRequestModel.getData().selectSingleNode("/wrq:WrsRequest/wrq:Select/f:Filter/f:Expression[@bRef='country']/@value").nodeValue = "FR";
  myRequestModel.fire();
  // It will auto-reload and once geoModel.isReady() === true, it will hold region data for 'FR'
    @param {Type_RequestDocumentDataProviderConstructor_Args} args   Parameter object
      ````js
      { requestModel?, url?, modelUrl?, uri?, id?, isAutoRefresh?, attachSessionHash?, name?, method? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_RequestDocumentDataProviderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.RequestDocumentDataProvider?id=setisautorefresh)
    @description   If true, this DataProvider will always update itself when the requestDoc changes (without the need for execute) and fire a data modification event
    @param {boolean} isAutoRefresh
    @public
    @return {void}
    */
    public setIsAutoRefresh(isAutoRefresh: boolean): void;
}
export type Type_RequestDocumentDataProviderConstructor_Args = {
    /**
     * A DataProvider providing a request, for example a wrs:WrsRequest
     */
    requestModel?: bcdui.core.DataProvider;
    /**
     * URL to load the data from, use this or args.requestModel.
     */
    url?: string;
    /**
     * default='WrsServlet'  When using args.requestModel, this is a string or string- DataProvider with the URL which to send the requestModel result to
     */
    modelUrl?: (string | bcdui.core.DataProvider);
    /**
     * uri extension as a suffix to .url to tag requests, must not start with '/'. This parameter is ineffective if .modelUrl or .url is provided.
     */
    uri?: string;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * If true, this DataProvider will always update itself when the requestDoc changes (without the need for execute) and fire a data modification event
                                        If used as a urlProvider from a {@link bcdui.core.SimpleModel SimpleModel}, it inherits its isAutoRefresh
     */
    isAutoRefresh?: boolean;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation
     */
    attachSessionHash?: boolean;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation, locally unique
     */
    name?: string;
    /**
     * default="GET"  Request method for SimpleModel, either "POST" or "GET"
     */
    method?: string;
};
import * as bcdui from "../exports.js";
