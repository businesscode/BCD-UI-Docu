/**
  @typedef {Object} Type_DataProviderHtmlAttributeConstructor_Args
  @property {string} htmlElementId
  @property {string} attributeName
  */
/**
  @class bcdui.core.DataProviderHtmlAttribute
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHtmlAttribute)
  @description A DataProvider retrieving its content on getData() from an attribute in the HTML DOM tree.
  
  @example
  // Usage
var myDPHA = new bcdui.core.DataProviderHtmlAttribute({ htmlElementId, attributeName });


  @example
  <div id="myDiv" attr="123"><div>
<script type="text/javascript">
  var dp = new bcdui.core.DataProviderHtmlAttribute({ htmlElementId: 'myDiv', attributeName: 'attr'});
  dp.onceReady( () => console.log(dp.getData()) ); // -> '123'
<script>
  @extends bcdui.core.DataProvider
*/
export class DataProviderHtmlAttribute extends bcdui.core.DataProvider {
    /**
    @description A DataProvider retrieving its content on getData() from an attribute in the HTML DOM tree.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHtmlAttribute)
    
    @example
    // Usage
  var myDPHA = new bcdui.core.DataProviderHtmlAttribute({ htmlElementId, attributeName });
  
  
    @example
    <div id="myDiv" attr="123"><div>
  <script type="text/javascript">
    var dp = new bcdui.core.DataProviderHtmlAttribute({ htmlElementId: 'myDiv', attributeName: 'attr'});
    dp.onceReady( () => console.log(dp.getData()) ); // -> '123'
  <script>
    @param {Type_DataProviderHtmlAttributeConstructor_Args} args
      ````js
      { htmlElementId, attributeName }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_DataProviderHtmlAttributeConstructor_Args);
}
export type Type_DataProviderHtmlAttributeConstructor_Args = {
    htmlElementId: string;
    attributeName: string;
};
import * as bcdui from "../exports.js";
