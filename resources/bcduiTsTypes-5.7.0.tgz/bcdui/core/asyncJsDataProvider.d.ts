/**
  @typedef {Object} Type_AsyncJsDataProviderConstructor_Args
  @property {function} callback   The callback providing the data; gets args object with 'setData' function to call once data is available.
  @property {string} [id]   A globally unique id for use in declarative contexts
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation, locally unique
  */
/**
  @class bcdui.core.AsyncJsDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AsyncJsDataProvider)
  @description Allows providing a js callback function for deferred execution which has to execute .setData(data) on provided instance once data is available.<p/>
As all DataProviders, AsyncJsDataProvider will not become ready until data is available, i.e. until the callback has delivered data for the first time.
This leaves the callback time to do asynchronous data requests against a server for example.
  
  @example
  // Usage
var myAJDP = new bcdui.core.AsyncJsDataProvider({ callback: myCbFunc });

@extends bcdui.core.DataProvider
*/
export class AsyncJsDataProvider extends bcdui.core.DataProvider {
    /**
    @description Allows providing a js callback function for deferred execution which has to execute .setData(data) on provided instance once data is available.<p/>
  As all DataProviders, AsyncJsDataProvider will not become ready until data is available, i.e. until the callback has delivered data for the first time.
  This leaves the callback time to do asynchronous data requests against a server for example.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AsyncJsDataProvider)
    
    @example
    // Usage
  var myAJDP = new bcdui.core.AsyncJsDataProvider({ callback: myCbFunc });
  
  @param {Type_AsyncJsDataProviderConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { callback, id?, name? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_AsyncJsDataProviderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AsyncJsDataProvider?id=setdata)
    @description   To be called by the callback once data is available. Sets data and transits this dataproviders state to .getReadyStatus() and fires data updated event
    @param {*} data
    @public
    @return {void}
    */
    public setData(data: any): void;
}
export type Type_AsyncJsDataProviderConstructor_Args = {
    /**
     * The callback providing the data; gets args object with 'setData' function to call once data is available.
     */
    callback: Function;
    /**
     * A globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation, locally unique
     */
    name?: string;
};
import * as bcdui from "../exports.js";
