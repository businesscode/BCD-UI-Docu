/**
  @typedef {Object} Type_JsDataProviderConstructor_Args
  @property {function} callback   The callback providing the data
  @property {boolean} [doAllwaysRefresh]   If true, each getData() calls the callback, otherwise only execute() will do.
  @property {string} [id]   Globally unique id for use in declarative contexts
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation, locally unique
  */
/**
  @class bcdui.core.JsDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.JsDataProvider)
  @description Allows providing a custom js callback function returning a value.
  
  @example
  // Usage
var myJDP = new bcdui.core.JsDataProvider({ callback: myCbFunc });

@extends bcdui.core.DataProvider
*/
export class JsDataProvider extends bcdui.core.DataProvider {
    /**
    @description Allows providing a custom js callback function returning a value.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.JsDataProvider)
    
    @example
    // Usage
  var myJDP = new bcdui.core.JsDataProvider({ callback: myCbFunc });
  
  @param {Type_JsDataProviderConstructor_Args} args   The parameter map contains the following properties:
      ````js
      { callback, doAllwaysRefresh?, id?, name? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_JsDataProviderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.JsDataProvider?id=getdata)
    @description   Access to the data of this DataProvider for read and modification access
    @overrides bcdui.core.DataProvider#getData
    @public
    @return {string} The text returned by the callback function
    */
    public getData(): string;
}
export type Type_JsDataProviderConstructor_Args = {
    /**
     * The callback providing the data
     */
    callback: Function;
    /**
     * If true, each getData() calls the callback, otherwise only execute() will do.
     */
    doAllwaysRefresh?: boolean;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation, locally unique
     */
    name?: string;
};
import * as bcdui from "../exports.js";
