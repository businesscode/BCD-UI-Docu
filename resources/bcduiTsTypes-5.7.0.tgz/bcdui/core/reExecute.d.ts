/**
@param {Object} obj   The abstract executable object which should be reexecuted
  @param {function} [readyFunction]   Function to be executed once on ready status
  @param {boolean} [shouldRefresh]   Set this parameter to "false" if this method should do nothing when the object is already in the ready status.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.reExecute)
  @description   Reexecutes the process implemented by the concrete sub-class.
  @method reExecute
@return {void}
  @memberOf bcdui.core
 */
export function reExecute(obj: Object, readyFunction?: Function, shouldRefresh?: boolean): void;
