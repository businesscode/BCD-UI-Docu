/**
  @typedef {Object} Type_RendererConstructor_Args
  @property {bcdui.core.DataProvider} inputModel   The model with the data to be transformed in html
  @property {chainDef} [chain="/bcdui/xslt/renderer/htmlBuilder.xslt"]  default="/bcdui/xslt/renderer/htmlBuilder.xslt"  The definition of the transformation chain
<ul>
  <li>Default is a WRS-to-table renderer, capable of row and column dimensions and aware of all Wrs format specifications like scale and &commat;caption</li>
  <li>But it can be a single string with the URL of the transformation XSLT or doTjs template</li>
  <li>or a JS transformator function</li>
  <li>or an array with a mixture of URLs and JS transformators</li>
  <li>or a DataProvider with an XML document following xsd http://www.businesscode.de/schema/bcdui/chain-1.0.0</li>
</ul>
Make sure the last transformation outputs html, for example in case of XSLT set the last stylesheet to &lt;xsl:output method="html"
  @property {targetHtmlRef} [targetHtml]   A reference to the HTML DOM Element where to put the output
  @property {Object} [parameters]   An object, where each property holds a DataProvider as a transformation parameter
Once this Renderer is {@link bcdui.core.AbstractExecutable#execute executed}, it will check each parameter and execute it if it is not {@link bcdui.core.AbstractExecutable .isReady()} before executing itself.
  @property {string} [id]   Globally unique id for use in declarative contexts
  @property {boolean} [suppressInitialRendering]   If true, the renderer does not initially auto execute but waits for an explicit execute
  @property {function} [postHtmlAttachProcess]   synchronous js function called after attaching html fragment to dom (either partitially or fully). Note: custom elements will not be applied, wait for isRead() if you need that
  */
/**
  @class bcdui.core.Renderer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Renderer)
  @description This class renders data to HTML, per default a table view of Wrs, but it does support any kind of input and HTML output when providing a `chain`.
A Renderer is started on page entry and makes asks its DataProviders to become ready and waits if necessary.
The chain represents the exact logic of the Renderer can be implemented as JavaScript functions or XSLTs,
default is htmlBuilder.xslt, which is ideal for showing Wrs tabular data.
  
  @example
  // Usage
var myRnd = new bcdui.core.Renderer({ inputModel: myModel });


  @example
  // Show the data on page load, applying any filer in $guiStatus/guiStatus:Status/f:Filter
const companiesModel = new bcdui.core.AutoModel({ bindingSetId: "Companies", bRefs: "id, name, address, country" });
const renderer = new bcdui.core.Renderer({ targetHtml: "#companiesDiv", inputModel: companiesModel });
  
  @example
  // Wait for country to be selected (mandatoryFilterBRefsSubset), and re-display the data whenever $guiStatus/guiStatus:Status/f:Filter changes (isAutoRefresh, onReady)
const companiesModel = new bcdui.core.AutoModel({
 bindingSetId: "Companies", bRefs: "id, name, address, country",
  mandatoryFilterBRefsSubset: "country",
  isAutoRefresh: true
});
const renderer = new bcdui.core.Renderer({
  targetHtml: "#companiesDiv",
  inputModel: companiesModel
});
companiesModel.onReady( () => renderer.execute(true) );
  @extends bcdui.core.TransformationChain
*/
export class Renderer extends bcdui.core.TransformationChain {
    /**
    @description This class renders data to HTML, per default a table view of Wrs, but it does support any kind of input and HTML output when providing a `chain`.
  A Renderer is started on page entry and makes asks its DataProviders to become ready and waits if necessary.
  The chain represents the exact logic of the Renderer can be implemented as JavaScript functions or XSLTs,
  default is htmlBuilder.xslt, which is ideal for showing Wrs tabular data.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Renderer)
    
    @example
    // Usage
  var myRnd = new bcdui.core.Renderer({ inputModel: myModel });
  
  
    @example
    // Show the data on page load, applying any filer in $guiStatus/guiStatus:Status/f:Filter
  const companiesModel = new bcdui.core.AutoModel({ bindingSetId: "Companies", bRefs: "id, name, address, country" });
  const renderer = new bcdui.core.Renderer({ targetHtml: "#companiesDiv", inputModel: companiesModel });
    
    @example
    // Wait for country to be selected (mandatoryFilterBRefsSubset), and re-display the data whenever $guiStatus/guiStatus:Status/f:Filter changes (isAutoRefresh, onReady)
  const companiesModel = new bcdui.core.AutoModel({
   bindingSetId: "Companies", bRefs: "id, name, address, country",
    mandatoryFilterBRefsSubset: "country",
    isAutoRefresh: true
  });
  const renderer = new bcdui.core.Renderer({
    targetHtml: "#companiesDiv",
    inputModel: companiesModel
  });
  companiesModel.onReady( () => renderer.execute(true) );
    @param {Type_RendererConstructor_Args} args   An argument object with the following properties:
      ````js
      { inputModel, chain?, targetHtml?, parameters?, id?, suppressInitialRendering?, postHtmlAttachProcess? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_RendererConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Renderer?id=execute)
    @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/>
  Executes the process implemented by the concrete sub-class
  This method is called by the Renderer when it is ready to render the model
  It is often asynchronous.
  Note, Renderer and sub-classes execute all input models recursively automatically.
  This means, usually you do not need to call this method directly. Note: it is asynchronous.
  Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
    @param {(boolean|Type_RendererExecute_Args)} args   either true for forced or parameter map
    @overrides bcdui.core.TransformationChain#execute
    @public
    @return {void}
    */
    public execute(args: (boolean | Type_RendererExecute_Args)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Renderer?id=gettargethtml)
    @description   Return the target html element where the renderer places its output
    @public
    @return {void}
    */
    public getTargetHtml(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.Renderer?id=settargethtml)
    @description   Sets the target html element where the renderer places its output
    @param {HtmlElement} targetHtmlElement   target html element
    @public
    @return {void}
    */
    public setTargetHtml(targetHtmlElement: HtmlElement): void;
}
export type Type_RendererConstructor_Args = {
    /**
     * The model with the data to be transformed in html
     */
    inputModel: bcdui.core.DataProvider;
    /**
     * default="/bcdui/xslt/renderer/htmlBuilder.xslt"  The definition of the transformation chain
    <ul>
    <li>Default is a WRS-to-table renderer, capable of row and column dimensions and aware of all Wrs format specifications like scale and &commat;caption</li>
    <li>But it can be a single string with the URL of the transformation XSLT or doTjs template</li>
    <li>or a JS transformator function</li>
    <li>or an array with a mixture of URLs and JS transformators</li>
    <li>or a DataProvider with an XML document following xsd http://www.businesscode.de/schema/bcdui/chain-1.0.0</li>
    </ul>
    Make sure the last transformation outputs html, for example in case of XSLT set the last stylesheet to &lt;xsl:output method="html"
     */
    chain?: chainDef;
    /**
     * A reference to the HTML DOM Element where to put the output
     */
    targetHtml?: targetHtmlRef;
    /**
     * An object, where each property holds a DataProvider as a transformation parameter
    Once this Renderer is {@link bcdui.core.AbstractExecutable#execute executed}, it will check each parameter and execute it if it is not {@link bcdui.core.AbstractExecutable.isReady ()} before executing itself.
     */
    parameters?: Object;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * If true, the renderer does not initially auto execute but waits for an explicit execute
     */
    suppressInitialRendering?: boolean;
    /**
     * synchronous js function called after attaching html fragment to dom (either partitially or fully). Note: custom elements will not be applied, wait for isRead() if you need that
     */
    postHtmlAttachProcess?: Function;
};
import * as bcdui from "../exports.js";
