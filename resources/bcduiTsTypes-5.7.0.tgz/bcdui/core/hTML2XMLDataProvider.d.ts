/**
  @typedef {Object} Type_HTML2XMLDataProviderConstructor_Args
  @property {string} id
  @property {string} name
  @property {(string|HtmlElement)} idOrElement
  */
/**
  @class bcdui.core.HTML2XMLDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.HTML2XMLDataProvider)
  
  @example
  // Usage
var myHTMLXMLDP = new bcdui.core.HTML2XMLDataProvider({ id, name, idOrElement });

@extends bcdui.core.DataProvider
*/
export class HTML2XMLDataProvider extends bcdui.core.DataProvider {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.HTML2XMLDataProvider)
    
    @example
    // Usage
  var myHTMLXMLDP = new bcdui.core.HTML2XMLDataProvider({ id, name, idOrElement });
  
  @param {Type_HTML2XMLDataProviderConstructor_Args} args
      ````js
      { id, name, idOrElement }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_HTML2XMLDataProviderConstructor_Args);
}
export type Type_HTML2XMLDataProviderConstructor_Args = {
    id: string;
    name: string;
    idOrElement: (string | HtmlElement);
};
import * as bcdui from "../exports.js";
