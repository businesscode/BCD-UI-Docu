/**
  @class bcdui.core.SimpleModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.SimpleModel)
  @description This class represents the standard case of a model where the data is loaded from a specified URL. Its document can be accessed
  via {@link bcdui.core.SimpleModel#getData myModel.getData()}. Javascript and {@link bcdui.core.Modelupdater Modelupdaters} can modify the data.
  Data loading is triggered by {@link bcdui.core.AbstractExecutable#execute myModel.execute()}
The constructor of the model takes only one property besides the mandatory
"id" property (defined in AbstractExecutable) in its args parameter map namely
the "url" property. It specifies the URL the XML document represented by this
model should be loaded from.
The parameter isAutoRefresh=true forces a reload if the DataProvider has changed.
If not text/plain, (derived or via mimeType), the data is parsed.
 <table>
   <tr><th>file extension</th><th>value</th><th>Result</th></tr>
   <tr><td>*.json</td><td>"application/json"</td><td>are turned into a js object</td></tr>
   <tr><td>*.js</td><td>"application/javascript"</td><td>are loaded and executed</td></tr>
   <tr><td>*.xml, .xsl, .xslt</td><td>"application/xml", "application/xslt+xml"</td><td>are parsed into DOM</td></tr>
 </table>
 All other content is just loaded as plain text.
  
  @example
  // Load plain content and use it in a renderer
var bookModel = new bcdui.core.SimpleModel( "../docs/allBooks.xml" );
var renderer  = new bcdui.core.Renderer({ targetHtml: "booksDiv", chain: "renderer.xslt", inputModel: bookModel });
  
  @example
  // Load a model using a Wrs request document from Wrs servlet
// Provide data as a {@link bcdui.core.DataProvider DataProvider}
var myModel = new bcdui.core.SimpleModel({ id: "dayModel", url: new bcdui.core.RequestDocumentDataProvider({ url: "requestDoc.xml"}) });
// Reference by id
bcdui.widgetNg.createSingleSelect({ targetHtml: "selectDayHtml", optionsModelXPath: "$dayModel/Values/V", targetModelXPath: "$guiStatus/guiStatus:Status/guiStatus:SelectedDay/@value" });
// Note: Only if using in plain JS, execute the model to load the data. Renderers and Widgets do that for you automatically.
myModel.onceReady({ executeIfNotReady: true, onSuccess: () => {
  var myVal = myModel.getData().selectSingleNode("/wrs:Wrs/wrs:Data/wrs:R[1]/wrs:C[3]").nodeValue;
  // ...
});
// Add a row and save it
myModel.tblInsert({author: 'Descartes', title: "Principles of Philosophy", year: "1644"});
myModel.sendData();
  @extends bcdui.core.AbstractUpdatableModel
*/
export class SimpleModel extends bcdui.core.AbstractUpdatableModel {
    /**
    @description This class represents the standard case of a model where the data is loaded from a specified URL. Its document can be accessed
    via {@link bcdui.core.SimpleModel#getData myModel.getData()}. Javascript and {@link bcdui.core.Modelupdater Modelupdaters} can modify the data.
    Data loading is triggered by {@link bcdui.core.AbstractExecutable#execute myModel.execute()}
  The constructor of the model takes only one property besides the mandatory
  "id" property (defined in AbstractExecutable) in its args parameter map namely
  the "url" property. It specifies the URL the XML document represented by this
  model should be loaded from.
  The parameter isAutoRefresh=true forces a reload if the DataProvider has changed.
  If not text/plain, (derived or via mimeType), the data is parsed.
   <table>
     <tr><th>file extension</th><th>value</th><th>Result</th></tr>
     <tr><td>*.json</td><td>"application/json"</td><td>are turned into a js object</td></tr>
     <tr><td>*.js</td><td>"application/javascript"</td><td>are loaded and executed</td></tr>
     <tr><td>*.xml, .xsl, .xslt</td><td>"application/xml", "application/xslt+xml"</td><td>are parsed into DOM</td></tr>
   </table>
   All other content is just loaded as plain text.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.SimpleModel)
    
    @example
    // Load plain content and use it in a renderer
  var bookModel = new bcdui.core.SimpleModel( "../docs/allBooks.xml" );
  var renderer  = new bcdui.core.Renderer({ targetHtml: "booksDiv", chain: "renderer.xslt", inputModel: bookModel });
    
    @example
    // Load a model using a Wrs request document from Wrs servlet
  // Provide data as a {@link bcdui.core.DataProvider DataProvider}
  var myModel = new bcdui.core.SimpleModel({ id: "dayModel", url: new bcdui.core.RequestDocumentDataProvider({ url: "requestDoc.xml"}) });
  // Reference by id
  bcdui.widgetNg.createSingleSelect({ targetHtml: "selectDayHtml", optionsModelXPath: "$dayModel/Values/V", targetModelXPath: "$guiStatus/guiStatus:Status/guiStatus:SelectedDay/@value" });
  // Note: Only if using in plain JS, execute the model to load the data. Renderers and Widgets do that for you automatically.
  myModel.onceReady({ executeIfNotReady: true, onSuccess: () => {
    var myVal = myModel.getData().selectSingleNode("/wrs:Wrs/wrs:Data/wrs:R[1]/wrs:C[3]").nodeValue;
    // ...
  });
  // Add a row and save it
  myModel.tblInsert({author: 'Descartes', title: "Principles of Philosophy", year: "1644"});
  myModel.sendData();
    @param {(string|SimpleModelParam)} args   An url for the data or an argument map {@link SimpleModelParam}
      */
    constructor(args: (string | SimpleModelParam));
    /**
       * The model was created but no {@link bcdui.core.SimpleModel#execute myModel.execute()} was called explicitly or by a DataProvider or Renderer, having this as an input.
       * @type {bcdui.core.Status}
       */
    initializedStatus: bcdui.core.Status;
    /**
       * Indicating the model is ready for access. Check via {@link bcdui.core.SimpleModel#isReady myModel.isReady()}
       * @type {bcdui.core.Status}
       */
    transformedStatus: bcdui.core.Status;
}
import * as bcdui from "../exports.js";
