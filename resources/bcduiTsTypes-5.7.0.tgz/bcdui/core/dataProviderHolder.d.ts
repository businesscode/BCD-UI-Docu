/**
  @typedef {Object} Type_DataProviderHolderConstructor_Args
  @property {bcdui.core.DataProvider} [source]   The data provider to be wrapped, unless set later via {@link bcdui.core.DataProviderHolder#setSource}
  */
/**
  @class bcdui.core.DataProviderHolder
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHolder)
  @description This acts as a holder for the real DataProvider and behaves like a DataProvider itself.
It is possible to instantiate this even without a source, we then only become ready, once a source was set and became ready.
Use this if a DataProvider or even its type is not known in the moment you need it as a parameter.
If we are executed, we pass through it directly or once out source is added later.
We mirror our source's state but reduce them to only initialized and loaded = ready.
  @extends bcdui.core.DataProvider
*/
export class DataProviderHolder extends bcdui.core.DataProvider {
    /**
    @description This acts as a holder for the real DataProvider and behaves like a DataProvider itself.
  It is possible to instantiate this even without a source, we then only become ready, once a source was set and became ready.
  Use this if a DataProvider or even its type is not known in the moment you need it as a parameter.
  If we are executed, we pass through it directly or once out source is added later.
  We mirror our source's state but reduce them to only initialized and loaded = ready.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHolder)
    @param {Type_DataProviderHolderConstructor_Args} [args]   The argument map
      ````js
      { source? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @param {string} [id]   id
      */
    constructor(args?: Type_DataProviderHolderConstructor_Args, id?: string);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHolder?id=query)
    @description   Reads a single node from a given xPath
    @param {string} xPath   xPath to query
    @overrides bcdui.core.DataProvider#query
    @public
    @return {(DomNode|null)} single node or null if query fails or source isn't set yet
    */
    public query(xPath: string): (DomNode | null);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHolder?id=querynodes)
    @description   Get node list from a given xPath
    @param {string} xPath   xPath to query
    @overrides bcdui.core.DataProvider#queryNodes
    @public
    @return {Array.<DomNode>} node list or empty list if query fails or source isn't set yet
    */
    public queryNodes(xPath: string): Array<DomNode>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderHolder?id=setsource)
    @description   Set the underlying source delayed instead of via the constructor.
  The DataProviderHolder does only become ready after the source was set and is or becomes ready.
    @public
    @return {void}
    */
    public setSource(): void;
}
export type Type_DataProviderHolderConstructor_Args = {
    /**
     * The data provider to be wrapped, unless set later via {@link bcdui.core.DataProviderHolder#setSource}
     */
    source?: bcdui.core.DataProvider;
};
import * as bcdui from "../exports.js";
