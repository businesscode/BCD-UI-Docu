/**
  @typedef {Object} Type_ModelUpdaterConstructor_Args
  @property {chainDef} chain   The definition of the transformation chain
<ul>
  <li>a single string with the URL of the transformation XSLT or doTjs template</li>
  <li>or a JS transformator function</li>
  <li>or an array with a mixture of URLs and JS transformators</li>
  <li>or a DataProvider with an XML document following xsd http://www.businesscode.de/schema/bcdui/chain-1.0.0</li>
</ul>
  @property {bcdui.core.DataProvider} targetModel   The model to be transformed and replaced
  @property {Object} [parameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
Once this ModelUpdater is {@link bcdui.core.AbstractExecutable#execute executed}, it will check each parameter and execute it, if it is not {@link bcdui.core.AbstractExecutable#isReady .isReady()}
  @property {boolean} [autoUpdate=true]  default=true  A boolean value indicating if the ModelUpdater should run on every change in the targetModel. Can be a data modification event or if targetModel again reaches the ready status. If autoUpdate is false a model updater only runs when the targetModel is (re)executed.
  @property {string} [id]   Globally unique id for use in declarative contexts
  */
/**
  @class bcdui.core.ModelUpdater
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ModelUpdater)
  @description A concrete subclass of {@link bcdui.core.TransformationChain TransformationChain}, replacing its targetModel's content with the result of the transformation applied to it.
Can be applied to all concrete subclasses of {@link bcdui.core.AbstractUpdatableModel AbstractUpdatableModel},
like {@link bcdui.core.StaticModel StaticModel} or {@link bcdui.core.SimpleModel SimpleModel}
Technically, this is a bcdui.core.TransformationChain object but it should not be executed, fired, modified or read from directly.
  
  @example
  // Usage
var myMU = new bcdui.core.ModelUpdater({ chain: ["myRenderer.xslt", finalCleanupFunc], targetModel });


  @example
  // Example for a default value for the GuiStatus: If no filter is set, limit the id range
 new bcdui.core.ModelUpdater({ targetModel: bcdui.wkModels.guiStatus , autoUpdate: false,
   chain: function guiStatusFilter(guiStatusDataDoc) {
     if( guiStatusDataDoc.selectSingleNode("/guiStatus:Status/f:Filter" ) === null) {
       bcdui.core.createElementWithPrototype(guiStatusDataDoc, "/guiStatus:Status/f:Filter/f:Expression[@bRef='id' and @op='>=' and @value='1030000']");
       bcdui.core.createElementWithPrototype(guiStatusDataDoc, "/guiStatus:Status/f:Filter/f:Expression[@bRef='id' and @op='<=' and @value='1030125']");
     }
   }
 });
  @extends bcdui.core.TransformationChain
*/
export class ModelUpdater extends bcdui.core.TransformationChain {
    /**
    @description A concrete subclass of {@link bcdui.core.TransformationChain TransformationChain}, replacing its targetModel's content with the result of the transformation applied to it.
  Can be applied to all concrete subclasses of {@link bcdui.core.AbstractUpdatableModel AbstractUpdatableModel},
  like {@link bcdui.core.StaticModel StaticModel} or {@link bcdui.core.SimpleModel SimpleModel}
  Technically, this is a bcdui.core.TransformationChain object but it should not be executed, fired, modified or read from directly.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ModelUpdater)
    
    @example
    // Usage
  var myMU = new bcdui.core.ModelUpdater({ chain: ["myRenderer.xslt", finalCleanupFunc], targetModel });
  
  
    @example
    // Example for a default value for the GuiStatus: If no filter is set, limit the id range
   new bcdui.core.ModelUpdater({ targetModel: bcdui.wkModels.guiStatus , autoUpdate: false,
     chain: function guiStatusFilter(guiStatusDataDoc) {
       if( guiStatusDataDoc.selectSingleNode("/guiStatus:Status/f:Filter" ) === null) {
         bcdui.core.createElementWithPrototype(guiStatusDataDoc, "/guiStatus:Status/f:Filter/f:Expression[@bRef='id' and @op='>=' and @value='1030000']");
         bcdui.core.createElementWithPrototype(guiStatusDataDoc, "/guiStatus:Status/f:Filter/f:Expression[@bRef='id' and @op='<=' and @value='1030125']");
       }
     }
   });
    @param {Type_ModelUpdaterConstructor_Args} args   An argument object with the following properties:
      ````js
      { chain, targetModel, parameters?, autoUpdate?, id? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ModelUpdaterConstructor_Args);
}
export type Type_ModelUpdaterConstructor_Args = {
    /**
     * The definition of the transformation chain
    <ul>
    <li>a single string with the URL of the transformation XSLT or doTjs template</li>
    <li>or a JS transformator function</li>
    <li>or an array with a mixture of URLs and JS transformators</li>
    <li>or a DataProvider with an XML document following xsd http://www.businesscode.de/schema/bcdui/chain-1.0.0</li>
    </ul>
     */
    chain: chainDef;
    /**
     * The model to be transformed and replaced
     */
    targetModel: bcdui.core.DataProvider;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
    Once this ModelUpdater is {@link bcdui.core.AbstractExecutable#execute executed}, it will check each parameter and execute it, if it is not {@link bcdui.core.AbstractExecutable#isReady .isReady()}
     */
    parameters?: Object;
    /**
     * default=true  A boolean value indicating if the ModelUpdater should run on every change in the targetModel. Can be a data modification event or if targetModel again reaches the ready status. If autoUpdate is false a model updater only runs when the targetModel is (re)executed.
     */
    autoUpdate?: boolean;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
};
import * as bcdui from "../exports.js";
