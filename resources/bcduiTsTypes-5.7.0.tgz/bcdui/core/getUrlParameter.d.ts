/**
@param {string} url   The URL containing the parameter.
  @param {string} parameterName   The parameter name.
  @param {string} [defaultValue]   The default value when the result would be null.
If not specified it returns null if the parameter is not found.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.getUrlParameter)
  @description   Extracts the value of a parameter definition from the URL. For example if
the URL is "http://myHost/myApp/myReport.jsp?guiStatusGZ=abc" and the
parameterName is "guiStatusGZ" the return value is "abc".
  @method getUrlParameter

  @example
  // Usage
var ret = bcdui.core.getUrlParameter( url, parameterName );

@return {string}  The value of the parameter or the default value (usually NULL)
if the parameter is empty or not found.
@memberOf bcdui.core
 */
export function getUrlParameter(url: string, parameterName: string, defaultValue?: string): string;
