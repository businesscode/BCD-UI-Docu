/**
  @class bcdui.core.AbstractUpdatableModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractUpdatableModel)
  @description This is the base class for Model classes which support the usage of {@link bcdui.core.ModelUpdater ModelUpdaters}.
Model updaters are executed on each data modification event.
  @description This class is abstract and not meant to be instantiated directly
  @extends bcdui.core.DataProvider
*/
export class AbstractUpdatableModel extends bcdui.core.DataProvider {
    /**
    @description This is the base class for Model classes which support the usage of {@link bcdui.core.ModelUpdater ModelUpdaters}.
  Model updaters are executed on each data modification event.
    @description This class is abstract and not meant to be instantiated directly
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AbstractUpdatableModel)
      */
    constructor();
}
import * as bcdui from "../exports.js";
