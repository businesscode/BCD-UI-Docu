/**
  @class bcdui.core.DataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider)
  @description A data provider is an abstract class on top of the {@link bcdui.core.AbstractExecutable},
extending it by data-related functions (like getName, getData, data modification events).
The name is filled with the id by default or set from the "name" argument.
getData() is abstract and must be provided by sub-classes.

<br/>Most common implementations are:
{@link bcdui.core.StaticModel} &bull;
{@link bcdui.core.SimpleModel} &bull;
{@link bcdui.core.ModelWrapper}

<br/>Further implementations:
{@link bcdui.core.AsyncJsDataProvider} &bull;
{@link bcdui.core.StringDataProvider} &bull;
{@link bcdui.core.DataProviderHtmlAttribute} &bull;
{@link bcdui.core.RequestDocumentDataProvider} &bull;
{@link bcdui.core.DataProviderWithXPathNodes} &bull;
{@link bcdui.core.DataProviderWithXPath} &bull;
{@link bcdui.core.DataProviderHolder} &bull;
{@link bcdui.core.DataProviderAlias} &bull;
{@link bcdui.core.ConstantDataProvider} &bull;
{@link bcdui.core.PromptDataProvider}
  @description Calls the initializer of {@link bcdui.core.AbstractExecutable} and additionally sets
the name property. This property is filled from the "args" parameter
map or set to the "id" if there is no "args.name" value in the map.
<p>
  In contrast to the id property the name does not need to be globally unique,
  Instead, it should be unique within the scope it is used for. For example
  if the data provider is passed to a {@link bcdui.core.TransformationChain} the name should
  be unique for within this TransformationChain object.
</p>
  @extends bcdui.core.AbstractExecutable
*/
export class DataProvider extends bcdui.core.AbstractExecutable {
    /**
    @description A data provider is an abstract class on top of the {@link bcdui.core.AbstractExecutable},
  extending it by data-related functions (like getName, getData, data modification events).
  The name is filled with the id by default or set from the "name" argument.
  getData() is abstract and must be provided by sub-classes.
  
  <br/>Most common implementations are:
  {@link bcdui.core.StaticModel} &bull;
  {@link bcdui.core.SimpleModel} &bull;
  {@link bcdui.core.ModelWrapper}
  
  <br/>Further implementations:
  {@link bcdui.core.AsyncJsDataProvider} &bull;
  {@link bcdui.core.StringDataProvider} &bull;
  {@link bcdui.core.DataProviderHtmlAttribute} &bull;
  {@link bcdui.core.RequestDocumentDataProvider} &bull;
  {@link bcdui.core.DataProviderWithXPathNodes} &bull;
  {@link bcdui.core.DataProviderWithXPath} &bull;
  {@link bcdui.core.DataProviderHolder} &bull;
  {@link bcdui.core.DataProviderAlias} &bull;
  {@link bcdui.core.ConstantDataProvider} &bull;
  {@link bcdui.core.PromptDataProvider}
    @description Calls the initializer of {@link bcdui.core.AbstractExecutable} and additionally sets
  the name property. This property is filled from the "args" parameter
  map or set to the "id" if there is no "args.name" value in the map.
  <p>
    In contrast to the id property the name does not need to be globally unique,
    Instead, it should be unique within the scope it is used for. For example
    if the data provider is passed to a {@link bcdui.core.TransformationChain} the name should
    be unique for within this TransformationChain object.
  </p>
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider)
    @param {object} args
      */
    constructor(args: object);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=debugiswaitingfor)
    @public
    @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
    */
    public debugIsWaitingFor(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=debugstatus)
    @public
    @return {string} Human readable message about the current state state
    */
    public debugStatus(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=fetchdata)
    @description   asynchronously fetch data for this data provider.
    @public
    @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
    */
    public fetchData(): Promise<bcdui.core.DataProvider>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=fire)
    @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completed
  and data is consistent again.
    @public
    @return {void}
    */
    public fire(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getdata)
    @description   Access to the data of this DataProvider for read and modification access
    @public
    @return {*} The data provided by the specific sub-class.
    */
    public getData(): any;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getname)
    @description   Getter for the name of the data provider. This name is for example used
  to set parameters names of a {@link bcdui.core.TransformationChain}.
    @public
    @return {string} The name of the data provider. This name should be unique
  within the scope it is used and is usually not globally unique (as the id).
    */
    public getName(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=isclean)
    @description   True, if DataProvider is ready and there are no uncommitted write transactions,
  see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
    @public
    @return {boolean}
    */
    public isClean(): boolean;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=onchange)
    @param {(function|OnChangeParam)} listenerObject   Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
    @param {string} [trackingXPath]   xPath to monitor to monitor for changes
    @public
    @return {void}
    */
    public onChange(listenerObject: (Function | OnChangeParam), trackingXPath?: string): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=promptdata)
    @description   Convenience method for debugging showing data in a prompt for copy-and-paste
    @public
    @return {void}
    */
    public promptData(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=query)
    @description   Reads a single node from a given xPath
    @param {string} xPath   xPath to query
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @public
    @return {(DomNode|null)} single node or null if query fails
    */
    public query(xPath: string, fillParams?: Object): (DomNode | null);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=querynodes)
    @description   Get node list from a given xPath
    @param {string} xPath   xPath to query
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @public
    @return {Array.<DomNode>} node list or empty list if query fails
    */
    public queryNodes(xPath: string, fillParams?: Object): Array<DomNode>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=read)
    @description   Reads the string value from a given xPath (or optionally return default value).
    @param {string} xPath   xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @param {string} [defaultValue]   default value in case xPath value does not exist
    @public
    @return {string} text value stored at xPath (or null if no text was found and no defaultValue supplied)
    */
    public read(xPath: string, fillParams?: Object, defaultValue?: string): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=remove)
    @description   Deletes data at a given xPath from the model
    @param {string} xPath   xPath pointing to the value
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @param {boolean} [fire]   if true a fire is triggered to notify data modification listener
    @public
    @return {void}
    */
    public remove(xPath: string, fillParams?: Object, fire?: boolean): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=removedatalistener)
    @param {(string|function|RemoveDataListenerParam)} listenerObject   Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
    @public
    @return {void}
    */
    public removeDataListener(listenerObject: (string | Function | RemoveDataListenerParam)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=senddata)
    @description   Sends the current data to the original URL
    @public
    @return {void}
    */
    public sendData(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=serialize)
    @description   Serialize dataprovider's data if available
    @public
    @return {string} String containing the serialized data
    */
    public serialize(): string;
    /**
      @typedef {Object} Type_DataProviderTblDelete_Args
      @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
      @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
      @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
      @property {string} [rowId]   id specifying row which should be deleted (or use filter)
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tbldelete)
    @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
    @param {Type_DataProviderTblDelete_Args} args   parameter bag
      ````js
      { filter?, rmi?, fire?, rowId? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {number} count of removed rows
    */
    public tblDelete(args: {
        /**
         * object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
         */
        filter?: Object;
        /**
         * default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
         */
        rmi?: boolean;
        /**
         * default=true  lets the listeners know, that the update was finished
         */
        fire?: boolean;
        /**
         * id specifying row which should be deleted (or use filter)
         */
        rowId?: string;
    }): number;
    /**
      @typedef {Object} Type_DataProviderTblInsert_Args
      @property {Object} values   object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
      @property {boolean} [rmi=true]  default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
      @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblinsert)
    @description   inserts a new row in the wrs data, values given as object
    @param {Type_DataProviderTblInsert_Args} args   parameter bag
      ````js
      { values, rmi?, fire? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  var ret = myDP.tblInsert({ values });
  
  @return {string} row id of newly inserted row
    */
    public tblInsert(args: {
        /**
         * object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
         */
        values: Object;
        /**
         * default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
         */
        rmi?: boolean;
        /**
         * default=true  lets the listeners know, that the update was finished
         */
        fire?: boolean;
    }): string;
    /**
      @typedef {Object} Type_DataProviderTblSelect_Args
      @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
      @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblselect)
    @description   returns an array of requested data
    @param {Type_DataProviderTblSelect_Args} args   parameter bag
      ````js
      { filter?, columns? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {Array.<Object>} Array of objects holding the requested data
    */
    public tblSelect(args: {
        /**
         * object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
         */
        filter?: Object;
        /**
         * string array of requested columns, if not given, all columns are returned
         */
        columns?: Array<string>;
    }): Array<Object>;
    /**
      @typedef {Object} Type_DataProviderTblSelectRow_Args
      @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
      @property {string} [rowId]   rowId of row which should be queried (or use filter)
      @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblselectrow)
    @description   returns one object representing the filtered data (either filter or rowId). In case of multiple filter matches, the first one is returned
    @param {Type_DataProviderTblSelectRow_Args} args   parameter bag
      ````js
      { filter?, rowId?, columns? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {Object} Array  of objects holding the requested data
    */
    public tblSelectRow(args: {
        /**
         * object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
         */
        filter?: Object;
        /**
         * rowId of row which should be queried (or use filter)
         */
        rowId?: string;
        /**
         * string array of requested columns, if not given, all columns are returned
         */
        columns?: Array<string>;
    }): Object;
    /**
      @typedef {Object} Type_DataProviderTblUpdate_Args
      @property {Object} values   object holding cell values which should be used for updating, e.g. { country: 'DE', flag: true }
      @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
      @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
      @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
      @property {string} [rowId]   id specifying row which should be updated (or use filter)
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblupdate)
    @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
    @param {Type_DataProviderTblUpdate_Args} args   parameter bag
      ````js
      { values, filter?, rmi?, fire?, rowId? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  var ret = myDP.tblUpdate({ values });
  
  @return {number} count of updated rows
    */
    public tblUpdate(args: {
        /**
         * object holding cell values which should be used for updating, e.g. { country: 'DE', flag: true }
         */
        values: Object;
        /**
         * object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
         */
        filter?: Object;
        /**
         * default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
         */
        rmi?: boolean;
        /**
         * default=true  lets the listeners know, that the update was finished
         */
        fire?: boolean;
        /**
         * id specifying row which should be updated (or use filter)
         */
        rowId?: string;
    }): number;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=write)
    @description   Set a value to on a certain xPath and create the xPath where necessary.
  This combines Element.evaluate() for a single node with creating the path where necessary.
  It will prefer extending an existing start-part over creating a second one.
  After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
    @param {string} xPath   xPath pointing to the node which is set to the value or plain xPath to be created if not there.
     It tries to reuse all matching parts that are already there. If you provide for example `/n:Root/n:MyElem/&commat;attr2` and there is already `/n:Root/n:MyElem/&commat;attr1`, then `/n:Root/n:MyElem` will be "re-used" and get an additional attribute attr2.
     Many expressions are allowed, for example `/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem` is also ok.
     By nature, some xPath expressions are not allowed, for example using '//' or `/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem` is obviously not unambiguous enough and will throw an error.
     This method is Wrs aware, use for example `/wrs:Wrs/wrs:Data/wrs:*[2]/wrs:C[3]` as xPath, and it will turn wrs:R[wrs:C] into wrs:M[wrs:C and wrs:O], see Wrs format.
     (can include dot template placeholders which get filled with the given fillParams)
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
      Example: `bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])`
    @param {string} [value]   Optional value which should be written, for example to `/n:Root/n:MyElem/&commat;attr` or with `/n:Root/n:MyElem` as the element's text content.
     If not provided, the xPath contains all values like in `/n:Root/n:MyElem[&commat;attr='a' and &commat;attr1='b']` or needs none like `/n:Root/n:MyElem`
    @param {boolean} [fire]   If true a fire is triggered to inform data modification listeners
    @public
    @return {DomNode} The xPath's node or null if dataProvider isn't ready
    */
    public write(xPath: string, fillParams?: Object, value?: string, fire?: boolean): DomNode;
    /**
           * @constant
           * @type {bcdui.core.Status}
           * @example
           * if( model.getStatus() === model.savedStatus )
           *   ...
           */
    savedStatus: bcdui.core.Status;
    /**
           * @constant
           * @type {bcdui.core.Status}
           */
    saveFailedStatus: bcdui.core.Status;
}
import * as bcdui from "../exports.js";
