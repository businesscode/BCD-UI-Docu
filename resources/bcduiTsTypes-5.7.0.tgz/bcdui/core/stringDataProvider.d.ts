/**
  @typedef {Object} Type_StringDataProviderConstructor_Args
  @property {string} value   The data
  @property {string} [id]   Globally unique id for use in declarative contexts
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation, locally unique
  */
/**
  @class bcdui.core.StringDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StringDataProvider)
  @description A StringDataProvider provides a plain string via getData()
  
  @example
  // Usage
var mySDP = new bcdui.core.StringDataProvider({ value });

@extends bcdui.core.DataProvider
*/
export class StringDataProvider extends bcdui.core.DataProvider {
    /**
    @description A StringDataProvider provides a plain string via getData()
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StringDataProvider)
    
    @example
    // Usage
  var mySDP = new bcdui.core.StringDataProvider({ value });
  
  @param {Type_StringDataProviderConstructor_Args} args
      ````js
      { value, id?, name? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_StringDataProviderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StringDataProvider?id=setdata)
    @description   Assign a new value
    @param {string} value   The new value
    @public
    @return {void}
    */
    public setData(value: string): void;
    /**
         * @constant
         * @type {bcdui.core.status.InitializedStatus}
         */
    initializedStatus: bcdui.core.status.InitializedStatus;
    /**
         * @type {bcdui.core.status.TransformedStatus}
         * @constant
         */
    transformedStatus: bcdui.core.status.TransformedStatus;
}
export type Type_StringDataProviderConstructor_Args = {
    /**
     * The data
     */
    value: string;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation, locally unique
     */
    name?: string;
};
import * as bcdui from "../exports.js";
