/**
  @typedef {Object} Type_PromptDataProviderConstructor_Args
  @property {string} [name]   Title provided to the user when the input box pops up.
  @property {string} [id]   Globally unique id for use in declarative contexts
  */
/**
  @class bcdui.core.PromptDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.PromptDataProvider)
  @description This is a data provider showing the user a prompt on each execute() and returning the value the user has entered. It is mainly intended for debugging.
  @extends bcdui.core.DataProvider
*/
export class PromptDataProvider extends bcdui.core.DataProvider {
    /**
    @description This is a data provider showing the user a prompt on each execute() and returning the value the user has entered. It is mainly intended for debugging.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.PromptDataProvider)
    @param {Type_PromptDataProviderConstructor_Args} args
      ````js
      { name?, id? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_PromptDataProviderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.PromptDataProvider?id=getdata)
    @description   Access to the data of this DataProvider for read and modification access
    @overrides bcdui.core.DataProvider#getData
    @public
    @return {string} The text the user has entered in the input dialog.
    */
    public getData(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.PromptDataProvider?id=getreadystatus)
    @description   Getter for the ready status of the instance. This status is a final state
  defined by each sub-class which is reached when the process has finished
  normally.
    @overrides bcdui.core.DataProvider#getReadyStatus
    @public
    @return {bcdui.core.status.NullStatus} The null status because since the value is provided in
  the constructor and is therefore always ready.
    */
    public getReadyStatus(): bcdui.core.status.NullStatus;
}
export type Type_PromptDataProviderConstructor_Args = {
    /**
     * Title provided to the user when the input box pops up.
     */
    name?: string;
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
};
import * as bcdui from "../exports.js";
