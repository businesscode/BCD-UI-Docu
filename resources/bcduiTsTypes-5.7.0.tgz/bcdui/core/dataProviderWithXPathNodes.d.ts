/**
  @typedef {Object} Type_DataProviderWithXPathNodesConstructor_Args
  @property {modelXPath} [xPath]   Data source like <code>"$modelId/guiStatus:MyNode/&commat;myAttr"</code>
  @property {bcdui.core.DataProvider} [source]   Optional source, which will override source reference from args.xPath
  @property {string} [name]   Logical name of this DataProvider when used as a parameter in a transformation
  */
/**
  @class bcdui.core.DataProviderWithXPathNodes
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderWithXPathNodes)
  @description This class creates a static model with a top level element '<Root/>' and appends all
 the elements that are found by xpath as children. Useful for be passing data as parameter to an XSLT transformation.
 See {@link bcdui.core.DataProviderWithXPath DataProviderWithXPath} for reading a single value as a string
  @extends bcdui.core.DataProviderHolder
*/
export class DataProviderWithXPathNodes extends bcdui.core.DataProviderHolder {
    /**
    @description This class creates a static model with a top level element '<Root/>' and appends all
   the elements that are found by xpath as children. Useful for be passing data as parameter to an XSLT transformation.
   See {@link bcdui.core.DataProviderWithXPath DataProviderWithXPath} for reading a single value as a string
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderWithXPathNodes)
    @param {Type_DataProviderWithXPathNodesConstructor_Args} args
      ````js
      { xPath?, source?, name? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_DataProviderWithXPathNodesConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProviderWithXPathNodes?id=getxpath)
    @public
    @return {string}
    */
    public getXPath(): string;
}
export type Type_DataProviderWithXPathNodesConstructor_Args = {
    /**
     * Data source like <code>"$modelId/guiStatus:MyNode/&commat;myAttr"</code>
     */
    xPath?: modelXPath;
    /**
     * Optional source, which will override source reference from args.xPath
     */
    source?: bcdui.core.DataProvider;
    /**
     * Logical name of this DataProvider when used as a parameter in a transformation
     */
    name?: string;
};
import * as bcdui from "../exports.js";
