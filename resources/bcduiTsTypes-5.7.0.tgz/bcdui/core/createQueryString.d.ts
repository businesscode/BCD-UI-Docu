/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.createQueryString)
  @description   encode parameters into a query-string
  @method createQueryString
@return {string}  the query string, with encoded parameters; this string does not start with '?'
@memberOf bcdui.core
 */
export function createQueryString(): string;
