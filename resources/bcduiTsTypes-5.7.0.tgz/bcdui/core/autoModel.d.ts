/**
  @typedef {Object} Type_AutoModelConstructorSaveOptions_Args
  @property {chainDef} [saveChain]   The definition of the transformation chain
  @property {Object} [saveParameters]   An object, where each property holds a DataProvider, used as a transformation parameters.
  @property {boolean} [reload]   Useful especially for models of type SimpleModel for refreshing from server after save
  @property {function} [onSuccess]   Callback after saving (and optionally reloading) was successfully finished
  @property {function} [onFailure]   Callback on failure, is called if error occurs
  @property {function} [onWrsValidationFailure]   Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
  @property {bcdui.core.DataProvider} [urlProvider]   DataProvider holding the request url (by default taken from the underlying simple model url)
  */
/**
  @typedef {Object} Type_AutoModelConstructor_Args
  @property {string} bindingSetId   Id of BindingSet to read from.
  @property {string} bRefs   Space separated list of bRefs to be loaded, also defines the order of columns.
  @property {string} [filterBRefs]   Space separated list of bRefs to be used from `$guiStatus/guiStatus:Status/f:Filter`, default is all.
  @property {string} [orderByBRefs]   Space separated list of bRefs that will be used to order the data. This ordering has a higher priority over possible auto ordering by useCaptions or isDistinct. A minus(-) sign at the end indicates descending sorting.
  @property {string} [initialFilterBRefs]   Space separated list of bRefs in `$guiStatus/guiStatus:Status/f:Filter` to be used as filters for very first request only. Filters are ignored for later requests or for isAutoRefresh=true.
  @property {string} [mandatoryFilterBRefsSubset]   Space separated subset of bRefs that needs to be set in any filter before the AutoModel gets data. Until available, no request will be run. Usefull if user needs to make selections first or you want to enforce a specific filter.
  @property {boolean} [isDistinct]   If true, a group-by across all columns is generated. Parameter .groupByBRefs is ignored in this case.
  @property {boolean} [useCaptions]   If true, &commat;bRef+'_caption' will be used as bRef for the caption.
  @property {modelXPath} [additionalFilterXPath]   Allows using additional filters (not part of `$guiStatus/guiStatus:Status/f:Filter`). The given xPath needs to point to the filter expression itself (f:And or f:Expression), not to for example f:Filter.
  @property {modelXPath} [additionalPassiveFilterXPath]   Allows using additional filters (not part of `$guiStatus/guiStatus:Status/f:Filter`), unlike 'additionalFilterXPath', this xPath is not monitored for changes.
  @property {number} [maxRows]   Optional, limits the request to n rows. Use distinct if you need a certain order.
  @property {string} [id]   Optional, a globally unique id for use in declarative contexts
  @property {boolean} [isAutoRefresh]   If true, will reload data when (filterBRefs in) `$guiStatus/guiStatus:Status/f:Filter` or any of additionalFilterXPath changes but not additionalPassiveFilterXPath
  @property {Object} [reqDocParameters]   Optional parameters for a custom request document builder.
  @property {Array.<string>} [reqDocChain=['wrs/requestDocumentBuilder.xslt']]  default=['wrs/requestDocumentBuilder.xslt']  Optional custom chain for request document builder.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatus]  default=bcdui.wkModels.guiStatus  the status model to resolve .filterBRefs against
  @property {bcdui.core.DataProvider} [statusModelEstablished]   the established status model to provide to ModelWrapper creating request document as 'statusModelEstablished' parameter
  @property {string} [groupByBRefs]   Space separated list of bRefs for grouping. Is not effective when using .isDistinct=true parameter.
  @property {(DomDocument|DomElement|string)} [filterElement]   custom filter element (f:And, f:Or, f:Not, f:Expression) in wrs-filter format, see filter-1.0.0.xsd
    or a string as required by {@link bcdui.wrs.wrsUtil.parseFilterExpression} `filterElement: 'ctr='DE' and (product='AMS' or product='WWS')`
    or the result of it `filterElement: bcdui.wrs.wrsUtil.parseFilterExpression(region='Asia' and ctr='${{}}', "People's Republic of China")`- note that this allows filling in values without escaping issues.
  @property {Type_AutoModelConstructorSaveOptions_Args} [saveOptions]   An object, with the following elements
    ````js
    { saveChain?, saveParameters?, reload?, onSuccess?, onFailure?, onWrsValidationFailure?, urlProvider? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  */
/**
  @class bcdui.core.AutoModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AutoModel)
  @description An AutoModel is an easy way for loading data from a BindingSet in many cases, using `$guiStatus/guiStatus:Status/f:Filter` per default.
At minimum just provide the BindingSet id and a list of bRefs.
To trigger a data re-load, prefer `args.isAutoRefresh` to whatch for changed f:Filters instead of `execute(true)`.
  
  @example
  // Usage
var myAM = new bcdui.core.AutoModel({ bindingSetId, bRefs });


  @example
  // Get a list of authors
let authors = new bcdui.core.AutoModel({ bindingSetId: 'books', bRefs: 'author', isDistinct: 'true' });
// Read values for bindingItems 'author', 'title' and 'year' from BindingSet 'books' for 'DE' from database
var am = new bcdui.core.AutoModel({ bindingSetId: "books", bRefs: "author title year", filterElement: "country='DE'" });
// Show data
let rnd = new bcdui.core.Renderer({inputModel: am, targetHtml: "#myDataDiv"});
// Read/write values with JavaScript from DataProvider
am.onceReady({ executeIfNotReady: true, onSuccess: () => {
  let descartesBooks = am.tblSelect({ filter: { author: "Descartes" }, columns: ['title', 'year'] });
  ...
  // Add a row and save it
  am.tblInsert({ values: {author: 'Descartes', title: "Principles of Philosophy", year: "1644"} });
  am.sendData();
}});
  @extends bcdui.core.SimpleModel
*/
export class AutoModel extends bcdui.core.SimpleModel {
    /**
    @description An AutoModel is an easy way for loading data from a BindingSet in many cases, using `$guiStatus/guiStatus:Status/f:Filter` per default.
  At minimum just provide the BindingSet id and a list of bRefs.
  To trigger a data re-load, prefer `args.isAutoRefresh` to whatch for changed f:Filters instead of `execute(true)`.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AutoModel)
    
    @example
    // Usage
  var myAM = new bcdui.core.AutoModel({ bindingSetId, bRefs });
  
  
    @example
    // Get a list of authors
  let authors = new bcdui.core.AutoModel({ bindingSetId: 'books', bRefs: 'author', isDistinct: 'true' });
  // Read values for bindingItems 'author', 'title' and 'year' from BindingSet 'books' for 'DE' from database
  var am = new bcdui.core.AutoModel({ bindingSetId: "books", bRefs: "author title year", filterElement: "country='DE'" });
  // Show data
  let rnd = new bcdui.core.Renderer({inputModel: am, targetHtml: "#myDataDiv"});
  // Read/write values with JavaScript from DataProvider
  am.onceReady({ executeIfNotReady: true, onSuccess: () => {
    let descartesBooks = am.tblSelect({ filter: { author: "Descartes" }, columns: ['title', 'year'] });
    ...
    // Add a row and save it
    am.tblInsert({ values: {author: 'Descartes', title: "Principles of Philosophy", year: "1644"} });
    am.sendData();
  }});
    @param {Type_AutoModelConstructor_Args} args   The parameter map contains the following properties. Most parameters only apply when using default wrq-stylesheet.
      ````js
      { bindingSetId, bRefs, filterBRefs?, orderByBRefs?, initialFilterBRefs?, mandatoryFilterBRefsSubset?, isDistinct?, useCaptions?, additionalFilterXPath?, additionalPassiveFilterXPath?, maxRows?, id?, isAutoRefresh?, reqDocParameters?, reqDocChain?, statusModel?, statusModelEstablished?, groupByBRefs?, filterElement?, saveOptions? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_AutoModelConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.AutoModel?id=destroy)
    @description   Destroys the AutoModel and all sub-objects
    @overrides bcdui.core.SimpleModel#destroy
    @public
    @return {void}
    */
    public destroy(): void;
}
export type Type_AutoModelConstructorSaveOptions_Args = {
    /**
     * The definition of the transformation chain
     */
    saveChain?: chainDef;
    /**
     * An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    saveParameters?: Object;
    /**
     * Useful especially for models of type SimpleModel for refreshing from server after save
     */
    reload?: boolean;
    /**
     * Callback after saving (and optionally reloading) was successfully finished
     */
    onSuccess?: Function;
    /**
     * Callback on failure, is called if error occurs
     */
    onFailure?: Function;
    /**
     * Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
     */
    onWrsValidationFailure?: Function;
    /**
     * DataProvider holding the request url (by default taken from the underlying simple model url)
     */
    urlProvider?: bcdui.core.DataProvider;
};
export type Type_AutoModelConstructor_Args = {
    /**
     * Id of BindingSet to read from.
     */
    bindingSetId: string;
    /**
     * Space separated list of bRefs to be loaded, also defines the order of columns.
     */
    bRefs: string;
    /**
     * Space separated list of bRefs to be used from `$guiStatus/guiStatus:Status/f:Filter`, default is all.
     */
    filterBRefs?: string;
    /**
     * Space separated list of bRefs that will be used to order the data. This ordering has a higher priority over possible auto ordering by useCaptions or isDistinct. A minus(-) sign at the end indicates descending sorting.
     */
    orderByBRefs?: string;
    /**
     * Space separated list of bRefs in `$guiStatus/guiStatus:Status/f:Filter` to be used as filters for very first request only. Filters are ignored for later requests or for isAutoRefresh=true.
     */
    initialFilterBRefs?: string;
    /**
     * Space separated subset of bRefs that needs to be set in any filter before the AutoModel gets data. Until available, no request will be run. Usefull if user needs to make selections first or you want to enforce a specific filter.
     */
    mandatoryFilterBRefsSubset?: string;
    /**
     * If true, a group-by across all columns is generated. Parameter .groupByBRefs is ignored in this case.
     */
    isDistinct?: boolean;
    /**
     * If true, &commat;bRef+'_caption' will be used as bRef for the caption.
     */
    useCaptions?: boolean;
    /**
     * Allows using additional filters (not part of `$guiStatus/guiStatus:Status/f:Filter`). The given xPath needs to point to the filter expression itself (f:And or f:Expression), not to for example f:Filter.
     */
    additionalFilterXPath?: modelXPath;
    /**
     * Allows using additional filters (not part of `$guiStatus/guiStatus:Status/f:Filter`), unlike 'additionalFilterXPath', this xPath is not monitored for changes.
     */
    additionalPassiveFilterXPath?: modelXPath;
    /**
     * Optional, limits the request to n rows. Use distinct if you need a certain order.
     */
    maxRows?: number;
    /**
     * Optional, a globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * If true, will reload data when (filterBRefs in) `$guiStatus/guiStatus:Status/f:Filter` or any of additionalFilterXPath changes but not additionalPassiveFilterXPath
     */
    isAutoRefresh?: boolean;
    /**
     * Optional parameters for a custom request document builder.
     */
    reqDocParameters?: Object;
    /**
     * default=['wrs/requestDocumentBuilder.xslt']  Optional custom chain for request document builder.
     */
    reqDocChain?: Array<string>;
    /**
     * default=bcdui.wkModels.guiStatus  the status model to resolve .filterBRefs against
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * the established status model to provide to ModelWrapper creating request document as 'statusModelEstablished' parameter
     */
    statusModelEstablished?: bcdui.core.DataProvider;
    /**
     * Space separated list of bRefs for grouping. Is not effective when using .isDistinct=true parameter.
     */
    groupByBRefs?: string;
    /**
     * custom filter element (f:And, f:Or, f:Not, f:Expression) in wrs-filter format, see filter-1.0.0.xsd
    or a string as required by {@link bcdui.wrs.wrsUtil.parseFilterExpression} `filterElement: 'ctr='DE' and (product='AMS' or product='WWS')`
    or the result of it `filterElement: bcdui.wrs.wrsUtil.parseFilterExpression(region='Asia' and ctr='${{}}', "People's Republic of China")`- note that this allows filling in values without escaping issues.
     */
    filterElement?: (DomDocument | DomElement | string);
    /**
     * An object, with the following elements
     * ````js
     * { saveChain?, saveParameters?, reload?, onSuccess?, onFailure?, onWrsValidationFailure?, urlProvider? }
     * ````
     * <br/>Use autocomplete in {} to get a full parameter description <br/>
     */
    saveOptions?: Type_AutoModelConstructorSaveOptions_Args;
};
import * as bcdui from "../exports.js";
