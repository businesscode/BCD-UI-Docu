/**
  @typedef {Object} Type_ConstantDataProviderConstructor_Args
  @property {string} [id]   Globally unique id for use in declarative contexts
  @property {string} [name]   The name of the data provider. This name should be unique within the scopt it is used, however it is not required to globally unique
  @property {(string|number|boolean|object)} value   The data
  */
/**
  @class bcdui.core.ConstantDataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ConstantDataProvider)
  @description A data provider for constant values. This is especially useful to set values for the xsl:param elements of a {@link bcdui.core.TransformationChain TransformationChain} subclass.
  
  @example
  // Usage
var myCDP = new bcdui.core.ConstantDataProvider({ value });

@extends bcdui.core.DataProvider
*/
export class ConstantDataProvider extends bcdui.core.DataProvider {
    /**
    @description A data provider for constant values. This is especially useful to set values for the xsl:param elements of a {@link bcdui.core.TransformationChain TransformationChain} subclass.
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ConstantDataProvider)
    
    @example
    // Usage
  var myCDP = new bcdui.core.ConstantDataProvider({ value });
  
  @param {Type_ConstantDataProviderConstructor_Args} args   paramater map
      ````js
      { id?, name?, value }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ConstantDataProviderConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ConstantDataProvider?id=getreadystatus)
    @description   Getter for the ready status of the instance. This status is a final state
  defined by each sub-class which is reached when the process has finished
  normally.
    @overrides bcdui.core.DataProvider#getReadyStatus
    @public
    @return {bcdui.core.status.NullStatus} The null status because since the value is provided in
  the constructor and is therefore always ready.
    */
    public getReadyStatus(): bcdui.core.status.NullStatus;
}
export type Type_ConstantDataProviderConstructor_Args = {
    /**
     * Globally unique id for use in declarative contexts
     */
    id?: string;
    /**
     * The name of the data provider. This name should be unique within the scopt it is used, however it is not required to globally unique
     */
    name?: string;
    /**
     * The data
     */
    value: (string | number | boolean | object);
};
import * as bcdui from "../exports.js";
