/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.lifecycle.switchToMainUrl)
  @description
  @method switchToMainUrl
@return {void}
  @memberOf bcdui.core.lifecycle
 */
export function switchToMainUrl(): void;
