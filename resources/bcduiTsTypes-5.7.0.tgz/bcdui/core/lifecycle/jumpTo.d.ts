/**
@param {string} href   target URL to jump to.
  @param {DomDocument} [statusDocument]   status document to pass as guiStatusGZ parameter to href.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.lifecycle.jumpTo)
  @description   Jumps to another url optionally setting status document, this function is executed asynchronously.
  @method jumpTo
@return {void}
  @memberOf bcdui.core.lifecycle
 */
export function jumpTo(href: string, statusDocument?: DomDocument): void;
