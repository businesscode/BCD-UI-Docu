/**
  @typedef {Object} Type_LifecycleBookmarkAction_Args
  @property {Object} [proposedName=document.title]  default=document.title  Name of the bookmark
  @property {Object} [cleanClientSettings=true]  default=true  True or false whether or not to clean /guiStatus:Status/guiStatus:ClientSettings from the $guiStatus
  @property {Object} [cleanXPath]   Additional XPath to be cleaned from the guiStatus, useful for removing current period filter for example
  */
/**
@param {Type_LifecycleBookmarkAction_Args} args
  ````js
  { proposedName?, cleanClientSettings?, cleanXPath? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.lifecycle.bookmarkAction)
@description   Creates a bookmark entry for the current page + guiStatus
@method bookmarkAction
@return {void}
@memberOf bcdui.core.lifecycle
*/
export function bookmarkAction(args: Type_LifecycleBookmarkAction_Args): void;
export type Type_LifecycleBookmarkAction_Args = {
    /**
     * default=document.title  Name of the bookmark
     */
    proposedName?: Object;
    /**
     * default=true  True or false whether or not to clean /guiStatus:Status/guiStatus:ClientSettings from the $guiStatus
     */
    cleanClientSettings?: Object;
    /**
     * Additional XPath to be cleaned from the guiStatus, useful for removing current period filter for example
     */
    cleanXPath?: Object;
};
