/**
  @typedef {Object} Type_VisualizeXmlVisualizeModel_Args
  @property {targetHtmlRef} targetHtml   Id of the html element where to show the output.
  @property {string} [title]   Title of the content box; if not provided, the title is set to the ID of the visualized model.
  @property {string} [idRef]   Id of the model to be visualized
  @property {bcdui.core.DataProvider} [inputModel]   Instead of an id, the model can be provided directly
  @property {boolean} [isAutoRefresh=true]  default=true  Automatically redraw when model changes
  @property {string} [stylesheetUrl="/bcdui/js/widget/visualizeXml/visualizeXmlCaller.xslt"]  default="/bcdui/js/widget/visualizeXml/visualizeXmlCaller.xslt"  renderer stylesheet
  @property {function} [onReady]   onReady function for renderer
  */
/**
@param {Type_VisualizeXmlVisualizeModel_Args} args   The argument map containing the following elements:
  ````js
  { targetHtml, title?, idRef?, inputModel?, isAutoRefresh?, stylesheetUrl?, onReady? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.visualizeXml.visualizeModel)
@description   Visualiazes data of a model / data provider
@method visualizeModel

@example
// Usage
bcdui.widget.visualizeXml.visualizeModel({ targetHtml: "#myDiv" });


@example
// Load, transform and visualize a model
let sm = new bcdui.core.SimpleModel("input.xml");
let mw = new bcdui.core.ModelWrapper({inputModel: sm, chain: "transformer.xslt"});
bcdui.widget.visualizeXml.visualizeModel({targetHtml: "testOutput", inputModel: mw, title: "Transformed Output"});
@return {void}
@memberOf bcdui.widget.visualizeXml
*/
export function visualizeModel(args: Type_VisualizeXmlVisualizeModel_Args): void;
export type Type_VisualizeXmlVisualizeModel_Args = {
    /**
     * Id of the html element where to show the output.
     */
    targetHtml: targetHtmlRef;
    /**
     * Title of the content box; if not provided, the title is set to the ID of the visualized model.
     */
    title?: string;
    /**
     * Id of the model to be visualized
     */
    idRef?: string;
    /**
     * Instead of an id, the model can be provided directly
     */
    inputModel?: bcdui.core.DataProvider;
    /**
     * default=true  Automatically redraw when model changes
     */
    isAutoRefresh?: boolean;
    /**
     * default="/bcdui/js/widget/visualizeXml/visualizeXmlCaller.xslt"  renderer stylesheet
     */
    stylesheetUrl?: string;
    /**
     * onReady function for renderer
     */
    onReady?: Function;
};
import * as bcdui from "../../exports.js";
