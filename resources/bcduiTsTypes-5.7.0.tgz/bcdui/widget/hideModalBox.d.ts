/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.hideModalBox)
  @description   Hide opened modalbox
  @method hideModalBox
@return {void}
  @memberOf bcdui.widget
 */
export function hideModalBox(): void;
