/**
  @typedef {Object} Type_WidgetShowModalBox_Args
  @property {string} [title]   Modal box title. You can also use titleTranslate.
  @property {string} [titleTranslate]   It will be used as i18n key to translate the title.
  @property {string} [message]   Modal box message. You can also use messageTranslate.
  @property {string} [messageTranslate]   It will be used as i18n key to translate the message.
  @property {integer} [modalBoxType]   One of three types modalBoxTypes.ok, modalBoxTypes.warning, modalBoxTypes.error. By default = modalBoxTypes.ok
  @property {integer} [width=300]  default=300  Width of modal box. 300 by default
  @property {integer} [height]   Height of modal box. auto by default
  @property {string} [onclick]   Optional js function which is called after closing the modal box
  @property {string} [position]   jQuery position parameter bag. Default is center top
  @property {string} [htmlElementId]   Id of a html segment which is taken as messagebox instead. ModalBoxType is ignored in this case.
  */
/**
@param {Type_WidgetShowModalBox_Args} args   The parameter map contains the following properties.
  ````js
  { title?, titleTranslate?, message?, messageTranslate?, modalBoxType?, width?, height?, onclick?, position?, htmlElementId? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.showModalBox)
@description   Open and show modalbox
@method showModalBox
@return {void}
@memberOf bcdui.widget
*/
export function showModalBox(args: Type_WidgetShowModalBox_Args): void;
export type Type_WidgetShowModalBox_Args = {
    /**
     * Modal box title. You can also use titleTranslate.
     */
    title?: string;
    /**
     * It will be used as i18n key to translate the title.
     */
    titleTranslate?: string;
    /**
     * Modal box message. You can also use messageTranslate.
     */
    message?: string;
    /**
     * It will be used as i18n key to translate the message.
     */
    messageTranslate?: string;
    /**
     * One of three types modalBoxTypes.ok, modalBoxTypes.warning, modalBoxTypes.error. By default = modalBoxTypes.ok
     */
    modalBoxType?: integer;
    /**
     * default=300  Width of modal box. 300 by default
     */
    width?: integer;
    /**
     * Height of modal box. auto by default
     */
    height?: integer;
    /**
     * Optional js function which is called after closing the modal box
     */
    onclick?: string;
    /**
     * jQuery position parameter bag. Default is center top
     */
    position?: string;
    /**
     * Id of a html segment which is taken as messagebox instead. ModalBoxType is ignored in this case.
     */
    htmlElementId?: string;
};
