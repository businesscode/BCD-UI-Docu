/**
  @typedef {Object} Type_NotificatorConstructor_Args
  @property {integer} [retainMessagesNumber=5]  default=5  number of messages to retain in viewable area
  @property {boolean} [attachMouseHandler]   if true, the mousehover/unhover will close the box
  @property {integer} [autoHideMs]   if greater 0, the box will autohide after that amount of ms, otherwise the box has to be closed manually
  */
/**
  @class bcdui.widget.notifications.Notificator
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator)
  @description Notificator component displaying user notifications
  */
export class Notificator {
    /**
    @description Notificator component displaying user notifications
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator)
    @param {Type_NotificatorConstructor_Args} args   Parameter object
      ````js
      { retainMessagesNumber?, attachMouseHandler?, autoHideMs? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_NotificatorConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator?id=addmessage)
    @description   adds a message to notificator and displays notificator if appropriate
    @param {string} message   The message you want to display
    @param {string} [type=INFO]   The type of the message, use WARN or INFO
    @param {string} [anchorId]   If given the message will contain a link to that anchor)
    @public
    @return {void}
    */
    public addMessage(message: string, type?: string, anchorId?: string): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator?id=displaynotificationbar)
    @description   displays notification bar rendering messages in the queue
    @public
    @return {void}
    */
    public displayNotificationBar(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator?id=hidenotificationbar)
    @description   hides notification bar
    @public
    @return {void}
    */
    public hideNotificationBar(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator?id=removeallmessages)
    @description   removes all messages and hides notification window
    @public
    @return {void}
    */
    public removeAllMessages(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.notifications.Notificator?id=shownotificationbar)
    @description   shows notification bar
    @public
    @return {void}
    */
    public showNotificationBar(): void;
}
export type Type_NotificatorConstructor_Args = {
    /**
     * default=5  number of messages to retain in viewable area
     */
    retainMessagesNumber?: integer;
    /**
     * if true, the mousehover/unhover will close the box
     */
    attachMouseHandler?: boolean;
    /**
     * if greater 0, the box will autohide after that amount of ms, otherwise the box has to be closed manually
     */
    autoHideMs?: integer;
};
