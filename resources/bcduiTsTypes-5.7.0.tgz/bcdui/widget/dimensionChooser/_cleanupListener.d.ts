/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.dimensionChooser._cleanupListener)
  @description
  @method _cleanupListener
@return {void}
  @memberOf bcdui.widget.dimensionChooser
 */
export function _cleanupListener(): void;
