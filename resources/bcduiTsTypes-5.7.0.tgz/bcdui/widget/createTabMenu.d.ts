/**
  @typedef {Object} Type_WidgetCreateTabMenu_Args
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} defElementId   Html element id where tabs are defined.
  @property {string} [id]   ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [handlerJsClassName]   Custom JS class name to handler click action on tab.
  @property {string} [rendererUrl]   URL to custom renderer.
  @property {boolean} [isPersistent]   Set this to true to make the tab selection persistent.
  */
/**
@param {Type_WidgetCreateTabMenu_Args} args   The parameter map contains the following properties.
  ````js
  { targetHtml, defElementId, id?, handlerJsClassName?, rendererUrl?, isPersistent? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createTabMenu)
@description   Creates tab menu widget.
@method createTabMenu

@example
// Usage
bcdui.widget.createTabMenu({ targetHtml: "#myDiv", defElementId });

@return {void}
@memberOf bcdui.widget
*/
export function createTabMenu(args: Type_WidgetCreateTabMenu_Args): void;
export type Type_WidgetCreateTabMenu_Args = {
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * Html element id where tabs are defined.
     */
    defElementId: string;
    /**
     * ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
     */
    id?: string;
    /**
     * Custom JS class name to handler click action on tab.
     */
    handlerJsClassName?: string;
    /**
     * URL to custom renderer.
     */
    rendererUrl?: string;
    /**
     * Set this to true to make the tab selection persistent.
     */
    isPersistent?: boolean;
};
