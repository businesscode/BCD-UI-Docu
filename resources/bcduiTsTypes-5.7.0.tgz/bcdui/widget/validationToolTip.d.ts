/**
  @typedef {Object} Type_ValidationToolTipConstructor_Args
  @property {string} id   option widget identifier
  @property {string} targetModelId   identifier of model that should be tracked
  @property {xPath} targetModelXPath   xpath of model that should be tracked
  @property {DomElement} containerHtmlElement   html container with binded control
  @property {url} validateWrapperUrl   xstl transformation which implement concrete validation logic
  @property {object} validateWrapperParameters   parameters that should be passed to validateWrapper
  */
/**
  @class bcdui.widget.validationToolTip
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.validationToolTip)
  @description Tooltip for widget validation results
  @description Initializing tooltip widget
  
  @example
  // Usage
var myTT = new bcdui.widget.validationToolTip({ id, targetModelId, targetModelXPath: "$guiStatus/cust:Elem/@value", containerHtmlElement, validateWrapperUrl, validateWrapperParameters });

*/
export class validationToolTip {
    /**
    @description Tooltip for widget validation results
    @description Initializing tooltip widget
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.validationToolTip)
    
    @example
    // Usage
  var myTT = new bcdui.widget.validationToolTip({ id, targetModelId, targetModelXPath: "$guiStatus/cust:Elem/@value", containerHtmlElement, validateWrapperUrl, validateWrapperParameters });
  
  @param {Type_ValidationToolTipConstructor_Args} args
      ````js
      { id, targetModelId, targetModelXPath, containerHtmlElement, validateWrapperUrl, validateWrapperParameters }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_ValidationToolTipConstructor_Args);
}
export type Type_ValidationToolTipConstructor_Args = {
    /**
     * option widget identifier
     */
    id: string;
    /**
     * identifier of model that should be tracked
     */
    targetModelId: string;
    /**
     * xpath of model that should be tracked
     */
    targetModelXPath: xPath;
    /**
     * html container with binded control
     */
    containerHtmlElement: DomElement;
    /**
     * xstl transformation which implement concrete validation logic
     */
    validateWrapperUrl: url;
    /**
     * parameters that should be passed to validateWrapper
     */
    validateWrapperParameters: object;
};
