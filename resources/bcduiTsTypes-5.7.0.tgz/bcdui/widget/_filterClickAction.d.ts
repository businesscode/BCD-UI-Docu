/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget._filterClickAction)
  @description
  @method _filterClickAction
@return {void}
  @memberOf bcdui.widget
 */
export function _filterClickAction(): void;
