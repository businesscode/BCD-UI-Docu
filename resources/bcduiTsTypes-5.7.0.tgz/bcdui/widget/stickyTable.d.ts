/**
  @typedef {Object} Type_WidgetStickyTable_Args
  @property {HtmlElement} targetHtml   targetHtml containing/being table
  @property {string} [width]   the width of the table  (e.g. 10, 20px or 30em)
  @property {string} [height]   the height of the table (e.g. 10, 20px or 30em)
  @property {boolean} [header]   make header sticky
  @property {boolean} [footer]   make footer sticky
  @property {integer} [nFirstCols]   make the first n columns sticky
  @property {integer} [nFirstRows]   make the first n rows sticky
  @property {integer} [nLastCols]   make the last n columns sticky
  @property {integer} [nLastRows]   make the last n rows sticky
  @property {boolean} [bcdDimension]   make all dimension cells (cube) sticky (higher prio than other options)
  @property {boolean} [disableMaxWH]   setting this to true will use width/heigth instead of max-width/max-height
  */
/**
@param {Type_WidgetStickyTable_Args} args
  ````js
  { targetHtml, width?, height?, header?, footer?, nFirstCols?, nFirstRows?, nLastCols?, nLastRows?, bcdDimension?, disableMaxWH? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.stickyTable)
@description   make parts of the given table sticky
@method stickyTable

@example
// Usage
bcdui.widget.stickyTable({ targetHtml: "#myDiv" });

@return {void}
@memberOf bcdui.widget
*/
export function stickyTable(args: Type_WidgetStickyTable_Args): void;
export type Type_WidgetStickyTable_Args = {
    /**
     * targetHtml containing/being table
     */
    targetHtml: HtmlElement;
    /**
     * the width of the table  (e.g. 10, 20px or 30em)
     */
    width?: string;
    /**
     * the height of the table (e.g. 10, 20px or 30em)
     */
    height?: string;
    /**
     * make header sticky
     */
    header?: boolean;
    /**
     * make footer sticky
     */
    footer?: boolean;
    /**
     * make the first n columns sticky
     */
    nFirstCols?: integer;
    /**
     * make the first n rows sticky
     */
    nFirstRows?: integer;
    /**
     * make the last n columns sticky
     */
    nLastCols?: integer;
    /**
     * make the last n rows sticky
     */
    nLastRows?: integer;
    /**
     * make all dimension cells (cube) sticky (higher prio than other options)
     */
    bcdDimension?: boolean;
    /**
     * setting this to true will use width/heigth instead of max-width/max-height
     */
    disableMaxWH?: boolean;
};
