/**
@param {string} msgKey
  @param {string} defaultValue
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.i18nAlert)
  @description   shows a js alert box with the given message
  @method i18nAlert

  @example
  // Usage
bcdui.widget.i18nAlert( msgKey, defaultValue );

@return {void}
  @memberOf bcdui.widget
 */
export function i18nAlert(msgKey: string, defaultValue: string): void;
