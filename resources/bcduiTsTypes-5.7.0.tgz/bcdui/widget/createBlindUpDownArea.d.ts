/**
  @typedef {Object} Type_WidgetCreateBlindUpDownArea_Args
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [id]   ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [caption]   Caption shown in the blindUpDown Header.
  @property {string} [defaultState="closed"]  default="closed"  'closed' or empty String for opened, default is closed.
  @property {number} [duration=0.2]  default=0.2  The duration of the blind effect, valid values are from 0 to 1.0 as decimal.
  @property {writableModelXPath} [targetModelXPath="$guiStatus/guiStatus:Status/guiStatus:ClientSettings/BlindUpDown"]  default="$guiStatus/guiStatus:Status/guiStatus:ClientSettings/BlindUpDown"  The xPath pointing to the root-node this input widget will place entered selected items into. with attribute status=open/closed
  @property {boolean} [noEffect]   True for a simple show/hide without blind effect (blind can influence charts gradients on IE
  */
/**
@param {Type_WidgetCreateBlindUpDownArea_Args} args   The parameter map contains the following properties.
  ````js
  { targetHtml, id?, caption?, defaultState?, duration?, targetModelXPath?, noEffect? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createBlindUpDownArea)
@description   Creates a BlindUpDown Area.
@method createBlindUpDownArea

@example
// Usage
bcdui.widget.createBlindUpDownArea({ targetHtml: "#myDiv" });

@return {void}
@memberOf bcdui.widget
*/
export function createBlindUpDownArea(args: Type_WidgetCreateBlindUpDownArea_Args): void;
export type Type_WidgetCreateBlindUpDownArea_Args = {
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
     */
    id?: string;
    /**
     * Caption shown in the blindUpDown Header.
     */
    caption?: string;
    /**
     * default="closed"  'closed' or empty String for opened, default is closed.
     */
    defaultState?: string;
    /**
     * default=0.2  The duration of the blind effect, valid values are from 0 to 1.0 as decimal.
     */
    duration?: number;
    /**
     * default="$guiStatus/guiStatus:Status/guiStatus:ClientSettings/BlindUpDown"  The xPath pointing to the root-node this input widget will place entered selected items into. with attribute status=open/closed
     */
    targetModelXPath?: writableModelXPath;
    /**
     * True for a simple show/hide without blind effect (blind can influence charts gradients on IE
     */
    noEffect?: boolean;
};
