/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.formulaEditor.Parser.shunting_yard)
  @description   Parse a maths formula in input like "2+3*A" into a calc:Calc expression
If optionsModel and optionsModelXPath are given, only variable names (like A) are allowed which exist in the options model
  @method shunting_yard
@return {void}
  @memberOf bcdui.widget.formulaEditor.Parser
 */
export function shunting_yard(): void;
