/**
  @class bcdui.widget.DetachedEvent
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent)
  @description <p>
  This class represents a DOM event which can be stored for later use,
  especially in a timeout function. It encapsulates the event functionality
  provided by prototype.js, but it is not destroyed when the event has
  finished. Instead it can be kept to invoke the event handler later.
</p>
<p>
  A use case for this event object is for example a delayed tooltip
  appearing for example 200 ms after the mouse over event has occurred.
</p>
  */
export class DetachedEvent {
    /**
    @description <p>
    This class represents a DOM event which can be stored for later use,
    especially in a timeout function. It encapsulates the event functionality
    provided by prototype.js, but it is not destroyed when the event has
    finished. Instead it can be kept to invoke the event handler later.
  </p>
  <p>
    A use case for this event object is for example a delayed tooltip
    appearing for example 200 ms after the mouse over event has occurred.
  </p>
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent)
    @param {Event} event   The event object that should be the base for this
  object.
    @param {HtmlElement} [element]   The source element of the event if it should
  not be derived from the provided event.
    @param {HtmlElement} [endElement]   The optional end element for the findAttribute
  method. No attribute on of an ancestor of this element is returned by
  findAttribute.
      */
    constructor(event: Event, element?: HtmlElement, endElement?: HtmlElement);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent?id=element)
    @description   Getter for the event origin element.
    @public
    @return {HtmlElement} The element that caused the event.
    */
    public element(): HtmlElement;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent?id=findattribute)
    @description   A convenience wrapper for {@link bcdui.widget._findAttribute}.
    @public
    @return {void}
    */
    public findAttribute(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent?id=pointer)
    @description   Getter for the coordinates the event has been triggered at.
    @public
    @return {Object} An object in the form { x: ##, y: ## } holding the x and y position
  where the event has been triggered.
    */
    public pointer(): Object;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent?id=pointerx)
    @description   Getter for the X coordinate of the event.
    @public
    @return {integer} The X coordinate where the event has been triggered.
    */
    public pointerX(): integer;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.DetachedEvent?id=pointery)
    @description   Getter for the Y coordinate of the event.
    @public
    @return {integer} The Y coordinate where the event has been triggered.
    */
    public pointerY(): integer;
}
