/**
  @typedef {Object} Type_WidgetCreateTableHeadFilter_Args
  @property {HtmlElement} tableElement   The HTML Table Element which you want to use for injection
  @property {writableModelXPath} targetModelXPath   The xPath pointing to the root-node this widget will place entered selected items into
  @property {bcdui.core.DataProvider} inputModel   WRS datamodel representing the table columns
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatus]  default=bcdui.wkModels.guiStatus  StatusModel where the widget will write its content to.
  @property {boolean} [useCustomHeaderRenderer]   Set to true when your code adds bcdFilterButton classes on its own (e.g. grid)
  @property {function} [callback]   Function which will be executed after a change of the filters have been performed
  @property {function} [getCaptionForColumnValue]   Function (colIdx, colValue) which returns the rendered caption for the cell. By default standard wrs &commat;caption, wrs:references and unit/scale handling is supported already. Deprecated (prefer valueCaptionProvider parameter).
  @property {function} [getFilteredValues]   Function (colIdx) which needs to return a wrs:C array which holds the valid values for the current column. Use this to e.g. only show prefiltered values . Deprecated (prefer valueCaptionProvider parameter).
  @property {function} [valueCaptionProvider]   Function (inputModel, colIdx) which needs to return a Promise which resolves with an array of objects {value, caption, isFiltered}
  @property {Object} [columnFiltersCustomFilter]   CustomColumnFilter functions passed to column filter. columnFiltersCustomFilter is an array holding an object per bRef/column and an operations array which defines id, caption, valueCaptionProvider, filterFunction and gridFilterRowFunction
  */
/**
@param {Type_WidgetCreateTableHeadFilter_Args} args   The parameter map contains the following properties.
  ````js
  { tableElement, targetModelXPath, inputModel, statusModel?, useCustomHeaderRenderer?, callback?, getCaptionForColumnValue?, getFilteredValues?, valueCaptionProvider?, columnFiltersCustomFilter? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createTableHeadFilter)
@description   injectFilter in table
@method createTableHeadFilter

@example
// Usage
bcdui.widget.createTableHeadFilter({ tableElement, targetModelXPath: "$guiStatus/cust:Elem/@value", inputModel: myModel });

@return {void}
@memberOf bcdui.widget
*/
export function createTableHeadFilter(args: Type_WidgetCreateTableHeadFilter_Args): void;
export type Type_WidgetCreateTableHeadFilter_Args = {
    /**
     * The HTML Table Element which you want to use for injection
     */
    tableElement: HtmlElement;
    /**
     * The xPath pointing to the root-node this widget will place entered selected items into
     */
    targetModelXPath: writableModelXPath;
    /**
     * WRS datamodel representing the table columns
     */
    inputModel: bcdui.core.DataProvider;
    /**
     * default=bcdui.wkModels.guiStatus  StatusModel where the widget will write its content to.
     */
    statusModel?: bcdui.core.DataProvider;
    /**
     * Set to true when your code adds bcdFilterButton classes on its own (e.g. grid)
     */
    useCustomHeaderRenderer?: boolean;
    /**
     * Function which will be executed after a change of the filters have been performed
     */
    callback?: Function;
    /**
     * Function (colIdx, colValue) which returns the rendered caption for the cell. By default standard wrs &commat;caption, wrs:references and unit/scale handling is supported already. Deprecated (prefer valueCaptionProvider parameter).
     */
    getCaptionForColumnValue?: Function;
    /**
     * Function (colIdx) which needs to return a wrs:C array which holds the valid values for the current column. Use this to e.g. only show prefiltered values . Deprecated (prefer valueCaptionProvider parameter).
     */
    getFilteredValues?: Function;
    /**
     * Function (inputModel, colIdx) which needs to return a Promise which resolves with an array of objects {value, caption, isFiltered}
     */
    valueCaptionProvider?: Function;
    /**
     * CustomColumnFilter functions passed to column filter. columnFiltersCustomFilter is an array holding an object per bRef/column and an operations array which defines id, caption, valueCaptionProvider, filterFunction and gridFilterRowFunction
     */
    columnFiltersCustomFilter?: Object;
};
import * as bcdui from "../exports.js";
