/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.effects)
 * @description   A namespace for the BCD-UI widget effects.
 * @namespace bcdui.widget.effects
 */
/**
 * default duration of effects
 */
export const defaultDuration: 0.2;
