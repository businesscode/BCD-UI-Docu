/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.effects.htmlBuilderOnLoad)
  @description
  @method htmlBuilderOnLoad
@return {void}
  @memberOf bcdui.widget.effects
 */
export function htmlBuilderOnLoad(): void;
