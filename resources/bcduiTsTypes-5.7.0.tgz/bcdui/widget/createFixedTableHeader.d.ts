/**
  @typedef {Object} Type_WidgetCreateFixedTableHeader_Args
  @property {string} rendererId   Id of the renderer to work on
  @property {boolean} [storeSize=true]  default=true  Decide whether the action is to be called synchronous or not
  @property {boolean} [enableColumnFilters]   Set to true to enable column filters
  @property {function} [getCaptionForColumnValue]   if you enabled column filters, you can set its getCaptionForColumnValue here
  */
/**
@param {Type_WidgetCreateFixedTableHeader_Args} args   The parameter map contains the following properties.
  ````js
  { rendererId, storeSize?, enableColumnFilters?, getCaptionForColumnValue? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createFixedTableHeader)
@description   Create fixed table header by adding a fixed copy of the original
Its size is derived from the "original" header, still in place for the table
@method createFixedTableHeader

@example
// Usage
bcdui.widget.createFixedTableHeader({ rendererId });

@return {void}
@memberOf bcdui.widget
*/
export function createFixedTableHeader(args: Type_WidgetCreateFixedTableHeader_Args): void;
export type Type_WidgetCreateFixedTableHeader_Args = {
    /**
     * Id of the renderer to work on
     */
    rendererId: string;
    /**
     * default=true  Decide whether the action is to be called synchronous or not
     */
    storeSize?: boolean;
    /**
     * Set to true to enable column filters
     */
    enableColumnFilters?: boolean;
    /**
     * if you enabled column filters, you can set its getCaptionForColumnValue here
     */
    getCaptionForColumnValue?: Function;
};
