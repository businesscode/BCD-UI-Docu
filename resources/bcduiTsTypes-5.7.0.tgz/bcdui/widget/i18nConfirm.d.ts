/**
@param {string} msgKey
  @param {string} defaultValue
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.i18nConfirm)
  @description   shows a js confirm box with the given message
  @method i18nConfirm

  @example
  // Usage
bcdui.widget.i18nConfirm( msgKey, defaultValue );

@return {void}
  @memberOf bcdui.widget
 */
export function i18nConfirm(msgKey: string, defaultValue: string): void;
