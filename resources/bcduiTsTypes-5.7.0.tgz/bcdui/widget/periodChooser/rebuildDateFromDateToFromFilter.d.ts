/**
@param {DomDocument} targetModelDoc   containing the filter nodes which needs to get worked on
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.periodChooser.rebuildDateFromDateToFromFilter)
  @description   adds/overwrites dateFrom/dateTo attributes on periodChoosers filter nodes (outer And)
based on the currently available filters
  @method rebuildDateFromDateToFromFilter
@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function rebuildDateFromDateToFromFilter(targetModelDoc: DomDocument): void;
