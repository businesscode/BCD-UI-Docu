/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.periodChooser.init)
  @description
  @method init
@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function init(): void;
