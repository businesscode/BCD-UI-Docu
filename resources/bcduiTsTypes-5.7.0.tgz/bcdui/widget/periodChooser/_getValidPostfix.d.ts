/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.periodChooser._getValidPostfix)
  @description
  @method _getValidPostfix
@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function _getValidPostfix(): void;
