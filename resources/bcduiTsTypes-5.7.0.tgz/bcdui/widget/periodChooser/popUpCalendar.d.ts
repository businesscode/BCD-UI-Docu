/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.periodChooser.popUpCalendar)
  @description
  @method popUpCalendar
@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function popUpCalendar(): void;
