/**
  @typedef {Object} Type_PeriodChooserPeriodToRangeTransformator_Args
  @property {integer} rangeSize   Size of the range.
  @property {string} targetModelXPath   The xPath pointing to the period filter within the transformed document.
  */
/**
@param {Type_PeriodChooserPeriodToRangeTransformator_Args} parameters
  ````js
  { rangeSize, targetModelXPath }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.periodChooser.periodToRangeTransformator)
@description   A transformer, taking the input, leaving everything 1:1 except a period filter, which is transformed to a range
with the given date or range end as the end and keeping the input period type
@method periodToRangeTransformator

@example
// Usage
bcdui.widget.periodChooser.periodToRangeTransformator({ rangeSize, targetModelXPath: "$guiStatus/cust:Elem/@value" });

@return {void}
@memberOf bcdui.widget.periodChooser
*/
export function periodToRangeTransformator(parameters: Type_PeriodChooserPeriodToRangeTransformator_Args): void;
export type Type_PeriodChooserPeriodToRangeTransformator_Args = {
    /**
     * Size of the range.
     */
    rangeSize: integer;
    /**
     * The xPath pointing to the period filter within the transformed document.
     */
    targetModelXPath: string;
};
