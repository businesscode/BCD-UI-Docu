/**
@param {string} id   id of the period chooser widget
  @param {string} period_type   new period_type
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.periodChooser.switchPostfix)
  @description   Switch periodchooser to a different period_type
by replacing the bRef attributes and the bcdPostfix attribute
  @method switchPostfix

  @example
  // Usage
bcdui.widget.periodChooser.switchPostfix( id, period_type );

@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function switchPostfix(id: string, period_type: string): void;
