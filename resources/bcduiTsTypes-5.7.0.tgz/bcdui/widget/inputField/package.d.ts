/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.inputField)
 * @description   A namespace for the BCD-UI inputField widget. For creation &commat;see {@link bcdui.widget.createInputField}
 * @namespace bcdui.widget.inputField
 */
/**
 * observable events
 */
export const events: {};
