/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.inputField.buildRequestTransformator)
  @description   Transformator for building a MultiLevelSuggestion request
Connect the inputfield with a (auto)model using this as request builder (input doesn't matter, use guistatus)
And refresh it via additionalFilterXPath, same as for plain suggest
  @method buildRequestTransformator
@return {void}
  @memberOf bcdui.widget.inputField
 */
export function buildRequestTransformator(): void;
