/**
  @typedef {Object} Type_WidgetCreateNavPath_Args
  @property {targetHtmlRef} [targetHtml="#bcdNavPath"]  default="#bcdNavPath"  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [title="Report"]  default="Report"  A title string which is used during filename generation for exports
  @property {string} [values]   A space separated string which lists the ordered targetIds of the widgets which should be queried
  @property {string} [separator]   A string used for delimiter between single widget navpath values, default is ' ' (space)
  */
/**
@param {Type_WidgetCreateNavPath_Args} [args]   The parameter map contains the following properties.
  ````js
  { targetHtml?, title?, values?, separator? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createNavPath)
@description   Writes navpath widget information to the given target and updates this information changes
@method createNavPath
@return {void}
@memberOf bcdui.widget
*/
export function createNavPath(args?: Type_WidgetCreateNavPath_Args): void;
export type Type_WidgetCreateNavPath_Args = {
    /**
     * default="#bcdNavPath"  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml?: targetHtmlRef;
    /**
     * default="Report"  A title string which is used during filename generation for exports
     */
    title?: string;
    /**
     * A space separated string which lists the ordered targetIds of the widgets which should be queried
     */
    values?: string;
    /**
     * A string used for delimiter between single widget navpath values, default is ' ' (space)
     */
    separator?: string;
};
