/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget)
 * @description   A namespace for the BCD-UI widgets.
 * @namespace bcdui.widget
 */
/**
 * well known html dom events, which are fired by widgets at given circumstances,
these events are fired by widgets using jQuery.trigger() and can be consumed by
jQuery.on(). Values: writeValueToModel
 */
export const events: {};
/**
 * Enumeration with modalBox types. Values: ok | ‚warning | error | plainText
 */
export const modalBoxTypes: {};
