/**
  @typedef {Object} Type_MenuConstructor_Args
  @property {(string|HtmlElement)} rootIdOrElement   root Node of the menu (ul)
  @property {string} name   name of the variable that stores the result
                                                          of this constructor function
  @property {function} customConfigFunction   optional config function to override the default settings
                                                         for an example see Menu.prototype.config
  */
/**
  @class bcdui.widget.menu.Menu
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.Menu)
  
  @example
  // Usage
var myMn = new bcdui.widget.menu.Menu({ rootIdOrElement, name, customConfigFunction });

*/
export class Menu {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.Menu)
    
    @example
    // Usage
  var myMn = new bcdui.widget.menu.Menu({ rootIdOrElement, name, customConfigFunction });
  
  @param {Type_MenuConstructor_Args} args
      ````js
      { rootIdOrElement, name, customConfigFunction }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(args: Type_MenuConstructor_Args);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.Menu?id=getclassname)
    @public
    @return {string} class name
    */
    public getClassName(): string;
}
export type Type_MenuConstructor_Args = {
    /**
     * root Node of the menu (ul)
     */
    rootIdOrElement: (string | HtmlElement);
    /**
     * name of the variable that stores the result
                                  of this constructor function
     */
    name: string;
    /**
     * optional config function to override the default settings
               for an example see Menu.prototype.config
     */
    customConfigFunction: Function;
};
