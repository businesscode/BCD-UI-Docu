/**
  @class bcdui.widget.menu.MenuContainer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.MenuContainer)
  @description MenuContainer
  */
export class MenuContainer {
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.MenuContainer?id=getclassname)
    @public
    @return {string} class name
    */
    public getClassName(): string;
}
