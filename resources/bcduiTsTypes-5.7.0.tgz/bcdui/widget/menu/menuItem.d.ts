/**
  @class bcdui.widget.menu.MenuItem
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.MenuItem)
  @description Menu
  @extends bcdui.widget.menu.MenuContainer
*/
export class MenuItem extends bcdui.widget.menu.MenuContainer {
}
import * as bcdui from "../../exports.js";
