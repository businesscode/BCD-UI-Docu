/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.resolveContextMenuUniversalFilter)
  @description
  @method resolveContextMenuUniversalFilter
@return {void}
  @memberOf bcdui.widget
 */
export function resolveContextMenuUniversalFilter(): void;
