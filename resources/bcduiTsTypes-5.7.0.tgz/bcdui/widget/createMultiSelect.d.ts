/**
  @typedef {Object} Type_WidgetCreateMultiSelect_Args
  @property {writableModelXPath} targetModelXPath   The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target. Keep in mind when specifying a targetModelXPath for the multiSelect, you should use a f:Or in your expression. For example: /guiStatus:Status/f:Filter/f:Or/f:Expression[&commat;bRef='country' and &commat;op='=']/&commat;value.
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {modelXPath} optionsModelXPath   xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {string} [id]   ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [optionsModelRelativeValueXPath]   xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {string} [delimiter]   If defined, will switch to delimiter-based storing, i.e. multiple values will be written into one DOM node and separated by given delimiter.
  @property {integer} [visibleSize]   Number of visible elements in list.
  @property {boolean} [isCheckBox]   Use checkbox html element instead of multiselect.
  @property {boolean} [keepEmptyValueExpression]   A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty.
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  @property {boolean} [enableNavPath]   Set to true if widget should not be added to navpath handling.
  @property {boolean} [doSortOptions]   Set to true if widget should sort options.
  @property {string} [label]   If provided, renders label element to this input
  */
/**
@param {Type_WidgetCreateMultiSelect_Args} args   The parameter map contains the following properties.
  ````js
  { targetModelXPath, targetHtml, optionsModelXPath, id?, optionsModelRelativeValueXPath?, delimiter?, visibleSize?, isCheckBox?, keepEmptyValueExpression?, widgetCaption?, enableNavPath?, doSortOptions?, label? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createMultiSelect)
@description   Creates a multi selection box where multiple values can be selected and stored to the target model.
@method createMultiSelect

@example
// Usage
bcdui.widget.createMultiSelect({ targetModelXPath: "$guiStatus/cust:Elem/@value", targetHtml: "#myDiv", optionsModelXPath: "$myModel/wrs:Wrs/wrs:Data/wrs:R/wrs:C[1]" });

@return {void}
@memberOf bcdui.widget
*/
export function createMultiSelect(args: Type_WidgetCreateMultiSelect_Args): void;
export type Type_WidgetCreateMultiSelect_Args = {
    /**
     * The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target. Keep in mind when specifying a targetModelXPath for the multiSelect, you should use a f:Or in your expression. For example: /guiStatus:Status/f:Filter/f:Or/f:Expression[&commat;bRef='country' and &commat;op='=']/&commat;value.
     */
    targetModelXPath: writableModelXPath;
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
     */
    optionsModelXPath: modelXPath;
    /**
     * ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
     */
    id?: string;
    /**
     * xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
     */
    optionsModelRelativeValueXPath?: string;
    /**
     * If defined, will switch to delimiter-based storing, i.e. multiple values will be written into one DOM node and separated by given delimiter.
     */
    delimiter?: string;
    /**
     * Number of visible elements in list.
     */
    visibleSize?: integer;
    /**
     * Use checkbox html element instead of multiselect.
     */
    isCheckBox?: boolean;
    /**
     * A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty.
     */
    keepEmptyValueExpression?: boolean;
    /**
     * A caption which is used as prefix for navPath generation for this widget.
     */
    widgetCaption?: string;
    /**
     * Set to true if widget should not be added to navpath handling.
     */
    enableNavPath?: boolean;
    /**
     * Set to true if widget should sort options.
     */
    doSortOptions?: boolean;
    /**
     * If provided, renders label element to this input
     */
    label?: string;
};
