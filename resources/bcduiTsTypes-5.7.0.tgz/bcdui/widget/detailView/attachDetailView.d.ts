/**
  @typedef {Object} Type_DetailViewAttachDetailViewFilterFunctionEventContext_Args
  @property {string} event   the event
  */
/**
  @typedef {Object} Type_DetailViewAttachDetailViewRenderViewContainerFunctionEventContext_Args
  @property {Object} event   the event object which triggered this function, may be null
  @property {DomElement} targetElement   the target element which event occurred, may be null
  */
/**
  @typedef {Object} Type_DetailViewAttachDetailViewEventContext_Args
  @property {DomElement} targetElement   the target element where event has occurred
  */
/**
  @typedef {Object} Type_DetailViewAttachDetailViewRenderViewContainerFunction_Args
  @property {function} renderDialogContainer,   please refer to docs for more infos, arguments passed to this function:
  @property {Object} factoryArgs   the initial factory args which were provided attachDetailView() function, may be null
  @property {DomElement} referenceElement   is eventContext.targetElement
  @property {DomElement} targetHtmlElement   element to attach view container on
  */
/**
  @typedef {Object} Type_DetailViewAttachDetailView_Args
  @property {(string|Element)} targetHtmlElement   to attach listener to
  @property {(string|bcdui.core.Renderer)} targetRenderer   optional the target renderer, targetHtmlElement has precedence
  @property {boolean} consumeEvent   optional, default is: FALSE, consumes the event or allow propagation
  @property {string} childElementSelector   filter (jQuery) compatible for filtering on nested children, default is "tbody tr"
  @property {string} event   event to attach on , default is 'dblclick'
  @property {function} filterFunction   a filter function to check on target element if to pass, default is a filter
                                         function expecting targetElement to have 'bcdrowident' attribute
                                         this function shall return TRUE of FALSE, an argument is provided to the function
                                         containing following properties:
  @property {Type_DetailViewAttachDetailViewRenderViewContainerFunction_Args} renderViewContainerFunction   a function which renders the view container, the default implementation is
    ````js
    { renderDialogContainer,, factoryArgs, referenceElement, targetHtmlElement }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @property {function} renderViewContainerFunctionParamsFactory   factory for additional params which are mixed-in to the argument of renderViewContainerFunction()
                                                     available through extra.* property; this function gets same arguments as 'renderViewContainerFunction'
  @property {function} containerViewRenderedCb   a function which is called by renderViewContainerFunction() once container is contructed
  */
/**
@param {Type_DetailViewAttachDetailView_Args} args
  ````js
  { targetHtmlElement, targetRenderer, consumeEvent, childElementSelector, event, filterFunction, renderViewContainerFunction, renderViewContainerFunctionParamsFactory, containerViewRenderedCb }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.detailView.attachDetailView)
@description
@method attachDetailView

@example
// Usage
var ret = bcdui.widget.detailView.attachDetailView({ targetHtmlElement, targetRenderer, consumeEvent, childElementSelector, event, filterFunction, filterFunction, eventContext, renderViewContainerFunction, renderViewContainerFunction, renderViewContainerFunction, renderViewContainerFunction, renderViewContainerFunction, renderViewContainerFunction, renderViewContainerFunction, renderViewContainerFunctionParamsFactory, containerViewRenderedCb });

@return {(Object|void)}  args, additionally contains .unbind() function which stops this handler working; when called that function, you have to attachDetailView() again
@memberOf bcdui.widget.detailView
*/
export function attachDetailView(args: Type_DetailViewAttachDetailView_Args): (Object | void);
export type Type_DetailViewAttachDetailViewFilterFunctionEventContext_Args = {
    /**
     * the event
     */
    event: string;
};
export type Type_DetailViewAttachDetailViewRenderViewContainerFunctionEventContext_Args = {
    /**
     * the event object which triggered this function, may be null
     */
    event: Object;
    /**
     * the target element which event occurred, may be null
     */
    targetElement: DomElement;
};
export type Type_DetailViewAttachDetailViewEventContext_Args = {
    /**
     * the target element where event has occurred
     */
    targetElement: DomElement;
};
export type Type_DetailViewAttachDetailViewRenderViewContainerFunction_Args = {
    /**
     * ,   please refer to docs for more infos, arguments passed to this function:
     */
    renderDialogContainer: Function;
    /**
     * the initial factory args which were provided attachDetailView() function, may be null
     */
    factoryArgs: Object;
    /**
     * is eventContext.targetElement
     */
    referenceElement: DomElement;
    /**
     * element to attach view container on
     */
    targetHtmlElement: DomElement;
};
export type Type_DetailViewAttachDetailView_Args = {
    /**
     * to attach listener to
     */
    targetHtmlElement: (string | Element);
    /**
     * optional the target renderer, targetHtmlElement has precedence
     */
    targetRenderer: (string | bcdui.core.Renderer);
    /**
     * optional, default is: FALSE, consumes the event or allow propagation
     */
    consumeEvent: boolean;
    /**
     * filter (jQuery) compatible for filtering on nested children, default is "tbody tr"
     */
    childElementSelector: string;
    /**
     * event to attach on , default is 'dblclick'
     */
    event: string;
    /**
     * a filter function to check on target element if to pass, default is a filter
     function expecting targetElement to have 'bcdrowident' attribute
     this function shall return TRUE of FALSE, an argument is provided to the function
     containing following properties:
     */
    filterFunction: Function;
    /**
     * a function which renders the view container, the default implementation is
     * ````js
     * { renderDialogContainer,, factoryArgs, referenceElement, targetHtmlElement }
     * ````
     * <br/>Use autocomplete in {} to get a full parameter description <br/>
     */
    renderViewContainerFunction: Type_DetailViewAttachDetailViewRenderViewContainerFunction_Args;
    /**
     * factory for additional params which are mixed-in to the argument of renderViewContainerFunction()
    available through extra.* property; this function gets same arguments as 'renderViewContainerFunction'
     */
    renderViewContainerFunctionParamsFactory: Function;
    /**
     * a function which is called by renderViewContainerFunction() once container is contructed
     */
    containerViewRenderedCb: Function;
};
import * as bcdui from "../../exports.js";
