/**
@param {string} str   string holding placeholders like {{=it[0]}} or {{=it.myProperty}}
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.template)
  @description   returns a function which resolves basic doT like placeholder expressions
  @method template
@return {function}  function which can be called with an object to finally resolve the parameters
@memberOf bcdui.util
 */
export function template(str: string): Function;
