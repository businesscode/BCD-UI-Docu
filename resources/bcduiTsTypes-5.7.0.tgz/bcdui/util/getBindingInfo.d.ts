/**
@param {string} bindingSetId   The id of the binding set
  @param {(string|Array.<string>)} bRefs   requested binding items. Can be a comma-separated value list or an array
  @param {function} callback   The function which is called after a successful call of the BindingInfo servlet and returns the collected data
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.getBindingInfo)
  @description   returns an object map holding information for a binding's items (id, description and type)
  @method getBindingInfo

  @example
  // Usage
bcdui.util.getBindingInfo( bindingSetId, bRefs, callback );

@return {void}
  @memberOf bcdui.util
 */
export function getBindingInfo(bindingSetId: string, bRefs: (string | Array<string>), callback: Function): void;
