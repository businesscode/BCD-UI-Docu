/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.clipboard.paste)
  @description   Paste
  @method paste
@return {Promise.<string>}  - resolving with clipboard data
@memberOf bcdui.util.clipboard
 */
export function paste(): Promise<string>;
