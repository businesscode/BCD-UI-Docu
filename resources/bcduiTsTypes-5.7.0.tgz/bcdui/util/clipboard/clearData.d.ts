/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.clipboard.clearData)
  @description   Cleans the current clipboard
  @method clearData
@return {void}
  @memberOf bcdui.util.clipboard
 */
export function clearData(): void;
