/**
@param {string} data   Data to be copied to clipboard
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.clipboard.copy)
  @description   Copy
  @method copy
@return {void}
  @memberOf bcdui.util.clipboard
 */
export function copy(data: string): void;
