/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.htmlBuilderOnLoad)
  @description   wrapper function for effects htmlBuilderOnLoad. This here is called from htmlBuilderTemplate on bcdOnLoad
which tests if effects package (via widgets) is actually loaded.
  @method htmlBuilderOnLoad
@return {void}
  @memberOf bcdui.util
 */
export function htmlBuilderOnLoad(): void;
