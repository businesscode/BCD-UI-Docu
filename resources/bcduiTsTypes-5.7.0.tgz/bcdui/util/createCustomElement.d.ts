/**
@param {string} elementName   The name of the custom element to create, must adhere to custom element standards.
  @param {function} createdCallback   The function which is called on the element once it is attached to the document, the context is set to the element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.createCustomElement)
  @description   Custom element creation helper.
  @method createCustomElement

  @example
  // Usage
bcdui.util.createCustomElement( elementName, createdCallback );

@return {void}
  @memberOf bcdui.util
 */
export function createCustomElement(elementName: string, createdCallback: Function): void;
