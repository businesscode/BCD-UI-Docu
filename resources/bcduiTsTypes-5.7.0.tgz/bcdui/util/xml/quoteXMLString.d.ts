/**
@param {string} xmlString   The string to be processed.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.quoteXMLString)
  @description   Replaces the XML control characters in the specified string with the appropriate
pre-defined entities.
  @method quoteXMLString
@return {string}  The parameter with XML control characters replaced.
@memberOf bcdui.util.xml
 */
export function quoteXMLString(xmlString: string): string;
