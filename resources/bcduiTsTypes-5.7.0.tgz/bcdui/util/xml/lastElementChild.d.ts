/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.lastElementChild)
  @description
  @method lastElementChild
@return {void}
  @memberOf bcdui.util.xml
 */
export function lastElementChild(): void;
