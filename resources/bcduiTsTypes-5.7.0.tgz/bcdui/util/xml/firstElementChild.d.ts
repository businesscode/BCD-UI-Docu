/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.firstElementChild)
  @description
  @method firstElementChild
@return {void}
  @memberOf bcdui.util.xml
 */
export function firstElementChild(): void;
