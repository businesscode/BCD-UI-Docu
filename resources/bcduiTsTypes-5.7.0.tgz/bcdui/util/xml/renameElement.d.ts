/**
@param {DomElement} element   The XML element to be renamed.
  @param {string} newName   The new name of the XML element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.renameElement)
  @description   Renames an XML element and optionally filters its child elements (which is
useful in conjunction with the wrs-Format).
  @method renameElement

  @example
  // Usage
var ret = bcdui.util.xml.renameElement( element, newName );

@return {DomElement}  The renamed XML element.
@memberOf bcdui.util.xml
 */
export function renameElement(element: DomElement, newName: string): DomElement;
