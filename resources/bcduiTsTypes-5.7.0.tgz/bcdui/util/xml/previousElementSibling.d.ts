/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.previousElementSibling)
  @description
  @method previousElementSibling
@return {void}
  @memberOf bcdui.util.xml
 */
export function previousElementSibling(): void;
