/**
@param {(DomElement|DomAttribute)} node
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.getParentNode)
  @description   Determines the parent element of a node, no matter if it is an attribute node
or an element. It is quite useful especially for attribute nodes, because the
parentNode property does not work on them.
  @method getParentNode
@return {DomElement}  The parent element of the specified node.
@memberOf bcdui.util.xml
 */
export function getParentNode(node: (DomElement | DomAttribute)): DomElement;
