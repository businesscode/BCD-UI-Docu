/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.getUuid)
  @description   Generates a new UUID
  @method getUuid
@return {string}  uuid
@memberOf bcdui.util
 */
export function getUuid(): string;
