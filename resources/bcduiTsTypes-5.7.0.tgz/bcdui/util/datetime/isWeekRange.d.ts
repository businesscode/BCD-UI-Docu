/**
@param {(Date|string)} startDate   First day of the date range
  @param {(Date|string)} endDate   Last day of the date range
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.isWeekRange)
  @description   Tests if the given date range covers exactly one or more calendar weeks.
  @method isWeekRange

  @example
  // Usage
var ret = bcdui.util.datetime.isWeekRange( startDate, endDate );

@return {boolean}
@memberOf bcdui.util.datetime
 */
export function isWeekRange(startDate: (Date | string), endDate: (Date | string)): boolean;
