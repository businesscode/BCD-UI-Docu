/**
@param {string} date   The date string to be parsed.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.isValidDate)
  @description   Checks if date passed is valid date
  @method isValidDate
@return {boolean}  Whether the parsed "date" argument is valid date string.
@memberOf bcdui.util.datetime
 */
export function isValidDate(date: string): boolean;
