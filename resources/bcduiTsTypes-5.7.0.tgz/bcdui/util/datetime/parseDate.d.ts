/**
@param {(Date|string)} date   The date object to be parsed.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.parseDate)
  @description   Parses a date if the argument is a string or returns the date otherwise. The
date can be in XML date or timestamp format.
  @method parseDate
@return {Date}  The parsed date or the "date" argument if it is already a date object.
@memberOf bcdui.util.datetime
 */
export function parseDate(date: (Date | string)): Date;
