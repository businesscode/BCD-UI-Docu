/**
@param {(Date|string)} startDate   First day of the date range
  @param {(Date|string)} endDate   Last day of the date range
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.isQuarterRange)
  @description   Tests if the date range corresponds to exactly to one quarter (Jan - Mar, Apr - Jun, Jul - Sep or Oct - Dec of the same year)
  @method isQuarterRange

  @example
  // Usage
var ret = bcdui.util.datetime.isQuarterRange( startDate, endDate );

@return {boolean}
@memberOf bcdui.util.datetime
 */
export function isQuarterRange(startDate: (Date | string), endDate: (Date | string)): boolean;
