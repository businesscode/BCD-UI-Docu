/**
@param {integer} month
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.getShortMonthName)
  @description   The month name as abbreviated string (e.g. "Jul")
  @method getShortMonthName
@return {string}  .
@memberOf bcdui.util.datetime
 */
export function getShortMonthName(month: integer): string;
