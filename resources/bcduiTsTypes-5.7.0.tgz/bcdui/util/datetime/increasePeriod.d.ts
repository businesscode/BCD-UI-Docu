/**
@param {integer} value   An integer of how many periods the input is to be shifted. Negative values are allowed.
  @param {Date} startDate
  @param {Date} endDate
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.increasePeriod)
  @description   Shifts the given period by the given value
The value is assumed to have the same period type (qu, mo, dy) as startDate and endDate
  @method increasePeriod

  @example
  // Usage
bcdui.util.datetime.increasePeriod( value, startDate, endDate );

@return {void}
  @memberOf bcdui.util.datetime
 */
export function increasePeriod(value: integer, startDate: Date, endDate: Date): void;
