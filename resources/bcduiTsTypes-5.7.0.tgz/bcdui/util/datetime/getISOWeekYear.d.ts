/**
@param {(Date|string)} date   date for which to determine the CW
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.getISOWeekYear)
  @description   Calculates The year of the ISO week the date lies within. This can be different from
the year of the date, especially when the year has 53 ISO weeks.
  @method getISOWeekYear
@return {integer}  cwYr
@memberOf bcdui.util.datetime
 */
export function getISOWeekYear(date: (Date | string)): integer;
