/**
@param {Date} date
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.formatDate)
  @description   The date in the XML date format (e.g. "2010-07-23")
  @method formatDate
@return {string}
@memberOf bcdui.util.datetime
 */
export function formatDate(date: Date): string;
