/**
@param {(Date|string)} startDate   First day of the date range
  @param {(Date|string)} endDate   Last day of the date range
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.prettyPrintDateRange)
  @description   Pretty prints a date range
  @method prettyPrintDateRange

  @example
  // Usage
var ret = bcdui.util.datetime.prettyPrintDateRange( startDate, endDate );

@return {string}  A string describing the date range (e.g. "Jul 2010" or "CW 30, 2010").
@memberOf bcdui.util.datetime
 */
export function prettyPrintDateRange(startDate: (Date | string), endDate: (Date | string)): string;
