/**
@param {Date} date
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.formatDateTime)
  @description   The date in the XML datetime format (e.g. "2010-07-23T00:00:00")
  @method formatDateTime
@return {string}
@memberOf bcdui.util.datetime
 */
export function formatDateTime(date: Date): string;
