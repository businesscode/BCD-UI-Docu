/**
@param {(Date|string)} date   date for which to determine the CW
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.datetime.getISOWeekNumber)
  @description   Calculates the ISO week number the date belongs to. Derived from Klaus Tondering's Calendar document.
  @method getISOWeekNumber
@return {integer}  cw
@memberOf bcdui.util.datetime
 */
export function getISOWeekNumber(date: (Date | string)): integer;
