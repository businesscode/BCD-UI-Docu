/**
@param {string} string   Value to be escaped
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.escapeHtml)
  @description
  @method escapeHtml
@return {string}  Escaped string
@memberOf bcdui.util
 */
export function escapeHtml(string: string): string;
