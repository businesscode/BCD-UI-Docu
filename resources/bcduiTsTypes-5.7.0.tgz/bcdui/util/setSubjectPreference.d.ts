/**
@param {string} name   The name of the subjectSetting
  @param {string} value   The value of for the subjectSetting specified by the name parameter. Can be a comma-separated value list
  @param {function} callback   The function which is called after a successful call of the subjectPreferences servlet
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.setSubjectPreference)
  @description   sets a subject preference
  @method setSubjectPreference

  @example
  // Usage
bcdui.util.setSubjectPreference( name, value, callback );

@return {void}
  @memberOf bcdui.util
 */
export function setSubjectPreference(name: string, value: string, callback: Function): void;
