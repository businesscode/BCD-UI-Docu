/**
@param {string} url   The URL to be inspected.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.url.isAbsoluteURL)
  @description   Tests if the specified URL is an absolute URL or null. In this case it
returns true and false otherwise.
  @method isAbsoluteURL
@return {boolean}  True if the URL is either null or an absolute URL.
@memberOf bcdui.util.url
 */
export function isAbsoluteURL(url: string): boolean;
