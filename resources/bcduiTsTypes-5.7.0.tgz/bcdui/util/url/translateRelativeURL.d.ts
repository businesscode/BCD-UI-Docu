/**
@param {string} relativeBaseUrl   The URL the relativeUrl is based on. This may be a relative or an absolute URL.
  @param {string} relativeUrl   The relative URL to be resolved.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.url.translateRelativeURL)
  @description   This utility function applies a relative URL to a base URL and returns the
resulting URL. It is quite useful to compute for example the value of the
xml:base attribute of XIncludes, because the xml:base URL it the model's
data URL applied to the browser's href. For example if the relativeBaseUrl
is "/myProject/reports/myReport.jsp" and the relativeUrl is
"../include/data.xml" the result will be "/myProject/include/data.xml".
  @method translateRelativeURL

  @example
  // Usage
var ret = bcdui.util.url.translateRelativeURL( relativeBaseUrl, relativeUrl );

@return {string}  The result of applying the relativeUrl to the relativeBaseUrl.
@memberOf bcdui.util.url
 */
export function translateRelativeURL(relativeBaseUrl: string, relativeUrl: string): string;
