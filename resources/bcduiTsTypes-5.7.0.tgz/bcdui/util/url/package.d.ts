/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.url)
 * @description   Utilities for working with URLs
 * @namespace bcdui.util.url
 */
/**
 * Classification of a URL
 */
export const CLASSIFY_LINK_RESULT: {};
