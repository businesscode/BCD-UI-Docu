/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util._sendFormRequest)
  @description   sends a HTTP request using HTML form submit

{string} url                   the url to call
{object} [args]                optional arguments
{string} [args.method=get]     request method
{string} [args.target=_blank]  the target
{string} [args.enctype=application/x-www-form-urlencoded]  the enctype
{object} [args.parameters]     object map with parameters to send
  @method _sendFormRequest
@return {void}
  @memberOf bcdui.util
 */
export function _sendFormRequest(): void;
