/**
@param {string} string   Value to be unescaped
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.unescapeHtml)
  @description
  @method unescapeHtml
@return {string}  unescaped string
@memberOf bcdui.util
 */
export function unescapeHtml(string: string): string;
