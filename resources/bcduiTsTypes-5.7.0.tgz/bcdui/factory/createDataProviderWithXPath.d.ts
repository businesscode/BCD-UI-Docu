/**
@param {Object} args   The parameter map contains the same members as {@link bcdui.core.DataProviderWithXPath}
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.factory.createDataProviderWithXPath)
  @description   Creates a dataprovider from an xPath, its value is the evaluated xPath
  @method createDataProviderWithXPath
@return {void}
  @memberOf bcdui.factory
 */
export function createDataProviderWithXPath(args: Object): void;
