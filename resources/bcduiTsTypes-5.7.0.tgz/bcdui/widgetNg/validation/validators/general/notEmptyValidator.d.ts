/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.general.notEmptyValidator)
  @description   validates that value is neither null nor blank,params:
- value
  @method notEmptyValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.general
 */
export function notEmptyValidator(): void;
