/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.general)
 * @description   A namespace for the BCD-UI widget validation (general).
 * @namespace bcdui.widgetNg.validation.validators.general
 */
/**
 * generic type validators, input parameter is only a value:
- value, nulls / empty values are valid!
 */
export const TYPE_VALIDATORS: {};
