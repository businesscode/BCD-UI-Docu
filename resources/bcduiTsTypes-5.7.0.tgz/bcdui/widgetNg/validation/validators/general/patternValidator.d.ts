/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.general.patternValidator)
  @description   validates the string against given regex pattern, params:
- value {string}, may be null
- pattern {string} regular expression
  @method patternValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.general
 */
export function patternValidator(): void;
