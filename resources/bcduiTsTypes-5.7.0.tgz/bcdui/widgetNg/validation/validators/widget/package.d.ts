/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget)
 * @description   A namespace for the BCD-UI widget validation (specific).
 * @namespace bcdui.widgetNg.validation.validators.widget
 */
/**
 * type validator adapters
 */
export const TYPE_VALIDATORS: {};
