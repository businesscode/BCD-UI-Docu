/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget.getValue)
  @description   Current value of the chooser.
Use this instead of native value property as it understands our placeholder implementation.
  @method getValue
@return {string}  value of the field or "" if the field is empty
@memberOf bcdui.widgetNg.validation.validators.widget
 */
export function getValue(): string;
