/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget.invalidModelDataValidator)
  @description   checks that target data node is not tagged invalid with bcdInvalid attribute. The attribute
itself carries the validation-message. This validator shall not be used generally by sticking
it to other widget validators, since it does NOT validate widget's validity but the model's
validity. This validator shall be handled manually by a widget only during SYNC_READ, so that
it is always able to SYNC_WRITE (write back) widget's data to the model. General widget validation
API supports this case as of widget.validator.validateElement(htmlElementId, checkDataValidity) function.

extended widget configuration api used:
 - config.target.modelId
 - config.target.xPath
  @method invalidModelDataValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.widget
 */
export function invalidModelDataValidator(): void;
