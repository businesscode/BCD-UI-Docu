/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget.notEmptyValidator)
  @description
  @method notEmptyValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.widget
 */
export function notEmptyValidator(): void;
