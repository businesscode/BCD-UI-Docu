/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget.patternValidator)
  @description
  @method patternValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.widget
 */
export function patternValidator(): void;
