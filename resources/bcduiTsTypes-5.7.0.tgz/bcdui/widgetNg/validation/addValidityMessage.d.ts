/**
@param {object} validationResult   The validationResult object to extend or null to create a new one, this object is modified.
  @param {(string|Array.<string>)} message   Message to append to the validationResult.validationMessage
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.addValidityMessage)
  @description   appends validity message to validationResult object and returns validationResult,
creates a new one if none is provided. message must not be null.
  @method addValidityMessage

  @example
  // Usage
var ret = bcdui.widgetNg.validation.addValidityMessage( validationResult, message );

@return {object}  validationResult object with validationMessage array with appended message(s)
@memberOf bcdui.widgetNg.validation
 */
export function addValidityMessage(validationResult: object, message: (string | Array<string>)): object;
