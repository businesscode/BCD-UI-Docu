/**
@param {targetHtmlRef} targetHtml   element to undergo widget validation, selector, element or jQuery object.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.utils.validate)
  @description   Asynchronously triggers re-validation of visible widgets within container and focuses on first invalid input
inside the targetHtml.
  @method validate

  @example
  const form = jQuery('.form');
bcdui.widgetNg.utils.validate(form).then((validationResult) => {
  if (validationResult.isValid) {
    form.submit();
  }
});
  @return {Promise.<Object>}  resolving to { isValid : true|false }
@memberOf bcdui.widgetNg.utils
 */
export function validate(targetHtml: targetHtmlRef): Promise<Object>;
