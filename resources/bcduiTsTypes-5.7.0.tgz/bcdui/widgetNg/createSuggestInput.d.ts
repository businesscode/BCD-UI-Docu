/**
  @typedef {Object} Type_WidgetNgCreateSuggestInput_Args
  @property {modelXPath} optionsModelXPath   xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {writableModelXPath} targetModelXPath   The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted.
  @property {function} [applyListItemSelectionFunction]   this function is called when applying value from a dropdown selection (custom rendering mode only), it gets following parameters: (instance, htmlElementId, bcdCaption, bcdId) the bcdCaption is the string provided by options model and the bcdId is the value, in case provided by options model, too. The default implementation is executing { instance._syncWrite(htmlElementId, bcdCaption); }
  @property {function} [asyncValidationFunction]   Like 'validationFunction' but this one must return a Promise resolving with validation result. While validating, the widget sets 'bcdValidationPending' CSS class on the owning html element. The value is written to the model after a positive validation result. If a Promise is rejected for any reason, the widget switches to invalid state.
  @property {boolean} [autofocus]   requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {(boolean|i18nToken)} [clearOption]   if enabled, there will be an option to clear the selection. This attribute may be true|false or a string, in latter case the option is considered enabled and a string follows the i18nToken type definition.
  @property {boolean} [disabled]   All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [disableNativeSupport]   This parameter disables native HTML5 support for this widget. Please read more on side-effects in widget documentation.
  @property {boolean} [disableResetControl=true]  default=true  set this parameter to 'false' to enable built-in reset-control, which empties content once clicked.
  @property {boolean} [displayBalloon]   hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [doRetainInputSchema]   This option is 'false' per default, what means that the internal options model generates following schema: /Values/Value[&commat;caption]+ per matched item. The Value element itself holds the ID with optional &commat;caption attribute holding either ID or mapped caption in case optionsModelRelativeValueXPath is provided. In some cases you might want to work with internal options model and elements of the input document. Then you can enable this flag, which effictively disables any semantics, such as 'caption' or 'id' - as the internal options document will contain only matched elements from the input document, pay attention if you select an attribute in your xpath.
  @property {boolean} [doSortOptions]   Can be set to 'true' if the options should be sorted alphabetically. This is disabled per default to avoid CPU wasting.
  @property {boolean} [doTrimInput]   If enabled, the input is trimms leading/trailing spaces before writing to data model
  @property {boolean} [enableNavPath]   Set to true if widget should be added to navpath handling.
  @property {string} [filterFunction]   function name of filtering function receiving keystrokes; it gets { value, onComplete } and must call onComplete() callback once its done
  @property {i18nToken} [hint]   A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id]   Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {boolean} [isSync]   Uses synchronously validation when set to true. This also disables the use of asyncValidationFunction. Only necessary for setups where you can't handle waiting for the async write of data (e.g. grid widgets)
  @property {boolean} [isTextSelectedOnFocus]   if set, the text will be selected once the field gets a focus, so that further user input will replace the content. In case 'setCursorPositionAtEnd' is also set to true - this option has precedence.
  @property {boolean} [keepEmptyValueExpression]   A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty. TODO: better spec
  @property {i18nToken} [label]   If provided, enables widget to render a label element
  @property {integer} [maxlength]   if defined, limits the input to the given length.
  @property {xPath} [optionsModelRelativeValueXPath="."]  default="."  xPath expression relative to 'optionsModelXPath' providing values
  @property {string} [optionsRendererId]   * only applies to non-native implementation of this widget - to use this option you have to flag disableNativeSupport * The renderer provided here *must* exist prior binding to widget, that is it has to be known to ObjectRegistry at this time. At is recommended to construct your renderer with suppressInitialRendering=true, so that it does not run at the construction time and also provide targetHTMLElementId pointing to invisible container, since the renderer would reset containers CSS class having visual effects at construction time. Default options rendering stylesheet is located at /bcdui/widgetNg/suggestInput/optionsRenderer.xslt but you can provide your own here; the transformation has to output HTML with root element DIV containing block elements each representing an inidivual value. The children elements provides the value via bcdValue attribute. The rendered list is displayed in a dialog so user can pick-up an item. After that, the value is written to model which is found at bcdValue attribute. This way you can render complex HTML content. Recommended format is: div[div[&commat;bcdValue]*] You can also respect current widget value i.e. to implement prefiltering, the values are provided as parameters to the stylesheet. Please refer to original stylesheet documentation for more information and parameters which are provided during transformation. the targetHTMLElementId of the renderer is automatically bound to internal options list box, the input document to this renderer is the options-model of the widget.
  @property {string} [pattern]   regular expression pattern to validate the input
  @property {i18nToken} [placeholder]   A default text displayed if no content was entered, this is i18n key or true for default. May be empty to display nothing.
  @property {boolean} [required]   An empty string or not set value is not allowed if required is true. Disabled fields are not evaluated.
  @property {boolean} [setCursorPositionAtEnd]   if set the cursor position will always be at the end of the input once the input field gets a focus
  @property {integer} [suggestItemCount=10]  default=10  Number of items to suggest during typing, this applies to non-native implementation only.
  @property {integer} [tabindex]   the HTML compliant tabIndex
  @property {string} [validationFunction]   Name of a widget validator function which will be attached additionally to implicit validators. the API of given function is: validatorFunction(htmlElementId) : returns either NULL or object containing validationMessage (String or array of Strings) property, i.e. { validationMessage : String } or { validationMessage[] : String[] }, the validationMessage carries the message to be displayed to the user. The String may start with bcdui.i18n.TAG character to classify an i18n-key of the message, rather than a message itself. the args parameter is the htmlElementId of the widget to validate. Please use: bcdui.widgetNg.validation.validators.widget.getValue(htmlElementId) to properly retrieve widgets value. There is only one validator function allowed. In order to use or re-use or combine existing validations please do so in your validationFunction (that is delegate to other validators) and simply aggregate validation results into array of validationMessage[] This validator MUST ignore NULL or empty value.
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  @property {string} [wildcard="startswith"]  default="startswith"  The wildcards apply to filtering within the drop down list and for server side filters. This option applies only if bound to a f:Expression element and is ignored otherwise. For a f:Filter with &commat;op='like', this controls the prefilling with wildcards ('*') when the value is yet empty and the field gets the focus. Can be 'contains', 'startswith' or 'endswith'. The user can overwrite this by adding/removing wildcards when editing the field.
  */
/**
@param {Type_WidgetNgCreateSuggestInput_Args} args   The parameter map contains the following properties.
  ````js
  { optionsModelXPath, targetHtml, targetModelXPath, applyListItemSelectionFunction?, asyncValidationFunction?, autofocus?, clearOption?, disabled?, disableNativeSupport?, disableResetControl?, displayBalloon?, doRetainInputSchema?, doSortOptions?, doTrimInput?, enableNavPath?, filterFunction?, hint?, id?, isSync?, isTextSelectedOnFocus?, keepEmptyValueExpression?, label?, maxlength?, optionsModelRelativeValueXPath?, optionsRendererId?, pattern?, placeholder?, required?, setCursorPositionAtEnd?, suggestItemCount?, tabindex?, validationFunction?, widgetCaption?, wildcard? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.createSuggestInput)
@description   Allowing to either depict certain value from a list or accepting new value not in list. This input type always offers an input prompt which either acts as pre-filter for the list or also allows to enter new items. This widget can handle big number of options at good performance as well as supports complex options layout in non-native mode. Furthermore it provides you with ability to access remote data. [No ID/Caption mapping is available here.]
@method createSuggestInput

@example
// Usage
bcdui.widgetNg.createSuggestInput({ optionsModelXPath: "$myModel/wrs:Wrs/wrs:Data/wrs:R/wrs:C[1]", targetHtml: "#myDiv", targetModelXPath: "$guiStatus/cust:Elem/@value" });

@return {void}
@memberOf bcdui.widgetNg
*/
export function createSuggestInput(args: Type_WidgetNgCreateSuggestInput_Args): void;
export type Type_WidgetNgCreateSuggestInput_Args = {
    /**
     * xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
     */
    optionsModelXPath: modelXPath;
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted.
     */
    targetModelXPath: writableModelXPath;
    /**
     * this function is called when applying value from a dropdown selection (custom rendering mode only), it gets following parameters: (instance, htmlElementId, bcdCaption, bcdId) the bcdCaption is the string provided by options model and the bcdId is the value, in case provided by options model, too. The default implementation is executing { instance._syncWrite(htmlElementId, bcdCaption); }
     */
    applyListItemSelectionFunction?: Function;
    /**
     * Like 'validationFunction' but this one must return a Promise resolving with validation result. While validating, the widget sets 'bcdValidationPending' CSS class on the owning html element. The value is written to the model after a positive validation result. If a Promise is rejected for any reason, the widget switches to invalid state.
     */
    asyncValidationFunction?: Function;
    /**
     * requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
     */
    autofocus?: boolean;
    /**
     * if enabled, there will be an option to clear the selection. This attribute may be true|false or a string, in latter case the option is considered enabled and a string follows the i18nToken type definition.
     */
    clearOption?: (boolean | i18nToken);
    /**
     * All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
     */
    disabled?: boolean;
    /**
     * This parameter disables native HTML5 support for this widget. Please read more on side-effects in widget documentation.
     */
    disableNativeSupport?: boolean;
    /**
     * default=true  set this parameter to 'false' to enable built-in reset-control, which empties content once clicked.
     */
    disableResetControl?: boolean;
    /**
     * hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
     */
    displayBalloon?: boolean;
    /**
     * This option is 'false' per default, what means that the internal options model generates following schema: /Values/Value[&commat;caption]+ per matched item. The Value element itself holds the ID with optional &commat;caption attribute holding either ID or mapped caption in case optionsModelRelativeValueXPath is provided. In some cases you might want to work with internal options model and elements of the input document. Then you can enable this flag, which effictively disables any semantics, such as 'caption' or 'id' - as the internal options document will contain only matched elements from the input document, pay attention if you select an attribute in your xpath.
     */
    doRetainInputSchema?: boolean;
    /**
     * Can be set to 'true' if the options should be sorted alphabetically. This is disabled per default to avoid CPU wasting.
     */
    doSortOptions?: boolean;
    /**
     * If enabled, the input is trimms leading/trailing spaces before writing to data model
     */
    doTrimInput?: boolean;
    /**
     * Set to true if widget should be added to navpath handling.
     */
    enableNavPath?: boolean;
    /**
     * function name of filtering function receiving keystrokes; it gets { value, onComplete } and must call onComplete() callback once its done
     */
    filterFunction?: string;
    /**
     * A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
     */
    hint?: i18nToken;
    /**
     * Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
     */
    id?: string;
    /**
     * Uses synchronously validation when set to true. This also disables the use of asyncValidationFunction. Only necessary for setups where you can't handle waiting for the async write of data (e.g. grid widgets)
     */
    isSync?: boolean;
    /**
     * if set, the text will be selected once the field gets a focus, so that further user input will replace the content. In case 'setCursorPositionAtEnd' is also set to true - this option has precedence.
     */
    isTextSelectedOnFocus?: boolean;
    /**
     * A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty. TODO: better spec
     */
    keepEmptyValueExpression?: boolean;
    /**
     * If provided, enables widget to render a label element
     */
    label?: i18nToken;
    /**
     * if defined, limits the input to the given length.
     */
    maxlength?: integer;
    /**
     * default="."  xPath expression relative to 'optionsModelXPath' providing values
     */
    optionsModelRelativeValueXPath?: xPath;
    /**
     * * only applies to non-native implementation of this widget - to use this option you have to flag disableNativeSupport * The renderer provided here *must* exist prior binding to widget, that is it has to be known to ObjectRegistry at this time. At is recommended to construct your renderer with suppressInitialRendering=true, so that it does not run at the construction time and also provide targetHTMLElementId pointing to invisible container, since the renderer would reset containers CSS class having visual effects at construction time. Default options rendering stylesheet is located at /bcdui/widgetNg/suggestInput/optionsRenderer.xslt but you can provide your own here; the transformation has to output HTML with root element DIV containing block elements each representing an inidivual value. The children elements provides the value via bcdValue attribute. The rendered list is displayed in a dialog so user can pick-up an item. After that, the value is written to model which is found at bcdValue attribute. This way you can render complex HTML content. Recommended format is: div[div[&commat;bcdValue]*] You can also respect current widget value i.e. to implement prefiltering, the values are provided as parameters to the stylesheet. Please refer to original stylesheet documentation for more information and parameters which are provided during transformation. the targetHTMLElementId of the renderer is automatically bound to internal options list box, the input document to this renderer is the options-model of the widget.
     */
    optionsRendererId?: string;
    /**
     * regular expression pattern to validate the input
     */
    pattern?: string;
    /**
     * A default text displayed if no content was entered, this is i18n key or true for default. May be empty to display nothing.
     */
    placeholder?: i18nToken;
    /**
     * An empty string or not set value is not allowed if required is true. Disabled fields are not evaluated.
     */
    required?: boolean;
    /**
     * if set the cursor position will always be at the end of the input once the input field gets a focus
     */
    setCursorPositionAtEnd?: boolean;
    /**
     * default=10  Number of items to suggest during typing, this applies to non-native implementation only.
     */
    suggestItemCount?: integer;
    /**
     * the HTML compliant tabIndex
     */
    tabindex?: integer;
    /**
     * Name of a widget validator function which will be attached additionally to implicit validators. the API of given function is: validatorFunction(htmlElementId) : returns either NULL or object containing validationMessage (String or array of Strings) property, i.e. { validationMessage : String } or { validationMessage[] : String[] }, the validationMessage carries the message to be displayed to the user. The String may start with bcdui.i18n.TAG character to classify an i18n-key of the message, rather than a message itself. the args parameter is the htmlElementId of the widget to validate. Please use: bcdui.widgetNg.validation.validators.widget.getValue(htmlElementId) to properly retrieve widgets value. There is only one validator function allowed. In order to use or re-use or combine existing validations please do so in your validationFunction (that is delegate to other validators) and simply aggregate validation results into array of validationMessage[] This validator MUST ignore NULL or empty value.
     */
    validationFunction?: string;
    /**
     * A caption which is used as prefix for navPath generation for this widget.
     */
    widgetCaption?: string;
    /**
     * default="startswith"  The wildcards apply to filtering within the drop down list and for server side filters. This option applies only if bound to a f:Expression element and is ignored otherwise. For a f:Filter with &commat;op='like', this controls the prefilling with wildcards ('*') when the value is yet empty and the field gets the focus. Can be 'contains', 'startswith' or 'endswith'. The user can overwrite this by adding/removing wildcards when editing the field.
     */
    wildcard?: string;
};
