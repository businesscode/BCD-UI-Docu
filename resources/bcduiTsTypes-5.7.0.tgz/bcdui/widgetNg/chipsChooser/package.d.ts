/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.chipsChooser)
 * @description   A namespace for the BCD-UI chipsChooser widget. For creation &commat;see {@link bcdui.widgetNg.createChipsChooser}
 * @namespace bcdui.widgetNg.chipsChooser
 */
/**
 * onBeforeChange dir attribute value, can be used to identify the direction of the item move
 */
export const CHANGE_DIRECTION: {};
