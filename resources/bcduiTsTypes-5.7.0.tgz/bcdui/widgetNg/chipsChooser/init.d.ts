/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.chipsChooser.init)
  @description
  @method init
@return {void}
  @memberOf bcdui.widgetNg.chipsChooser
 */
export function init(): void;
