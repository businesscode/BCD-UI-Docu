/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.commons.balloon.hideHintBalloon)
  @description   hides previously visible balloon
  @method hideHintBalloon
@return {void}
  @memberOf bcdui.widgetNg.commons.balloon
 */
export function hideHintBalloon(): void;
