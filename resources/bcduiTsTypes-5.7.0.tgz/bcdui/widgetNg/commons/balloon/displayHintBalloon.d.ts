/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.commons.balloon.displayHintBalloon)
  @description   permanently displays the hint-balloon for given htmlElementId using the
default tooltip technique but reposition it (next to the element) as tray-message,
you have to hide the the balloon executing general hideHintBalloon()

configuration params:

- balloonRendererId

configuration object is expected to be in the element map: bcdui.widgetNg.commons.balloon.MAPKEY_CONFIG
  @method displayHintBalloon
@return {void}
  @memberOf bcdui.widgetNg.commons.balloon
 */
export function displayHintBalloon(): void;
