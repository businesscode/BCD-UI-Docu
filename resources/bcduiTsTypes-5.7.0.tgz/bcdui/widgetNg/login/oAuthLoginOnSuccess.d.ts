/**
@param {string} redirectUrl
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.login.oAuthLoginOnSuccess)
  @description   To support OAuth flow with cookie SameSite strict, we work with a client-site redirect here
which is triggered from within the popup by a script send from OAuthAuthenticatingFilter on login success
This way we get the cookie and stay in the successfully validated session
  @method oAuthLoginOnSuccess
@return {void}
  @memberOf bcdui.widgetNg.login
 */
export function oAuthLoginOnSuccess(redirectUrl: string): void;
