/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.sideBySideChooser.init)
  @description
  @method init
@return {void}
  @memberOf bcdui.widgetNg.sideBySideChooser
 */
export function init(): void;
