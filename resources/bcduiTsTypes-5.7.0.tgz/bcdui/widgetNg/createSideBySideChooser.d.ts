/**
  @typedef {Object} Type_WidgetNgCreateSideBySideChooser_Args
  @property {modelXPath} optionsModelXPath   xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {writableModelXPath} targetModelXPath   The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted.
  @property {boolean} [allowUnknownTargetValue]   If true, target items are not removed when they are not part of the source's options model.
  @property {boolean} [autofocus]   requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {boolean} [disabled]   All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [displayBalloon]   hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [doSortOptions=true]  default=true  Can be set to 'false' if the options should not be sorted alphabetically.
  @property {boolean} [enableNavPath]   Set to true if widget should be added to navpath handling.
  @property {i18nToken} [hint]   A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id]   Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {function} [onBeforeChange]   Handler function triggered before change, if false is returned, the change is rejected receives property map: {element = the widget element, dir = one of bcdui.widgetNg.sideBySideChooser.CHANGE_DIRECTION.*, scope = object with .items to move, which can also be modified (i.e. remove items not eligible to move)}
  @property {function} [onChange]   Handler function triggered after change
  @property {function} [onChangeAction]   Handler function triggered after change
  @property {xPath} [optionsModelRelativeFilterPredicate]   xPath expression relative to 'optionsModelXPath' which can be used to filter options model items
  @property {xPath} [optionsModelRelativeValueXPath]   xPath expression relative to 'optionsModelXPath' providing values
  @property {i18nToken} [sourceCaption="\uE0FFbcd_widget_sbsc_sourceCaption"]  default="\uE0FFbcd_widget_sbsc_sourceCaption"  Caption(header) for source block items. Can be an i18n key (with leading i18n token).
  @property {boolean} [sourceFilter_doSortOptions]   Sorting option for the preselection filter dropdown
  @property {i18nToken} [sourceFilter_label]   Label for the preselection filter dropdown
  @property {xPath} [sourceFilter_optionsModelRelativeValueXPath]   optionsModelRelativeValueXPath for the preselection filter drowdown
  @property {modelXPath} [sourceFilter_optionsModelXPath]   OptionsModelXPath for the preselection filter drowdown. This is required when using sourceFilters.
  @property {i18nToken} [sourceFilter_placeholder]   Placeholder for the preselection filter dropdown
  @property {xPath} [sourceFilter_relativeCompareValueXPath]   A relative xpath to the final sbs options model value which is used to compare the selected filter value against
  @property {integer} [tabindex]   the HTML compliant tabIndex
  @property {i18nToken} [targetCaption="\uE0FFbcd_widget_sbsc_targetCaption"]  default="\uE0FFbcd_widget_sbsc_targetCaption"  Caption(header) for target block items. Can be an i18n key (with leading i18n token).
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  @property {string} [wrsInlineValueDelim]   Delimiter used for WRS read and write. Default is a slash.
  */
/**
@param {Type_WidgetNgCreateSideBySideChooser_Args} args   The parameter map contains the following properties.
  ````js
  { optionsModelXPath, targetHtml, targetModelXPath, allowUnknownTargetValue?, autofocus?, disabled?, displayBalloon?, doSortOptions?, enableNavPath?, hint?, id?, onBeforeChange?, onChange?, onChangeAction?, optionsModelRelativeFilterPredicate?, optionsModelRelativeValueXPath?, sourceCaption?, sourceFilter_doSortOptions?, sourceFilter_label?, sourceFilter_optionsModelRelativeValueXPath?, sourceFilter_optionsModelXPath?, sourceFilter_placeholder?, sourceFilter_relativeCompareValueXPath?, tabindex?, targetCaption?, widgetCaption?, wrsInlineValueDelim? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.createSideBySideChooser)
@description   Offers a SideBySiderChooser where you can select items on a source side and move them to a target side
@method createSideBySideChooser

@example
// Usage
bcdui.widgetNg.createSideBySideChooser({ optionsModelXPath: "$myModel/wrs:Wrs/wrs:Data/wrs:R/wrs:C[1]", targetHtml: "#myDiv", targetModelXPath: "$guiStatus/cust:Elem/@value" });

@return {void}
@memberOf bcdui.widgetNg
*/
export function createSideBySideChooser(args: Type_WidgetNgCreateSideBySideChooser_Args): void;
export type Type_WidgetNgCreateSideBySideChooser_Args = {
    /**
     * xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
     */
    optionsModelXPath: modelXPath;
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted.
     */
    targetModelXPath: writableModelXPath;
    /**
     * If true, target items are not removed when they are not part of the source's options model.
     */
    allowUnknownTargetValue?: boolean;
    /**
     * requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
     */
    autofocus?: boolean;
    /**
     * All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
     */
    disabled?: boolean;
    /**
     * hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
     */
    displayBalloon?: boolean;
    /**
     * default=true  Can be set to 'false' if the options should not be sorted alphabetically.
     */
    doSortOptions?: boolean;
    /**
     * Set to true if widget should be added to navpath handling.
     */
    enableNavPath?: boolean;
    /**
     * A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
     */
    hint?: i18nToken;
    /**
     * Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
     */
    id?: string;
    /**
     * Handler function triggered before change, if false is returned, the change is rejected receives property map: {element = the widget element, dir = one of bcdui.widgetNg.sideBySideChooser.CHANGE_DIRECTION.*, scope = object with .items to move, which can also be modified (i.e. remove items not eligible to move)}
     */
    onBeforeChange?: Function;
    /**
     * Handler function triggered after change
     */
    onChange?: Function;
    /**
     * Handler function triggered after change
     */
    onChangeAction?: Function;
    /**
     * xPath expression relative to 'optionsModelXPath' which can be used to filter options model items
     */
    optionsModelRelativeFilterPredicate?: xPath;
    /**
     * xPath expression relative to 'optionsModelXPath' providing values
     */
    optionsModelRelativeValueXPath?: xPath;
    /**
     * default="\uE0FFbcd_widget_sbsc_sourceCaption"  Caption(header) for source block items. Can be an i18n key (with leading i18n token).
     */
    sourceCaption?: i18nToken;
    /**
     * Sorting option for the preselection filter dropdown
     */
    sourceFilter_doSortOptions?: boolean;
    /**
     * Label for the preselection filter dropdown
     */
    sourceFilter_label?: i18nToken;
    /**
     * optionsModelRelativeValueXPath for the preselection filter drowdown
     */
    sourceFilter_optionsModelRelativeValueXPath?: xPath;
    /**
     * OptionsModelXPath for the preselection filter drowdown. This is required when using sourceFilters.
     */
    sourceFilter_optionsModelXPath?: modelXPath;
    /**
     * Placeholder for the preselection filter dropdown
     */
    sourceFilter_placeholder?: i18nToken;
    /**
     * A relative xpath to the final sbs options model value which is used to compare the selected filter value against
     */
    sourceFilter_relativeCompareValueXPath?: xPath;
    /**
     * the HTML compliant tabIndex
     */
    tabindex?: integer;
    /**
     * default="\uE0FFbcd_widget_sbsc_targetCaption"  Caption(header) for target block items. Can be an i18n key (with leading i18n token).
     */
    targetCaption?: i18nToken;
    /**
     * A caption which is used as prefix for navPath generation for this widget.
     */
    widgetCaption?: string;
    /**
     * Delimiter used for WRS read and write. Default is a slash.
     */
    wrsInlineValueDelim?: string;
};
