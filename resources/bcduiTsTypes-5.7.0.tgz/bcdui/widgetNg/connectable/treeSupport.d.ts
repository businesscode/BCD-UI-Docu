/**
  @typedef {Object} Type_TreeSupportConstructor_Args
  @property {boolean} [isDefaultCollapsed=true]  default=true  Initial state
  @property {string} levelNodeName   Local nodename of the level, i.e. "Level"
  @property {string} itemNodeName   Local nodename of the item, i.e. "Item"
  @property {string} valueAttrName   Attribute name of value attribute, i.e. "id"
  @property {string} captionAttrName   Attribute name of caption attribute, i.e. "caption"
  @property {number} [leftPaddingLevel=14]  default=14  Left padding in pixels per level depth
  */
/**
  @class bcdui.widgetNg.connectable.TreeSupport
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.connectable.TreeSupport)
  @description Tree support class providing item rendering, controls binding and onItemMoved handler
  
  @example
  // Usage
var myTS = new bcdui.widgetNg.connectable.TreeSupport({ levelNodeName, itemNodeName, valueAttrName, captionAttrName });

*/
export class TreeSupport {
    /**
    @description Tree support class providing item rendering, controls binding and onItemMoved handler
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.connectable.TreeSupport)
    
    @example
    // Usage
  var myTS = new bcdui.widgetNg.connectable.TreeSupport({ levelNodeName, itemNodeName, valueAttrName, captionAttrName });
  
  @param {jQuery} container   The container
    @param {Type_TreeSupportConstructor_Args} config   Options
      ````js
      { isDefaultCollapsed?, levelNodeName, itemNodeName, valueAttrName, captionAttrName, leftPaddingLevel? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
      */
    constructor(container: jQuery, config: Type_TreeSupportConstructor_Args);
}
export type Type_TreeSupportConstructor_Args = {
    /**
     * default=true  Initial state
     */
    isDefaultCollapsed?: boolean;
    /**
     * Local nodename of the level, i.e. "Level"
     */
    levelNodeName: string;
    /**
     * Local nodename of the item, i.e. "Item"
     */
    itemNodeName: string;
    /**
     * Attribute name of value attribute, i.e. "id"
     */
    valueAttrName: string;
    /**
     * Attribute name of caption attribute, i.e. "caption"
     */
    captionAttrName: string;
    /**
     * default=14  Left padding in pixels per level depth
     */
    leftPaddingLevel?: number;
};
