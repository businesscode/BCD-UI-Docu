/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.connectable)
 * @description   A namespace for the BCD-UI connectable widget. For creation &commat;see {@link bcdui.widgetNg.createConnectable}
 * @namespace bcdui.widgetNg.connectable
 */
/**
 * onBeforeChange dir attribute value, can be used to identify the direction of the item move
 */
export const CHANGE_DIRECTION: {};
