// Make globally available
declare global {

type integer = number;
type DomDocument = Object;
type DomElement = Object;
type DomAttribute = Object;
type DomNodeSet = Object;
type DomNode = Object;
type HtmlElement = Object;
type SymLink = Object;
type chainDef = string | Function | Array<(string | Function)> | import("./exports").core.DataProvider;
/**
 * An absolute or relative url
 */
type url = string;
type i18nToken = string;
type jQuery = Object;
type targetHtmlRef = string | HtmlElement | jQuery;
type modelXPath = string;
type xPath = string;
type writableModelXPath = string;
type BcdScrollToParamOptions = {
    /**
     * snapTo can have following values: 'beginning': put the scrollTo-target on the top of container.
     */
    snapTo?: string;
};
type AddStatusListenerParam = {
    /**
     * - A function or StatusListener object representing the listener action.
     */
    listener: (Function | import("./exports").core.StatusListener);
    /**
     * - The status it should listen to.
     * If it is missing the listener is executed on all status transitions, otherwise it is executed when the status is set to the specified status.
     */
    status: import("./exports").core.Status;
    /**
     * - A boolean variable indicating that the listener should be automatically removed after it has been executed.
     */
    onlyOnce?: boolean;
};
type RemoveStatusListenerParam = {
    /**
     * - A function <p/>or StatusListener object representing the listener action.
     */
    listener: (Function | import("./exports").core.StatusListener);
    /**
     * - The status this listener is listening to. If it is missing it is assumed that the listener belongs to the global scope.
     */
    status: import("./exports").core.Status;
};
type OnceReadyParam = {
    /**
     * - callback function which is called when {@link bcdui.core.AbstractExecutable} is or gets ready
     */
    onSuccess: Function;
    /**
     * - callback function which is called when {@link bcdui.core.AbstractExecutable} gets into failed status
     */
    onFailure?: Function;
    /**
     * - do execute {@link bcdui.core.AbstractExecutable} if it's not ready
     */
    executeIfNotReady?: boolean;
};
type OnReadyParam = {
    /**
     * - callback function which is called when {@link bcdui.core.AbstractExecutable} is or gets ready
     */
    onSuccess: Function;
    /**
     * - callback function which is called when {@link bcdui.core.AbstractExecutable} gets into failed status
     */
    onFailure?: Function;
    /**
     * - call callback only once or on each ready state
     */
    onlyOnce?: boolean;
    /**
     * - only future ready states will trigger the callback. Per default the callback is called immediately (but async), if the AbstractExecutable is already in ready state
     */
    onlyFuture?: boolean;
    /**
     * - do execute {@link bcdui.core.AbstractExecutable} if it's not ready
     */
    executeIfNotReady?: boolean;
};
type RemoveDataListenerParam = {
    /**
     * - listener id
     */
    id?: string;
    /**
     * - listener function
     */
    callback?: string;
};
/**
 * Adds a data listener to the DataProvider which can be triggered when the data (XML
 * document) is changed. The listener offers two options: It can either be fired on
 * any change or on a change in a specific XPath result.
 * Note that no uniqueness check is done before adding the listener so it is possible to add the same listener twice or more times.
 * /
 * /**
 */
type OnChangeParam = {
    /**
     * - function to be called after changes
     */
    callback: Function;
    /**
     * - xPath to monitor for changes
     */
    trackingXPath?: string;
    /**
     * - fire on each change or only once  (higher priority than listenerObject's onlyOnce)
     */
    onlyOnce?: boolean;
    /**
     * - listener id (only needed for removeDataListener usability)
     */
    id?: string;
};
type SimpleModelParamSaveOptions = {
    /**
     * - The definition of the transformation chain
     */
    saveChain?: chainDef;
    /**
     * - An object, where each property holds a DataProvider, used as a transformation parameters.
     */
    saveParameters?: Object;
    /**
     * - Useful especially for models of type SimpleModel for refreshing from server after save
     */
    reload?: boolean;
    /**
     * - Callback after saving (and optionally reloading) was successfully finished
     */
    onSuccess?: Function;
    /**
     * - Callback on failure, is called if error occurs
     */
    onFailure?: Function;
    /**
     * - Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
     */
    onWrsValidationFailure?: Function;
    /**
     * - dataProvider holding the request url (by default taken from the args.url).
     */
    urlProvider?: import("./exports").core.DataProvider;
};
type SimpleModelParam = {
    /**
     * - A string with the URL or a RequestDocumentDataProvider providing the request. See {@link bcdui.core.RequestDocumentDataProvider RequestDocumentDataProvider} for an example.
     */
    url: (string | import("./exports").core.RequestDocumentDataProvider);
    /**
     * - uri extension as a suffix to .url to tag requests, must not start with '/'. This parameter is ineffective if .url is provided.
     */
    uri?: string;
    /**
     * - Globally unique id for used in declarative contexts
     */
    id?: string;
    /**
     * - If true, each change of args.urlProvider triggers a reload of the model
     */
    isAutoRefresh?: boolean;
    /**
     * - Mimetype of the expected data. If "auto" or none is given it is derived from the url
     */
    mimeType?: string;
    /**
     * - An argument map for save options {@link SimpleModelParamSaveOptions}
     */
    saveOptions?: SimpleModelParamSaveOptions;
};
type StaticModelParam = {
    /**
     * - Globally unique id for use in declarative contexts, ignored if args.data is not set
     */
    id?: string;
    /**
     * - An XML string, which is parsed, a DOM document </p>or a parameter map
     */
    data: (string | Object | DomDocument);
};
type Type_RendererExecute_Args = {
    /**
     * A function called once when the object becomes ready again. Called immediately if we are already ready && shouldRefresh==false
     */
    fn?: Function;
    /**
     * Space separated list of html element ids. If given, only these elements within targetHmtlElement of the render
     * are touched in the DOM tree, plus the chain gets the parameter bcdPartialHtmlTargets set to this value. Valid for this one call only, cleared after.
     */
    partialHtmlTargets?: string;
    /**
     * "false" if this method should do nothing when the object is already in the ready status. Default is "true"false".
     */
    shouldRefresh?: boolean;
};
/**
 * Translates and formats if needed the given message id.
 * The function should be used only if bcduiI18Model ready. If
 * the catalog is not initialized up to this moment (the catalog
 * initialization is asychronous) then NULL is returned in production
 * and an error is thrown in debug mode.
 *
 * /**
 */
type SyncTranslateFormatMessageParam = {
    /**
     * - the message id
     */
    msgid?: string;
};
type PostWrsParam = {
    /**
     * - Document(s) / DataProvider
     */
    wrsDoc: DomDocument | DomDocument[] | import("./exports").core.DataProvider | import("./exports").core.DataProvider[];
    /**
     * - Callback on success, is called after successful POST or if POST was not issued due to to changes in the document
     */
    onSuccess?: Function;
    /**
     * - Callback on failure, is called if error occurs
     */
    onFailure?: Function;
    /**
     * - Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
     */
    onWrsValidationFailure?: Function;
    /**
     * - An URI (i.e. SomeDoc) which is appended as pathInfo to WrsServlet
     */
    uri?: string;
};
type Type_Quickedit_CallbackHandler_TYPE = string;
/**
 * This callback is displayed as part of the Requester class.
 */
type Type_Quickedit_CallbackHandler = (instance: import("./exports").widgetNg.QuickEdit, type: Type_Quickedit_CallbackHandler_TYPE, args: object) => any;

}

export{};