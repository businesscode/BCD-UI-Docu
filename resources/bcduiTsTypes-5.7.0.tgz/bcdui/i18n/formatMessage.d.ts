/**
@param {string} message
  @param {Array.<any>} values   Array values to set
  @param {object} formattingFunctions
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.i18n.formatMessage)
  @description   formats message
  @method formatMessage

  @example
  // Usage
bcdui.i18n.formatMessage( message, values, formattingFunctions );


  @example
  bcdui.i18n.formatMessage( "Successfully updated {0} records in {1,number,#0.00} columns.", [ 3, 2 ] );
  @return {void}
  @memberOf bcdui.i18n
 */
export function formatMessage(message: string, values: Array<any>, formattingFunctions: object): void;
