/**
@param {string} lang   the language code
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.i18n.switchLanguage)
  @description   reloads entire page in a given language
this function requires the mapped SubjectPreferences servlet and a subjectPreferences.xml holding
an entry for <cnf:Setting name="bcd_i18n:lang">
  @method switchLanguage
@return {void}
  @memberOf bcdui.i18n
 */
export function switchLanguage(lang: string): void;
