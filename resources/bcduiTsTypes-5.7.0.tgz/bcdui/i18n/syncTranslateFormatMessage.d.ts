/**
@param {(SyncTranslateFormatMessageParam|string)} messageId   Either an object with property msgid, or the messageId itself
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.i18n.syncTranslateFormatMessage)
  @description   Assumes bcdui.wkModels.bcdI18nModel is ready and synchronously translates and formats the given message id.
  @method syncTranslateFormatMessage
@return {string}  translated and formated message
@memberOf bcdui.i18n
 */
export function syncTranslateFormatMessage(messageId: (SyncTranslateFormatMessageParam | string)): string;
