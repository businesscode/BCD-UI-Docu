/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.i18n.isReady)
  @description
  @method isReady
@return {boolean}  true, when i18n catalog is loaded and ready to use
@memberOf bcdui.i18n
 */
export function isReady(): boolean;
