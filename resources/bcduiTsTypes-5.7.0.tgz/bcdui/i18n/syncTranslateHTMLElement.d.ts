/**
  @typedef {Object} Type_I18nSyncTranslateHTMLElement_Args
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id. This is prefered over args.elementOrId
  @property {(HtmlElement|string)} elementOrId   ID or HTML element to translate, default "document"
  @property {Object} catalog   Catalog with i18n entries
  @property {boolean} doDefer=true  default=true  If true, in case at time of syncTranslateHtmlElement the catalog is not loaded yet, the translation is deferred and re-executed once catalog is loaded
  */
/**
@param {Type_I18nSyncTranslateHTMLElement_Args} args   Parameter object
  ````js
  { targetHtml, elementOrId, catalog, doDefer }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.i18n.syncTranslateHTMLElement)
@description   Translates the given over HTML element or the whole document
without waiting for i18nModel, we rely on it being loaded and executed before. If
the catalog is not initialized up to this moment (the catalog
initialization is asynchronous) then translation is optionally scheduled to a point
when the catalog is loaded.
@method syncTranslateHTMLElement

@example
// Usage
bcdui.i18n.syncTranslateHTMLElement({ targetHtml: "#myDiv", elementOrId, catalog, doDefer });

@return {void}
@memberOf bcdui.i18n
*/
export function syncTranslateHTMLElement(args: Type_I18nSyncTranslateHTMLElement_Args): void;
export type Type_I18nSyncTranslateHTMLElement_Args = {
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id. This is prefered over args.elementOrId
     */
    targetHtml: targetHtmlRef;
    /**
     * ID or HTML element to translate, default "document"
     */
    elementOrId: (HtmlElement | string);
    /**
     * Catalog with i18n entries
     */
    catalog: Object;
    /**
     * =true  default=true  If true, in case at time of syncTranslateHtmlElement the catalog is not loaded yet, the translation is deferred and re-executed once catalog is loaded
     */
    doDefer: boolean;
};
