/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.i18n)
 * @namespace bcdui.i18n
 */
/**
 * A magic i18n token, which can prefix a string literal to tag it as an i18n-key rather than plain-text.
This is an incubating feature only.
 */
export const TAG: {};
