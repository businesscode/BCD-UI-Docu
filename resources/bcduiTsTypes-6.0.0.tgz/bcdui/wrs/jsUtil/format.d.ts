/**
@param {(string|number)} value
  @param {(number|null)} scale   A) If abs(scale)&lt; 10 the number of decimal digits. If positive padded with trailing 0.
  B) If abs(scale)> 10 then rounded to the nearest multiple of scale, negative here is only allowed for scale = 10 pow n.
  C) Samples (in US format) for 14990.404: scale 2 -> 1490.40, scale -2 -> 1490.4, scale 1000 -> 15,000, scale -1000 -> 1.5.
  @param {string} locale   'en' (default) or 'de'
  @param {string} unit   optional unit string. If '%', the value is multiplied by 100 and '%' is appended. Everything else (including ' %') is just appened
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.jsUtil.format)
  @description   Mirrors BCD-UI's numberFormatting.xslt formatNumber logic.
  @method format

  @example
  // Usage
var ret = bcdui.wrs.jsUtil.format( value, scale, locale, unit );

@return {string}
@memberOf bcdui.wrs.jsUtil
 */
export function format(value: (string | number), scale: (number | null), locale: string, unit: string): string;
