/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.jsUtil.isNumericTypeName)
  @description   Check if a type-name string as defined by BindingSet means numeric
  @method isNumericTypeName
@return {void}
  @memberOf bcdui.wrs.jsUtil
 */
export function isNumericTypeName(): void;
