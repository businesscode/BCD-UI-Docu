/**
  @typedef {Object} Type_WrsUtilSaveModel_Args
  @property {(string|bcdui.core.DataProvider)} model   DataProvider (or its id), holding the Wrs with wrs:R|I|M|D row and wrs:C|O column nodesto be saved
  @property {boolean} [reload]   Useful especially for models of type SimpleModel for refreshing from server after save
  @property {function} [onSuccess]   Callback after saving (and optionally reloading) was successfully finished
  */
/**
@param {Type_WrsUtilSaveModel_Args} args   Parameter object with the following properties:
  ````js
  { model, reload?, onSuccess? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.saveModel)
@description   Save Wrs data of a {@link bcdui.core.DataProvider}
@method saveModel

@example
// Usage
bcdui.wrs.wrsUtil.saveModel({ model });

@return {void}
@memberOf bcdui.wrs.wrsUtil
*/
export function saveModel(args: Type_WrsUtilSaveModel_Args): void;
export type Type_WrsUtilSaveModel_Args = {
    /**
     * DataProvider (or its id), holding the Wrs with wrs:R|I|M|D row and wrs:C|O column nodesto be saved
     */
    model: (string | bcdui.core.DataProvider);
    /**
     * Useful especially for models of type SimpleModel for refreshing from server after save
     */
    reload?: boolean;
    /**
     * Callback after saving (and optionally reloading) was successfully finished
     */
    onSuccess?: Function;
};
import * as bcdui from "../../exports.js";
