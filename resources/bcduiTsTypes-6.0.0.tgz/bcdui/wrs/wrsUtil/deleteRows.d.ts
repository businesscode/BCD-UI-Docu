/**
  @typedef {Object} Type_WrsUtilDeleteRows_Args
  @property {bcdui.core.DataProvider} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} rowStartPos   Delete rows from
  @property {integer} [rowEndPos=rowStartPos]  default=rowStartPos  Delete rows including to. By default is equal rowStartPos
  @property {function} [fn]   Callback function called after operation
  @property {boolean} [propagateUpdate=true]  default=true  If false, model is not fired
  */
/**
@param {Type_WrsUtilDeleteRows_Args} args   Parameter object with the following properties
  ````js
  { model, rowStartPos, rowEndPos?, fn?, propagateUpdate? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.deleteRows)
@description   Deleting rows (operation will change source model).
See {@link bcdui.wrs.wrsUtil.restore restore()} on how the change history is maintained.
@method deleteRows

@example
// Usage
bcdui.wrs.wrsUtil.deleteRows({ model, rowStartPos });

@return {void}
@memberOf bcdui.wrs.wrsUtil
*/
export function deleteRows(args: Type_WrsUtilDeleteRows_Args): void;
export type Type_WrsUtilDeleteRows_Args = {
    /**
     * Id of a DataProvider or the DataProvider itself (dp must be ready)
     */
    model: bcdui.core.DataProvider;
    /**
     * Delete rows from
     */
    rowStartPos: integer;
    /**
     * default=rowStartPos  Delete rows including to. By default is equal rowStartPos
     */
    rowEndPos?: integer;
    /**
     * Callback function called after operation
     */
    fn?: Function;
    /**
     * default=true  If false, model is not fired
     */
    propagateUpdate?: boolean;
};
import * as bcdui from "../../exports.js";
