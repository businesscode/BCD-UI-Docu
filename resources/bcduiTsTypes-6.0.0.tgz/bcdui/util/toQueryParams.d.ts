/**
@param {string} url   URL with the parameters
  @param {string} separator
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.toQueryParams)
  @description   Logic derived from PrototypeJs library to "Parses a URI-like query string and returns an object composed of parameter/value pairs".
  @method toQueryParams

  @example
  // Usage
var ret = bcdui.util.toQueryParams( url, separator );

@return {string}  An object with the parameters of the url as properties
@memberOf bcdui.util
 */
export function toQueryParams(url: string, separator: string): string;
