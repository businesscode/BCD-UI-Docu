/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.showSessionTimeoutMessage)
  @description
  @method showSessionTimeoutMessage
@return {void}
  @memberOf bcdui.util
 */
export function showSessionTimeoutMessage(): void;
