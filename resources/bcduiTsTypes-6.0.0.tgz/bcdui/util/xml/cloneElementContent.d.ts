/**
@param {HtmlElement} targetElement   The element the content (child elements + attributes) of the
source element should be copied to.
  @param {HtmlElement} sourceElement   The source for the elements and attributes copied under the
target element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.xml.cloneElementContent)
  @description   Copies all child elements and attributes from a source XML element to a target
XML element.
  @method cloneElementContent

  @example
  // Usage
var ret = bcdui.util.xml.cloneElementContent( targetElement, sourceElement );

@return {DomElement}  The targetElement.
@memberOf bcdui.util.xml
 */
export function cloneElementContent(targetElement: HtmlElement, sourceElement: HtmlElement): DomElement;
