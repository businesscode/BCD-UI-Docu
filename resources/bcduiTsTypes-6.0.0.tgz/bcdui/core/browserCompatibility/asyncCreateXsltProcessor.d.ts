/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.asyncCreateXsltProcessor)
  @description
  @method asyncCreateXsltProcessor
@return {void}
  @memberOf bcdui.core.browserCompatibility
 */
export function asyncCreateXsltProcessor(): void;
