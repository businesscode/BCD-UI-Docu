/**
  @class bcdui.core.DataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider)
  @description A data provider is an abstract class on top of the {@link bcdui.core.AbstractExecutable},
extending it by data-related functions (like getName, getData, data modification events).
The name is filled with the id by default or set from the "name" argument.
getData() is abstract and must be provided by sub-classes.

<br/>Most common implementations are:
{@link bcdui.core.StaticModel} &bull;
{@link bcdui.core.SimpleModel} &bull;
{@link bcdui.core.ModelWrapper}

<br/>Further implementations:
{@link bcdui.core.AsyncJsDataProvider} &bull;
{@link bcdui.core.StringDataProvider} &bull;
{@link bcdui.core.DataProviderHtmlAttribute} &bull;
{@link bcdui.core.RequestDocumentDataProvider} &bull;
{@link bcdui.core.DataProviderWithXPathNodes} &bull;
{@link bcdui.core.DataProviderWithXPath} &bull;
{@link bcdui.core.DataProviderHolder} &bull;
{@link bcdui.core.DataProviderAlias} &bull;
{@link bcdui.core.ConstantDataProvider} &bull;
{@link bcdui.core.PromptDataProvider}
  @description Calls the initializer of {@link bcdui.core.AbstractExecutable} and additionally sets
the name property. This property is filled from the "args" parameter
map or set to the "id" if there is no "args.name" value in the map.
<p>
  In contrast to the id property the name does not need to be globally unique,
  Instead, it should be unique within the scope it is used for. For example
  if the data provider is passed to a {@link bcdui.core.TransformationChain} the name should
  be unique for within this TransformationChain object.
</p>
  @extends bcdui.core.AbstractExecutable
*/
export class DataProvider extends bcdui.core.AbstractExecutable {
    /**
    @description A data provider is an abstract class on top of the {@link bcdui.core.AbstractExecutable},
  extending it by data-related functions (like getName, getData, data modification events).
  The name is filled with the id by default or set from the "name" argument.
  getData() is abstract and must be provided by sub-classes.
  
  <br/>Most common implementations are:
  {@link bcdui.core.StaticModel} &bull;
  {@link bcdui.core.SimpleModel} &bull;
  {@link bcdui.core.ModelWrapper}
  
  <br/>Further implementations:
  {@link bcdui.core.AsyncJsDataProvider} &bull;
  {@link bcdui.core.StringDataProvider} &bull;
  {@link bcdui.core.DataProviderHtmlAttribute} &bull;
  {@link bcdui.core.RequestDocumentDataProvider} &bull;
  {@link bcdui.core.DataProviderWithXPathNodes} &bull;
  {@link bcdui.core.DataProviderWithXPath} &bull;
  {@link bcdui.core.DataProviderHolder} &bull;
  {@link bcdui.core.DataProviderAlias} &bull;
  {@link bcdui.core.ConstantDataProvider} &bull;
  {@link bcdui.core.PromptDataProvider}
    @description Calls the initializer of {@link bcdui.core.AbstractExecutable} and additionally sets
  the name property. This property is filled from the "args" parameter
  map or set to the "id" if there is no "args.name" value in the map.
  <p>
    In contrast to the id property the name does not need to be globally unique,
    Instead, it should be unique within the scope it is used for. For example
    if the data provider is passed to a {@link bcdui.core.TransformationChain} the name should
    be unique for within this TransformationChain object.
  </p>
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider)
    @param {object} args
      */
    constructor(args: object);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=debugiswaitingfor)
    @public
    @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
    */
    public debugIsWaitingFor(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=debugstatus)
    @public
    @return {string} Human readable message about the current state state
    */
    public debugStatus(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=fetchdata)
    @description   asynchronously fetch data for this data provider.
    @public
    @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
    */
    public fetchData(): Promise<bcdui.core.DataProvider>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=fire)
    @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completed
  and data is consistent again.
    @public
    @return {void}
    */
    public fire(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getdata)
    @description   Access to the data of this DataProvider for read and modification access
    @public
    @return {*} The data provided by the specific sub-class.
    */
    public getData(): any;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getname)
    @description   Getter for the name of the data provider. This name is for example used
  to set parameters names of a {@link bcdui.core.TransformationChain}.
    @public
    @return {string} The name of the data provider. This name should be unique
  within the scope it is used and is usually not globally unique (as the id).
    */
    public getName(): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=isclean)
    @description   True, if DataProvider is ready and there are no uncommitted write transactions,
  see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
    @public
    @return {boolean}
    */
    public isClean(): boolean;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=onchange)
    @param {(function|OnChangeParam)} listenerObject   Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
    @param {string} [trackingXPath]   xPath to monitor to monitor for changes
    @public
    @return {void}
    */
    public onChange(listenerObject: (Function | OnChangeParam), trackingXPath?: string): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=promptdata)
    @description   Convenience method for debugging showing data in a prompt for copy-and-paste
    @public
    @return {void}
    */
    public promptData(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=query)
    @description   Reads a single node from a given xPath
    @param {string} xPath   xPath to query
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @public
    @return {(DomNode|null)} single node or null if query fails
    */
    public query(xPath: string, fillParams?: Object): (DomNode | null);
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=querynodes)
    @description   Get node list from a given xPath
    @param {string} xPath   xPath to query
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @public
    @return {Array.<DomNode>} node list or empty list if query fails
    */
    public queryNodes(xPath: string, fillParams?: Object): Array<DomNode>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=read)
    @description   Reads the string value from a given xPath (or optionally return default value).
    @param {string} xPath   xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @param {string} [defaultValue]   default value in case xPath value does not exist
    @public
    @return {string} text value stored at xPath (or null if no text was found and no defaultValue supplied)
    */
    public read(xPath: string, fillParams?: Object, defaultValue?: string): string;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=remove)
    @description   Deletes data at a given xPath from the model
    @param {string} xPath   xPath pointing to the value
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
    @param {boolean} [fire]   if true a fire is triggered to notify data modification listener
    @public
    @return {void}
    */
    public remove(xPath: string, fillParams?: Object, fire?: boolean): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=removedatalistener)
    @param {(string|function|RemoveDataListenerParam)} listenerObject   Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
    @public
    @return {void}
    */
    public removeDataListener(listenerObject: (string | Function | RemoveDataListenerParam)): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=senddata)
    @description   Sends the current data to the original URL
    @public
    @return {void}
    */
    public sendData(): void;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=serialize)
    @description   Serialize dataprovider's data if available
    @public
    @return {string} String containing the serialized data
    */
    public serialize(): string;
    /**
      @typedef {Object} Type_DataProviderTblDelete_Args
      @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
      @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
      @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
      @property {string} [rowId]   id specifying row which should be deleted (or use filter)
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tbldelete)
    @description   Delete Wrs rows. Either a single row (via rowId) or single/multiple ones via filter
  The filter's property names refer to the columns ids.
    @param {Type_DataProviderTblDelete_Args} args   parameter bag
      ````js
      { filter?, rmi?, fire?, rowId? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {number} count of removed rows
    */
    public tblDelete(args: {
        /**
         * affected row(s) for example `{ country: 'DE', flag: true }`
         */
        filter?: Object;
        /**
         * default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
         */
        rmi?: boolean;
        /**
         * default=true  lets the listeners know, that the update was finished
         */
        fire?: boolean;
        /**
         * id specifying row which should be deleted (or use filter)
         */
        rowId?: string;
    }): number;
    /**
      @typedef {Object} Type_DataProviderTblGetColumnMetadata_Args
      @property {Array.<string>} [columns]   Limit to these column ids
      @property {boolean} [doSort]   Sort the columns according to the given columns list. If not given, the columns are returned in the order they are defined in the WRS.
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblgetcolumnmetadata)
    @description   Returns an array of columns of a Wrs with their metadata attributes like id, caption, type-name etc.
  Includes id, caption, pos, type-name, display-size, scale, isKey, nullable, references etc.
  For example: `[{id: 'ctr', caption: 'Country', pos: '1'}, {id: 'state', caption: 'State', pos: '2', references: [ {value: '#e00', caption: 'Red'}, {value: '#0e0', caption: 'Green'} ]}]`
    @param {Type_DataProviderTblGetColumnMetadata_Args} [args]
      ````js
      { columns?, doSort? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {Array.<Object>} column metadata
    */
    public tblGetColumnMetadata(args?: {
        /**
         * Limit to these column ids
         */
        columns?: Array<string>;
        /**
         * Sort the columns according to the given columns list. If not given, the columns are returned in the order they are defined in the WRS.
         */
        doSort?: boolean;
    }): Array<Object>;
    /**
      @typedef {Object} Type_DataProviderTblGetRowIds_Args
      @property {object} [filter]   object holding requested filter conditions, e.g. `{ country: 'DE', flag: true }`
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblgetrowids)
    @description   Returns an array of row ids (wrs:R/&commat;id) of the rows matching the filter.
  If no filter is given, all row ids are returned.
  The order of ids matches the order of the rows in the Wrs.
    @param {Type_DataProviderTblGetRowIds_Args} args
      ````js
      { filter? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {Array.<string>} row ids
    */
    public tblGetRowIds(args: {
        /**
         * object holding requested filter conditions, e.g. `{ country: 'DE', flag: true }`
         */
        filter?: object;
    }): Array<string>;
    /**
      @typedef {Object} Type_DataProviderTblInsert_Args
      @property {Object} values   object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
      @property {boolean} [rmi=true]  default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
      @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblinsert)
    @description   Inserts a new row in the Wrs. The property names match the Wrs header ids.
    @param {Type_DataProviderTblInsert_Args} args   parameter bag
      ````js
      { values, rmi?, fire? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  var ret = myDP.tblInsert({ values });
  
  @return {string} row id of newly inserted row
    */
    public tblInsert(args: {
        /**
         * object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
         */
        values: Object;
        /**
         * default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
         */
        rmi?: boolean;
        /**
         * default=true  lets the listeners know, that the update was finished
         */
        fire?: boolean;
    }): string;
    /**
      @typedef {Object} Type_DataProviderTblSelect_Args
      @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
      @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblselect)
    @description   Selects an array of row values like `[{ctr: 'DE', site: 'HAM', flag: true}, {ctr: 'DE', site: 'BER', flag: false}];` for a given filter.
  The filter's and the returned property names match the column ids.
    @param {Type_DataProviderTblSelect_Args} args   parameter bag
      ````js
      { filter?, columns? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {Array.<Object>} Array of objects holding the requested data
    */
    public tblSelect(args: {
        /**
         * object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
         */
        filter?: Object;
        /**
         * string array of requested columns, if not given, all columns are returned
         */
        columns?: Array<string>;
    }): Array<Object>;
    /**
      @typedef {Object} Type_DataProviderTblSelectRow_Args
      @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
      @property {string} [rowId]   rowId of row which should be queried (or use filter)
      @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblselectrow)
    @description   Get the values of a single row, identified either by its `wrs:/&commat;id`, or the first one matching the filter.
  The filter's and the returned property names match the column ids.
    @param {Type_DataProviderTblSelectRow_Args} args   parameter bag
      ````js
      { filter?, rowId?, columns? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    @return {Object} Array  of objects holding the requested data
    */
    public tblSelectRow(args: {
        /**
         * object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
         */
        filter?: Object;
        /**
         * rowId of row which should be queried (or use filter)
         */
        rowId?: string;
        /**
         * string array of requested columns, if not given, all columns are returned
         */
        columns?: Array<string>;
    }): Object;
    /**
      @typedef {Object} Type_DataProviderTblUpdate_Args
      @property {Object} values   columns and values to be updated. This sets 2 columns { country: 'DE', flag: true }
      @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
      @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
      @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
      @property {string} [rowId]   id specifying row which should be updated (or use filter)
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblupdate)
    @description   Updates one or multiple Wrs rows with given data.
  Either a single row (via rowId) or single/multiple ones (via filter)
  The filter's and the given values' property names refer to the columns ids.
    @param {Type_DataProviderTblUpdate_Args} args   parameter bag
      ````js
      { values, filter?, rmi?, fire?, rowId? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  var ret = myDP.tblUpdate({ values });
  
  @return {number} count of updated rows
    */
    public tblUpdate(args: {
        /**
         * columns and values to be updated. This sets 2 columns { country: 'DE', flag: true }
         */
        values: Object;
        /**
         * affected row(s) for example `{ country: 'DE', flag: true }`
         */
        filter?: Object;
        /**
         * default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
         */
        rmi?: boolean;
        /**
         * default=true  lets the listeners know, that the update was finished
         */
        fire?: boolean;
        /**
         * id specifying row which should be updated (or use filter)
         */
        rowId?: string;
    }): number;
    /**
      @typedef {Object} Type_DataProviderTblValidateRowChange_Args
      @property {Object} values   { colId: value } map of values to validate
      @property {string} [rowId]   only needed for key uniqueness: identifies the row being validated so it is excluded from the duplicate check.
       If not given values is treated like a new row to be inserted
      @property {Object} [filter]   alternative to parameter rowId; first matching row is used
      */
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblvalidaterowchange)
    @description   Validates a set of column values against the WRS header constraints of this DataProvider, i.e., would these valus be valid.
  The check is purely client-side (no server round-trip): type, scale, display-size, nullable,
  embedded header References, and key uniqueness within the loaded data are all covered.
  Only columns present in args.values are validated.
  For a planned tblUpdate, provide rowId or filter to exclude the changed row from uniqueness check.
  For a planned tblInsert, rowId is not needed as the uniqueness check is performed against all current loaded data.
    @param {Type_DataProviderTblValidateRowChange_Args} args   parameter bag
      ````js
      { values, rowId?, filter? }
      ````
      <br/>Use autocomplete in {} to get a full parameter description <br/>
    @public
    
    @example
    // Usage
  var ret = myDP.tblValidateRowChange({ values });
  
  @return {Array.<{colId: string, errorCode: string}>} list of validation errors
    */
    public tblValidateRowChange(args: {
        /**
         * { colId: value } map of values to validate
         */
        values: Object;
        /**
         * only needed for key uniqueness: identifies the row being validated so it is excluded from the duplicate check.
        If not given values is treated like a new row to be inserted
         */
        rowId?: string;
        /**
         * alternative to parameter rowId; first matching row is used
         */
        filter?: Object;
    }): Array<{
        colId: string;
        errorCode: string;
    }>;
    /**
    @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=write)
    @description   Set a value to on a certain xPath and create the xPath where necessary.
  This combines Element.evaluate() for a single node with creating the path where necessary.
  It will prefer extending an existing start-part over creating a second one.
  After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
    @param {string} xPath   xPath pointing to the node which is to be modified. Only the first match will be modified.
     If it does not exist, it will be created.
     For example, if you provide `/n:Root/n:MyElem/&commat;attr2` and there is already `/n:Root/n:MyElem/&commat;attr1`, then `/n:Root/n:MyElem` will be "re-used" and get an additional attribute attr2.
     Even complex expressions are allowed, like predicates `/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem`.
     Ambiguous xPaths are not allowed, for example, using `//` or `/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem`, and will throw an error.
     The method is Wrs aware, for Wrs it turns wrs:R into wrs:M etc., see Wrs format.
     Using {{=it[0]}} templates makes sure values are escaped correctly.
    @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
      Example: `bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])`
    @param {string} [value]   Optional value which should be written, for example to `/n:Root/n:MyElem/&commat;attr` or with `/n:Root/n:MyElem` as the element's text content.
     If not provided, the xPath contains all values and either there is a full match or it will be created.
    @param {boolean} [fire]   If true a fire is triggered to inform data modification listeners
    @public
    @return {DomNode} The xPath's node or null if dataProvider isn't ready
    */
    public write(xPath: string, fillParams?: Object, value?: string, fire?: boolean): DomNode;
    /**
           * @constant
           * @type {bcdui.core.Status}
           * @example
           * if( model.getStatus() === model.savedStatus )
           *   ...
           */
    savedStatus: bcdui.core.Status;
    /**
           * @constant
           * @type {bcdui.core.Status}
           */
    saveFailedStatus: bcdui.core.Status;
}
import * as bcdui from "../exports.js";
