/**
@param {function} fn   The function executed as soon as the browser has finished loading.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.ready)
  @description   Registers a callback function to be executed when the browser has finished
loading. If the loading has already finished the function is executed
immediately.
  @method ready
@return {void}
  @memberOf bcdui.core
 */
export function ready(fn: Function): void;
