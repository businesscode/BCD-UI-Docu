/**
  @typedef {Object} Type_LifecycleApplyAction_Args
  @property {boolean} [cleanXPath]   Additional XPath to be cleaned from the guiStatus
  @property {boolean} [validateFilters]   True or false whether or not to check IsValid flags of guiStatus filters
  @property {DomDocument} [statusDocument=bcdui.wkModels.guiStatus]  default=bcdui.wkModels.guiStatus  optionally, other statusDocument than guiStatus
  @property {boolean} [removeAllParams]   True or false whether or not to remove all url parameters first
  */
/**
@param {Type_LifecycleApplyAction_Args} args
  ````js
  { cleanXPath?, validateFilters?, statusDocument?, removeAllParams? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.lifecycle.applyAction)
@description   Takes the current guiStatus and re-invokes the current page with it
<code>/guiStatus:Status/guiStatus:ClientSettings</code> is removed as it only serves for temporary information
@method applyAction
@return {void}
@memberOf bcdui.core.lifecycle
*/
export function applyAction(args: Type_LifecycleApplyAction_Args): void;
export type Type_LifecycleApplyAction_Args = {
    /**
     * Additional XPath to be cleaned from the guiStatus
     */
    cleanXPath?: boolean;
    /**
     * True or false whether or not to check IsValid flags of guiStatus filters
     */
    validateFilters?: boolean;
    /**
     * default=bcdui.wkModels.guiStatus  optionally, other statusDocument than guiStatus
     */
    statusDocument?: DomDocument;
    /**
     * True or false whether or not to remove all url parameters first
     */
    removeAllParams?: boolean;
};
