/**
  @typedef {Object} Type_WidgetFilterRows_Args
  @property {XMLDocument} guiStatus   Status model
  @property {XMLDocument} paramModel   (DOM) Parameter model according to xmlns http://www.businesscode.de/schema/bcdui/xsltParams-1.0.0
  @property {string} [paramSetId]   Optional specific parameter set ID
  @property {string} [filtersXpath]   Optional XPath where are the filter values, like $guiStatus/guiStatus:Status/guiStatus:ClientSettings/Grid[&commat;id='myGrid']/Filter
                                        default: $paramModel//xp:FilterXPath[&commat;paramSetId=$paramSetId or not(@paramSetId) and not($paramSetId)]/xp:Value
  */
/**
@param {XMLDocument} doc   function input wrs document
@param {Type_WidgetFilterRows_Args} args   parameter object
  ````js
  { guiStatus, paramModel, paramSetId?, filtersXpath? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.filterRows)
@description   js implementation of filterRowsTemplate.xslt
Allows filtering of rows of a wrs input document by specifying column filters
@method filterRows

@example
// Usage
var ret = bcdui.widget.filterRows({ guiStatus, paramModel });

@return {XMLDocument}  filtered document
@memberOf bcdui.widget
*/
export function filterRows(doc: XMLDocument, args: Type_WidgetFilterRows_Args): XMLDocument;
export type Type_WidgetFilterRows_Args = {
    /**
     * Status model
     */
    guiStatus: XMLDocument;
    /**
     * (DOM) Parameter model according to xmlns http://www.businesscode.de/schema/bcdui/xsltParams-1.0.0
     */
    paramModel: XMLDocument;
    /**
     * Optional specific parameter set ID
     */
    paramSetId?: string;
    /**
     * Optional XPath where are the filter values, like $guiStatus/guiStatus:Status/guiStatus:ClientSettings/Grid[&commat;id='myGrid']/Filter
         default: $paramModel//xp:FilterXPath[&commat;paramSetId=$paramSetId or not(@paramSetId) and not($paramSetId)]/xp:Value
     */
    filtersXpath?: string;
};
