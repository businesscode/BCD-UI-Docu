/**
@param {string} [values]   A space separated string which lists the ordered targetIds of the widgets which should be queried (or empty for all)
  @param {string} [separator=" "]   A string used for delimiter between single widget navpath values
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.getCurrentNavPath)
  @description   Get current navpath widget information for the given widget targets.
  @method getCurrentNavPath
@return {string}  string containing the current navPath for your selected values
@memberOf bcdui.widget
 */
export function getCurrentNavPath(values?: string, separator?: string): string;
