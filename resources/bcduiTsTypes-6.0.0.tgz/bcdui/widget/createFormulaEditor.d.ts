/**
  @typedef {Object} Type_WidgetCreateFormulaEditor_Args
  @property {writableModelXPath} targetModelXPath   The xPath pointing to the root-node this widget will place entered selected items into. The underlying XML  format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target.
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [id]   ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [caption='']  default=''  Default '', it will be used as i18n key to translate the caption.
  @property {boolean} [mandatory]   An empty value is invalid if this parameters sets to true. Default is false.
  @property {modelXPath} [optionsModelXPath]   xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {string} [optionsModelRelativeValueXPath]   xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {boolean} [validate=true]  default=true  Turn on-off the validation of the formula.
  @property {boolean} [validateVariableNamesCheckbox]   Show or hide checkbox for validate variables option.
  @property {string} [skipValidationCaption="Skip check of values"]  default="Skip check of values"  Caption to be shown for skipping validation. Default is 'Skip check of values'.
  @property {boolean} [skipServerSidedFunctions]   Set to true to disable usage of server sided functions like CntDist. Default is false.
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  @property {boolean} [enableNavPath]   Set to true if widget should not be added to navpath handling.
  */
/**
@param {Type_WidgetCreateFormulaEditor_Args} args   The parameter map contains the following properties.
  ````js
  { targetModelXPath, targetHtml, id?, caption?, mandatory?, optionsModelXPath?, optionsModelRelativeValueXPath?, validate?, validateVariableNamesCheckbox?, skipValidationCaption?, skipServerSidedFunctions?, widgetCaption?, enableNavPath? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.createFormulaEditor)
@description   Displays a field where the user can enter a formula
@method createFormulaEditor

@example
// Usage
bcdui.widget.createFormulaEditor({ targetModelXPath: "$guiStatus/cust:Elem/@value", targetHtml: "#myDiv" });

@return {void}
@memberOf bcdui.widget
*/
export function createFormulaEditor(args: Type_WidgetCreateFormulaEditor_Args): void;
export type Type_WidgetCreateFormulaEditor_Args = {
    /**
     * The xPath pointing to the root-node this widget will place entered selected items into. The underlying XML  format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target.
     */
    targetModelXPath: writableModelXPath;
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
     */
    id?: string;
    /**
     * default=''  Default '', it will be used as i18n key to translate the caption.
     */
    caption?: string;
    /**
     * An empty value is invalid if this parameters sets to true. Default is false.
     */
    mandatory?: boolean;
    /**
     * xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
     */
    optionsModelXPath?: modelXPath;
    /**
     * xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
     */
    optionsModelRelativeValueXPath?: string;
    /**
     * default=true  Turn on-off the validation of the formula.
     */
    validate?: boolean;
    /**
     * Show or hide checkbox for validate variables option.
     */
    validateVariableNamesCheckbox?: boolean;
    /**
     * default="Skip check of values"  Caption to be shown for skipping validation. Default is 'Skip check of values'.
     */
    skipValidationCaption?: string;
    /**
     * Set to true to disable usage of server sided functions like CntDist. Default is false.
     */
    skipServerSidedFunctions?: boolean;
    /**
     * A caption which is used as prefix for navPath generation for this widget.
     */
    widgetCaption?: string;
    /**
     * Set to true if widget should not be added to navpath handling.
     */
    enableNavPath?: boolean;
};
