/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.hasValidStatus)
  @description   NO REVALIDATION, just retrieval of current validity state, consideres
native (constraint validation api) state and bcdui-internal ( existence of 'bcdInvalid' class).
CSS case has to be considered because browsers native validation implementaion may
switch validity state so that we cannot detect the change without fully revalidating
the field.
  @method hasValidStatus
@return {boolean}  true if valid, false otherwise
@memberOf bcdui.widgetNg.validation
 */
export function hasValidStatus(): boolean;
