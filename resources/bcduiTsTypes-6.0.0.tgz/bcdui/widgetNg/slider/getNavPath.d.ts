/**
@param {string} id   targetHtml of widget
  @param {function} callback   to be called with generated caption
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.slider.getNavPath)
  @description
  @method getNavPath

  @example
  // Usage
var ret = bcdui.widgetNg.slider.getNavPath( id, callback );

@return {string}  NavPath information via callback for widget
@memberOf bcdui.widgetNg.slider
 */
export function getNavPath(id: string, callback: Function): string;
