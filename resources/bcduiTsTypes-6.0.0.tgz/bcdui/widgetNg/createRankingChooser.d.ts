/**
  @typedef {Object} Type_WidgetNgCreateRankingChooser_Args
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {writableModelXPath} targetModelXPath   The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget.
  @property {boolean} [autofocus]   requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {boolean} [disabled]   All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [displayBalloon]   hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [enableNavPath]   Set to true if widget should be added to navpath handling.
  @property {i18nToken} [hint]   A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id]   Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {boolean} [isScorecard]   Can be set to 'true' if ranking is used for a scorecard. In this case scc: prefix is used.
  @property {i18nToken} [label]   If provided, enables widget to render a label element
  @property {number} [limit=3]  default=3  Limit the number of possible rankings.
  @property {xPath} [optionsModelRelativeValueXPathDimensions="."]  default="."  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {xPath} [optionsModelRelativeValueXPathMeasures="."]  default="."  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {xPath} [optionsModelXPathDimensions]   xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {xPath} [optionsModelXPathMeasures]   xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {integer} [tabindex]   the HTML compliant tabIndex
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  */
/**
@param {Type_WidgetNgCreateRankingChooser_Args} args   The parameter map contains the following properties.
  ````js
  { targetHtml, targetModelXPath, autofocus?, disabled?, displayBalloon?, enableNavPath?, hint?, id?, isScorecard?, label?, limit?, optionsModelRelativeValueXPathDimensions?, optionsModelRelativeValueXPathMeasures?, optionsModelXPathDimensions?, optionsModelXPathMeasures?, tabindex?, widgetCaption? }
  ````
  <br/>Use autocomplete in {} to get a full parameter description <br/>
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.createRankingChooser)
@description   Offers a ranking chooser where you can select dimensions and measures for a ranking operation
@method createRankingChooser

@example
// Usage
bcdui.widgetNg.createRankingChooser({ targetHtml: "#myDiv", targetModelXPath: "$guiStatus/cust:Elem/@value" });

@return {void}
@memberOf bcdui.widgetNg
*/
export function createRankingChooser(args: Type_WidgetNgCreateRankingChooser_Args): void;
export type Type_WidgetNgCreateRankingChooser_Args = {
    /**
     * An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
     */
    targetHtml: targetHtmlRef;
    /**
     * The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget.
     */
    targetModelXPath: writableModelXPath;
    /**
     * requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
     */
    autofocus?: boolean;
    /**
     * All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
     */
    disabled?: boolean;
    /**
     * hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
     */
    displayBalloon?: boolean;
    /**
     * Set to true if widget should be added to navpath handling.
     */
    enableNavPath?: boolean;
    /**
     * A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
     */
    hint?: i18nToken;
    /**
     * Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
     */
    id?: string;
    /**
     * Can be set to 'true' if ranking is used for a scorecard. In this case scc: prefix is used.
     */
    isScorecard?: boolean;
    /**
     * If provided, enables widget to render a label element
     */
    label?: i18nToken;
    /**
     * default=3  Limit the number of possible rankings.
     */
    limit?: number;
    /**
     * default="."  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
     */
    optionsModelRelativeValueXPathDimensions?: xPath;
    /**
     * default="."  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
     */
    optionsModelRelativeValueXPathMeasures?: xPath;
    /**
     * xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
     */
    optionsModelXPathDimensions?: xPath;
    /**
     * xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
     */
    optionsModelXPathMeasures?: xPath;
    /**
     * the HTML compliant tabIndex
     */
    tabindex?: integer;
    /**
     * A caption which is used as prefix for navPath generation for this widget.
     */
    widgetCaption?: string;
};
