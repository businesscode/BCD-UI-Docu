/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.core.DataProvider
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider)
  @description A data provider is an abstract class on top of the {@link bcdui.core.AbstractExecutable},extending it by data-related functions (like getName, getData, data modification events).The name is filled with the id by default or set from the "name" argument.getData() is abstract and must be provided by sub-classes.<br/>Most common implementations are:{@link bcdui.core.StaticModel} &bull;{@link bcdui.core.SimpleModel} &bull;{@link bcdui.core.ModelWrapper}<br/>Further implementations:{@link bcdui.core.AsyncJsDataProvider} &bull;{@link bcdui.core.StringDataProvider} &bull;{@link bcdui.core.DataProviderHtmlAttribute} &bull;{@link bcdui.core.RequestDocumentDataProvider} &bull;{@link bcdui.core.DataProviderWithXPathNodes} &bull;{@link bcdui.core.DataProviderWithXPath} &bull;{@link bcdui.core.DataProviderHolder} &bull;{@link bcdui.core.DataProviderAlias} &bull;{@link bcdui.core.ConstantDataProvider} &bull;{@link bcdui.core.PromptDataProvider}
  @description Calls the initializer of {@link bcdui.core.AbstractExecutable} and additionally setsthe name property. This property is filled from the "args" parametermap or set to the "id" if there is no "args.name" value in the map.<p>  In contrast to the id property the name does not need to be globally unique,  Instead, it should be unique within the scope it is used for. For example  if the data provider is passed to a {@link bcdui.core.TransformationChain} the name should  be unique for within this TransformationChain object.</p>
  @extends bcdui.core.AbstractExecutable
*/
// @ts-ignore
export class DataProvider extends bcdui.core.AbstractExecutable {
  /**
  @description A data provider is an abstract class on top of the {@link bcdui.core.AbstractExecutable},extending it by data-related functions (like getName, getData, data modification events).The name is filled with the id by default or set from the "name" argument.getData() is abstract and must be provided by sub-classes.<br/>Most common implementations are:{@link bcdui.core.StaticModel} &bull;{@link bcdui.core.SimpleModel} &bull;{@link bcdui.core.ModelWrapper}<br/>Further implementations:{@link bcdui.core.AsyncJsDataProvider} &bull;{@link bcdui.core.StringDataProvider} &bull;{@link bcdui.core.DataProviderHtmlAttribute} &bull;{@link bcdui.core.RequestDocumentDataProvider} &bull;{@link bcdui.core.DataProviderWithXPathNodes} &bull;{@link bcdui.core.DataProviderWithXPath} &bull;{@link bcdui.core.DataProviderHolder} &bull;{@link bcdui.core.DataProviderAlias} &bull;{@link bcdui.core.ConstantDataProvider} &bull;{@link bcdui.core.PromptDataProvider}
  @description Calls the initializer of {@link bcdui.core.AbstractExecutable} and additionally setsthe name property. This property is filled from the "args" parametermap or set to the "id" if there is no "args.name" value in the map.<p>  In contrast to the id property the name does not need to be globally unique,  Instead, it should be unique within the scope it is used for. For example  if the data provider is passed to a {@link bcdui.core.TransformationChain} the name should  be unique for within this TransformationChain object.</p>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider)
  @param {object} args 
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=debugiswaitingfor)
  @public
  @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
  */
  debugIsWaitingFor() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=debugstatus)
  @public
  @return {string} Human readable message about the current state state
  */
  debugStatus() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=fetchdata)
  @description   asynchronously fetch data for this data provider.
  @public
  @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
  */
  fetchData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=fire)
  @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completedand data is consistent again.
  @public
  @return {void}
  */
  fire() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getclassname)
  @description   Get className
  @overrides bcdui.core.AbstractExecutable#getClassName
  @public
  @return {string} className
  */
  getClassName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getdata)
  @description   Access to the data of this DataProvider for read and modification access
  @public
  @return {*} The data provided by the specific sub-class.
  */
  getData() { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getname)
  @description   Getter for the name of the data provider. This name is for example usedto set parameters names of a {@link bcdui.core.TransformationChain}.
  @public
  @return {string} The name of the data provider. This name should be uniquewithin the scope it is used and is usually not globally unique (as the id).
  */
  getName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=isclean)
  @description   True, if DataProvider is ready and there are no uncommitted write transactions,see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
  @public
  @return {boolean}
  */
  isClean() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=onchange)
  @param {(function|OnChangeParam)} listenerObject   Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
  @param {string} [trackingXPath]   xPath to monitor to monitor for changes
  @public
  @return {void}
  */
  onChange(listenerObject,trackingXPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=promptdata)
  @description   Convenience method for debugging showing data in a prompt for copy-and-paste
  @public
  @return {void}
  */
  promptData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=query)
  @description   Reads a single node from a given xPath
  @param {string} xPath   xPath to query
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @public
  @return {(DomNode|null)} single node or null if query fails
  */
  query(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=querynodes)
  @description   Get node list from a given xPath
  @param {string} xPath   xPath to query
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @public
  @return {Array.<DomNode>} node list or empty list if query fails
  */
  queryNodes(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=read)
  @description   Reads the string value from a given xPath (or optionally return default value).
  @param {string} xPath   xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [defaultValue]   default value in case xPath value does not exist
  @public
  @return {string} text value stored at xPath (or null if no text was found and no defaultValue supplied)
  */
  read(xPath,fillParams,defaultValue) { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=remove)
  @description   Deletes data at a given xPath from the model
  @param {string} xPath   xPath pointing to the value
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {boolean} [fire]   if true a fire is triggered to notify data modification listener
  @public
  @return {void}
  */
  remove(xPath,fillParams,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=removedatalistener)
  @param {(string|function|RemoveDataListenerParam)} listenerObject   Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
  @public
  @return {void}
  */
  removeDataListener(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=senddata)
  @description   Sends the current data to the original URL
  @public
  @return {void}
  */
  sendData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=serialize)
  @description   Serialize dataprovider's data if available
  @public
  @return {string} String containing the serialized data
  */
  serialize() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=setstatus)
  @description   Makes a transition from the current status to the new status if theyare not equal. After the status is changed it fires the status eventto the registered listeners.<p/>Usually this method will only be called by the library but you can use it to re-trigger an action. For available statuses and their effect, see the concrete class,
  @param {bcdui.core.Status} args 
  @overrides bcdui.core.AbstractExecutable#setStatus
  @public
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_DataProviderTblDelete_Args
  @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
  @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  @property {string} [rowId]   id specifying row which should be deleted (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tbldelete)
  @description   Delete Wrs rows. Either a single row (via rowId) or single/multiple ones via filterThe filter's property names refer to the columns ids.
  @param {Type_DataProviderTblDelete_Args} args   parameter bag
    ````js
    { filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  @return {number} count of removed rows
  */
  tblDelete(args) { return 0; }
/**
  @typedef {Object} Type_DataProviderTblInsert_Args
  @property {Object} values   object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true]  default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblinsert)
  @description   Inserts a new row in the Wrs. The property names match the Wrs header ids.
  @param {Type_DataProviderTblInsert_Args} args   parameter bag
    ````js
    { values, rmi?, fire? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  // Usage
var ret = myDP.tblInsert({ values });

@return {string} row id of newly inserted row
  */
  tblInsert(args) { return ""; }
/**
  @typedef {Object} Type_DataProviderTblSelect_Args
  @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblselect)
  @description   Selects an array of row values like `[{ctr: 'DE', site: 'HAM', flag: true}, {ctr: 'DE', site: 'BER', flag: false}];` for a given filter.The filter's and the returned property names match the column ids.
  @param {Type_DataProviderTblSelect_Args} args   parameter bag
    ````js
    { filter?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  @return {Array.<Object>} Array of objects holding the requested data
  */
  tblSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_DataProviderTblSelectRow_Args
  @property {Object} [filter]   object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {string} [rowId]   rowId of row which should be queried (or use filter)
  @property {Array.<string>} [columns]   string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblselectrow)
  @description   Returns an object with the values of a single row, which is either identified by its `wrs:/&commat;id` if given, or the first one matching the filter.The filter's and the returned property names match the column ids.
  @param {Type_DataProviderTblSelectRow_Args} args   parameter bag
    ````js
    { filter?, rowId?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  @return {Object} Array  of objects holding the requested data
  */
  tblSelectRow(args) { return {}; }
/**
  @typedef {Object} Type_DataProviderTblUpdate_Args
  @property {Object} values   columns and values to be updated. This sets 2 columns { country: 'DE', flag: true }
  @property {Object} [filter]   affected row(s) for example `{ country: 'DE', flag: true }`
  @property {boolean} [rmi=true]  default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true]  default=true  lets the listeners know, that the update was finished
  @property {string} [rowId]   id specifying row which should be updated (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tblupdate)
  @description   Updates one or multiple Wrs rows with given data.Either a single row (via rowId) or single/multiple ones (via filter)The filter's and the given values' property names refer to the columns ids.
  @param {Type_DataProviderTblUpdate_Args} args   parameter bag
    ````js
    { values, filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  // Usage
var ret = myDP.tblUpdate({ values });

@return {number} count of updated rows
  */
  tblUpdate(args) { return 0; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=tostring)
  @description   Useful for debugging.
  @overrides bcdui.core.AbstractExecutable#toString
  @public
  @return {string} A short string summary of this object.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=write)
  @description   Set a value to on a certain xPath and create the xPath where necessary. This combines Element.evaluate() for a single node with creating the path where necessary. It will prefer extending an existing start-part over creating a second one.After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
  @param {string} xPath   xPath pointing to the node which is to be modified. Only the first match will be modified.   If it does not exist, it will be created.   For example, if you provide `/n:Root/n:MyElem/&commat;attr2` and there is already `/n:Root/n:MyElem/&commat;attr1`, then `/n:Root/n:MyElem` will be "re-used" and get an additional attribute attr2.   Even complex expressions are allowed, like predicates `/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem`.   Ambiguous xPaths are not allowed, for example, using `//` or `/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem`, and will throw an error.   The method is Wrs aware, for Wrs it turns wrs:R into wrs:M etc., see Wrs format.   Using {{=it[0]}} templates makes sure values are escaped correctly.
  @param {Object} [fillParams]   array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions    Example: `bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])`
  @param {string} [value]   Optional value which should be written, for example to `/n:Root/n:MyElem/&commat;attr` or with `/n:Root/n:MyElem` as the element's text content.   If not provided, the xPath contains all values and either there is a full match or it will be created.
  @param {boolean} [fire]   If true a fire is triggered to inform data modification listeners
  @public
  @return {DomNode} The xPath's node or null if dataProvider isn't ready
  */
  write(xPath,fillParams,value,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=addstatuslistener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args   Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @inherits bcdui.core.AbstractExecutable#addStatusListener
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=execute)
  @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/>Executes the process implemented by the concrete sub-classThis method is called by the Renderer when it is ready to render the modelIt is often asynchronous.Note, Renderer and sub-classes execute all input models recursively automatically.This means, usually you do not need to call this method directly. Note: it is asynchronous.Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
  @param {boolean} [doesRefresh=true]   Set this parameter to "false" if this method should donothing when the object is already in the ready status. The default is "true"meaning that the process is re-started when it is currently ready.
  @inherits bcdui.core.AbstractExecutable#execute
  @return {void}
  */
  execute(doesRefresh) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getfailedstatus)
  @description   Getter for the list of error statuses of this class. This implementation returns anempty list.
  @inherits bcdui.core.AbstractExecutable#getFailedStatus
  @return {Array.<bcdui.core.Status>} The status objects corresponding to failures in the object'sprocess.
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getreadystatus)
  @description   Getter for the ready status of the instance. This status is a final statedefined by each sub-class which is reached when the process has finishednormally.
  @inherits bcdui.core.AbstractExecutable#getReadyStatus
  @return {bcdui.core.Status} The status object indicating that the process belongingto this class is finished.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=getstatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @inherits bcdui.core.AbstractExecutable#getStatus
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=hasfailed)
  @description   Tests if the object has reached a failure status. These status codes arereturned by the "getFailedStatus" method.
  @inherits bcdui.core.AbstractExecutable#hasFailed
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=isready)
  @description   Tests if the current state is the readyStatus. This status is the samestatus as returned by "getReadyStatus".
  @inherits bcdui.core.AbstractExecutable#isReady
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=onceready)
  @param {(function|OnceReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onceReady
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=onready)
  @param {(function|OnReadyParam)} listenerObject   Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onReady
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.DataProvider?id=removestatuslistener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args   The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @inherits bcdui.core.AbstractExecutable#removeStatusListener
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       * @example
       * if( model.getStatus() === model.savedStatus )
       *   ...
       */
  savedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       */
  saveFailedStatus= null;
  
}


