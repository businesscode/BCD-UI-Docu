/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "./exports.js";
/**
@param {boolean} isDebugEnabled 
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui._setIsDebug)
  @description   Sets debug mode flag
  @method _setIsDebug
@return {void}
  @memberOf bcdui
 */
export function _setIsDebug(isDebugEnabled) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
