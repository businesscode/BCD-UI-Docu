/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} lang -  the language code
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.i18n.html#.switchLanguage)
  @description   reloads entire page in a given language this function requires the mapped SubjectPreferences servlet and a subjectPreferences.xml holding an entry for <cnf:Setting name="bcd_i18n:lang">
  @method switchLanguage
@return {void}
  @memberOf bcdui.i18n
 */
export function switchLanguage(lang) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
