/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {(SyncTranslateFormatMessageParam|string)} messageId -  Either an object with property msgid, or the messageId itself
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.i18n.html#.syncTranslateFormatMessage)
  @description   Assumes bcdui.wkModels.bcdI18nModel is ready and synchronously translates and formats the given message id.
  @method syncTranslateFormatMessage
@return {string}  translated and formated message
@memberOf bcdui.i18n
 */
export function syncTranslateFormatMessage(messageId) { return ""; };
