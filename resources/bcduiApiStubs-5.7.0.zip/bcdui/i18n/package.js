/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.i18n.html)
 * @namespace bcdui.i18n
 */

/**
 * A magic i18n token, which can prefix a string literal to tag it as an i18n-key rather than plain-text.This is an incubating feature only.
 */
export const TAG = {};
