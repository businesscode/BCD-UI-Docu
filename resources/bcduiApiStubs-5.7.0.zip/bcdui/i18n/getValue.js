/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} key -  the key to translate
  @param {string} defaultValue -  to return in case no translation was found or the i18n model is not ready yet
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.i18n.html#.getValue)
  @description   synchronously translates i18n key, please always use bcdTranslate attribute on html for i18n whenever possible. bcdui.is18n.isReady() must be true prior calling this, otherwise catalog is not loaded yet. You can wrap your main init function into bcdui.core.ready() to ensure core resources are initialized prior executing your code.
  @method getValue

  @example
  ````js
    // Usage
    var ret = bcdui.i18n.getValue( key, defaultValue );
  ````

@return {string}  translated or default value
@memberOf bcdui.i18n
 */
export function getValue(key, defaultValue) { return ""; };
