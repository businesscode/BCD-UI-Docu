/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_I18nTranslateHTMLElement_Args
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id. This is prefered over args.elementOrId
  @property {(HtmlElement|string)} elementOrId -  ID or HTML element to translate, default "document"
  @property {string} i18nModelId -  model with i18n entries, default "bcdI18nModel"
  @property {string} display -  original css 'display' value of the HTML element to be set after translation
  */
  /**
@param {Type_I18nTranslateHTMLElement_Args} args -  Parameter object
    ````js
    { targetHtml, elementOrId, i18nModelId, display }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.i18n.html#.translateHTMLElement)
  @description   Translates HTML element and its children according to i18n model values, the method is asynchronous and "schedules" the translation
  @method translateHTMLElement

  @example
  ````js
    // Usage
    var ret = bcdui.i18n.translateHTMLElement({ targetHtml: "#myDiv", elementOrId, i18nModelId, display });
  ````

@return {void} 
@memberOf bcdui.i18n
 */
export function translateHTMLElement(args) { return ; };
