/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} message -
  @param {Array.<any>} values -  Array values to set
  @param {object} formattingFunctions -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.i18n.html#.formatMessage)
  @description   formats message
  @method formatMessage

  @example
  ````js
    // Usage
    bcdui.i18n.formatMessage( message, values, formattingFunctions );
  ````


  @example
  bcdui.i18n.formatMessage( "Successfully updated {0} records in {1,number,#0.00} columns.", [ 3, 2 ] );
  @return {void}
  @memberOf bcdui.i18n
 */
export function formatMessage(message, values, formattingFunctions) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
