/**
 * BCD-UI library
 * @see https://businesscode.github.io/BCD-UI-Docu
 * Copyright 2010-2025 BusinessCode GmbH, Germany
 * Apache License, Version 2.0
 */
export * as bcdui from './exports.js';
