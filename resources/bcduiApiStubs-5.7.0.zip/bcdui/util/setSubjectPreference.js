/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} name -  The name of the subjectSetting
  @param {string} value -  The value of for the subjectSetting specified by the name parameter. Can be a comma-separated value list
  @param {function} callback -  The function which is called after a successful call of the subjectPreferences servlet
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.html#.setSubjectPreference)
  @description   sets a subject preference
  @method setSubjectPreference

  @example
  ````js
    // Usage
    bcdui.util.setSubjectPreference( name, value, callback );
  ````

@return {void}
  @memberOf bcdui.util
 */
export function setSubjectPreference(name, value, callback) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
