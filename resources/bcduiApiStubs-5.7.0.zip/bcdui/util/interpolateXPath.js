/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} xPath -  xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.html#.interpolateXPath)
  @description   transforms a xpath string with placeholders. A value with an apostrophe gets translated into a concat statement.
  @method interpolateXPath

  @example
  ````js
    // Usage
    var ret = bcdui.util.interpolateXPath( xPath );
  ````

@return {string}  final xPath with filled in values for possibly existing placeholders
@memberOf bcdui.util
 */
export function interpolateXPath(xPath, fillParams) { return ""; };
