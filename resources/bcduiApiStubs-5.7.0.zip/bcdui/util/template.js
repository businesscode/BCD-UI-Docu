/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} str   string holding placeholders like {{=it[0]}} or {{=it.myProperty}}
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.template)
  @description   returns a function which resolves basic doT like placeholder expressions
  @method template
@return {function}  function which can be called with an object to finally resolve the parameters
@memberOf bcdui.util
 */
export function template(str) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
