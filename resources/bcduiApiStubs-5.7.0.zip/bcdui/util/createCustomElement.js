/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} elementName -  The name of the custom element to create, must adhere to custom element standards.
  @param {function} createdCallback -  The function which is called on the element once it is attached to the document, the context is set to the element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.html#.createCustomElement)
  @description   Custom element creation helper.
  @method createCustomElement

  @example
  ````js
    // Usage
    bcdui.util.createCustomElement( elementName, createdCallback );
  ````

@return {void}
  @memberOf bcdui.util
 */
export function createCustomElement(elementName, createdCallback) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
