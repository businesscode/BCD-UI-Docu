/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.html#._sendFormRequest)
  @description   sends a HTTP request using HTML form submit  {string} url                   the url to call {object} [args]                optional arguments {string} [args.method=get]     request method {string} [args.target=_blank]  the target {string} [args.enctype=application/x-www-form-urlencoded]  the enctype {object} [args.parameters]     object map with parameters to send
  @method _sendFormRequest
@return {void}
  @memberOf bcdui.util
 */
export function _sendFormRequest() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
