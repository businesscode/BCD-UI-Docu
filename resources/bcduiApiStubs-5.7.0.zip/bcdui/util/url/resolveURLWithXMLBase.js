/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomElement} DomElement -  The point where the xml:base resolution should start.
  @param {string} url -  The URL to be resolved.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.url.html#.resolveURLWithXMLBase)
  @description   Resolves a URL with its correct xml:base. To compute the xml:base for the URL it may be necessary to resolve the xml:base with its ancestor xml:base elements unless one of them is an absolute URL.
  @method resolveURLWithXMLBase

  @example
  ````js
    // Usage
    var ret = bcdui.util.url.resolveURLWithXMLBase( DomElement, url );
  ````

@return {string}  The URL resolved with all xml:base elements of the elementitself and its ancestor elements.
@memberOf bcdui.util.url
 */
export function resolveURLWithXMLBase(DomElement, url) { return ""; };
