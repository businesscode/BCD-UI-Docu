/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} url -  The (relative or absolute) url to a full URL path.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.url.html#.resolveToFullURLPathWithCurrentURL)
  @description   Converts a relative URL (like ../Ziplet) to a full URL path (like (/myApp/ZipLet), based on the current page location.
  @method resolveToFullURLPathWithCurrentURL
@return {string}  The full URL path which is the absolute URLwithout the host/protocol/port part, starting with slash.
@memberOf bcdui.util.url
 */
export function resolveToFullURLPathWithCurrentURL(url) { return ""; };
