/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} url -  The URL to be inspected.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.url.html#.isAbsoluteURL)
  @description   Tests if the specified URL is an absolute URL or null. In this case it returns true and false otherwise.
  @method isAbsoluteURL
@return {boolean}  True if the URL is either null or an absolute URL.
@memberOf bcdui.util.url
 */
export function isAbsoluteURL(url) { return false; };
