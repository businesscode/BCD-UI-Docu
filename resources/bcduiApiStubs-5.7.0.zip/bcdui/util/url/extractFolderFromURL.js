/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} url -  The URL the folder is computed from.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.url.html#.extractFolderFromURL)
  @description   Gets the folder containing the document identified by the URL. So if the URL is for example "http://xxxxx/root/data.xml" it returns "http://xxxxx/root/". If the URL is already pointing to a folder (ending with "/") it simply returns this URL.
  @method extractFolderFromURL
@return {string}  The parent folder of the element denoted by the URL orthe URL itself if it is already a folder (ending with slash "/").
@memberOf bcdui.util.url
 */
export function extractFolderFromURL(url) { return ""; };
