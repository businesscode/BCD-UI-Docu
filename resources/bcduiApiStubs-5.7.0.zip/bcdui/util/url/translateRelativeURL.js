/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} relativeBaseUrl -  The URL the relativeUrl is based on. This may be a relative or an absolute URL.
  @param {string} relativeUrl -  The relative URL to be resolved.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.url.html#.translateRelativeURL)
  @description   This utility function applies a relative URL to a base URL and returns the resulting URL. It is quite useful to compute for example the value of the xml:base attribute of XIncludes, because the xml:base URL it the model's data URL applied to the browser's href. For example if the relativeBaseUrl is "/myProject/reports/myReport.jsp" and the relativeUrl is "../include/data.xml" the result will be "/myProject/include/data.xml".
  @method translateRelativeURL

  @example
  ````js
    // Usage
    var ret = bcdui.util.url.translateRelativeURL( relativeBaseUrl, relativeUrl );
  ````

@return {string}  The result of applying the relativeUrl to the relativeBaseUrl.
@memberOf bcdui.util.url
 */
export function translateRelativeURL(relativeBaseUrl, relativeUrl) { return ""; };
