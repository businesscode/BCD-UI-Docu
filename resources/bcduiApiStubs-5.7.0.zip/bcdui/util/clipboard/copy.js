/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} data -  Data to be copied to clipboard
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.clipboard.html#.copy)
  @description   Copy
  @method copy
@return {void}
  @memberOf bcdui.util.clipboard
 */
export function copy(data) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
