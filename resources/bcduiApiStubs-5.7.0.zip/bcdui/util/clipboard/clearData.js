/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.clipboard.clearData)
  @description   Cleans the current clipboard
  @method clearData
@return {void}
  @memberOf bcdui.util.clipboard
 */
export function clearData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
