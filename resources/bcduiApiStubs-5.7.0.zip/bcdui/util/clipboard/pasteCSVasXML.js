/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} [data] -  Optional parameter containing CSV data which should be converted instead of the clipboard data. If omitted the CSV data is taken from the clipboard.
  @param {boolean} [emptyRowIfNoData] -  If true and there is no data to paste, an emtpy row with one column is produced in the resulting XML, this is useful for pasting as new rows, in case only empty-cells were previously copied to the clipboard.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.clipboard.html#.pasteCSVasXML)
  @description   Gets CSV data from the clipboard (or the provided data) and converts it to XML according to the csv-1.0.0.xsd.
  @method pasteCSVasXML

  @example
  ````js
    // Usage
    bcdui.util.clipboard.pasteCSVasXML();
  ````

@return {void}
  @memberOf bcdui.util.clipboard
 */
export function pasteCSVasXML(data, emptyRowIfNoData) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
