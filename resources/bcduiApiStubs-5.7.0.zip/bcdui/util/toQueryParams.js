/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} url -  URL with the parameters
  @param {string} separator -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.html#.toQueryParams)
  @description   Logic derived from PrototypeJs library to "Parses a URI-like query string and returns an object composed of parameter/value pairs".
  @method toQueryParams

  @example
  ````js
    // Usage
    var ret = bcdui.util.toQueryParams( url, separator );
  ````

@return {string}  An object with the parameters of the url as properties
@memberOf bcdui.util
 */
export function toQueryParams(url, separator) { return ""; };
