/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {Date} date -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.formatDate)
  @description   The date in the XML date format (e.g. "2010-07-23")
  @method formatDate
@return {string} 
@memberOf bcdui.util.datetime
 */
export function formatDate(date) { return ""; };
