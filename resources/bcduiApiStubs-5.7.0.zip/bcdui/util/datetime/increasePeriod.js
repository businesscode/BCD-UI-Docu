/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {integer} value -  An integer of how many periods the input is to be shifted. Negative values are allowed.
  @param {Date} startDate -
  @param {Date} endDate -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.increasePeriod)
  @description   Shifts the given period by the given value The value is assumed to have the same period type (qu, mo, dy) as startDate and endDate
  @method increasePeriod

  @example
  ````js
    // Usage
    bcdui.util.datetime.increasePeriod( value, startDate, endDate );
  ````

@return {void}
  @memberOf bcdui.util.datetime
 */
export function increasePeriod(value, startDate, endDate) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
