/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(Date|string)} date -  date for which to determine the CW
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.getISOWeekNumber)
  @description   Calculates the ISO week number the date belongs to. Derived from Klaus Tondering's Calendar document.
  @method getISOWeekNumber
@return {integer}  cw
@memberOf bcdui.util.datetime
 */
export function getISOWeekNumber(date) { return 0; };
