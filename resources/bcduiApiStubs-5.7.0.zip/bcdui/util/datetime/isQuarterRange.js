/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(Date|string)} startDate -  First day of the date range
  @param {(Date|string)} endDate -  Last day of the date range
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.isQuarterRange)
  @description   Tests if the date range corresponds to exactly to one quarter (Jan - Mar, Apr - Jun, Jul - Sep or Oct - Dec of the same year)
  @method isQuarterRange

  @example
  ````js
    // Usage
    var ret = bcdui.util.datetime.isQuarterRange( startDate, endDate );
  ````

@return {boolean} 
@memberOf bcdui.util.datetime
 */
export function isQuarterRange(startDate, endDate) { return false; };
