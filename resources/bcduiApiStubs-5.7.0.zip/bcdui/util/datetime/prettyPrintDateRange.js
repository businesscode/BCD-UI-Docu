/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(Date|string)} startDate -  First day of the date range
  @param {(Date|string)} endDate -  Last day of the date range
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.prettyPrintDateRange)
  @description   Pretty prints a date range
  @method prettyPrintDateRange

  @example
  ````js
    // Usage
    var ret = bcdui.util.datetime.prettyPrintDateRange( startDate, endDate );
  ````

@return {string}  A string describing the date range (e.g. "Jul 2010" or "CW 30, 2010").
@memberOf bcdui.util.datetime
 */
export function prettyPrintDateRange(startDate, endDate) { return ""; };
