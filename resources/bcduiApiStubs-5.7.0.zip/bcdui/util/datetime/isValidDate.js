/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} date -  The date string to be parsed.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.isValidDate)
  @description   Checks if date passed is valid date
  @method isValidDate
@return {boolean}  Whether the parsed "date" argument is valid date string.
@memberOf bcdui.util.datetime
 */
export function isValidDate(date) { return false; };
