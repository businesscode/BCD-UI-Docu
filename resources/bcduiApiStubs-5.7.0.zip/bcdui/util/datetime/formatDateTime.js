/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {Date} date -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.datetime.html#.formatDateTime)
  @description   The date in the XML datetime format (e.g. "2010-07-23T00:00:00")
  @method formatDateTime
@return {string} 
@memberOf bcdui.util.datetime
 */
export function formatDateTime(date) { return ""; };
