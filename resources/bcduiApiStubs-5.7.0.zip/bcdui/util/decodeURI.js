/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} string   Value to be decoded
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.decodeURI)
  @description   Decode a URI
  @method decodeURI
@return {string}  decoded string
@memberOf bcdui.util
 */
export function decodeURI(string) { return ""; };
