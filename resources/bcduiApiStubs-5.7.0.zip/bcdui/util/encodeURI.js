/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} string   Value to be encoded
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.encodeURI)
  @description   Encode a URI
  @method encodeURI
@return {string}  encoded string
@memberOf bcdui.util
 */
export function encodeURI(string) { return ""; };
