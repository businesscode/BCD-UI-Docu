/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.html#.getUuid)
  @description   Generates a new UUID
  @method getUuid
@return {string}  uuid
@memberOf bcdui.util
 */
export function getUuid() { return ""; };
