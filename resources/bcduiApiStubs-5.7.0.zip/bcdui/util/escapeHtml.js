/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} string   Value to be escaped
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.util.escapeHtml)
  @description 
  @method escapeHtml
@return {string}  Escaped string
@memberOf bcdui.util
 */
export function escapeHtml(string) { return ""; };
