/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {HtmlElement} targetElement -  The element the content (child elements + attributes) of the source element should be copied to.
  @param {HtmlElement} sourceElement -  The source for the elements and attributes copied under the target element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.xml.html#.cloneElementContent)
  @description   Copies all child elements and attributes from a source XML element to a target XML element.
  @method cloneElementContent

  @example
  ````js
    // Usage
    var ret = bcdui.util.xml.cloneElementContent( targetElement, sourceElement );
  ````

@return {DomElement}  The targetElement.
@memberOf bcdui.util.xml
 */
export function cloneElementContent(targetElement, sourceElement) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
