/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|DomDocument|DomElement|DomAttribute)} doc -  XML Document as a String or Document or Node. If a document or a node is provided, they are cloned. A node is re-built as a document.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.xml.html#.parseDocument)
  @description   Parses an XML document and register well-known namespaces and their prefixes to enable xPath lookups thru JS API, i.e. document.selectSingleNode("/wrs:Wrs/wrs:Header").
  @method parseDocument
@return {document}  wrapped Document with namespace resolver and .selectSingleNode(), .selectNodes() API
@memberOf bcdui.util.xml
 */
export function parseDocument(doc) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
