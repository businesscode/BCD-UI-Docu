/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} xmlString -  The string to be processed.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.xml.html#.quoteXMLString)
  @description   Replaces the XML control characters in the specified string with the appropriate pre-defined entities.
  @method quoteXMLString
@return {string}  The parameter with XML control characters replaced.
@memberOf bcdui.util.xml
 */
export function quoteXMLString(xmlString) { return ""; };
