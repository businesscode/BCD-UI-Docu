/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(DomDocument|bcdui.core.DataProvider)} doc -  The document the XPath specified in the "path" argument is evaluated on.
  @param {(writableModelXPath|string)} path -  The XPath pointing to the nodes to be removed.
  @param {boolean} [enableWrsExtensions=true] -  Set this flag to "true" if the function should treat wrs elements differently (like converting wrs:R to wrs:D instead of removing it). It is "true" by default.
  @param {boolean} [removeEmptyElements] -  A flag indicating if elements which do not contain any content anymore should be removed. The default value is "false". This is for example very useful when the path is something like /Items/Item/&commat;value and the respective Item elements need to be cleared as well.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.xml.html#.removeXPath)
  @description   Removes XML elements from a DOM document. These XML elements are identified with an XPath.
  @method removeXPath

  @example
  ````js
    // Usage
    var ret = bcdui.util.xml.removeXPath( doc, path );
  ````

@return {number}  The number of removed nodes.
@memberOf bcdui.util.xml
 */
export function removeXPath(doc, path, enableWrsExtensions, removeEmptyElements) { return 0; };
