/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomElement} element -  The XML element to be renamed.
  @param {string} newName -  The new name of the XML element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.xml.html#.renameElement)
  @description   Renames an XML element and optionally filters its child elements (which is useful in conjunction with the wrs-Format).
  @method renameElement

  @example
  ````js
    // Usage
    var ret = bcdui.util.xml.renameElement( element, newName );
  ````

@return {DomElement}  The renamed XML element.
@memberOf bcdui.util.xml
 */
export function renameElement(element, newName) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
