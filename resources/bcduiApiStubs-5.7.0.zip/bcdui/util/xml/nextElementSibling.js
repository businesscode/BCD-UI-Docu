/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomElement} element -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.util.xml.html#.nextElementSibling)
  @description   Computes which XML element is the next sibling of the given element. In contrast to the nextSibling DOM function this function does only return an XML element (not a comment, text node etc.) or null if there is no sibling element. If the function is supported by the browser (e.g. FireFox) the native implementation is used. In other browsers (e.g. Internet Explorer) it is computed here.
  @method nextElementSibling
@return {DomElement}  The element immediately following the specified element ornull if there is no such element.
@memberOf bcdui.util.xml
 */
export function nextElementSibling(element) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
