/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} redirectUrl -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.login.html#.oAuthLoginOnSuccess)
  @description   To support OAuth flow with cookie SameSite strict, we work with a client-site redirect here which is triggered from within the popup by a script send from OAuthAuthenticatingFilter on login success This way we get the cookie and stay in the successfully validated session
  @method oAuthLoginOnSuccess
@return {void}
  @memberOf bcdui.widgetNg.login
 */
export function oAuthLoginOnSuccess(redirectUrl) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
