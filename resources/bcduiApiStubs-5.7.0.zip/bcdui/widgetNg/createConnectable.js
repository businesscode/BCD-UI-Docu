/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetNgCreateConnectable_Args
  @property {string} scope -  Defines the scope of the box. Source.
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {boolean} [allowUnknownTargetValue] -  If true, target items are not removed when they are not part of the source's options model.
  @property {boolean} [autofocus] -  requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {string} [className] -  Optional additional classname which is added to the container.
  @property {boolean} [dblClick=true] - default=true  If true, double clicking an item moves it. Default is true.
  @property {boolean} [disabled] -  All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [displayBalloon] -  hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [doSortOptions] -  Can be set to 'true' if the options should be sorted using the 'sortOptionsFunction' function. This is disabled per default to avoid CPU wasting.
  @property {boolean} [enableNavPath] -  Set to true if widget should be added to navpath handling.
  @property {function} [generateItemHelperHtml] -  Function to generate the html for helper container item which appears when you drag items. Basically the function for jQuery's sortable helper function. By default the first 5 items are listed.
  @property {function} [generateItemHtml] -  Function to generate the html for one container item. Gets object with properties: value, caption, position; see implementation documentation to read more about the structure to return by this function.
  @property {i18nToken} [hint] -  A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id] -  Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {boolean} [isDoubleClickTarget] -  If true (and box is target) then double click moves items from source to this target, otherwise first found target. Default is false.
  @property {function} [onBeforeChange] -  Handler function triggered before change of this box only, if false is returned, the change is rejected receives property map: {element = the widget element, dir = one of bcdui.widgetNg.connectable.CHANGE_DIRECTION.*, scope = object with .items to move, which can also be modified (i.e. remove items not eligible to move)}
  @property {function} [onChange] -  Handler function triggered after change. It's triggered on source AND destination of the change (e.g. source/target, target/source and target/target)
  @property {function} [onItemMoved] -  Handler function triggered after an item was moved. Receives property map: {from = source, to = destination, dir = one of bcdui.widgetNg.connectable.CHANGE_DIRECTION.*}
  @property {function} [onSelected] -  Handler function triggered when at least of the connectable items changed its status from selected to unselected (or moved a selected). This may fire multiple times.
  @property {xPath} [optionsModelRelativeFilterPredicate] -  xPath expression relative to 'optionsModelXPath' which can be used to filter options model items
  @property {xPath} [optionsModelRelativeValueXPath] -  xPath expression relative to 'optionsModelXPath' providing values
  @property {writableModelXPath} [optionsModelXPath] -  xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]. If you specify an optionsmodelxpath, the box automatically acts as source.
  @property {boolean} [showLasso=true] - default=true  If true, you get a selection lasso. Default is true.
  @property {boolean} [singleClick] -  If true, single clicking an item moves it. Default is false.
  @property {boolean} [singleSelect] -  Can be set to 'true' if you want to limit the selection to one item only.
  @property {function} [sortOptionsFunction] -  a compareFunction(a,b) passed to Array.prototype.sort(); with a, b are objects with { caption, value } A function used to sort items in the connectable. The defaulting implementation uses alphabetic sorting on caption.
  @property {integer} [tabindex] -  the HTML compliant tabIndex
  @property {writableModelXPath} [targetModelXPath] -  The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target
  @property {boolean} [unselectAfterMove] -  If true, the items get unselected after being moved. Default is false.
  @property {string} [widgetCaption] -  A caption which is used as prefix for navPath generation for this widget.
  @property {string} [wildcard="startswith"] - default="startswith"  The wildcards apply to filtering within the drop down list and for server side filters. This option applies only if bound to a f:Expression element and is ignored otherwise. For a f:Filter with &commat;op='like', this controls the prefilling with wildcards ('*') when the value is yet empty and the field gets the focus. Can be 'contains', 'startswith' or 'endswith'. The user can overwrite this by adding/removing wildcards when editing the field.
  @property {boolean} [writeCaptions] -  If true, target items also get a bcdCaption attribute holding the caption of the value. If used, you should add it to source and target connectables.
  @property {string} [wrsInlineValueDelim] -  Delimiter used for WRS read and write. Default is a slash.
  */
  /**
@param {Type_WidgetNgCreateConnectable_Args} args -  The parameter map contains the following properties.
    ````js
    { scope, targetHtml, allowUnknownTargetValue?, autofocus?, className?, dblClick?, disabled?, displayBalloon?, doSortOptions?, enableNavPath?, generateItemHelperHtml?, generateItemHtml?, hint?, id?, isDoubleClickTarget?, onBeforeChange?, onChange?, onItemMoved?, onSelected?, optionsModelRelativeFilterPredicate?, optionsModelRelativeValueXPath?, optionsModelXPath?, showLasso?, singleClick?, singleSelect?, sortOptionsFunction?, tabindex?, targetModelXPath?, unselectAfterMove?, widgetCaption?, wildcard?, writeCaptions?, wrsInlineValueDelim? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.html#.createConnectable)
  @description   Offers a simple container with multi select, drag'n drop functionalities
  @method createConnectable

  @example
  ````js
    // Usage
    bcdui.widgetNg.createConnectable({ scope, targetHtml: "#myDiv" });
  ````

@return {void}
  @memberOf bcdui.widgetNg
 */
export function createConnectable(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
