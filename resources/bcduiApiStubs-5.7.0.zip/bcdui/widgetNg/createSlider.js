/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetNgCreateSlider_Args
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {writableModelXPath} targetModelXPath -  The xPath pointing to the root-node this input widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted.
  @property {boolean} [autofocus] -  requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {boolean} [disabled] -  All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [disableResetControl=true] - default=true  set this parameter to 'false' to enable built-in reset-control, which empties content once clicked.
  @property {boolean} [displayBalloon] -  hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [enableNavPath] -  Set to true if widget should be added to navpath handling.
  @property {i18nToken} [hint] -  A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id] -  Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {boolean} [isRange] -  If enabled, the slider will operate in range-selection mode, providing min/max handles to define a range.
  @property {boolean} [keepEmptyValueExpression] -  A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty. TODO: better spec
  @property {function} [labelRenderingFunction] -  Your custom rendering function to render the label, which gets args with following properties: targetHtml, values[], captions[]; this function is executed on every update to the widget but also while sliding. This option is only effective unless native 'tooltips' option is used.
  @property {string} [labelRenderingFunctionTargetHtml] -  jQuery selector to access element to use as targetHtml for labelRenderingFunction, if you choose to use your custom one. This option is only effective unless native 'tooltips' option is used.
  @property {number} [max] -  Defines the maximum value, must not be set if optionsModelXpath is provided.
  @property {number} [min] -  Defines the minimum value, must not be set if optionsModelXpath is provided.
  @property {xPath} [optionsModelRelativeValueXPath="."] - default="."  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions.
  @property {modelXPath} [optionsModelXPath] -  xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]. If not provided, the widget is not linked to discrete values, in this case the min/max options has to be provided.
  @property {xPath} [relativeTargetXPathMax="/max"] - default="/max"  When operating in range-mode, this defines the relative xpath to targetModelXPath, to write the 'max' value. This option not defined in non-range mode.
  @property {xPath} [relativeTargetXPathMin="/min"] - default="/min"  When operating in range-mode, this defines the relative xpath to targetModelXPath, to write the 'min' value. This option not defined in non-range mode.
  @property {boolean} [required] -  An empty string or not set value is not allowed if required is true. Disabled fields are not evaluated.
  @property {integer} [tabindex] -  the HTML compliant tabIndex
  @property {string} [widgetCaption] -  A caption which is used as prefix for navPath generation for this widget.
  */
  /**
@param {Type_WidgetNgCreateSlider_Args} args -  The parameter map contains the following properties.
    ````js
    { targetHtml, targetModelXPath, autofocus?, disabled?, disableResetControl?, displayBalloon?, enableNavPath?, hint?, id?, isRange?, keepEmptyValueExpression?, labelRenderingFunction?, labelRenderingFunctionTargetHtml?, max?, min?, optionsModelRelativeValueXPath?, optionsModelXPath?, relativeTargetXPathMax?, relativeTargetXPathMin?, required?, tabindex?, widgetCaption? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.html#.createSlider)
  @description   A slider widget providing UI with a moving handle to select a value or to select a range. The implementation is based on noUiSlider, so is the API. Please refer to original documentation to explore all options. You can use full options from JS-API, however, they are not available from declarative context. Currently, the range mode is restricted to 2 handles only and you cannot provide start option, since it is read from the model.
  @method createSlider

  @example
  ````js
    // Usage
    bcdui.widgetNg.createSlider({ targetHtml: "#myDiv", targetModelXPath: "$guiStatus/cust:Elem/@value" });
  ````

@return {void}
  @memberOf bcdui.widgetNg
 */
export function createSlider(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
