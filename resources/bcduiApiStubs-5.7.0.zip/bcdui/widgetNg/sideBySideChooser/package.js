/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.sideBySideChooser)
 * @description   A namespace for the BCD-UI sideBySideChooser widget. For creation &commat;see {@link bcdui.widgetNg.createSideBySideChooser}
 * @namespace bcdui.widgetNg.sideBySideChooser
 */

/**
 * onBeforeChange dir attribute value, can be used to identify the direction of the item move
 */
export const CHANGE_DIRECTION = {};
