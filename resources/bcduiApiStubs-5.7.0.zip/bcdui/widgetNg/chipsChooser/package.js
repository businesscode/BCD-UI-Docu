/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.chipsChooser.html)
 * @description   A namespace for the BCD-UI chipsChooser widget. For creation &commat;see {@link bcdui.widgetNg.createChipsChooser}
 * @namespace bcdui.widgetNg.chipsChooser
 */

/**
 * onBeforeChange dir attribute value, can be used to identify the direction of the item move
 */
export const CHANGE_DIRECTION = {};
