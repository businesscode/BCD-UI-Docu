/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.chipsChooser.html#.init)
  @description 
  @method init
@return {void}
  @memberOf bcdui.widgetNg.chipsChooser
 */
export function init() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
