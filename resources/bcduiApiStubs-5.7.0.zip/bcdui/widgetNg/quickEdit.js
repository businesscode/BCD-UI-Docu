/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_QuickEditConstructor_Args
  @property {bcdui.core.DataProvider} wrsDataProvider -  The dataProvider with Wrs document
  @property {string} rowId -  the rowId to edit, the row with such ID must exist in the document already
  @property {targetHtmlRef} targetHtml -  the targetHtml to render UI
  @property {object} [columnTypeWidgetRendererMap] -  optional mapping for widget renderers mapped by 'type-name' of Wrs
  @property {Type_Quickedit_CallbackHandler} [callbackHandler] -  optional callback handler function. It is recommended to provide a handler to at least handle "DISPOSE" type, otherwise we just hide the widget and clean its targetHtml if user clicks on "close" button.
  */
  
/**
  @class bcdui.widgetNg.QuickEdit
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.QuickEdit.html)
  @description QuickEdit widget provides UI to edit Wrs row
  
  @example
  ````js
    // Usage
    var myQE = new bcdui.widgetNg.QuickEdit({ wrsDataProvider, rowId, targetHtml: "#myDiv" });
  ````


  @example
  <caption>HTML container for QuickEdit</caption>&lt;div id="formContainer">&lt;/div>
  
  @example
  <caption>Sample 1: static call</caption>jQuery("#formContainer").bcduiQuickEdit({  wrsDataProvider  : new bcdui.core.SimpleModel(), // some wrs data  rowId            : "R1"                          // i.e. first row});
  
  @example
  <caption>Sample 2: call edit form from Wrs grid rendering (default/htmlBuilder.xslt rendering)</caption>const targetHtml = jQuery(".grid-rendering");  // element for grid rendererconst wrsModel = new bcdui.core.SimpleModel(); // Wrs data model// default Wrs renderingconst wrsRendering = new bcdui.core.Renderer({ targetHtml, inputModel:wrsModel });// attach DOM event to open quickEdit on doubleclick on grid rowtargetHtml.on("dblclick", "[bcdrowident]", function(){  jQuery("&lt;div/>").appendTo(jQuery("#formContainer").empty()) // add DIV wrapper for repetitive rendering  .bcduiQuickEdit({    wrsDataProvider  : wrsModel,    rowId            : jQuery(this).attr("bcdrowident"), // current row identifier    callbackHandler  : (instance, type, args) => {       // our callback to process callbacks      if (type == "DISPOSE"){        wrsRendering.execute(); // refresh rendered grid on disposal of the form      }    }  });});
  */
// @ts-ignore
export class QuickEdit {
  /**
  @param {Type_QuickEditConstructor_Args} args -  the arguments
    ````js
    { wrsDataProvider, rowId, targetHtml, columnTypeWidgetRendererMap?, callbackHandler? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.QuickEdit.html)
  @description QuickEdit widget provides UI to edit Wrs row
  
  @example
  <caption>HTML container for QuickEdit</caption>&lt;div id="formContainer">&lt;/div>
  
  @example
  <caption>Sample 1: static call</caption>jQuery("#formContainer").bcduiQuickEdit({  wrsDataProvider  : new bcdui.core.SimpleModel(), // some wrs data  rowId            : "R1"                          // i.e. first row});
  
  @example
  <caption>Sample 2: call edit form from Wrs grid rendering (default/htmlBuilder.xslt rendering)</caption>const targetHtml = jQuery(".grid-rendering");  // element for grid rendererconst wrsModel = new bcdui.core.SimpleModel(); // Wrs data model// default Wrs renderingconst wrsRendering = new bcdui.core.Renderer({ targetHtml, inputModel:wrsModel });// attach DOM event to open quickEdit on doubleclick on grid rowtargetHtml.on("dblclick", "[bcdrowident]", function(){  jQuery("&lt;div/>").appendTo(jQuery("#formContainer").empty()) // add DIV wrapper for repetitive rendering  .bcduiQuickEdit({    wrsDataProvider  : wrsModel,    rowId            : jQuery(this).attr("bcdrowident"), // current row identifier    callbackHandler  : (instance, type, args) => {       // our callback to process callbacks      if (type == "DISPOSE"){        wrsRendering.execute(); // refresh rendered grid on disposal of the form      }    }  });});
    */
  constructor(args) {}
  
}


