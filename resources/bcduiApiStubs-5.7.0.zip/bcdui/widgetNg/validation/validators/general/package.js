/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.validators.general.html)
 * @description   A namespace for the BCD-UI widget validation (general).
 * @namespace bcdui.widgetNg.validation.validators.general
 */

/**
 * generic type validators, input parameter is only a value:- value, nulls / empty values are valid!
 */
export const TYPE_VALIDATORS = {};
