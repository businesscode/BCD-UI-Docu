/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.general.notEmptyValidator)
  @description   validates that value is neither null nor blank,params:
- value
  @method notEmptyValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.general
 */
export function notEmptyValidator() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
