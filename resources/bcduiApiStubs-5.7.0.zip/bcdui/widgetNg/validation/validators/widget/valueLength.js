/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget.valueLength)
  @description   checks the value of element for its length constraints,
widget configuration API used:
- maxlength
  @method valueLength
@return {(Object|null)}  null if valid, validationMessageObject otherwise
@memberOf bcdui.widgetNg.validation.validators.widget
 */
export function valueLength() { return {}; };
