/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.validators.widget.html#.invalidModelDataValidator)
  @description   checks that target data node is not tagged invalid with bcdInvalid attribute. The attribute itself carries the validation-message. This validator shall not be used generally by sticking it to other widget validators, since it does NOT validate widget's validity but the model's validity. This validator shall be handled manually by a widget only during SYNC_READ, so that it is always able to SYNC_WRITE (write back) widget's data to the model. General widget validation API supports this case as of widget.validator.validateElement(htmlElementId, checkDataValidity) function.  extended widget configuration api used: - config.target.modelId - config.target.xPath
  @method invalidModelDataValidator
@return {void}
  @memberOf bcdui.widgetNg.validation.validators.widget
 */
export function invalidModelDataValidator() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
