/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.validation.validators.widget.getValue)
  @description   Current value of the chooser.
Use this instead of native value property as it understands our placeholder implementation.
  @method getValue
@return {string}  value of the field or "" if the field is empty
@memberOf bcdui.widgetNg.validation.validators.widget
 */
export function getValue() { return ""; };
