/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.validators.widget.html#.getValue)
  @description   this getter we have to use which is compliant to the non-native placeholder feature
  @method getValue
@return {string}  value of the field or "" if the field is empty
@memberOf bcdui.widgetNg.validation.validators.widget
 */
export function getValue() { return ""; };
