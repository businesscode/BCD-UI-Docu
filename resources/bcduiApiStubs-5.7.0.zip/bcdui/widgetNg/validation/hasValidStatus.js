/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.html#.hasValidStatus)
  @description   NO REVALIDATION, just retrieval of current validity state, consideres native (constraint validation api) state and bcdui-internal ( existence of 'bcdInvalid' class). CSS case has to be considered because browsers native validation implementaion may switch validity state so that we cannot detect the change without fully revalidating the field.
  @method hasValidStatus
@return {boolean}  true if valid, false otherwise
@memberOf bcdui.widgetNg.validation
 */
export function hasValidStatus() { return false; };
