/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.html#.setCustomValidity)
  @description   sets custom validity, use html5 constraint validation API ensures that following properties are set properly: (Boolean) validity.valid (Boolean) validity.customError (String)  validationMessage (is set to "INVALID") in case of non-validity
  @method setCustomValidity
@return {void}
  @memberOf bcdui.widgetNg.validation
 */
export function setCustomValidity() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
