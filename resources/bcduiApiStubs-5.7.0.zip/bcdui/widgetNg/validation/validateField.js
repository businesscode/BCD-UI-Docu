/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|Element)} htmlElementId -  validatable element
  @param {Array.<string>} customValidationMessages -  An array of custom validation messages to display for this element (optional)
  @param {boolean} [skipNativeValidation] -  If you want to skip implicit, native html5 validation on the element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.html#.validateField)
  @description   this function carries out validation via native html5 constraint validation api (if available and not suppressed) and optionally marks the field as invalid in case customValidationMessages are provided (i.e. already has been validation with custom validators), additionally it displays the validationMessages to the user. Also resets the field to valid if neither customValidationMessages has been provided nor native validation has returned negative result.
  @method validateField

  @example
  ````js
    // Usage
    var ret = bcdui.widgetNg.validation.validateField( htmlElementId, customValidationMessages );
  ````

@return {boolean}  TRUE if field has been validated and has no errors, false otherwise
@memberOf bcdui.widgetNg.validation
 */
export function validateField(htmlElementId, customValidationMessages, skipNativeValidation) { return false; };
