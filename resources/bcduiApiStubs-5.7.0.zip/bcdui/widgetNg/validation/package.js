/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.html)
 * @description   validators package, common API all validators share:  validator functions are simple functions taking argument object as parameter and returning either NULL (for successful validation) or a validationError object in case of a failed validation.  the validationErrorObject properties:  validationMessage{i18nToken}  validation function MUST not run asynchronously! it is expected to block and return once validation is done. the argument object is arbitrary and defined by particular validation function.
 * @namespace bcdui.widgetNg.validation
 */
