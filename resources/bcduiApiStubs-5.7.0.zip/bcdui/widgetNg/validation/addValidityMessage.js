/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {object} validationResult -  The validationResult object to extend or null to create a new one, this object is modified.
  @param {(string|Array.<string>)} message -  Message to append to the validationResult.validationMessage
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.html#.addValidityMessage)
  @description   appends validity message to validationResult object and returns validationResult, creates a new one if none is provided. message must not be null.
  @method addValidityMessage

  @example
  ````js
    // Usage
    var ret = bcdui.widgetNg.validation.addValidityMessage( validationResult, message );
  ````

@return {object}  validationResult object with validationMessage array with appended message(s)
@memberOf bcdui.widgetNg.validation
 */
export function addValidityMessage(validationResult, message) { return {}; };
