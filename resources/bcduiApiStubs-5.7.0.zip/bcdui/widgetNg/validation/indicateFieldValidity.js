/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.validation.html#.indicateFieldValidity)
  @description   checks the field for validity via html5 constraint validation api and indicate by adding/removing particular CSS classes. The classes are always added, even in case native validation is supported (via :invalid pseudo class)
  @method indicateFieldValidity
@return {boolean}  TRUE if validation message has been placed, so field is not valid, false otherwise.
@memberOf bcdui.widgetNg.validation
 */
export function indicateFieldValidity() { return false; };
