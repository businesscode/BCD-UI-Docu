/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_TreeSupportConstructor_Args
  @property {boolean} [isDefaultCollapsed=true] - default=true  Initial state
  @property {string} levelNodeName -  Local nodename of the level, i.e. "Level"
  @property {string} itemNodeName -  Local nodename of the item, i.e. "Item"
  @property {string} valueAttrName -  Attribute name of value attribute, i.e. "id"
  @property {string} captionAttrName -  Attribute name of caption attribute, i.e. "caption"
  @property {number} [leftPaddingLevel=14] - default=14  Left padding in pixels per level depth
  */
  
/**
  @class bcdui.widgetNg.connectable.TreeSupport
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.connectable.TreeSupport.html)
  @description Tree support class providing item rendering, controls binding and onItemMoved handler
  
  @example
  ````js
    // Usage
    var myTS = new bcdui.widgetNg.connectable.TreeSupport({ levelNodeName, itemNodeName, valueAttrName, captionAttrName });
  ````

*/
// @ts-ignore
export class TreeSupport {
  /**
  @param {jQuery} container -  The container
  @param {Type_TreeSupportConstructor_Args} config -  Options
    ````js
    { isDefaultCollapsed?, levelNodeName, itemNodeName, valueAttrName, captionAttrName, leftPaddingLevel? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.connectable.TreeSupport.html)
  @description Tree support class providing item rendering, controls binding and onItemMoved handler
    */
  constructor(container, config) {}
  
}


