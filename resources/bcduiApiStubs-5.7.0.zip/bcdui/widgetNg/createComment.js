/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetNgCreateComment_Args
  @property {string} instance   A given instance for the current comments.
  @property {string} scope   A given scope for the current comments.
  @property {targetHtmlRef} targetHtml   An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [addBRefs="bcdUpdateStamp bcdUpdateBy"]  default="bcdUpdateStamp bcdUpdateBy"  Space separated list of additional bRefs you want to load.
  @property {boolean} [alwaysShowAdd]   If true, the add comment input area is always shown.
  @property {boolean} [autofocus]   requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {string} [bindingSetId="bcd_comment"]  default="bcd_comment"  Comment binding set name. Needs at least the bRefs: comment_text, instance and scope.
  @property {string} [caption]   A caption string which appears in the top add row.
  @property {boolean} [disabled]   All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [displayBalloon]   hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [enableNavPath]   Set to true if widget should be added to navpath handling.
  @property {string} [excludeBRefs]   Space separated list of bRefs which are removed before save/update.
  @property {string} [filterBRefs]   The space separated list of binding Refs that will be used in filter clause of request document.
  @property {i18nToken} [hint]   A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id]   Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {i18nToken} [label]   If provided, enables widget to render a label element
  @property {function} [onBeforeSave]   Function which is called before each save operation. Parameter holds current wrs dataprovider. Function needs to return true to save or false for skipping save process and resetting data.
  @property {string} [orderByBRefs="bcdUpdateStamp-"]  default="bcdUpdateStamp-"  Space separated list of bRefs that will be used to order the data. A minus(-) sign at the end indicates descending sorting. By default it orders by lastUpdate descending.
  @property {function} [renderComment]   A function which returns a HTML Element with the rendered comment. Function gets a param bag with comment, lastUpdate, updatedBy and uuid.
  @property {integer} [tabindex]   the HTML compliant tabIndex
  @property {boolean} [useTextarea]   If true, uses a textarea instead of an input field.
  @property {string} [widgetCaption]   A caption which is used as prefix for navPath generation for this widget.
  */
  /**
@param {Type_WidgetNgCreateComment_Args} args   The parameter map contains the following properties.
    ````js
    { instance, scope, targetHtml, addBRefs?, alwaysShowAdd?, autofocus?, bindingSetId?, caption?, disabled?, displayBalloon?, enableNavPath?, excludeBRefs?, filterBRefs?, hint?, id?, label?, onBeforeSave?, orderByBRefs?, renderComment?, tabindex?, useTextarea?, widgetCaption? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.createComment)
  @description   Offers a simple container with comment functionality
  @method createComment

  @example
  // Usage
bcdui.widgetNg.createComment({ instance, scope, targetHtml: "#myDiv" });

@return {void}
  @memberOf bcdui.widgetNg
 */
export function createComment(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
