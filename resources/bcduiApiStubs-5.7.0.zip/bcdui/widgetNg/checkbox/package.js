/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.checkbox)
 * @description   A namespace for the BCD-UI checkbox widget. For creation &commat;see {@link bcdui.widgetNg.createCheckbox}
 * @namespace bcdui.widgetNg.checkbox
 */
