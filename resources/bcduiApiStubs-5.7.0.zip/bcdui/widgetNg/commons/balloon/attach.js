/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";

/**
  @typedef {Object} Type_BalloonAttach_Args
  @property {boolean} [noTooltip] -  If balloon is attach a tooltip (mouseover) is attached as well,you can disable it here.
  @property {boolean} [noBalloon] -  If set to TRUE the static balloon is not displayed
  */
  /**
@param {(HtmlElement|string)} htmlElementId -  The target to attach ballon to.
  @param {Type_BalloonAttach_Args} [args] -  Object literal containing following properties
    ````js
    { noTooltip?, noBalloon? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.commons.balloon.html#.attach)
  @description   attaches the balloon to given, focusable element, this function does nothing in case a balloon is already attached on this element.
  @method attach

  @example
  ````js
    // Usage
    var ret = bcdui.widgetNg.commons.balloon.attach();
  ````

@return {boolean}  true if attached, false if not; if both noTooltip and noBalloon parameters are set, this function returns FALSE and has no effect.
@memberOf bcdui.widgetNg.commons.balloon
 */
export function attach(htmlElementId, args) { return false; };
