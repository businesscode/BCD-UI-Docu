/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.commons.balloon.html#.displayHintBalloon)
  @description   permanently displays the hint-balloon for given htmlElementId using the default tooltip technique but reposition it (next to the element) as tray-message, you have to hide the the balloon executing general hideHintBalloon()  configuration params:  - balloonRendererId  configuration object is expected to be in the element map: bcdui.widgetNg.commons.balloon.MAPKEY_CONFIG
  @method displayHintBalloon
@return {void}
  @memberOf bcdui.widgetNg.commons.balloon
 */
export function displayHintBalloon() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
