/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widgetNg.commons.balloon.html)
 * @description   A namespace for the BCD-UI balloon widget.
 * @namespace bcdui.widgetNg.commons.balloon
 */

/**
 * constants
 */
export const CONST = {};

/**
 * PrototypeJS element maps key for internal configuration object
 */
export const MAPKEY_CONFIG = {};

/**
 * the singleton data provider which is data provider to the tooltip renderer,it fetches the ID of element from 'bcdRowIdent' data provider, locates thatelement, fetches the tooltip message and validation messages from the 'bcdHint'attribute (or 'hint' option) and '_validationMessages_' map value respectively, parses them into a DOMdocument which is returned to the renderer to be rendered.
 */
export const DATA_PROVIDER = {};

/**
 * singleton tooltip renderer
 */
export const TOOLTIP_RENDERER = {};

/**
 * singleton balloon renderer
 */
export const BALLOON_RENDERER = {};
