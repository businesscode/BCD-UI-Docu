/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widgetNg.commons.balloon.messagesToXML)
  @description   construct XML string out of messages and tooltip data

DTD:
BalloonData&lt;Tooltip?,Messages?>
Tooltip&lt;CDATA>
ValidationMessages&lt;Item+>
Item&lt;CDATA>
  @method messagesToXML
@return {(null|string)}  NULL (if no messages found / tooltip) or DOM string
@memberOf bcdui.widgetNg.commons.balloon
 */
export function messagesToXML() { return null; };
