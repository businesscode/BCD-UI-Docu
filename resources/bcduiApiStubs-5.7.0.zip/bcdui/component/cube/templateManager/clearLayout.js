/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@param {string} objectId -  The id of the linked object (cube or scorecard)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.cube.templateManager.html#.clearLayout)
  @description   Removes the current layout
  @method clearLayout
@return {void}
  @memberOf bcdui.component.cube.templateManager
 */
export function clearLayout(objectId) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
