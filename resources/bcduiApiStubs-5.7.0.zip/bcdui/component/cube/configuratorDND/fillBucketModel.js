/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@param {string} cubeBucketModelId -  The id of the cubeBucketModel
  @param {string} configId -  The id of the used configuration
  @param {boolean} [noClear] -  true if current selection should not get changed
  @param {function} [callback] -  callback function which is called as soon as bucketModel is fully filled
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.cube.configuratorDND.html#.fillBucketModel)
  @description   Used for initial filling but can also be used to reinitialize bucket model (e.g. after hiding selectable measures)
  @method fillBucketModel

  @example
  ````js
    // Usage
    bcdui.component.cube.configuratorDND.fillBucketModel( cubeBucketModelId, configId );
  ````

@return {void}
  @memberOf bcdui.component.cube.configuratorDND
 */
export function fillBucketModel(cubeBucketModelId, configId, noClear, callback) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
