/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@param {string} cubeId -  The id of the linked cube
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.cube.configuratorDND.html#.reDisplay)
  @description   Refreshes the cube drag'n drop area This is e.g. necessary when a template is applied or the layout is cleaned or a client sided cube action is applied and you want to have e.g. icons being refreshed in the dnd area, or you have some custom options which remove measures dimensions on special rules and the dnd area needs to be in sync with the changes
  @method reDisplay
@return {void}
  @memberOf bcdui.component.cube.configuratorDND
 */
export function reDisplay(cubeId) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
