/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.component.cube.configurator.excludeDimMember)
  @description   Excludes (server side filter) the occurrences of a selected dimension member, i.e. for example all values for a country
Results in f:Filter expressions
  @method excludeDimMember
@return {void}
  @memberOf bcdui.component.cube.configurator
 */
export function excludeDimMember() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
