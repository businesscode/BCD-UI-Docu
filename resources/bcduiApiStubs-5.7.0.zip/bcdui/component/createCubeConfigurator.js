/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_ComponentCreateCubeConfigurator_Args
  @property {string} id -  Id of the created object
  @property {targetHtmlRef} targetHtml -  The target HTML element for the drag-and-drop matrix.
  @property {writableModelXPath} [targetModelXPath="$guiStatus/guiStatus:Status/cube:Layout"] - default="$guiStatus/guiStatus:Status/cube:Layout"  Where to write the result
  @property {(string|bcdui.core.DataProvider)} [config="./dimensionsAndMeasures.xml"] - default="./dimensionsAndMeasures.xml"  DataProvider containing the configuration for the cube configurator, per defaulz ./dimensionsAndMeasures.xml is loaded
  @property {(string|bcdui.component.cube.Cube)} cubeRenderer -  Cube we belong to
  @property {boolean} [isRanking] -  Show ranking editor. This is an Enterprise Edition only feature.
  @property {boolean} [isTemplate] -  Show template Editor true/false. This is an Enterprise Edition only feature.
  @property {boolean} [showSummary] -  Show summary of cube settings
  @property {string} [rankingTargetHtmlElementId] -  Custom location for ranking editor
  @property {string} [templateTargetHtmlElementId] -  Custom location for template editor
  @property {string} [summaryTargetHtmlElementId] -  Custom location for summary display
  @property {(boolean|string)} [contextMenu] -  If true, cube's default context menu is used, otherwise provide the url to your context menu xslt here.
  @property {(boolean|string)} [tooltip] -  If true, cube's default tooltip is used, otherwise provide the url to your tooltip xslt here.
  @property {boolean} [isDefaultHtmlLayout] -  If true, a standard layout for dnd area, ranking, templates and summary is created. Separate targetHtmlElements will be obsolete then. If false, you need to provide containers with classes: bcdCurrentRowDimensionList, bcdCurrentColMeasureList, bcdCurrentColDimensionList, bcdCurrentMeasureList, bcdDimensionList, bcdMeasureList within an outer bcdCubeDndMatrix container. if your targetHtml got classes bcdDndBlindOpen or bcdDndBlindClosed, the actual dnd area is also put in collapsable boxes (either open or closed by default).
  @property {boolean} [hasUserEditRole] -  Template Editor also has edit capability. If not given, bcdui.config.clientRights.bcdCubeTemplateEdit is used to determine state (either *(any) or cubeId to enable).
  @property {string} [applyFunction=bcdui.core.lifecycle.applyAction] - default=bcdui.core.lifecycle.applyAction  Function name which is used for the apply button in isDefaultHtmlLayout=true mode.
  @property {string} [url=WrsServlet] - default=WrsServlet  The URL the model for the grouping editor is loaded from. If omitted the WrsServlet is taken as default.
  @property {string} [expandCollapseCells] -  When specified (with 'expand' or 'collapse' or 'collapse2nd'), cube turns on the expand/collapse mode. collapse2nd initially keeps level one open.
  @property {boolean} [doSortOptions] -  When setting this to true, dimensions and measures lists are sorted by caption.
  */
  /**
@param {Type_ComponentCreateCubeConfigurator_Args} args -  The parameter map contains the following properties:
    ````js
    { id, targetHtml, targetModelXPath?, config?, cubeRenderer, isRanking?, isTemplate?, showSummary?, rankingTargetHtmlElementId?, templateTargetHtmlElementId?, summaryTargetHtmlElementId?, contextMenu?, tooltip?, isDefaultHtmlLayout?, hasUserEditRole?, applyFunction?, url?, expandCollapseCells?, doSortOptions? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.html#.createCubeConfigurator)
  @description   Creates a cube configurator, providing the cube:Layout section of the cube configuration, able of 1) Showing the drag and drop area for the dimensions and measures 2) Providing templates to the user 3) Allowing the user to save templates for him/herself 4) Allowing the user to create new measures with the formula editor
  @method createCubeConfigurator

  @example
  ````js
    // Usage
    bcdui.component.createCubeConfigurator({ id, targetHtml: "#myDiv", cubeRenderer });
  ````


  @example
  new bcdui.core.SimpleModel({   id:  "myDndOptions", // define ID explicitely   url: "dndOptionsModel.xml"  );  bcdui.component.createCubeConfigurator({      id:                  "cubeConfigurator",    , config:              "myDndOptions"    , targetHtml:          "cubeConfiguratorDiv"    , targetModelId        "guiStatus"    , isRanking            true    , cubeRenderer:        "cube"    , rankingTargetHtmlElementId: "rankingDiv"  });
  
  @example
  &lt;div class='container_24 bcdCubeDndMatrix'>   &lt;div class='grid_24'>     &lt;div class='grid_3 omega bcdCurrentRowDimensionList alpha'>&lt;/div>     &lt;div class='grid_3 omega bcdCurrentColMeasureList'>&lt;/div>     &lt;div class='grid_3 omega'>       &lt;div class='bcdCurrentColDimensionList'>&lt;/div>       &lt;div class='bcdCurrentMeasureList'>&lt;/div>     &lt;/div>     &lt;div class='grid_5 omega'>       &lt;div class='bcdHeader'>Dimensions&lt;/div>       &lt;div class='bcdDimensionList'>&lt;/div>     &lt;/div>     &lt;div class='grid_5 omega'>       &lt;div class='bcdHeader'>Measures&lt;/div>       &lt;div class='bcdMeasureList'>&lt;/div>     &lt;/div>   &lt;/div> &lt;/div>
  @return {void}
  @memberOf bcdui.component
 */
export function createCubeConfigurator(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
