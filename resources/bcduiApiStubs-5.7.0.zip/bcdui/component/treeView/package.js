/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.treeView.html)
 * @description   This namespace contains the functions for expanding and collapsing tree nodes in the tree viewer.
 * @namespace bcdui.component.treeView
 */
