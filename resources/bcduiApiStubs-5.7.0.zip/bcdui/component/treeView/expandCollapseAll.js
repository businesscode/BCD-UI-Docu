/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_TreeViewExpandCollapseAll_Args
  @property {string} rendererId -  Id of the treeView's renderer
  @property {boolean} isExpand -  True for expand, false for collapse
  */
  /**
@param {Type_TreeViewExpandCollapseAll_Args} args -  The argument map containing the following elements:
    ````js
    { rendererId, isExpand }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.treeView.html#.expandCollapseAll)
  @description   This function expands or collapses all levels of a treeView. It relies on the &commat;dimId and wrs:Data of the primary model of the renderer to calculate all levels and sets the guiStatus accordingly.
  @method expandCollapseAll

  @example
  ````js
    // Usage
    bcdui.component.treeView.expandCollapseAll({ rendererId, isExpand });
  ````

@return {void}
  @memberOf bcdui.component.treeView
 */
export function expandCollapseAll(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
