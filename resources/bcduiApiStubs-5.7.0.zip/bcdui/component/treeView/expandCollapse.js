/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} rendererId -  Id of the treeView's renderer
  @param {string} levelId -  Which level to change
  @param {boolean} isExpand -  True for expand, false for collapse
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.treeView.html#.expandCollapse)
  @description   Expand or collapse a level for a treeView renderer
  @method expandCollapse

  @example
  ````js
    // Usage
    bcdui.component.treeView.expandCollapse( rendererId, levelId, isExpand );
  ````

@return {void}
  @memberOf bcdui.component.treeView
 */
export function expandCollapse(rendererId, levelId, isExpand) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
