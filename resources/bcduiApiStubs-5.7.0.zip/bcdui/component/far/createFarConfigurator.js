/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_FarCreateFarConfigurator_Args
  @property {xPath} dimensions_optionsModelRelativeValueXPath -  xpath relative to 'dimensions_optionsModelXPath' that references a value attribute, i.e. '../&commat;value'
  @property {xPath} dimensions_optionsModelXPath -  items considered dimensions, xpath must reference the caption attribute on the item-set; Reference deep link to items (including levels) in case you have hierarhical structure i.e. $config/far:Configurator/far:Dimensions//* /&commat;caption
  @property {object} dimensions_treeConfig -  tree configuration object (see component documentation)
  @property {xPath} measures_optionsModelRelativeValueXPath -  xpath relative to 'dimensions_optionsModelXPath' that references a value attribute, i.e. '../&commat;value'
  @property {xPath} measures_optionsModelXPath -  items considered dimensions, xpath must reference the caption attribute on the item-set; Reference deep link to items (including levels) in case you have hierarhical structure i.e. $config/far:Configurator/far:Dimensions//* /&commat;caption
  @property {object} measures_treeConfig -  tree configuration object (see component documentation)
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {boolean} [autofocus] -  requests the widget to set the focus once it is rendered or enabled for the first time. Only one widget can have a focus, so in case the focus is requested by many widgets it is undefined which one will win.
  @property {boolean} [disabled] -  All input widgets can be set to be disabled. If disabled, a widget cannot receive a focus, also a style cannot be changed in many browsers. There is no read-only. Also consult read-only vs disabled: http://www.w3.org/TR/html4/interact/forms.html#h-17.12. Since this is a HTML property not a real boolean attribute, specify this only if you want to disable the widget. The actual value is ignored. If it is specified, the widget is disabled.
  @property {boolean} [displayBalloon] -  hints and validation messages are displayed in a fly-over if user moves the mouse over the widget. Additionally, they are also displayed in a balloon in bottom-left corner of a browser window in a balloon, which is static and appears as long as the widget has focus.
  @property {boolean} [doSortOptions] -  Can be set to 'true' if the options should be sorted alphabetically. This is disabled per default to avoid CPU wasting.
  @property {boolean} [enableNavPath] -  Set to true if widget should be added to navpath handling.
  @property {i18nToken} [hint] -  A general feature is the hint indicator on the widget so user can hover it with a mouse to reveal information about it. image aus theme intern handled by tooltip.
  @property {string} [id] -  Id of the widget, if not provided this id will be auto-generated. Must be unique. The id must not be used from jQuery UI API, the id should be used within declarative scope only, i.e. X-API / JSP. If provided, this id will overwrite targetHtml element's id.
  @property {integer} [tabindex] -  the HTML compliant tabIndex
  @property {writableModelXPath} [targetModelXPath="$guiStatus/guiStatus:Status"] - default="$guiStatus/guiStatus:Status"  Target xPath to write the far:ConfiguratorLayout configuration into.
  @property {string} [widgetCaption] -  A caption which is used as prefix for navPath generation for this widget.
  */
  /**
@param {Type_FarCreateFarConfigurator_Args} args -  The parameter map contains the following properties.
    ````js
    { dimensions_optionsModelRelativeValueXPath, dimensions_optionsModelXPath, dimensions_treeConfig, measures_optionsModelRelativeValueXPath, measures_optionsModelXPath, measures_treeConfig, targetHtml, autofocus?, disabled?, displayBalloon?, doSortOptions?, enableNavPath?, hint?, id?, tabindex?, targetModelXPath?, widgetCaption? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.far.html#.createFarConfigurator)
  @description   A FAR configurator UI displaying 3 side by side choosers for choosing Dimensions, Measures and Sorting of the items, writes far:ConfiguratorLayout format into targetModelXPath; this widget is configured by number of parameters referencing various nodesets as Dimensions and Measures source items. It is expected that every dimension and measure item is represented by an element in options model providing the value and caption in separate attributes on an element,i.e. Item[&commat;value &commat;caption]. This widget supports flat or hierarhical input. For either input (flat/hierarchical) you need to provider tree configuration object containing information about how determine your hierarchy. i.e. { levelNodeName : 'far:Category', itemNodeName : 'far:Item', isDefaultCollapsed: true }
  @method createFarConfigurator

  @example
  ````js
    // Usage
    bcdui.component.far.createFarConfigurator({ dimensions_optionsModelRelativeValueXPath, dimensions_optionsModelXPath, dimensions_treeConfig, measures_optionsModelRelativeValueXPath, measures_optionsModelXPath, measures_treeConfig, targetHtml: "#myDiv" });
  ````

@return {void}
  @memberOf bcdui.component.far
 */
export function createFarConfigurator(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
