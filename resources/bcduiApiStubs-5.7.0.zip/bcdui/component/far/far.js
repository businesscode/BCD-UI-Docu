/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_FarConstructor_Args
  @property {targetHtmlRef} targetHtml -  A reference to the HTML DOM Element where to render the output.
  @property {bcdui.core.DataProvider} config -  Configuration document from http://www.businesscode.de/schema/bcdui/far-1.0.0
  @property {string} [componentId="far"] - default="far"  An ID for the component, 'far' is the default. This is not the data provider's technical identifier, this ID is used as component identifer to support multiple components on single page, i.e. reuse same configuration.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished] - default=bcdui.wkModels.guiStatusEstablished  The StatusModel, containing the filters at /SomeRoot/f:Filter
  */
  
/**
  @class bcdui.component.far.Far
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.far.Far.html)
  @description A FAR component
  
  @example
  ````js
    // Usage
    var myFr = new bcdui.component.far.Far({ targetHtml: "#myDiv", config });
  ````

*/
// @ts-ignore
export class Far {
  /**
  @param {Type_FarConstructor_Args} args -  The parameter map contains the following properties:
    ````js
    { targetHtml, config, componentId?, statusModel? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.far.Far.html)
  @description A FAR component
    */
  constructor(args) {}
  
}


