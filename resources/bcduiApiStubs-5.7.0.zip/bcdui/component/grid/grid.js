/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_GridConstructor_Args
  @property {targetHtmlRef} targetHtml -  A reference to the HTML DOM Element where to put the output
  @property {bcdui.core.DataProvider} [config="./gridConfiguration.xml"] - default="./gridConfiguration.xml"  The model containing the grid configuration data. If it is not present a SimpleModel with the url  './gridConfiguration.xml' is created.
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatusEstablished] - default=bcdui.wkModels.guiStatusEstablished  StatusModel (default is 'guiStatusEstablished'), containing the filters as /SomeRoot/f:Filter
  @property {bcdui.core.DataProvider} [inputModel] -  WRS or GridModel which is used, if not provided, it is generated out of the config. If provided, config is ignored unless it is set explicitly
  @property {string} [id] -  The object's id, needed only when later accessing via id. If given the Grid registers itself at {@link bcdui.factory.objectRegistry}
  @property {Object} [hotArgs] -  Arguments which are extended to handsontable creation
  @property {(string|chainDef)} [tooltipChain] -  To overwrite default tooltip chain. An empty string will disable tooltips, otherwise the default gridTooltip.xslt is used
  @property {(boolean|string)} [contextMenu] -  If true, grid's default context menu is used, otherwise provide the url to your context menu xslt here.
  @property {function} [customSave] -  Custom save function
  @property {function} [afterAddRow] -  Custom function(args) which is called after a row was added (args.rowNode, wrs row node which was added, args.headerMeta wrs header object)
  @property {chainDef} [saveChain] -  A chain definition which is used for the grid saving operation
  @property {Object} [saveParameters] -  Parameters for the saving chain
  @property {chainDef} [loadChain] -  A chain definition which is used for the grid loading operation
  @property {Object} [loadParameters] -  Parameters for the loading chain
  @property {chainDef} [validationChain] -  A chain definition which is used for the validation operation. basic wrs and reference validation is given by default
  @property {Object} [validationParameters] -  Parameters for the validation chain
  @property {boolean} [allowNewRows=true] - default=true  Allows inserting new rows via default contextMenu or drag/paste
  @property {boolean} [columnFilters] -  Enable basic column filter input fields
  @property {integer} [maxHeight] -  Set a maximum vertical size in pixel (only used when no handsontable height is set)
  @property {boolean} [isReadOnly] -  Turn on viewer-only mode
  @property {boolean} [topMode] -  Add/save/restore buttons appear at the top, pagination at bottom, insert row at top
  @property {boolean} [forceAddAtBottom] -  Always add a new row at the bottom, no matter if topMode or pagination
  @property {boolean} [disableDeepKeyCheck] -  Set this to true if you really want to disable the deep key check which is active if your grid is only a subset of the underlying table
  @property {boolean} [ignoreKeyCase] -  Set this to true if the key test should not be case sensitive
  @property {function} [isReadOnlyCell] -  Custom check function if a given cell is read only or not. Function gets gridModel, wrsHeaderMeta, rowId, colId and value as input and returns true if the cell becomes readonly
  @property {function} [columnFiltersGetCaptionForColumnValue] -  Function which is used to determine the caption values for column filters. You need to customize this when you're e.g. using XML data in cells.
  @property {Object} [columnFiltersCustomFilter] -  CustomColumnFilter functions passed to column filter
  @property {boolean} [defaultButtons=true] - default=true  Set to false if you want to hide the default buttons reset/delete/save
  @property {boolean} [serverSidedPagination] -  Set to true if you want to enable server sided pagination
  @property {integer} [paginationSize=20] - default=20  Set pagination page size (and enable pagination)
  @property {boolean} [paginationAllPages] -  Set pagination show all option (and enable pagination)
  @property {chainDef} [requestPostChain] -  The definition of the transformation chain
  @property {(string|bcdui.core.DataProvider)} [modelUrl='WrsServlet'] - default='WrsServlet'  This is a string or string- DataProvider with the URL which to send the requestModel result to
  @property {string} [exportFileName] -  Filename for grid export
  @property {boolean} [disableExport] -  Disable export functionality.
  */
  
/**
  @class bcdui.component.grid.Grid
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html)
  @description Creates a grid UI based on given data or a configuration allowing to edit the data
  
  @example
  ````js
    // Usage
    var myGrd = new bcdui.component.grid.Grid({ targetHtml: "#myDiv" });
  ````

@extends bcdui.core.Renderer
*/
// @ts-ignore
export class Grid extends bcdui.core.Renderer {
  /**
  @param {Type_GridConstructor_Args} args -  The parameter map contains the following properties:
    ````js
    { targetHtml, config?, statusModel?, inputModel?, id?, hotArgs?, tooltipChain?, contextMenu?, customSave?, afterAddRow?, saveChain?, saveParameters?, loadChain?, loadParameters?, validationChain?, validationParameters?, allowNewRows?, columnFilters?, maxHeight?, isReadOnly?, topMode?, forceAddAtBottom?, disableDeepKeyCheck?, ignoreKeyCase?, isReadOnlyCell?, columnFiltersGetCaptionForColumnValue?, columnFiltersCustomFilter?, defaultButtons?, serverSidedPagination?, paginationSize?, paginationAllPages?, requestPostChain?, modelUrl?, exportFileName?, disableExport? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html)
  @description Creates a grid UI based on given data or a configuration allowing to edit the data
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getClassName)
  @description   Get className
  @overrides bcdui.core.Renderer#getClassName
  @public
  @return {string} className
  */
  getClassName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#jumpToError)
  @description   Jumps to the first error
  @public
  @return {void}
  */
  jumpToError() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#jumpToRow)
  @description   Jumps to given row/col
  @public
  @return {void}
  */
  jumpToRow() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#save)
  @description   Save the modified data to the database
  @public
  @return {void}
  */
  save() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#actionReset)
  @description   Drop all changes and load fresh data
  @public
  @return {void}
  */
  actionReset() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getConfigModel)
  @public
  @return {bcdui.core.DataProvider} configuration model of the grid
  */
  getConfigModel() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getEnhancedConfiguration)
  @public
  @return {bcdui.core.DataProvider} Enhanced configuration model of the grid
  */
  getEnhancedConfiguration() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#execute)
  @param {(boolean|Type_RendererExecute_Args)} args -  either true for forced or parameter map
  @inherits bcdui.core.Renderer#execute
  @return {void}
  */
  execute(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getTargetHtml)
  @description   Return the target html element where the renderer places its output
  @inherits bcdui.core.Renderer#getTargetHtml
  @return {void}
  */
  getTargetHtml() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#setTargetHtml)
  @description   Sets the target html element where the renderer places its output
  @param {HtmlElement} targetHtmlElement -  target html element
  @inherits bcdui.core.Renderer#setTargetHtml
  @return {void}
  */
  setTargetHtml(targetHtmlElement) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getReadyStatus)
  @description   The ready status for the transformation chain is reached as soon as all transformations are finished. <p> The status transitions of the class are as follows:          </p> <p style="padding-left: 10px"><table><tr><td style="border: 3px double black; text-align: center" colspan="2"> Initialized                                              </td><td style="padding-left: 20px"> All variables have been initialized. </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2"> Loading                                                  </td><td style="padding-left: 20px"> Start loading chain document. </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2"> ChainLoaded                                              </td><td style="padding-left: 20px"> The chain document has been loaded. Start loading chain stylesheets. </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2"> <i> WaitingForParameters </i>                                </td><td style="padding-left: 20px"> Chain stylesheets loaded. Waiting for parameter data providers (<i>execute</i>). </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2"> Transforming                                             </td><td style="padding-left: 20px"> The chain stylesheets are running. </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 3px double black; text-align: center" colspan="2"> <b> Transformed </b>                                         </td><td style="padding-left: 20px"> The output has been generated. (<b>ready</b>)  </td></tr></table></p>
  @inherits bcdui.core.TransformationChain#getReadyStatus
  @return {bcdui.core.Status} The transformed status.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getData)
  @description   A getter for the document produced by the transformation chain.
  @inherits bcdui.core.TransformationChain#getData
  @return {*} The output of the last transfomration in the chain if it doesnot produce HTML (output="html").
  */
  getData() { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#reloadStylesheets)
  @description   Start the loading process of the stylesheets and executes the transformations again.
  @inherits bcdui.core.TransformationChain#reloadStylesheets
  @return {void}
  */
  reloadStylesheets() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getDataProviderByName)
  @param {string} name -
  @inherits bcdui.core.TransformationChain#getDataProviderByName
  @return {bcdui.core.DataProvider} returns the parameter of the given name
  */
  getDataProviderByName(name) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#addDataProvider)
  @description   Adds a new data provider to the transformation chain. If there is already a data provider with the given name it is replaced.
  @param {Object} newDataProvider -  the new dataprovider which should be added
  @param {string} [newName] -  an optional new name for the provider. if given an alias will be created
  @inherits bcdui.core.TransformationChain#addDataProvider
  
  @example
  ````js
    // Usage
    var ret = myGrd.addDataProvider( newDataProvider );
  ````

@return {bcdui.core.DataProvider} The old data provider registered under the name ornull if there has not been any.
  */
  addDataProvider(newDataProvider,newName) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getPrimaryModel)
  @description   Getter for the primary model of the chain. The first transformation of the chain takes a document as input. This document comes from the primary model.
  @inherits bcdui.core.TransformationChain#getPrimaryModel
  @return {bcdui.core.DataProvider} The model the first transformation inthe chain is running on.
  */
  getPrimaryModel() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#setPrimaryModel)
  @description   Adds a new data provider to the list which becomes the new primary model of the transformation chain.
  @param {bcdui.core.DataProvider} primaryModel -  the new primary model of the transformation chain.
  @inherits bcdui.core.TransformationChain#setPrimaryModel
  @return {void}
  */
  setPrimaryModel(primaryModel) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#toString)
  @inherits bcdui.core.TransformationChain#toString
  @return {string} String representation of the chain.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getFailedStatus)
  @inherits bcdui.core.TransformationChain#getFailedStatus
  @return {Array.<bcdui.core.Status>} Returns all statuses indicating a failure
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#sendData)
  @description   Sends the current data to the original URL
  @inherits bcdui.core.DataProvider#sendData
  @return {void}
  */
  sendData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#fire)
  @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completed and data is consistent again.
  @inherits bcdui.core.DataProvider#fire
  @return {void}
  */
  fire() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getName)
  @description   Getter for the name of the data provider. This name is for example used to set parameters names of a {@link bcdui.core.TransformationChain}.
  @inherits bcdui.core.DataProvider#getName
  @return {string} The name of the data provider. This name should be uniquewithin the scope it is used and is usually not globally unique (as the id).
  */
  getName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#promptData)
  @description   Convenience method for debugging showing data in a prompt for copy-and-paste
  @inherits bcdui.core.DataProvider#promptData
  @return {void}
  */
  promptData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#debugIsWaitingFor)
  @inherits bcdui.core.DataProvider#debugIsWaitingFor
  @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
  */
  debugIsWaitingFor() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#debugStatus)
  @inherits bcdui.core.DataProvider#debugStatus
  @return {string} Human readable message about the current state state
  */
  debugStatus() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#read)
  @description   Reads the string value from a given xPath (or optionally return default value).
  @param {string} xPath -  xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [defaultValue] -  default value in case xPath value does not exist
  @inherits bcdui.core.DataProvider#read
  
  @example
  ````js
    // Usage
    var ret = myGrd.read( xPath );
  ````

@return {string} text value stored at xPath (or null if no text was found and no defaultValue supplied)
  */
  read(xPath,fillParams,defaultValue) { return ""; }
/**
  @typedef {Object} Type_GridTblInsert_Args
  @property {Object} values -  object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#tblInsert)
  @description   inserts a new row in the wrs data, values given as object
  @param {Type_GridTblInsert_Args} args -  parameter bag
    ````js
    { values, rmi?, fire? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblInsert
  
  @example
  ````js
    // Usage
    var ret = myGrd.tblInsert({ values });
  ````

@return {string} row id of newly inserted row
  */
  tblInsert(args) { return ""; }
/**
  @typedef {Object} Type_GridTblUpdate_Args
  @property {Object} values -  object holding cell values which should be used for updating, e.g. { country: 'DE', flag: true }
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  @property {string} [rowId] -  id specifying row which should be updated (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#tblUpdate)
  @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
  @param {Type_GridTblUpdate_Args} args -  parameter bag
    ````js
    { values, filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblUpdate
  
  @example
  ````js
    // Usage
    var ret = myGrd.tblUpdate({ values });
  ````

@return {number} count of updated rows
  */
  tblUpdate(args) { return 0; }
/**
  @typedef {Object} Type_GridTblDelete_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  @property {string} [rowId] -  id specifying row which should be deleted (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#tblDelete)
  @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
  @param {Type_GridTblDelete_Args} args -  parameter bag
    ````js
    { filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblDelete
  
  @example
  ````js
    // Usage
    var ret = myGrd.tblDelete();
  ````

@return {number} count of removed rows
  */
  tblDelete(args) { return 0; }
/**
  @typedef {Object} Type_GridTblSelect_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {Array.<string>} [columns] -  string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#tblSelect)
  @description   returns an array of requested data
  @param {Type_GridTblSelect_Args} args -  parameter bag
    ````js
    { filter?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelect
  
  @example
  ````js
    // Usage
    var ret = myGrd.tblSelect();
  ````

@return {Array.<Object>} Array of objects holding the requested data
  */
  tblSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_GridTblSelectRow_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {string} [rowId] -  rowId of row which should be queried (or use filter)
  @property {Array.<string>} [columns] -  string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#tblSelectRow)
  @description   returns one object representing the filtered data (either filter or rowId). In case of multiple filter matches, the first one is returned
  @param {Type_GridTblSelectRow_Args} args -  parameter bag
    ````js
    { filter?, rowId?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelectRow
  
  @example
  ````js
    // Usage
    var ret = myGrd.tblSelectRow();
  ````

@return {Object} Array  of objects holding the requested data
  */
  tblSelectRow(args) { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#write)
  @description   Set a value to on a certain xPath and create the xPath where necessary. This combines Element.evaluate() for a single node with creating the path where necessary. It will prefer extending an existing start-part over creating a second one. After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
  @param {string} xPath -  xPath pointing to the node which is set to the value or plain xPath to be created if not there. It tries to reuse all matching parts that are already there. If you provide for example "/n:Root/n:MyElem/&commat;attr2" and there is already "/n:Root/n:MyElem/&commat;attr1", then "/n:Root/n:MyElem" will be "re-used" and get an additional attribute attr2. Many expressions are allowed, for example "/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem" is also ok. By nature, some xPath expressions are not allowed, for example using '//' or "/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem" is obviously not unambiguous enough and will throw an error. This method is Wrs aware, use for example '/wrs:Wrs/wrs:Data/wrs:*[2]/wrs:C[3]' as xPath and it will turn wrs:R[wrs:C] into wrs:M[wrs:C and wrs:O], see Wrs format. (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions Example: bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])
  @param {string} [value] -  Optional value which should be written, for example to "/n:Root/n:MyElem/&commat;attr" or with "/n:Root/n:MyElem" as the element's text content. If not provided, the xPath contains all values like in "/n:Root/n:MyElem[&commat;attr='a' and &commat;attr1='b']" or needs none like "/n:Root/n:MyElem"
  @param {boolean} [fire] -  If true a fire is triggered to inform data modification listeners
  @inherits bcdui.core.DataProvider#write
  
  @example
  ````js
    // Usage
    var ret = myGrd.write( xPath );
  ````

@return {DomNode} The xPath's node or null if dataProvider isn't ready
  */
  write(xPath,fillParams,value,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#remove)
  @description   Deletes data at a given xPath from the model
  @param {string} xPath -  xPath pointing to the value
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {boolean} [fire] -  if true a fire is triggered to notify data modification listener
  @inherits bcdui.core.DataProvider#remove
  
  @example
  ````js
    // Usage
myGrd.remove( xPath );
  ````

@return {void}
  */
  remove(xPath,fillParams,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#query)
  @description   Reads a single node from a given xPath
  @param {string} xPath -  xPath to query
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @inherits bcdui.core.DataProvider#query
  
  @example
  ````js
    // Usage
    var ret = myGrd.query( xPath );
  ````

@return {(DomNode|null)} single node or null if query fails
  */
  query(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#queryNodes)
  @description   Get node list from a given xPath
  @param {string} xPath -  xPath to query
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @inherits bcdui.core.DataProvider#queryNodes
  
  @example
  ````js
    // Usage
    var ret = myGrd.queryNodes( xPath );
  ````

@return {Array.<DomNode>} node list or empty list if query fails
  */
  queryNodes(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#serialize)
  @description   Serialize dataprovider's data if available
  @inherits bcdui.core.DataProvider#serialize
  @return {string} String containing the serialized data
  */
  serialize() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#removeDataListener)
  @param {(string|function|RemoveDataListenerParam)} listenerObject -  Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
  @inherits bcdui.core.DataProvider#removeDataListener
  @return {void}
  */
  removeDataListener(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#onChange)
  @param {(function|OnChangeParam)} listenerObject -  Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
  @param {string} [trackingXPath] -  xPath to monitor to monitor for changes
  @inherits bcdui.core.DataProvider#onChange
  
  @example
  ````js
    // Usage
myGrd.onChange( listenerObject );
  ````

@return {void}
  */
  onChange(listenerObject,trackingXPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#setStatus)
  @param {bcdui.core.Status} args -
  @inherits bcdui.core.DataProvider#setStatus
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#isClean)
  @description   True, if DataProvider is ready and there are no uncommitted write transactions, see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
  @inherits bcdui.core.DataProvider#isClean
  @return {boolean}
  */
  isClean() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#fetchData)
  @description   asynchronously fetch data for this data provider.
  @inherits bcdui.core.DataProvider#fetchData
  @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
  */
  fetchData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#addStatusListener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args -  Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @inherits bcdui.core.AbstractExecutable#addStatusListener
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#removeStatusListener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args -  The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @inherits bcdui.core.AbstractExecutable#removeStatusListener
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#getStatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @inherits bcdui.core.AbstractExecutable#getStatus
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#isReady)
  @description   Tests if the current state is the readyStatus. This status is the same status as returned by "getReadyStatus".
  @inherits bcdui.core.AbstractExecutable#isReady
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#hasFailed)
  @description   Tests if the object has reached a failure status. These status codes are returned by the "getFailedStatus" method.
  @inherits bcdui.core.AbstractExecutable#hasFailed
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#onceReady)
  @param {(function|OnceReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onceReady
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.grid.Grid.html#onReady)
  @param {(function|OnReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onReady
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
   * This status is set when the constructor has set all parameters.
   * @type {bcdui.core.status.InitializedStatus}
   */
  initializedStatus= null;
  
/**
   * The status code activated as soon as the loading begins.
   * @type {bcdui.core.status.LoadingStatus}
   */
  loadingStatus= null;
  
/**
   * A status reached when the chain model is ready.
   * @type {bcdui.core.status.ChainLoadedStatus}
   */
  chainLoadedStatus= null;
  
/**
   * This status is kept as long as the transformation chain is waitingfor parameters to load and when the chain has already loaded.
   * @type {bcdui.core.status.WaitingForParametersStatus}
   */
  waitingForParametersStatus= null;
  
/**
   * As long as this status is active the XSLT transformations are running.
   * @type {bcdui.core.status.TransformingStatus}
   */
  transformingStatus= null;
  
/**
   * The status code is reached when a transformation failed and operation cannot proceed
   * @type {bcdui.core.status.TransformFailedStatus}
   */
  transformFailedStatus= null;
  
/**
   * The status code is reached when everything is finished and the transformationresult is available. This is the final state of the TransformationChain processif no error occurs.
   * @type {bcdui.core.status.TransformedStatus}
   */
  transformedStatus= null;
  
/**
   * This (final) status is reached when an error occurs during the loading ortransformation process.
   * @type {bcdui.core.status.LoadFailedStatus}
   */
  loadFailedStatus= null;
  
/**
   * This (final) status is reached when the chain model could not be loaded.
   * @type {bcdui.core.status.ChainStylesheetLoadingFailed}
   */
  chainLoadingFailed= null;
  
/**
   * This (final) status is reached when the loading of a chain stylesheet hasfailed.
   * @type {bcdui.core.status.ChainStylesheetLoadingFailed}
   */
  chainStylesheetLoadingFailed= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       * @example
       * if( model.getStatus() === model.savedStatus )
       *   ...
       */
  savedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       */
  saveFailedStatus= null;
  
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
}


