/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} scorecardId -  The id of the linked scorecard
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.scorecardConfigurator.html#.reDisplay)
  @description   Refreshes the scorecard drag'n drop area This is e.g. necessary when a template is applied or the layout is cleaned
  @method reDisplay
@return {void}
  @memberOf bcdui.component.scorecardConfigurator
 */
export function reDisplay(scorecardId) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
