/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_XmlChartConstructor_Args
  @property {targetHtmlRef} targetHtml -  Where to place the chart
  @property {bcdui.core.DataProvider} config -  Definition of the chart according to XSD http://www.businesscode.de/schema/bcdui/charts-1.0.0
  @property {boolean} [suppressInitialRendering] -  If true, the renderer does not initially auto execute but waits for an explicit execute
  @property {string} [id] -  Page unique id for used in declarative contexts. If provided, the chart will register itself
  @property {boolean} [showAxes=true] - default=true  If false, no axes will be shown
  @property {string} [title] -  Title
  @property {boolean} [suppressInitialRendering] -  As every renderer, charts will execute and output itself automatically and their parameters after creation. This can be suppressed here.
  @property {number} [width] -  Overwrite the chart's auto-width derived from targetHtml
  @property {number} [height] -  Overwrite the chart's auto-height derived from targetHtml
  */
  
/**
  @class bcdui.component.chart.XmlChart
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html)
  @description Implements XML-definition interface. Extends the JS implementation of the Chart class allowing an XML definition model as input.
  @description Constructor of bcdui.component.XmlChart, called by prototype.
  
  @example
  ````js
    // Usage
    var myXC = new bcdui.component.chart.XmlChart({ targetHtml: "#myDiv", config });
  ````

@extends bcdui.component.chart.Chart
*/
// @ts-ignore
export class XmlChart extends bcdui.component.chart.Chart {
  /**
  @param {Type_XmlChartConstructor_Args} args -  Parameter object
    ````js
    { targetHtml, config, suppressInitialRendering?, id?, showAxes?, title?, suppressInitialRendering?, width?, height? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html)
  @description Implements XML-definition interface. Extends the JS implementation of the Chart class allowing an XML definition model as input.
  @description Constructor of bcdui.component.XmlChart, called by prototype.
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getClassName)
  @description   Get className
  @overrides bcdui.component.chart.Chart#getClassName
  @public
  @return {string} className
  */
  getClassName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getData)
  @overrides bcdui.component.chart.Chart#getData
  @public
  @return {document} DOM document
  */
  getData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getPrimaryModel)
  @overrides bcdui.component.chart.Chart#getPrimaryModel
  @public
  @return {bcdui.core.DataProvider} model with the chart data
  */
  getPrimaryModel() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_XmlChartSetXAxis_Args
  @property {Array.<number>} [categories] -  Distinct values, provide this or xValues
  @property {Array.<number>} [xValues] -  Values for continuous axis for x-y charts
  @property {string} [caption] -  Axis caption
  @property {string} [unit] -  Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
  @property {string} [layoutFlow] -  css value
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#setXAxis)
  @description   Defines x (horizontal) axis
  @param {Type_XmlChartSetXAxis_Args} args -  Parameter object
    ````js
    { categories?, xValues?, caption?, unit?, layoutFlow? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.component.chart.Chart#setXAxis
  
  @example
  ````js
    // Usage
myXC.setXAxis();
  ````

@return {void}
  */
  setXAxis(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_XmlChartSetYAxis1_Args
  @property {string} [caption] -  Axis caption
  @property {string} [unit] -  Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
  @property {string} [layoutFlow] -  css value
  @property {number} [minValueUser] -  User set axis min value. Only used when below lowest actual value
  @property {number} [maxValueUser] -  User set axis max value. Only used when above highest actual value
  @property {boolean} [showGrid=true] - default=true  If false, no horizontal grid is shown but only small lines next to the y-axis values
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#setYAxis1)
  @description   Defines left y axis
  @param {Type_XmlChartSetYAxis1_Args} args -  Parameter object
    ````js
    { caption?, unit?, layoutFlow?, minValueUser?, maxValueUser?, showGrid? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.component.chart.Chart#setYAxis1
  
  @example
  ````js
    // Usage
myXC.setYAxis1();
  ````

@return {void}
  */
  setYAxis1(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_XmlChartSetYAxis2_Args
  @property {string} [caption] -  Axis caption
  @property {string} [unit] -  Unit like € or sec. If '%', values are shown as percent. Use '% ' to show percent without dividing by 100
  @property {string} [layoutFlow] -  css value
  @property {number} [minValueUser] -  User set axis min value. Only used when below lowest actual value
  @property {number} [maxValueUser] -  User set axis max value. Only used when above highest actual value
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#setYAxis2)
  @description   Defines right y axis
  @param {Type_XmlChartSetYAxis2_Args} args -  Parameter object
    ````js
    { caption?, unit?, layoutFlow?, minValueUser?, maxValueUser? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.component.chart.Chart#setYAxis2
  
  @example
  ````js
    // Usage
myXC.setYAxis2();
  ````

@return {void}
  */
  setYAxis2(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_XmlChartAddSeries_Args
  @property {integer} [yAxis1Or2] -  1 for left and 2 for right axis
  @property {Array.<number>} [yData] -  Data array or provide yDataInfo
  @property {DomNodeSet} [yDataInfo] -  XML nodeset with data
  @property {Array.<number>} [sizeData] -  2nd value for scattered charts
  @property {Array.<number>} [xValues] -  For x-y charts
  @property {(integer|string)} [chartType] -  Either name or numeric value for chart type
  @property {string} [rgb] -  Color
  @property {string} [dashstyle] -  Dash style
  @property {Array.<string>} [baseColors] -  Colors defining the tones of the generated colors, for example in case of a pie chart
  @property {string} [caption] -  Series caption
  @property {number} [width] -  Line width</li>
  @property {(function|string)} [onClick] -  Either a function or the name of a function
  @property {boolean} [toSeriesPercentage] -  If true, each value is represented by its percentage value of the full series.
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#addSeries)
  @description   Adds a data series to the chart
  @param {Type_XmlChartAddSeries_Args} args -  Parameter object
    ````js
    { yAxis1Or2?, yData?, yDataInfo?, sizeData?, xValues?, chartType?, rgb?, dashstyle?, baseColors?, caption?, width?, onClick?, toSeriesPercentage? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.component.chart.Chart#addSeries
  
  @example
  ````js
    // Usage
myXC.addSeries();
  ````

@return {void}
  */
  addSeries(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_XmlChartSetStacked_Args
  @property {integer} axis -  1 for left axis 2 for right one</li>
  @property {(integer|string)} chartType -  Either name or numeric value for chart type
  @property {boolean} [asPercent] -  Each series is calculated to its percentage of the sum if all series and shown as *100'%'
  @property {boolean} [isStacked=true] - default=true  Whether to stack or not
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#setStacked)
  @description   Define series as being stacked
  @param {Type_XmlChartSetStacked_Args} args -  map with
    ````js
    { axis, chartType, asPercent?, isStacked? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.component.chart.Chart#setStacked
  
  @example
  ````js
    // Usage
myXC.setStacked({ axis, chartType });
  ````

@return {void}
  */
  setStacked(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#toString)
  @description   Debugging function showing a text for this class.
  @inherits bcdui.component.chart.Chart#toString
  @return {string} A summary of the class.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getReadyStatus)
  @description   Getter for the ready status of the instance. This status is a final state defined by each sub-class which is reached when the process has finished normally.
  @inherits bcdui.core.AbstractExecutable#getReadyStatus
  @return {bcdui.core.Status} The status object indicating that the process belongingto this class is finished.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#sendData)
  @description   Sends the current data to the original URL
  @inherits bcdui.core.DataProvider#sendData
  @return {void}
  */
  sendData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#fire)
  @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completed and data is consistent again.
  @inherits bcdui.core.DataProvider#fire
  @return {void}
  */
  fire() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getName)
  @description   Getter for the name of the data provider. This name is for example used to set parameters names of a {@link bcdui.core.TransformationChain}.
  @inherits bcdui.core.DataProvider#getName
  @return {string} The name of the data provider. This name should be uniquewithin the scope it is used and is usually not globally unique (as the id).
  */
  getName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#promptData)
  @description   Convenience method for debugging showing data in a prompt for copy-and-paste
  @inherits bcdui.core.DataProvider#promptData
  @return {void}
  */
  promptData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#debugIsWaitingFor)
  @inherits bcdui.core.DataProvider#debugIsWaitingFor
  @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
  */
  debugIsWaitingFor() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#debugStatus)
  @inherits bcdui.core.DataProvider#debugStatus
  @return {string} Human readable message about the current state state
  */
  debugStatus() { return ""; }
/**
  @typedef {Object} Type_XmlChartTblInsert_Args
  @property {Object} values -  object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#tblInsert)
  @description   inserts a new row in the wrs data, values given as object
  @param {Type_XmlChartTblInsert_Args} args -  parameter bag
    ````js
    { values, rmi?, fire? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblInsert
  
  @example
  ````js
    // Usage
    var ret = myXC.tblInsert({ values });
  ````

@return {string} row id of newly inserted row
  */
  tblInsert(args) { return ""; }
/**
  @typedef {Object} Type_XmlChartTblUpdate_Args
  @property {Object} values -  object holding cell values which should be used for updating, e.g. { country: 'DE', flag: true }
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  @property {string} [rowId] -  id specifying row which should be updated (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#tblUpdate)
  @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
  @param {Type_XmlChartTblUpdate_Args} args -  parameter bag
    ````js
    { values, filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblUpdate
  
  @example
  ````js
    // Usage
    var ret = myXC.tblUpdate({ values });
  ````

@return {number} count of updated rows
  */
  tblUpdate(args) { return 0; }
/**
  @typedef {Object} Type_XmlChartTblDelete_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  @property {string} [rowId] -  id specifying row which should be deleted (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#tblDelete)
  @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
  @param {Type_XmlChartTblDelete_Args} args -  parameter bag
    ````js
    { filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblDelete
  
  @example
  ````js
    // Usage
    var ret = myXC.tblDelete();
  ````

@return {number} count of removed rows
  */
  tblDelete(args) { return 0; }
/**
  @typedef {Object} Type_XmlChartTblSelect_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {Array.<string>} [columns] -  string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#tblSelect)
  @description   returns an array of requested data
  @param {Type_XmlChartTblSelect_Args} args -  parameter bag
    ````js
    { filter?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelect
  
  @example
  ````js
    // Usage
    var ret = myXC.tblSelect();
  ````

@return {Array.<Object>} Array of objects holding the requested data
  */
  tblSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_XmlChartTblSelectRow_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {string} [rowId] -  rowId of row which should be queried (or use filter)
  @property {Array.<string>} [columns] -  string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#tblSelectRow)
  @description   returns one object representing the filtered data (either filter or rowId). In case of multiple filter matches, the first one is returned
  @param {Type_XmlChartTblSelectRow_Args} args -  parameter bag
    ````js
    { filter?, rowId?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelectRow
  
  @example
  ````js
    // Usage
    var ret = myXC.tblSelectRow();
  ````

@return {Object} Array  of objects holding the requested data
  */
  tblSelectRow(args) { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#serialize)
  @description   Serialize dataprovider's data if available
  @inherits bcdui.core.DataProvider#serialize
  @return {string} String containing the serialized data
  */
  serialize() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#removeDataListener)
  @param {(string|function|RemoveDataListenerParam)} listenerObject -  Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
  @inherits bcdui.core.DataProvider#removeDataListener
  @return {void}
  */
  removeDataListener(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#onChange)
  @param {(function|OnChangeParam)} listenerObject -  Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
  @param {string} [trackingXPath] -  xPath to monitor to monitor for changes
  @inherits bcdui.core.DataProvider#onChange
  
  @example
  ````js
    // Usage
myXC.onChange( listenerObject );
  ````

@return {void}
  */
  onChange(listenerObject,trackingXPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#setStatus)
  @param {bcdui.core.Status} args -
  @inherits bcdui.core.DataProvider#setStatus
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#isClean)
  @description   True, if DataProvider is ready and there are no uncommitted write transactions, see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
  @inherits bcdui.core.DataProvider#isClean
  @return {boolean}
  */
  isClean() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#fetchData)
  @description   asynchronously fetch data for this data provider.
  @inherits bcdui.core.DataProvider#fetchData
  @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
  */
  fetchData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#addStatusListener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args -  Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @inherits bcdui.core.AbstractExecutable#addStatusListener
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#removeStatusListener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args -  The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @inherits bcdui.core.AbstractExecutable#removeStatusListener
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getStatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @inherits bcdui.core.AbstractExecutable#getStatus
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#isReady)
  @description   Tests if the current state is the readyStatus. This status is the same status as returned by "getReadyStatus".
  @inherits bcdui.core.AbstractExecutable#isReady
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#hasFailed)
  @description   Tests if the object has reached a failure status. These status codes are returned by the "getFailedStatus" method.
  @inherits bcdui.core.AbstractExecutable#hasFailed
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#getFailedStatus)
  @description   Getter for the list of error statuses of this class. This implementation returns an empty list.
  @inherits bcdui.core.AbstractExecutable#getFailedStatus
  @return {Array.<bcdui.core.Status>} The status objects corresponding to failures in the object'sprocess.
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#execute)
  @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/> Executes the process implemented by the concrete sub-class This method is called by the Renderer when it is ready to render the model It is often asynchronous. Note, Renderer and sub-classes execute all input models recursively automatically. This means, usually you do not need to call this method directly. Note: it is asynchronous. Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
  @param {boolean} [doesRefresh=true] -  Set this parameter to "false" if this method should do nothing when the object is already in the ready status. The default is "true" meaning that the process is re-started when it is currently ready.
  @inherits bcdui.core.AbstractExecutable#execute
  @return {void}
  */
  execute(doesRefresh) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#onceReady)
  @param {(function|OnceReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onceReady
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.XmlChart.html#onReady)
  @param {(function|OnReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onReady
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
   * @constant
   * @type {integer}
   */
  LINECHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  AREACHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  BARCHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  PIECHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  SCATTEREDCHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  POINTCHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  GAUGECHART= null;
  
/**
   * @constant
   * @type {integer}
   */
  MARIMEKKOCHART= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       * @example
       * if( model.getStatus() === model.savedStatus )
       *   ...
       */
  savedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       */
  saveFailedStatus= null;
  
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
}


