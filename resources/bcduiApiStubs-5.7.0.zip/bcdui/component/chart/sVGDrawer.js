/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_SVGDrawerConstructor_Args
  @property {DomDocument} doc -  Document for creating the SVG drawing
  @property {Object} [scale={x:1,y:1}] - default={x:1,y:1}  Default is no scaling { x: 1, y: 1}
  @property {Object} [transform] -  Default is no shifting { x: 0, y: 0 }
  @property {function} [createToolTipCb] -  Call back getting the source element, returning the tool tip HTML</li>
  @property {Object} [addAttr] -  A set of additional string attributes to be attached to the root element</li>
  */
  
/**
  @class bcdui.component.chart.SVGDrawer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html)
  @description A SVG drawer, drawing basic geometries
  @extends bcdui.component.chart.SVGVMLDrawer
*/
// @ts-ignore
export class SVGDrawer extends bcdui.component.chart.SVGVMLDrawer {
  /**
  @param {Type_SVGDrawerConstructor_Args} args -  Parameter object
    ````js
    { doc, scale?, transform?, createToolTipCb?, addAttr? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html)
  @description A SVG drawer, drawing basic geometries
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
/**
  @typedef {Object} Type_SVGDrawerLine_Args
  @property {Array.<Array.<number>>} points -  2 dimensional array with x,y points, args.points[0][0] being the first one</li>
  @property {string} [effect] -  An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
  @property {string} [rgb="black"] - default="black"  Line color
  @property {number} [width=1] - default=1  Line width
  @property {boolean} [isFilled] -  Fill area
  @property {function} [onClick] -  On click callback
  @property {Object} [addAttr] -  A set of additional string attributes to be attached to the root element</li>
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#line)
  @description   Draw a SVG line
  @param {Type_SVGDrawerLine_Args} args -  Parameter object
    ````js
    { points, effect?, rgb?, width?, isFilled?, onClick?, addAttr? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGD.line({ points });
  ````

@return {void}
  */
  line(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_SVGDrawerBox_Args
  @property {number} x -  Left
  @property {number} y -  Top
  @property {number} width -  Width
  @property {number} height -  Height
  @property {string} [effect] -  An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
  @property {string} [rgb="black"] - default="black"  Color
  @property {boolean} [isFilled] -  Fill area
  @property {function} [onClick] -  On click callback
  @property {Object} [addAttr] -  A set of additional string attributes to be attached to the root element</li>
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#box)
  @description   Draw a SVG box
  @param {Type_SVGDrawerBox_Args} args -  Parameter object
    ````js
    { x, y, width, height, effect?, rgb?, isFilled?, onClick?, addAttr? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGD.box({ x, y, width, height });
  ````

@return {void}
  */
  box(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_SVGDrawerArc_Args
  @property {number} x -  Center
  @property {number} y -  Center
  @property {number} radius -  Radius
  @property {number} start -  Start
  @property {number} end -  End
  @property {string} [effect] -  An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
  @property {number} [percWidth] -  Inner radius
  @property {string} [rgb="black"] - default="black"  Fill color
  @property {string} [stroke="black"] - default="black"  Border color
  @property {boolean} [isFilled] -  Fill area
  @property {function} [onClick] -  On click callback
  @property {Object} [addAttr] -  A set of additional string attributes to be attached to the root element</li>
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#arc)
  @description   Draw a SVG arc
  @param {Type_SVGDrawerArc_Args} args -  Parameter object
    ````js
    { x, y, radius, start, end, effect?, percWidth?, rgb?, stroke?, isFilled?, onClick?, addAttr? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGD.arc({ x, y, radius, start, end });
  ````

@return {void}
  */
  arc(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_SVGDrawerCircle_Args
  @property {number} x -  Center
  @property {number} y -  Center
  @property {number} radius -  Radius
  @property {string} [effect] -  An effect to be used for areas. Possible values: linearGradient, radialPlate, linearRound, linearPlate
  @property {string} [rgb="black"] - default="black"  Color
  @property {boolean} [isFilled] -  Fill area
  @property {function} [onClick] -  On click callback
  @property {Object} [addAttr] -  A set of additional string attributes to be attached to the root element</li>
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#circle)
  @description   Draw a SVG circle
  @param {Type_SVGDrawerCircle_Args} args -  Parameter object
    ````js
    { x, y, radius, effect?, rgb?, isFilled?, onClick?, addAttr? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGD.circle({ x, y, radius });
  ````

@return {void}
  */
  circle(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_SVGDrawerText_Args
  @property {number} x -  Position
  @property {number} y -  Position
  @property {string} text -  The text
  @property {string} [cssClass] -  A css class to be used
  @property {string} [align] -  Possible values middle, end
  @property {string} [layoutFlow] -  A css value lie vertical-ideographic
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#text)
  @description   Draw a SVG text
  @param {Type_SVGDrawerText_Args} args -  Parameter object
    ````js
    { x, y, text, cssClass?, align?, layoutFlow? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGD.text({ x, y, text });
  ````

@return {void}
  */
  text(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_SVGDrawerImage_Args
  @property {number} x -  Left
  @property {number} y -  Top
  @property {number} width -  Width
  @property {number} height -  Height
  @property {string} [href] -  The image
  @property {function} [onClick] -  On click callback
  @property {Object} [addAttr] -  A set of additional string attributes to be attached to the root element</li>
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#image)
  @description   Draw an SVG image element
  @param {Type_SVGDrawerImage_Args} args -  Parameter object
    ````js
    { x, y, width, height, href?, onClick?, addAttr? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGD.image({ x, y, width, height });
  ````

@return {void}
  */
  image(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_SVGDrawerSetTransScale_Args
  @property {Object} [scale={x:1,y:1}] - default={x:1,y:1}  Default is no scaling \{ x: 1, y: 1\}
  @property {Object} [transform] -  Default is no shifting \{ x: 0, y: 0 \}
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#setTransScale)
  @description   Set transform and scale
  @param {Type_SVGDrawerSetTransScale_Args} args -  parameter Object
    ````js
    { scale?, transform? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.component.chart.SVGVMLDrawer#setTransScale
  
  @example
  ````js
    // Usage
mySVGD.setTransScale();
  ````

@return {void}
  */
  setTransScale(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGDrawer.html#getResult)
  @description   Returns the a DOM element containing the SVG drawing
  @inherits bcdui.component.chart.SVGVMLDrawer#getResult
  @return {DomElement} Returns the a DOM element containing the VML or SVG drawing
  */
  getResult() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


