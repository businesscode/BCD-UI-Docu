/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ChartCreateChartLegend_Args
  @property {bcdui.core.DataProvider} inputModel -  Input model to renderer
  @property {string} targetHtmlElementId -  Target HTML element ID
  @property {string} [id] -  Renderer ID
  @property {string} [chartRendererId] -  ID of chart renderer
  @property {string} [elementStyle] -  Style for legend HTML element
  */
  /**
@param {Type_ChartCreateChartLegend_Args} args -  Paramater object
    ````js
    { inputModel, targetHtmlElementId, id?, chartRendererId?, elementStyle? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.html#.createChartLegend)
  @description   Create a legend for the chart, listing all series
  @method createChartLegend

  @example
  ````js
    // Usage
    var ret = bcdui.component.chart.createChartLegend({ inputModel: myModel, targetHtmlElementId });
  ````

@return {bcdui.core.Renderer}  renderer that creates legend renderer
@memberOf bcdui.component.chart
 */
export function createChartLegend(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
