/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.html)
 * @description   The chart package contains classes to draw charts and for drawing primitives like circles, lines and polylines in SVG, see {@link bcdui.component.chart.SVGDrawer}. You can define a chart with js calls with {@link bcdui.component.chart.Chart} as well as be providing a XML definition according to http://www.businesscode.de/schema/bcdui/charts-1.0.0 using {@link bcdui.component.chart.XmlChart}.
 * @namespace bcdui.component.chart
 */
