/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_SVGVMLDrawerConstructor_Args
  @property {Object} [scale={x:1,y:1}] - default={x:1,y:1}  Default is no scaling { x: 1, y: 1 }
  @property {Object} [transform] -  Default is no shifting { x: 0, y: 0 }
  */
  
/**
  @class bcdui.component.chart.SVGVMLDrawer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGVMLDrawer.html)
  @description This class represents a base class for SVG and VML Drawers, which have the same interface.
  @description Constructor of bcdui.component.chart.SVGVMLDrawer, called by prototype.  Instantiate {@link bcdui.component.chart.SVGDrawer} concrete subclass
  */
// @ts-ignore
export class SVGVMLDrawer {
  /**
  @param {Type_SVGVMLDrawerConstructor_Args} args -  parameter Object
    ````js
    { scale?, transform? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGVMLDrawer.html)
  @description This class represents a base class for SVG and VML Drawers, which have the same interface.
  @description Constructor of bcdui.component.chart.SVGVMLDrawer, called by prototype.  Instantiate {@link bcdui.component.chart.SVGDrawer} concrete subclass
    */
  constructor(args) {}
  
/**
  @typedef {Object} Type_SVGVMLDrawerSetTransScale_Args
  @property {Object} [scale={x:1,y:1}] - default={x:1,y:1}  Default is no scaling \{ x: 1, y: 1\}
  @property {Object} [transform] -  Default is no shifting \{ x: 0, y: 0 \}
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGVMLDrawer.html#setTransScale)
  @description   Set transform and scale
  @param {Type_SVGVMLDrawerSetTransScale_Args} args -  parameter Object
    ````js
    { scale?, transform? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @public
  
  @example
  ````js
    // Usage
mySVGVMLD.setTransScale();
  ````

@return {void}
  */
  setTransScale(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.chart.SVGVMLDrawer.html#getResult)
  @description   Returns the a DOM element containing the SVG drawing
  @public
  @return {DomElement} Returns the a DOM element containing the VML or SVG drawing
  */
  getResult() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


