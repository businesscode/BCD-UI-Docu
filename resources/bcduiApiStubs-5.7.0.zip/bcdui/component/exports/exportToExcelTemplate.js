/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ExportsExportToExcelTemplate_Args
  @property {bcdui.core.DataProvider} inputModel -  containing wrs:WrsContainer with 1..n wrs:Wrs or wrq:WrsRequest elements, containing wrs:Header or rnd:Wrs2Excel defining target sheets
  @property {string} [fileName=excelExport.xlsx] - default=excelExport.xlsx  URL name used as suffix, must end with .xlsx
  */
  /**
@param {Type_ExportsExportToExcelTemplate_Args} args -  The argument map with the following properties
    ````js
    { inputModel, fileName? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.exports.html#.exportToExcelTemplate)
  @description   Uses ExcelExportServlet to export Wrs(s) into XLSX template
  @method exportToExcelTemplate

  @example
  ````js
    // Usage
    bcdui.component.exports.exportToExcelTemplate({ inputModel: myModel });
  ````

@return {void}
  @memberOf bcdui.component.exports
 */
export function exportToExcelTemplate(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
