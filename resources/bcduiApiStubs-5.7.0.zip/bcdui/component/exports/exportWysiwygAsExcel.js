/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ExportsExportWysiwygAsExcel_Args
  @property {(string|HtmlElement)} rootElement -  The id of or the root element itself
  @property {string} [fileName="export(_timestamp).xsl"] - default="export(_timestamp).xsl"  The name of the returned Excel document
  */
  /**
@param {Type_ExportsExportWysiwygAsExcel_Args} args -  The parameter map contains the following properties:
    ````js
    { rootElement, fileName? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.exports.html#.exportWysiwygAsExcel)
  @description   Produces a WYSIWYG Excel export of a windows.document subtree
  @method exportWysiwygAsExcel

  @example
  ````js
    // Usage
    bcdui.component.exports.exportWysiwygAsExcel({ rootElement });
  ````

@return {void}
  @memberOf bcdui.component.exports
 */
export function exportWysiwygAsExcel(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
