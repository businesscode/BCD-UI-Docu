/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.exports.html)
 * @description   Export package is the API to the WYSIWYG and detail exports of BCD-UI WYSIWYG can be pdf, excel or image
 * @namespace bcdui.component.exports
 */
