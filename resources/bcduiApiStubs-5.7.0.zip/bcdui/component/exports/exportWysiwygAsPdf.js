/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ExportsExportWysiwygAsPdf_Args
  @property {(string|HtmlElement)} rootElement -  The id of or the root element itself
  @property {string} [fileName=report.pdf] - default=report.pdf  The name of the returned pdf
  @property {(Array.<string>|string)} [css] -  An array or space separated list of URLs containing CSS files to be used, relative the the current page. This allows using different styling on export than on the page. You can also use an bcdPdfStyle for inline style only to be applied on export. Absolute paths starting with '/' are relative to the context path. Use more specific rule precedence. (css precedence based on later declaration is not supported). Local css are being cached.
  @property {boolean} [orientationLandscape] -  Set this flag to true to make the PDF appear in landscape page orientation
  @property {string} [dimension=A4] - default=A4  Physical dimension of the output like 'A5' or 'LETTER', default is A4.
  */
  /**
@param {Type_ExportsExportWysiwygAsPdf_Args} args -  The parameter map contains the following properties:
    ````js
    { rootElement, fileName?, css?, orientationLandscape?, dimension? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.exports.html#.exportWysiwygAsPdf)
  @description   Produces a WYSIWYG pdf export of a windows.document subtree, needs pdf extension, part of EnterpriseEdition
  @method exportWysiwygAsPdf

  @example
  ````js
    // Usage
    bcdui.component.exports.exportWysiwygAsPdf({ rootElement });
  ````


  @example
  bcdui.component.exports.exportWysiwygAsPdf( { rootElement: "myReportDiv", css: ["/bcdui/theme/css/allStyles.css", "my.css"] } );
  @return {void}
  @memberOf bcdui.component.exports
 */
export function exportWysiwygAsPdf(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
