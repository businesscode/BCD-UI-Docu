/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ExportsExportWysiwygAsImage_Args
  @property {(string|HtmlElement)} rootElement -  The id of or the root element itself
  @property {string} [fileName=report.format] - default=report.format  The name of the returned image
  @property {(Array.<string>|string)} [css] -  An array or space separated list of URLs containing CSS files to be used, relative the the current page. This allows using different styling on export than on the page. You can also use an bcdPdfStyle for inline style only to be applied on export. Absolute paths starting with '/' are relative to the context path. Use more specific rule precedence. (css precedence based on later declaration is not supported). Local css are being cached.
  @property {boolean} [orientationLandscape] -  Set this flag to true to make the PDF appear in landscape page orientation
  @property {string} [dimension=A4] - default=A4  Physical dimension of the output like 'A5' or 'LETTER', default is A4.
  */
  /**
@param {Type_ExportsExportWysiwygAsImage_Args} args -  The parameter map contains the following properties:
    ````js
    { rootElement, fileName?, css?, orientationLandscape?, dimension? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @param {string} [format=png] -  Image format, supported are 'jpg', 'png', 'bmp' or 'gif'
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.exports.html#.exportWysiwygAsImage)
  @description   Produces a WYSIWYG image export of a windows.document subtree, needs pdf extension, part of EnterpriseEdition
  @method exportWysiwygAsImage

  @example
  ````js
    // Usage
    bcdui.component.exports.exportWysiwygAsImage({ rootElement });
  ````


  @example
  bcdui.component.exports.exportWysiwygAsImage( { rootElement: "myReportDiv, format: "gif" } );
  @return {void}
  @memberOf bcdui.component.exports
 */
export function exportWysiwygAsImage(args, format) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
