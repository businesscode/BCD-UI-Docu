/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_ExportsDetailExport_Args
  @property {(string|bcdui.core.DataProvider)} wrq -  Model containing the wrs request according to XSD http://www.businesscode.de/schema/bcdui/wrs-request-1.0.0
  @property {string} [type=slk] - default=slk  Can be "slk" or "csv" or "xlsx". slk is efficient as csv and preserves numbers, use "xlsx" to preserve non-latin characters in addition
  @property {string} [fileName="export_(timestamp).(csv|xls)"] - default="export_(timestamp).(csv|xls)"  Name of the response file, depending on type, can also be provided via /wrq:WrsRequest/&commat;bcdFileName from within the request
  @property {string} [vfsFilename] -  when using vfs stored export lists, you can define a vfs path name here, if not, it is generated out of url/user information
  @property {string} [exportMode=full] - default=full  full - using the wrq as it is, show - always showing a column selector, silent - use stored column information (at least 1 column specified) if available, otherwise full
  @property {boolean} [allowSave] -  ability to save to vfs, ensure that vfs binding and user rights are available when turned on
  @property {boolean} [allDeselected] -  for the column picjer, all columns are initially selected by default and you can deselect some. Settings this flag to true, you inverse this behaviour
  @property {function} [wrqModify] -  function to do post wrq processing just before sending the request
  */
  /**
@param {Type_ExportsDetailExport_Args} args -  The argument map with the following properties
    ````js
    { wrq, type?, fileName?, vfsFilename?, exportMode?, allowSave?, allDeselected?, wrqModify? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.exports.html#.detailExport)
  @description   Uses SylkServlet, CsvServlet or ExcelExportServlet export servlets to provide the data of a WrsRequest, the response opens asynchronously in an extra window
  @method detailExport

  @example
  ````js
    // Usage
    bcdui.component.exports.detailExport({ wrq });
  ````

@return {void}
  @memberOf bcdui.component.exports
 */
export function detailExport(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
