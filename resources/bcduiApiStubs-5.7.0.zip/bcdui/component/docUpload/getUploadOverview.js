/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_DocUploadGetUploadOverview_Args
  @property {string} scope -  The scope identifier
  @property {string} [id] -  The id of the returned wrs modelwrapper
  @property {(string|Array.<string>)} [instance] -  Array or string or space separated string of instance ids in case you want to limit the output
  @property {string} [filterBRefs] -  The space separated list of binding Refs that will be used in filter clause of request document
  @property {bcdui.core.DataProvider} [config=bcdui.wkModels.bcdDocUpload] - default=bcdui.wkModels.bcdDocUpload  The model containing the docUpload configuration data. If it is not present the well known bcdui.wkModels.bcdDocUpload is used
  */
  /**
@param {Type_DocUploadGetUploadOverview_Args} args -  The parameter map contains the following properties:
    ````js
    { scope, id?, instance?, filterBRefs?, config? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.docUpload.html#.getUploadOverview)
  @description   Generate a wrs modelwrapper holding overview information for the given scope (optionally limited to instances) The wrs holds 1 row per instance with the information about loaded, needed and missing required documents
  @method getUploadOverview

  @example
  ````js
    // Usage
    var ret = bcdui.component.docUpload.getUploadOverview({ scope });
  ````

@return {bcdui.core.DataProvider}  a wrs model holding the overview information
@memberOf bcdui.component.docUpload
 */
export function getUploadOverview(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
