/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_UserCalcEditorShowUserCalcEditor_Args
  @property {writableModelXPath} targetModelXPath -  The XPath to write to.
  @property {string} [id] -  The base id of the field. If nothing is specified the id is generated.
  @property {modelXPath} [optionsModelXPath] -  An XPath returning a node-set holding the allowed
  @property {modelXPath} [uniqueOptionsModelXPath] -  variables for the formula editor. The parameter "optionsModelRelativeValueXPath" can optionally be set to define non-visible values belonging to the visible options denoted by this XPath.
  @property {xPath} [optionsModelRelativeValueXPath] -  If specified this XPath is applied to each node returned by the "optionsModelXPath" to get a non-visible value to be written to the target node. When no "optionsModelRelativeValueXPath" is given there is no distinction between the caption and value of each option.
  @property {string} [dialogCaption] -  Caption of dialog window, it will be used as i18n key to translate the caption.
  @property {boolean} [isFormatOptionsVisible=true] - default=true  Show format fields (format, scale, percent)
  @property {boolean} [validateVariableNamesCheckbox] -  Show checkbox which enabling\disabling validation of variable names with list in optionsModel while input formula
  @property {string} [validateVariableNamesCaption] -  Caption of checkbox, which enable\disable formula variables validation
  @property {function} successCallBack -  Callback function which called after success saving model after closing modal window
  @property {boolean} [skipServerSidedFunctions] -  Set to true to disable usage of server sided functions like CntDist.
  */
  /**
@param {Type_UserCalcEditorShowUserCalcEditor_Args} args -  The argument map:
    ````js
    { targetModelXPath, id?, optionsModelXPath?, uniqueOptionsModelXPath?, optionsModelRelativeValueXPath?, dialogCaption?, isFormatOptionsVisible?, validateVariableNamesCheckbox?, validateVariableNamesCaption?, successCallBack, skipServerSidedFunctions? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.component.userCalcEditor.html#.showUserCalcEditor)
  @description   Brings up a user calc editor, i.e. an inout field with autocomplete for entering formulas that can be used in calculation.xslt
  @method showUserCalcEditor

  @example
  ````js
    // Usage
    bcdui.component.userCalcEditor.showUserCalcEditor({ targetModelXPath: "$guiStatus/cust:Elem/@value", successCallBack });
  ````

@return {void}
  @memberOf bcdui.component.userCalcEditor
 */
export function showUserCalcEditor(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
