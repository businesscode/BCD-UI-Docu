/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {function} fn -  The function executed as soon as the browser has finished loading.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html#.ready)
  @description   Registers a callback function to be executed when the browser has finished loading. If the loading has already finished the function is executed immediately.
  @method ready
@return {void}
  @memberOf bcdui.core
 */
export function ready(fn) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
