/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_StatusEventConstructor_Args
  @property {Object} source   The object the status transition happened
  @property {bcdui.core.Status} newStatus   The new status of the source object
  */
  
/**
  @class bcdui.core.StatusEvent
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusEvent)
  @description Represents a status event thrown to status listeners of {@link bcdui.core.DataProvider DataProviders}, 
see {@link bcdui.core.AbstractExecutable#removeStatusListener} and {@link bcdui.core.StatusListener}
  @description The constructor creating a new StatusEvent object.
  
  @example
  // Usage
var mySE = new bcdui.core.StatusEvent({ source, newStatus });

*/
// @ts-ignore
export class StatusEvent {
  /**
  @description Represents a status event thrown to status listeners of {@link bcdui.core.DataProvider DataProviders}, 
see {@link bcdui.core.AbstractExecutable#removeStatusListener} and {@link bcdui.core.StatusListener}
  @description The constructor creating a new StatusEvent object.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusEvent)
  
  @example
  // Usage
var mySE = new bcdui.core.StatusEvent({ source, newStatus });

@param {Type_StatusEventConstructor_Args} args   This parameter map must contain two properties:
    ````js
    { source, newStatus }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
    */
  constructor(args) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusEvent?id=getsource)
  @description   Getter for the object that made the status transition.
  @public
  @return {object} The causer of the event.
  */
  getSource() { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusEvent?id=getstatus)
  @public
  @return {bcdui.core.Status} The new status of the source object.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.StatusEvent?id=tostring)
  @public
  @return {string} A summary of the status event.
  */
  toString() { return ""; }
}


