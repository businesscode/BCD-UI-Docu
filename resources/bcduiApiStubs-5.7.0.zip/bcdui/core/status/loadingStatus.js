/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @class bcdui.core.status.LoadingStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus)
  @description This class is active while the executable object is waiting for its document to be loaded.
As soon as the server response is complete, the status will switch.
  @extends bcdui.core.Status
*/
// @ts-ignore
export class LoadingStatus extends bcdui.core.Status {
  /**
  @description This class is active while the executable object is waiting for its document to be loaded.
As soon as the server response is complete, the status will switch.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus)
    */
  constructor() {
    // @ts-ignore (ignore wrong param list)
    super(); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus?id=equals)
  @description   Test the status for logical equivalence to another status object. Usually
this function should test if the target status is of the same class as
this status.
  @overrides bcdui.core.Status#equals
  @public
  @return {boolean} True, if the specified status object represents the same
logical status as the current one.
  */
  equals() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus?id=getcode)
  @overrides bcdui.core.Status#getCode
  @public
  @return {string} A short code for the Status which can be used for debugging.
  */
  getCode() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus?id=getdescription)
  @overrides bcdui.core.Status#getDescription
  @public
  @return {string} A longer description of the Status.
  */
  getDescription() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.LoadingStatus?id=tostring)
  @inherits bcdui.core.Status#toString
  @return {string} A debug string summarizing this status object.
  */
  toString() { return ""; }
}


