/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @class bcdui.core.status.TransformFailedStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.TransformFailedStatus.html)
  @description This status is activated when a transformation failed.
  @extends bcdui.core.Status
*/
// @ts-ignore
export class TransformFailedStatus extends bcdui.core.Status {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.TransformFailedStatus.html)
  @description This status is activated when a transformation failed.
    */
  constructor() {
    // @ts-ignore (ignore wrong param list)
    super(); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.TransformFailedStatus.html#getCode)
  @overrides bcdui.core.Status#getCode
  @public
  @return {string} A short code for the Status which can be used for debugging.
  */
  getCode() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.TransformFailedStatus.html#getDescription)
  @overrides bcdui.core.Status#getDescription
  @public
  @return {string} A longer description of the Status.
  */
  getDescription() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.TransformFailedStatus.html#equals)
  @description   Test the status for logical equivalence to another status object. Usually this function should test if the target status is of the same class as this status.
  @overrides bcdui.core.Status#equals
  @public
  @return {boolean} True, if the specified status object represents the samelogical status as the current one.
  */
  equals() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.TransformFailedStatus.html#toString)
  @inherits bcdui.core.Status#toString
  @return {string} A debug string summarizing this status object.
  */
  toString() { return ""; }
}


