/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.status.html)
 * @description   A namespace containing a set of status classes used by the BCD-UI system. They are used by the subclasses of the {@link bcdui.core.AbstractExecutable AbstractExecutable} to implement their status system. See {@link bcdui.core.AbstractExecutable#getStatus getStatus()}. </P> The statuses are useful during debugging, if parts of the page do not get ready. Normally, after loading and processing, all AbstractExecutable reach {@link bcdui.core.AbstractExecutable#isReady .isReady()}  === true, if everything is OK. It depends on the exact concrete subclass of AbstractExecutable, which of the statuses below means successful final, i.e. isReady(). You can retrieve this final-success status via {@link bcdui.core.AbstractExecutable#getReadyStatus .getReadyStatus()} of the subclass.
 * @namespace bcdui.core.status
 */
