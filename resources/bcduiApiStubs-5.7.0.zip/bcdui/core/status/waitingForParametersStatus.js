/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @class bcdui.core.status.WaitingForParametersStatus
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus)
  @description A status which is active as long as a transformation is waiting for its parameter DataProviders to become ready.
If a transformation remains too long in this status, one of its, check why its paramaters or input model did not become ready.
  @extends bcdui.core.Status
*/
// @ts-ignore
export class WaitingForParametersStatus extends bcdui.core.Status {
  /**
  @description A status which is active as long as a transformation is waiting for its parameter DataProviders to become ready.
If a transformation remains too long in this status, one of its, check why its paramaters or input model did not become ready.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus)
    */
  constructor() {
    // @ts-ignore (ignore wrong param list)
    super(); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus?id=equals)
  @description   Test the status for logical equivalence to another status object. Usually
this function should test if the target status is of the same class as
this status.
  @overrides bcdui.core.Status#equals
  @public
  @return {boolean} True, if the specified status object represents the same
logical status as the current one.
  */
  equals() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus?id=getcode)
  @overrides bcdui.core.Status#getCode
  @public
  @return {string} A short code for the Status which can be used for debugging.
  */
  getCode() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus?id=getdescription)
  @overrides bcdui.core.Status#getDescription
  @public
  @return {string} A longer description of the Status.
  */
  getDescription() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.status.WaitingForParametersStatus?id=tostring)
  @inherits bcdui.core.Status#toString
  @return {string} A debug string summarizing this status object.
  */
  toString() { return ""; }
}


