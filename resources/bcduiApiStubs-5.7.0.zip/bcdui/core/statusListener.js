/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.core.StatusListener
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StatusListener.html)
  @description An interface that status listeners must implement. A StatusListener is informed by DataProviders (more precisely by {@link bcdui.core.AbstractExecutable AbstractExecutables}) about status changes, becoming ready is the most important.
  */
// @ts-ignore
export class StatusListener {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StatusListener.html)
  @description An interface that status listeners must implement. A StatusListener is informed by DataProviders (more precisely by {@link bcdui.core.AbstractExecutable AbstractExecutables}) about status changes, becoming ready is the most important.
    */
  constructor() {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StatusListener.html#handleStatusEvent)
  @description   This method is called when the status transition the listener is registered for occurs.
  @param {bcdui.core.StatusEvent} statusEvent -  The status event belonging to the status transition. This object must not be modified, because it is shared among all listeners.
  @public
  @return {void}
  */
  handleStatusEvent(statusEvent) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


