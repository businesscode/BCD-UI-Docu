/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} url -  The URL containing the parameter.
  @param {string} parameterName -  The parameter name.
  @param {string} [defaultValue] -  The default value when the result would be null. If not specified it returns null if the parameter is not found.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html#.getUrlParameter)
  @description   Extracts the value of a parameter definition from the URL. For example if the URL is "http://myHost/myApp/myReport.jsp?guiStatusGZ=abc" and the parameterName is "guiStatusGZ" the return value is "abc".
  @method getUrlParameter

  @example
  ````js
    // Usage
    var ret = bcdui.core.getUrlParameter( url, parameterName );
  ````

@return {string}  The value of the parameter or the default value (usually NULL)if the parameter is empty or not found.
@memberOf bcdui.core
 */
export function getUrlParameter(url, parameterName, defaultValue) { return ""; };
