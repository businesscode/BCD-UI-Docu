/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} url -  The URL where the parameter replacement should be applied.
  @param {string} parameterName -  The name of the parameter.
  @param {string} unEscapedValue -  The parameter value which must not be escaped. This function escapes it. If this is NULL the parameter definition is removed.
  @param {boolean} [asAnchor] -  A boolean value (which is false by default) indicating if the parameter definition should be placed in the anchor section of the URL.
  @param {boolean} [allowMultiple] -  If set to true, allows multiple occurences of parameter (i.e. resulting in a parsed array on the server)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html#.setUrlParameter)
  @description   Replaces a parameter=value definition inside a URL. For example if the url is "/myApp/myReport.jsp?guiStatusGZ=abc&menuId=xyz", the parameterName is "guiStatusGZ" and the unEscapedValue is "newValue" the result will be "/myApp/myReport.jsp?menuId=xyz&guiStatusGZ=newValue". Please note that this function does not preserve the original parameter ordering. <br/> Additionally it can also put parameter definitions in the anchor section of the URL, for example like "/myApp/myReport.jsp?menuId=xyz#guiStatusGZ=bla".
  @method setUrlParameter

  @example
  ````js
    // Usage
    var ret = bcdui.core.setUrlParameter( url, parameterName, unEscapedValue );
  ````

@return {string}  The transformed URL.
@memberOf bcdui.core
 */
export function setUrlParameter(url, parameterName, unEscapedValue, asAnchor, allowMultiple) { return ""; };
