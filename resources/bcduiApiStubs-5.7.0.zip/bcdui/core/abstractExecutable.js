/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_AbstractExecutableConstructor_Args
  @property {string} [id] -  A unique id for declarative contexts
  @property {function} [bcdPreInit] -  a function which can be used to execute code before any super code of derived classes
  */
  
/**
  @class bcdui.core.AbstractExecutable
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html)
  @description The abstract executable class is a base class for asynchronous operating status-based classes in BCD-UI library. It offers a basic set of methods that these classes share. Most methods deal with status handling, transitions, listeners and synchronization.  <br/>Most common implementations are: {@link bcdui.core.StaticModel} &bull; {@link bcdui.core.SimpleModel} &bull;
  @description The constructor which must be called by all sub-classes. It initializes the listeners, status and id fields. This class is abstract and not meant to be instantiated directly
  */
// @ts-ignore
export class AbstractExecutable {
  /**
  @param {Type_AbstractExecutableConstructor_Args} [args] -  Parameter object
    ````js
    { id?, bcdPreInit? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html)
  @description The abstract executable class is a base class for asynchronous operating status-based classes in BCD-UI library. It offers a basic set of methods that these classes share. Most methods deal with status handling, transitions, listeners and synchronization.  <br/>Most common implementations are: {@link bcdui.core.StaticModel} &bull; {@link bcdui.core.SimpleModel} &bull;
  @description The constructor which must be called by all sub-classes. It initializes the listeners, status and id fields. This class is abstract and not meant to be instantiated directly
    */
  constructor(args) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#addStatusListener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args -  Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @public
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#removeStatusListener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args -  The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @public
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#setStatus)
  @description   Makes a transition from the current status to the new status if they are not equal. After the status is changed it fires the status event to the registered listeners.<p/> Usually this method will only be called by the library but you can use it to re-trigger an action. For available statuses and their effect, see the concrete class,
  @param {bcdui.core.Status} args -  Either a Status object or a parameter map with a property "status" holding a Status object.
  @public
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#getStatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @public
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#isReady)
  @description   Tests if the current state is the readyStatus. This status is the same status as returned by "getReadyStatus".
  @public
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#hasFailed)
  @description   Tests if the object has reached a failure status. These status codes are returned by the "getFailedStatus" method.
  @public
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#getReadyStatus)
  @description   Getter for the ready status of the instance. This status is a final state defined by each sub-class which is reached when the process has finished normally.
  @public
  @return {bcdui.core.Status} The status object indicating that the process belongingto this class is finished.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#getFailedStatus)
  @description   Getter for the list of error statuses of this class. This implementation returns an empty list.
  @public
  @return {Array.<bcdui.core.Status>} The status objects corresponding to failures in the object'sprocess.
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#toString)
  @public
  @return {string} Debug string with this class and its id.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#execute)
  @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/> Executes the process implemented by the concrete sub-class This method is called by the Renderer when it is ready to render the model It is often asynchronous. Note, Renderer and sub-classes execute all input models recursively automatically. This means, usually you do not need to call this method directly. Note: it is asynchronous. Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
  @param {boolean} [doesRefresh=true] -  Set this parameter to "false" if this method should do nothing when the object is already in the ready status. The default is "true" meaning that the process is re-started when it is currently ready.
  @public
  @return {void}
  */
  execute(doesRefresh) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#onceReady)
  @param {(function|OnceReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @public
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#onReady)
  @param {(function|OnReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @public
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.AbstractExecutable.html#getClassName)
  @description   Get className
  @public
  @return {string} className
  */
  getClassName() { return ""; }
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
}


