/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} str -  The string to be quotes as an XPath string.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html#.quoteXPathString)
  @description   Quotes a string so that it can be used within an XPath for selectNodes / selectSingleNode. For example the string myValue becomes 'myValue' . The quotes are automatically added so that it is a valid XPath string.
  @method quoteXPathString
@return {string}  The XPath string representing str.
@memberOf bcdui.core
 */
export function quoteXPathString(str) { return ""; };
