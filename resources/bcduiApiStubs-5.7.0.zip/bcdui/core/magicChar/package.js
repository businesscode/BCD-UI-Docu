/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.magicChar.html)
 * @description   These are named magic UTF-8 constants, defined by BCD-UI. When referring to it in xml, use &#xE0F0;
 * @namespace bcdui.core.magicChar
 */

/**
 * Indicates a null dimension value in expressions like "DE|\uE0F0" for DE-total or simple an empty station value
 */
export const dimEmpty = "";

/**
 * Indicates that the null in the expression above stands for a real null in the data
 */
export const dimNull = {};

/**
 * Indicates that the null in the expression above stands for a null due to aggregation level (grouping=1)
 */
export const dimTotal = {};

/**
 * Grand total column
 */
export const measureGTC = {};

/**
 * Sub total column
 */
export const measureSTC = {};

/**
 * Grand total row
 */
export const measureGTR = {};

/**
 * Subtotal row
 */
export const measureSTR = {};

/**
 * Used when concatenating strings as a separator which cannot (should not) appear in any data
 */
export const separator = "";

/**
 * Used in expressions similar to zin(), i.e. a null should become a value which cannot (should not) appear in any data and is also != separator
 */
export const nonWord = "";
