/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {HtmlElement} targetElement -  The targetElement which is used for appending the new element.
  @param {string} name -  The element name which may contain a well-known prefix.
  @param {boolean} insertBeforeTargetElement -  Prepend instead of append element.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.browserCompatibility.html#.appendElementWithPrefix)
  @description   Creates a new element whose name can contain a well-known prefix (like "wrs") and appends it to the specified target element. This function should be used rather than createElementNS, because the latter is not available on the Internet Explorer.
  @method appendElementWithPrefix

  @example
  ````js
    // Usage
    var ret = bcdui.core.browserCompatibility.appendElementWithPrefix( targetElement, name, insertBeforeTargetElement );
  ````

@return {DomElement}  The new XMLElement.
@memberOf bcdui.core.browserCompatibility
 */
export function appendElementWithPrefix(targetElement, name, insertBeforeTargetElement) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
