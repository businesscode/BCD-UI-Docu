/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|document)} doc -  The document (doc or string) which should be cleaned
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.browserCompatibility.html#.removeObsoleteNS)
  @description   removes obsolete namespace declarations and moves used ones to the root element
  @method removeObsoleteNS
@return {string}  The serialized and namespace-cleaned representation of the doc
@memberOf bcdui.core.browserCompatibility
 */
export function removeObsoleteNS(doc) { return ""; };
