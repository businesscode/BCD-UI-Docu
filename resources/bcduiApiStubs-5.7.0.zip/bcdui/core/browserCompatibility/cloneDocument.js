/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomDocument} doc   To be cloned
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.cloneDocument)
  @description 
  @method cloneDocument
@return {DomDocument}  A clone of the given DOM document
@memberOf bcdui.core.browserCompatibility
 */
export function cloneDocument(doc) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
