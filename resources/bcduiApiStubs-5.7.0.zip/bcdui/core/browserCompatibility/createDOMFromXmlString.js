/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} serializedDoc -  A serialized XML document.
  @param {string} msg -  Optional for better error message.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.browserCompatibility.html#.createDOMFromXmlString)
  @description   Parses given xml string and creates a DOMDocument out of it.
  @method createDOMFromXmlString

  @example
  ````js
    // Usage
    var ret = bcdui.core.browserCompatibility.createDOMFromXmlString( serializedDoc, msg );
  ````

@return {DomDocument}  The DOMDocument parsed from the serialized document string.
@memberOf bcdui.core.browserCompatibility
 */
export function createDOMFromXmlString(serializedDoc, msg) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
