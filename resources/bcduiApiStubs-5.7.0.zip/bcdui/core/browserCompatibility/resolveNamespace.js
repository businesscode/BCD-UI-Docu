/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.core.browserCompatibility.resolveNamespace)
  @description 
  @method resolveNamespace
@return {string}  URI for a given prefix
@memberOf bcdui.core.browserCompatibility
 */
export function resolveNamespace() { return ""; };
