/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.browserCompatibility.html#.preXslImportByProc)
  @description   Prepare for implementing xsl:import by replacing bcduicp: with the application's context
  @method preXslImportByProc
@return {void}
  @memberOf bcdui.core.browserCompatibility
 */
export function preXslImportByProc() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
