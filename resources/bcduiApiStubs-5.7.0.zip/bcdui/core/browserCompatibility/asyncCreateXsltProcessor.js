/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_BrowserCompatibilityAsyncCreateXsltProcessor_Args
  @property {DomDocument} model -  The XSLT document the XSLTProcessor instance should be
  @property {function} callBack -  The callback function executed when the processor has been created. It takes the processor instance as argument
  @property {string} callerDebug -  Additional (debug) information from the caller for logging
  */
  /**
@param {Type_BrowserCompatibilityAsyncCreateXsltProcessor_Args} args -  An argument map containing the following elements:
    ````js
    { model, callBack, callerDebug }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.browserCompatibility.html#.asyncCreateXsltProcessor)
  @description   Asynchronous creation of an XSLTProcessor object from a DOM document.
  @method asyncCreateXsltProcessor

  @example
  ````js
    // Usage
    bcdui.core.browserCompatibility.asyncCreateXsltProcessor({ model, callBack, callerDebug });
  ````

@return {void}
  @memberOf bcdui.core.browserCompatibility
 */
export function asyncCreateXsltProcessor(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
