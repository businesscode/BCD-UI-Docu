/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.browserCompatibility.html)
 * @description   <p>  This namespace contains XML-related functions to make the BCD-UI library work on different browsers' XML implementation. These functions deal with the following issues: <dl><dt> XML Document creation                                                     </dt><dd><p> Factory functions for creating XML documents, parsing and serialization and creating XSLT processors. </p></dd><dt> XML Manipulation + IE API Compatibility                                    </dt><dd><p> The Mozilla / Webkit XML classes are augmented so that they implement the IE-compatible interface. Then the users can focus on this API only. </p></dd><dt> Namespace handling                                                        </dt><dd><p> Align the handling of XML namespaces and prefixes so that the well-known BCD-UI prefixes as well as user prefixes can be used in the JavaScript API. </p></dd></dl></p><p> </p>
 * @namespace bcdui.core.browserCompatibility
 */
