/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html#.createQueryString)
  @description   encode parameters into a query-string
  @method createQueryString
@return {string}  the query string, with encoded parameters; this string does not start with '?'
@memberOf bcdui.core
 */
export function createQueryString() { return ""; };
