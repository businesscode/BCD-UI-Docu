/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.core.Status
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.Status.html)
  @description An abstract base class, representing a Status. See {@link bcdui.core.status} for concrete sub classes.
  */
// @ts-ignore
export class Status {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.Status.html)
  @description An abstract base class, representing a Status. See {@link bcdui.core.status} for concrete sub classes.
    */
  constructor() {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.Status.html#getCode)
  @public
  @return {string} A short code for the Status which can be used for debugging.
  */
  getCode() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.Status.html#getDescription)
  @public
  @return {string} A longer description of the Status.
  */
  getDescription() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.Status.html#equals)
  @description   Test the status for logical equivalence to another status object. Usually this function should test if the target status is of the same class as this status.
  @param {bcdui.core.Status} status -  The status object to compare with.
  @public
  @return {boolean} True, if the specified status object represents the samelogical status as the current one.
  */
  equals(status) { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.Status.html#toString)
  @public
  @return {string} A debug string summarizing this status object.
  */
  toString() { return ""; }
}


