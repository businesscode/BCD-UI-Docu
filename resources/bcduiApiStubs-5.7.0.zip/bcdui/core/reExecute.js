/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {Object} obj -  The abstract executable object which should be reexecuted
  @param {function} [readyFunction] -  Function to be executed once on ready status
  @param {boolean} [shouldRefresh] -  Set this parameter to "false" if this method should do nothing when the object is already in the ready status.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html#.reExecute)
  @description   Reexecutes the process implemented by the concrete sub-class.
  @method reExecute

  @example
  ````js
    // Usage
    bcdui.core.reExecute( obj );
  ````

@return {void}
  @memberOf bcdui.core
 */
export function reExecute(obj, readyFunction, shouldRefresh) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
