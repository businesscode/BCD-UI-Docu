/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.html)
 * @description   <p>  This namespace encapsulates consists of the lower layer of BCDUI core functionality. It is composed of three blocks of functionality: <dl><dt> Core Classes                                                              </dt><dd><p> The core classes are the foundation for most BCDUI objects on the page. The processes these objects are reflecting are running  asynchronously and implemented in the form of a state-machine behaviour. The central interface for these classes is the {@link bcdui.core.DataProvider} interface. </p></dd><dt> Page Lifecycle Support                                                    </dt><dd><p> These are functions dealing with the loading of XML and creating and executing XSLT, provided by the central {@link bcdui.core.xmlLoader} object. Additionally there are function for managing page status. This status is encapsulated in the {@link guiStatus} object which can be compressed and uncompressed to transport it in URLs and browser bookmarks. </p></dd><dt> Utility functions                                                         </dt><dd><p> The core package provides lots of utility functions to support XML processing, enhance cross-browser compatibility and to simplify JavaScript development. Most of these functions are located directly under the bcdui.core namespace. </p></dd></dl></p><p> The functions and classes provided here can be used directly or they can be accessed through a higher architecture layer such as the {@link bcdui.factory} namespace.  </p>
 * @namespace bcdui.core
 */

/**
 * The full URL to the webRowSet servlet.
 */
export const webRowSetServletPath = {};

/**
 * The full URL to the webRowSet servlet at servletsSessionCached path
 */
export const webRowSetServletPathSessionCached = {};

/**
 * A fixed empty model which can be used in various cases when the real model is notyet available. The model contains a single root element &lt;Empty/>.
 */
export const emptyModel = {};
