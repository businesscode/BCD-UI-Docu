/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.core.StaticModel
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html)
  @description Creates a model from fixed data without accessing the network.</p> As opposed to most DataProviders, execute() of a StaticModel is guaranteed to be synchronous except when using model updaters. Note that this implies that it is only static once the page is fully loaded {@link bcdui.core.ready()} <ol>   <li> execute() is called after {@link bcdui.core.ready()} was reached, because otherwise model updaters may still register themselves</li>   <li> at the time of .execute() no model updaters were registered for this model, because model updaters operate asynchronously</li> </ol>
  @description Create a StaticModel and provide the data.
  
  @example
  // Provide data as a {@link bcdui.core.DataProvider DataProvider} with an id or use in a declarative context by idvar m = new bcdui.core.StaticModel({ id: "dayModel", data: "<Values> <V>Mon</V> <V>Wed</V> </Values>" });bcdui.widgetNg.createSingleSelect({ targetHtml: "selectDayHtml", optionsModelXPath: "$dayModel/Values/V", targetModelXPath: "$guiStatus/guiStatus:Status/guiStatus:SelectedDay/@value" });
  
  @example
  Provide data as a {@link bcdui.core.DataProvider DataProvider}var myModel = new bcdui.core.StaticModel( "<Root myAttr='Test'></Root>" );// Widgets and Renderers automatically execute and wait for the model to be ready. If using it in plain JavaScript, do it yourself.myModel.onceReady({ executeIfNotReady: true, onSuccess: () => {  var myAttr = myModel.getData().selectSingleNode("/Root/@myAttr").nodeValue;  // ...}});
  @extends bcdui.core.AbstractUpdatableModel
*/
// @ts-ignore
export class StaticModel extends bcdui.core.AbstractUpdatableModel {
  /**
  @param {(string|StaticModelParam|DomDocument)} args -  And XML string, which is parsed, an XML Document or a JSON object or any other kind of data
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html)
  @description Creates a model from fixed data without accessing the network.</p> As opposed to most DataProviders, execute() of a StaticModel is guaranteed to be synchronous except when using model updaters. Note that this implies that it is only static once the page is fully loaded {@link bcdui.core.ready()} <ol> <li> execute() is called after {@link bcdui.core.ready()} was reached, because otherwise model updaters may still register themselves</li> <li> at the time of .execute() no model updaters were registered for this model, because model updaters operate asynchronously</li> </ol>
  @description Create a StaticModel and provide the data.
  
  @example
  // Provide data as a {@link bcdui.core.DataProvider DataProvider} with an id or use in a declarative context by idvar m = new bcdui.core.StaticModel({ id: "dayModel", data: "<Values> <V>Mon</V> <V>Wed</V> </Values>" });bcdui.widgetNg.createSingleSelect({ targetHtml: "selectDayHtml", optionsModelXPath: "$dayModel/Values/V", targetModelXPath: "$guiStatus/guiStatus:Status/guiStatus:SelectedDay/@value" });
  
  @example
  Provide data as a {@link bcdui.core.DataProvider DataProvider}var myModel = new bcdui.core.StaticModel( "<Root myAttr='Test'></Root>" );// Widgets and Renderers automatically execute and wait for the model to be ready. If using it in plain JavaScript, do it yourself.myModel.onceReady({ executeIfNotReady: true, onSuccess: () => {  var myAttr = myModel.getData().selectSingleNode("/Root/@myAttr").nodeValue;  // ...}});
    */
  constructor(args) {
    // @ts-ignore (ignore wrong param list)
    super(args); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#getClassName)
  @description   Get className
  @overrides bcdui.core.AbstractUpdatableModel#getClassName
  @public
  @return {string} className
  */
  getClassName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#getReadyStatus)
  @description   <p> The status transitions of the class are as follows:          </p> <p style="padding-left: 10px"><table><tr><td style="border: 3px double black; text-align: center" colspan="2"> Initialized                                              </td><td style="padding-left: 20px"> All variables have been initialized. </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 1px solid black; text-align: center" colspan="2"> <i> RefreshingModelUpdaters </i>                             </td><td style="padding-left: 20px"> ModelUpdaters are currently running. (<i>execute</i>) </td></tr><tr><td>&nbsp;</td><td style="border-left: 1px solid black">&nbsp;</td><td></td></tr><tr><td style="border: 3px double black; text-align: center" colspan="2"> <b> Transformed </b>                                         </td><td style="padding-left: 20px"> The data XML document has been generated. (<b>ready</b>)  </td></tr></table></p>
  @overrides bcdui.core.AbstractUpdatableModel#getReadyStatus
  @public
  @return {bcdui.core.Status} The ready state of the document.
  */
  getReadyStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#getData)
  @overrides bcdui.core.AbstractUpdatableModel#getData
  @public
  @return {DomDocument} The data document provided in the constructor.
  */
  getData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#toString)
  @description   Debugging function showing a text for this model.
  @overrides bcdui.core.AbstractUpdatableModel#toString
  @public
  @return {string} A summary of the model.
  */
  toString() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#sendData)
  @description   Sends the current data to the original URL
  @inherits bcdui.core.DataProvider#sendData
  @return {void}
  */
  sendData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#fire)
  @description   This informs modification listeners, registered via {@link bcdui.core.DataProvider#onChange onChange(args)}, that a change set was completed and data is consistent again.
  @inherits bcdui.core.DataProvider#fire
  @return {void}
  */
  fire() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#getName)
  @description   Getter for the name of the data provider. This name is for example used to set parameters names of a {@link bcdui.core.TransformationChain}.
  @inherits bcdui.core.DataProvider#getName
  @return {string} The name of the data provider. This name should be uniquewithin the scope it is used and is usually not globally unique (as the id).
  */
  getName() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#promptData)
  @description   Convenience method for debugging showing data in a prompt for copy-and-paste
  @inherits bcdui.core.DataProvider#promptData
  @return {void}
  */
  promptData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#debugIsWaitingFor)
  @inherits bcdui.core.DataProvider#debugIsWaitingFor
  @return {string} Human readable message, which DataProviders, this DataProvider depends on, are not currently in ready state
  */
  debugIsWaitingFor() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#debugStatus)
  @inherits bcdui.core.DataProvider#debugStatus
  @return {string} Human readable message about the current state state
  */
  debugStatus() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#read)
  @description   Reads the string value from a given xPath (or optionally return default value).
  @param {string} xPath -  xPath pointing to value (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [defaultValue] -  default value in case xPath value does not exist
  @inherits bcdui.core.DataProvider#read
  
  @example
  ````js
    // Usage
    var ret = mySM.read( xPath );
  ````

@return {string} text value stored at xPath (or null if no text was found and no defaultValue supplied)
  */
  read(xPath,fillParams,defaultValue) { return ""; }
/**
  @typedef {Object} Type_StaticModelTblInsert_Args
  @property {Object} values -  object holding cell values which should be inserted, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:I syntax when this is true, otherwise wrs:R is used, rmi=true also prefills default values
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#tblInsert)
  @description   inserts a new row in the wrs data, values given as object
  @param {Type_StaticModelTblInsert_Args} args -  parameter bag
    ````js
    { values, rmi?, fire? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblInsert
  
  @example
  ````js
    // Usage
    var ret = mySM.tblInsert({ values });
  ````

@return {string} row id of newly inserted row
  */
  tblInsert(args) { return ""; }
/**
  @typedef {Object} Type_StaticModelTblUpdate_Args
  @property {Object} values -  object holding cell values which should be used for updating, e.g. { country: 'DE', flag: true }
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  @property {string} [rowId] -  id specifying row which should be updated (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#tblUpdate)
  @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
  @param {Type_StaticModelTblUpdate_Args} args -  parameter bag
    ````js
    { values, filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblUpdate
  
  @example
  ````js
    // Usage
    var ret = mySM.tblUpdate({ values });
  ````

@return {number} count of updated rows
  */
  tblUpdate(args) { return 0; }
/**
  @typedef {Object} Type_StaticModelTblDelete_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {boolean} [rmi=true] - default=true  use wrs:M syntax when this is true, otherwise row columns element name is not touched
  @property {boolean} [fire=true] - default=true  lets the listeners know, that the update was finished
  @property {string} [rowId] -  id specifying row which should be deleted (or use filter)
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#tblDelete)
  @description   updates wrs rows with given data. Either a single row (via rowId) or single/multiple ones (via filter)
  @param {Type_StaticModelTblDelete_Args} args -  parameter bag
    ````js
    { filter?, rmi?, fire?, rowId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblDelete
  
  @example
  ````js
    // Usage
    var ret = mySM.tblDelete();
  ````

@return {number} count of removed rows
  */
  tblDelete(args) { return 0; }
/**
  @typedef {Object} Type_StaticModelTblSelect_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {Array.<string>} [columns] -  string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#tblSelect)
  @description   returns an array of requested data
  @param {Type_StaticModelTblSelect_Args} args -  parameter bag
    ````js
    { filter?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelect
  
  @example
  ````js
    // Usage
    var ret = mySM.tblSelect();
  ````

@return {Array.<Object>} Array of objects holding the requested data
  */
  tblSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
  @typedef {Object} Type_StaticModelTblSelectRow_Args
  @property {Object} [filter] -  object holding cell values which should be used for selecting the rows for update, e.g. { country: 'DE', flag: true }
  @property {string} [rowId] -  rowId of row which should be queried (or use filter)
  @property {Array.<string>} [columns] -  string array of requested columns, if not given, all columns are returned
  */
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#tblSelectRow)
  @description   returns one object representing the filtered data (either filter or rowId). In case of multiple filter matches, the first one is returned
  @param {Type_StaticModelTblSelectRow_Args} args -  parameter bag
    ````js
    { filter?, rowId?, columns? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @inherits bcdui.core.DataProvider#tblSelectRow
  
  @example
  ````js
    // Usage
    var ret = mySM.tblSelectRow();
  ````

@return {Object} Array  of objects holding the requested data
  */
  tblSelectRow(args) { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#write)
  @description   Set a value to on a certain xPath and create the xPath where necessary. This combines Element.evaluate() for a single node with creating the path where necessary. It will prefer extending an existing start-part over creating a second one. After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
  @param {string} xPath -  xPath pointing to the node which is set to the value or plain xPath to be created if not there. It tries to reuse all matching parts that are already there. If you provide for example "/n:Root/n:MyElem/&commat;attr2" and there is already "/n:Root/n:MyElem/&commat;attr1", then "/n:Root/n:MyElem" will be "re-used" and get an additional attribute attr2. Many expressions are allowed, for example "/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem" is also ok. By nature, some xPath expressions are not allowed, for example using '//' or "/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem" is obviously not unambiguous enough and will throw an error. This method is Wrs aware, use for example '/wrs:Wrs/wrs:Data/wrs:*[2]/wrs:C[3]' as xPath and it will turn wrs:R[wrs:C] into wrs:M[wrs:C and wrs:O], see Wrs format. (can include dot template placeholders which get filled with the given fillParams)
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions Example: bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])
  @param {string} [value] -  Optional value which should be written, for example to "/n:Root/n:MyElem/&commat;attr" or with "/n:Root/n:MyElem" as the element's text content. If not provided, the xPath contains all values like in "/n:Root/n:MyElem[&commat;attr='a' and &commat;attr1='b']" or needs none like "/n:Root/n:MyElem"
  @param {boolean} [fire] -  If true a fire is triggered to inform data modification listeners
  @inherits bcdui.core.DataProvider#write
  
  @example
  ````js
    // Usage
    var ret = mySM.write( xPath );
  ````

@return {DomNode} The xPath's node or null if dataProvider isn't ready
  */
  write(xPath,fillParams,value,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#remove)
  @description   Deletes data at a given xPath from the model
  @param {string} xPath -  xPath pointing to the value
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {boolean} [fire] -  if true a fire is triggered to notify data modification listener
  @inherits bcdui.core.DataProvider#remove
  
  @example
  ````js
    // Usage
mySM.remove( xPath );
  ````

@return {void}
  */
  remove(xPath,fillParams,fire) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#query)
  @description   Reads a single node from a given xPath
  @param {string} xPath -  xPath to query
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @inherits bcdui.core.DataProvider#query
  
  @example
  ````js
    // Usage
    var ret = mySM.query( xPath );
  ````

@return {(DomNode|null)} single node or null if query fails
  */
  query(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#queryNodes)
  @description   Get node list from a given xPath
  @param {string} xPath -  xPath to query
  @param {Object} [fillParams] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @inherits bcdui.core.DataProvider#queryNodes
  
  @example
  ````js
    // Usage
    var ret = mySM.queryNodes( xPath );
  ````

@return {Array.<DomNode>} node list or empty list if query fails
  */
  queryNodes(xPath,fillParams) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#serialize)
  @description   Serialize dataprovider's data if available
  @inherits bcdui.core.DataProvider#serialize
  @return {string} String containing the serialized data
  */
  serialize() { return ""; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#removeDataListener)
  @param {(string|function|RemoveDataListenerParam)} listenerObject -  Either a listener function or id or a parameter map {@link RemoveDataListenerParam}. Listeners are added with onChange()
  @inherits bcdui.core.DataProvider#removeDataListener
  @return {void}
  */
  removeDataListener(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#onChange)
  @param {(function|OnChangeParam)} listenerObject -  Either a function to be called after changes or a parameter map {@link OnChangeParam}. Listeners can be removed with removeDataListener()
  @param {string} [trackingXPath] -  xPath to monitor to monitor for changes
  @inherits bcdui.core.DataProvider#onChange
  
  @example
  ````js
    // Usage
mySM.onChange( listenerObject );
  ````

@return {void}
  */
  onChange(listenerObject,trackingXPath) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#setStatus)
  @param {bcdui.core.Status} args -
  @inherits bcdui.core.DataProvider#setStatus
  @return {void}
  */
  setStatus(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#isClean)
  @description   True, if DataProvider is ready and there are no uncommitted write transactions, see {@link bcdui.core.AbstractExecutable#isReady isReady()} and {@link bcdui.core.DataProvider#onChange fire()}.
  @inherits bcdui.core.DataProvider#isClean
  @return {boolean}
  */
  isClean() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#fetchData)
  @description   asynchronously fetch data for this data provider.
  @inherits bcdui.core.DataProvider#fetchData
  @return {Promise.<bcdui.core.DataProvider>} resolving once data has been loaded, first argument is this instance
  */
  fetchData() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#addStatusListener)
  @description   Listen for any status to be reached. For use cases with the ready status (by far the most common), see onReady() and onceReady() convenience functions.
  @param {(function|bcdui.core.StatusListener|AddStatusListenerParam)} args -  Either a function executed on all status transitions or a parameter map {@link AddStatusListenerParam}
  @inherits bcdui.core.AbstractExecutable#addStatusListener
  @return {void}
  */
  addStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#removeStatusListener)
  @param {(function|bcdui.core.StatusListener|RemoveStatusListenerParam)} args -  The listener to be removed. This can either be a function or a {@link bcdui.core.StatusListener StatusListener} or a parameter map {@link RemoveStatusListenerParam}.
  @inherits bcdui.core.AbstractExecutable#removeStatusListener
  @return {void}
  */
  removeStatusListener(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#getStatus)
  @description   Getter for the status of this object. See {@link bcdui.core.status} for possible return values.
  @inherits bcdui.core.AbstractExecutable#getStatus
  @return {bcdui.core.Status} The current status.
  */
  getStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#isReady)
  @description   Tests if the current state is the readyStatus. This status is the same status as returned by "getReadyStatus".
  @inherits bcdui.core.AbstractExecutable#isReady
  @return {boolean} True, if the object is ready.
  */
  isReady() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#hasFailed)
  @description   Tests if the object has reached a failure status. These status codes are returned by the "getFailedStatus" method.
  @inherits bcdui.core.AbstractExecutable#hasFailed
  @return {boolean} True, if the object's process has failed.
  */
  hasFailed() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#getFailedStatus)
  @description   Getter for the list of error statuses of this class. This implementation returns an empty list.
  @inherits bcdui.core.AbstractExecutable#getFailedStatus
  @return {Array.<bcdui.core.Status>} The status objects corresponding to failures in the object'sprocess.
  */
  getFailedStatus() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#execute)
  @description   <b>Instead of calling this method directly, better rely on a Renderer or on method onReady().</b><br/> Executes the process implemented by the concrete sub-class This method is called by the Renderer when it is ready to render the model It is often asynchronous. Note, Renderer and sub-classes execute all input models recursively automatically. This means, usually you do not need to call this method directly. Note: it is asynchronous. Use method .onReady({executeIfNotReady: true, onSuccess: callback }) if no Renderer is involved.
  @param {boolean} [doesRefresh=true] -  Set this parameter to "false" if this method should do nothing when the object is already in the ready status. The default is "true" meaning that the process is re-started when it is currently ready.
  @inherits bcdui.core.AbstractExecutable#execute
  @return {void}
  */
  execute(doesRefresh) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#onceReady)
  @param {(function|OnceReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnceReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onceReady
  @return {void}
  */
  onceReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.StaticModel.html#onReady)
  @param {(function|OnReadyParam)} listenerObject -  Either a function to be called on ready status (i.e. onSuccess) or a parameter map {@link OnReadyParam}. To listen for other states see addStatusListener()
  @inherits bcdui.core.AbstractExecutable#onReady
  @return {void}
  */
  onReady(listenerObject) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
       * @type {bcdui.core.status.InitializedStatus}
       * @constant
       */
  initializedStatus= null;
  
/**
       * @type {bcdui.core.status.TransformedStatus}
       * @constant
       */
  transformedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       * @example
       * if( model.getStatus() === model.savedStatus )
       *   ...
       */
  savedStatus= null;
  
/**
       * @constant
       * @type {bcdui.core.Status}
       */
  saveFailedStatus= null;
  
/**
   * A globally unique id of the object. DataProviders do also register themselves at {@link bcdui.factory.objectRegistry} when an id is provided to the constructor. This id is only needed in declarative contexts, like jsp or, when a DataProvider is accessed in a xPath like <bcd-input targetModelId="$myModelId/ns:Root/ns:MyValue"/>.If not provided in the constructor, a random id starting with 'bcd' is set, but the object is not automatically registered.
   * @type {string}
   */
  id= null;
  
}


