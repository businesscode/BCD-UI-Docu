/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_AutoRefreshConstructor_Args
  @property {bcdui.core.DataProvider} model -  Model to monitor for updates by calling execute(true) and checking with modifiedIf
  @property {number} [periodSec=300] - default=300  Period in sec how often to query the server
  @property {(boolean|function)} [activeIf=true] - default=true  Boolean or function to determine whether we should check for model updates, queries all periodSec. Also see strategies below
  @property {(boolean|function)} [modifiedIf=strategy.modifiedIf.wrsTs] - default=strategy.modifiedIf.wrsTs  Function called (with the current AutoRefresh as param) to check whether model was updated. Also see strategies below
  @property {function} [onModified=strategy.onModified.applyAction] - default=strategy.onModified.applyAction  Function called (with the current AutoRefresh as param) when new model data is available. Also see strategies below
  */
  
/**
  @class bcdui.core.lifecycle.AutoRefresh
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.lifecycle.AutoRefresh.html)
  @description Support for auto-refreshing a {bcdui.core.DataProvider} in the background and detecting, if new data is available.<br/> After trying to reload every periodSec, args.modifiedIf to see, if new data was sent.<br/> * If the server sent an 'expires' header in the future, our re-load attempts will not even go to the server but be fullfilled from the cache.<br/> * If the server sent a 304, we keep using the latest data sent from server.<br/> Both is supported for example by DataRefreshedFilter for example. Once new data was received from the server, args.onModified will be executed.
  
  @example
  ````js
    // Usage
    var myAR = new bcdui.core.lifecycle.AutoRefresh({ model });
  ````


  @example
  let arModel = myCube.getPrimaryModel().getPrimaryModel();new bcdui.core.lifecycle.AutoRefresh({ model: arModel });
  */
// @ts-ignore
export class AutoRefresh {
  /**
  @param {Type_AutoRefreshConstructor_Args} args -  The parameter map contains the following properties:
    ````js
    { model, periodSec?, activeIf?, modifiedIf?, onModified? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.lifecycle.AutoRefresh.html)
  @description Support for auto-refreshing a {bcdui.core.DataProvider} in the background and detecting, if new data is available.<br/> After trying to reload every periodSec, args.modifiedIf to see, if new data was sent.<br/> * If the server sent an 'expires' header in the future, our re-load attempts will not even go to the server but be fullfilled from the cache.<br/> * If the server sent a 304, we keep using the latest data sent from server.<br/> Both is supported for example by DataRefreshedFilter for example. Once new data was received from the server, args.onModified will be executed.
  
  @example
  let arModel = myCube.getPrimaryModel().getPrimaryModel();new bcdui.core.lifecycle.AutoRefresh({ model: arModel });
    */
  constructor(args) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.lifecycle.AutoRefresh.html#isActive)
  @description   Check whether we are still active according to args.activeIf
  @public
  @return {void}
  */
  isActive() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


