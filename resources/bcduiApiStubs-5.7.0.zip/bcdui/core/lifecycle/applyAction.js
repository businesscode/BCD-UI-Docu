/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_LifecycleApplyAction_Args
  @property {boolean} [cleanXPath] -  Additional XPath to be cleaned from the guiStatus
  @property {boolean} [validateFilters] -  True or false whether or not to check IsValid flags of guiStatus filters
  @property {DomDocument} [statusDocument=bcdui.wkModels.guiStatus] - default=bcdui.wkModels.guiStatus  optionally, other statusDocument than guiStatus
  @property {boolean} [removeAllParams] -  True or false whether or not to remove all url parameters first
  */
  /**
@param {Type_LifecycleApplyAction_Args} args -
    ````js
    { cleanXPath?, validateFilters?, statusDocument?, removeAllParams? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.lifecycle.html#.applyAction)
  @description   Takes the current guiStatus and re-invokes the current page with it <code>/guiStatus:Status/guiStatus:ClientSettings</code> is removed as it only serves for temporary information
  @method applyAction

  @example
  ````js
    // Usage
    bcdui.core.lifecycle.applyAction();
  ````

@return {void}
  @memberOf bcdui.core.lifecycle
 */
export function applyAction(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
