/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_LifecycleBookmarkAction_Args
  @property {Object} [proposedName=document.title] - default=document.title  Name of the bookmark
  @property {Object} [cleanClientSettings=true] - default=true  True or false whether or not to clean /guiStatus:Status/guiStatus:ClientSettings from the $guiStatus
  @property {Object} [cleanXPath] -  Additional XPath to be cleaned from the guiStatus, useful for removing current period filter for example
  */
  /**
@param {Type_LifecycleBookmarkAction_Args} args -
    ````js
    { proposedName?, cleanClientSettings?, cleanXPath? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.lifecycle.html#.bookmarkAction)
  @description   Creates a bookmark entry for the current page + guiStatus
  @method bookmarkAction

  @example
  ````js
    // Usage
    bcdui.core.lifecycle.bookmarkAction();
  ````

@return {void}
  @memberOf bcdui.core.lifecycle
 */
export function bookmarkAction(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
