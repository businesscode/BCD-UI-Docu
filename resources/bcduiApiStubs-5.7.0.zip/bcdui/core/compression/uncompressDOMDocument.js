/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} compressedXmlString -  The encoded and compressed XML document to be reconstructed.
  @param {string} id -  id the model will get, a random one i set otherwise
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.compression.html#.uncompressDOMDocument)
  @description   This function decodes an encoded and compressed XML document passed as the {@link bcdui.core.compression.compressDOMDocument compressedXmlString()} argument. It can either make the computations on the client or on the server dependent on the encoding type.
  @method uncompressDOMDocument

  @example
  ````js
    // Usage
    var ret = bcdui.core.compression.uncompressDOMDocument( compressedXmlString, id );
  ````

@return {bcdui.core.DataProvider}  A DataProvider instance holding theuncompressed data when it is in the Ready state.
@memberOf bcdui.core.compression
 */
export function uncompressDOMDocument(compressedXmlString, id) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
