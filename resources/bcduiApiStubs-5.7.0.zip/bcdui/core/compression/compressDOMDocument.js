/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomDocument} doc -  The DOM document to be compressed.
  @param {function} fn -  The callback function executed when the compression succeeds. This function gets a string argument with the compressed document.
  @param {function} [errorFn] -
  @param {boolean} [isSync] -  If set to true the compression is forced to call the callback *fn* synchronously, i.e. keeping the event call stack, etc
  @param {boolean} [compressAll] -  I f set to true 'tiny' compression is taken into account even for non guiStatus docs
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.core.compression.html#.compressDOMDocument)
  @description   Compresses a DOMDocument and encodes it in a string. This string can then be added to the URL to pass the DOMDocument to another page. Whenever possible this function tries to do the compression and encoding on the client. However if the client-side encoding is too big it makes a server request to get a more compact encoding. URL length limits for GET in chars: <ul> <li>IE       - 2048 <li>FF       - 65536 <li>Webkit   - 80000 <li>Opera    - 190000 <li>Tomcat/Apache  - 8190 overall, including url, header etc </ul> therefore max guiStatusGZ length: max URL length minus path length
  @method compressDOMDocument

  @example
  ````js
    // Usage
    bcdui.core.compression.compressDOMDocument( doc, fn );
  ````

@return {void}
  @memberOf bcdui.core.compression
 */
export function compressDOMDocument(doc, fn, errorFn, isSync, compressAll) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
