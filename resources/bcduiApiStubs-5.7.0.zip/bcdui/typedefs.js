/**
 * @typedef {Number} integer
 * @description
 * Integer
 */

/**
 * @typedef {Object} DomDocument
 * @description
 * DomDocument
 */

/**
 * @typedef {Object} DomElement
 * @description
 * DomElement
 */

/**
 * @typedef {Object} DomAttribute
 * @description
 * DomAttribute
 */

/**
 * @typedef {Object} DomNodeSet
 * @description
 * A DomNodeSet
 */

/**
 * @typedef {Object} DomNode
 * @description
 * A DomNode, can be text, an attribute or an element etc
 */

/**
 * @typedef {Object} HtmlElement
 * @description
 * HtmlElement
 */

/**
 * @typedef {Object} SymLink
 * @description
 * Symlink
 */

/**
 * @typedef {string|Function|Array.<(string|Function)>|import("./exports").core.DataProvider} chainDef
 * @description
 * Defines the transformation steps of a transformation chain, like {@link bcdui.core.ModelWrapper} or {@link bcdui.core.Renderer}.
 * <br/>Can be: url | function | Array<(url|function)> | bcdui.core.DataProvider
 * <br/>You can provide
 * <ul>
 *   <li>A single DataProvider, holding a chain definition following XML Schema 'chain-1.0.0.xsd'. Or
 *   <li>A single string holding the url of an xslt document (*.xslt) or a js template literate file (*.jstlit). Or
 *   <li>A javascript transformator function, representing a transformation. Such a function gets two parameters, data, like a DOM or JSON, whatever DataProvider.getData() returns
 *       and a parameter object, which maps parameter names to the actual parameters. It can return a new data object or modify the one, which was its input.
 *       It it does not return anything, its (modified) input doc is used as return default. Or
 *   <li>An array of such strings and functions in the order they are to be executed. In this case, the output of the n-th transformation becomes the input of n+1.
 * </ul>
 * @example <caption>These are all valid values for a chainDef:</caption>
 * "myStylesheet.xslt"                         // An <b>url</b> pointing to an *.xslt or a *.jstlit file
 * ["myTrans.jstlit", jsTrans]                 // An <b>array</b> of transformators, can be urls (js template literate or xslt) and js functions
 * new bcdui.core.StaticModel(...)             // A <b>DataProvider subclass</b>, providing an xml chain definition according to chain-1.0.0.xsd
 * function jsTrans(doc, params) {             // A <b>js function</b>, expecting a data object (DOM or JSON)
 *   var n = doc.getElementById('someId');
 *   n.setAttribute('someAttr', params.newValue);
 * }
 */

/**
 * @typedef {string} url
 * An absolute or relative url
 */

/**
 * @typedef {string} i18nToken
 * @description
 * A string value which is either taken as-is or an i18n key-marker as proposed by
 * <br/>We use xE0FF prefix to separate an i18n token from a plain string. This marker is available via bcdui.i18n.TAG
 * For i18n keys, see messages.xml or binding set bcd_i18n
 * @example
 * caption = "data"       // Treats value 'data' literal
 * caption = "\uE0FFdata" // Treats value 'data' as an i18n-key
 */

/**
 * @typedef {Object} jQuery
 * @description
 * A jQuery wrapped DOM element
 */

/**
 * @typedef {string|HtmlElement|jQuery} targetHtmlRef
 * @description
 * Any reference to an existing HTML element: Can be a DOM element, a jQuery object, a css selector or a plain id of an element.
 * The referenced element *must*  be attached to html document unless the reference itself is a DOM element.
 * <br/>If jQuery returns a list with multiple matches, the first member is used. These are all valid examples:
 * @example
 * document.getElementById("myId").firstChild      // Any plain <b>DOM element</b>
 * jQuery('#myElementId') &bull; jQuery('ul li:first')  // A <b>jQuery</b> list, first one is used
 * 'ul li:first'                                   // A <b>css selector</b>, first match is used
 * 'myElementId'                                   // Treated as an <b>element id</b> if its just letters (id without #)
 */

/**
 * @typedef {string} modelXPath
 * @description
 * Provide an XPath, which can be used to use nodes from, can point to an attribute or a full subtree.
 * Start the XPath with $someModelId, make sure that you create this {@link bcdui.core.DataProvider} with an explicit id.
 * Default for this is $guiStatus, which is always auto-registered.
 * <br/>Note: You can also build quite complex XPaths and refer to further registered models via '$myModelId' in predicates, see second example.
 * @example
 * $guiStatus/guiStatus:Status/guiStatus:MyNode                                     // A string with a simple XPath
 * $modelId/f:Filter/f:Filters[$guiStatus/guiStatus:Status/guiStatus:MyNodes/@attr] // A string with a more complex XPath, using multiple models
 */

/**
 * @typedef {string} xPath
 * @description
 * Provide an XPath, which can be used to use nodes from, can point to an attribute or a full subtree.
 * <br/>Note: must not contain model references.
 * @example
 * /guiStatus:Status/guiStatus:MyNode                                     // A string with a simple XPath
 */

/**
 * @typedef {string} writableModelXPath
 * @description
 * Provide an XPath, which can be used to append nodes to. In most cases the path will be created if it does not exist,
 * reusing as much as possible. See {@link bcdui.core.createElementWithPrototype}
 * Start the XPath with $dataProviderId, make sure that you create this {@link bcdui.core.DataProvider} with an explicit id.
 * Default for this is $guiStatus, which is always auto-registered.
 * Be aware that the model's data changes, if it is a ModelWrapper, the next execute() would of course overwrite the change.
 * <br/>You can also build complex XPaths and refer to further models via '$dataProviderId' in predicates.
 * @example
 * /guiStatus:Status/guiStatus:MyNode                                               // Default is $guiStatus
 * $modelId/f:Filter/f:Filters[$guiStatus/guiStatus:Status/guiStatus:MyNodes/@attr] // A string with a more complex XPath, using multiple models
 */

/**
   * @typedef {object} BcdScrollToParamOptions
   * @property {string}                [snapTo="beginning"] snapTo can have following values: 'beginning': put the scrollTo-target on the top of container.
   */

/**
   * @typedef {object} AddStatusListenerParam
   * @property {(function|import("./exports").core.StatusListener)} listener - A function or StatusListener object representing the listener action.
   * @property {import("./exports").core.Status} status - The status it should listen to.
   *   If it is missing the listener is executed on all status transitions, otherwise it is executed when the status is set to the specified status.
   * @property{boolean} [onlyOnce=false] - A boolean variable indicating that the listener should be automatically removed after it has been executed. 
   */

/**
   * @typedef {object} RemoveStatusListenerParam
   * @property {(function|import("./exports").core.StatusListener)} listener - A function <p/>or StatusListener object representing the listener action.
   * @property {import("./exports").core.Status}                  status   - The status this listener is listening to. If it is missing it is assumed that the listener belongs to the global scope.
   */

/**
     * @typedef {object} OnceReadyParam
     * @property {function} onSuccess - callback function which is called when {@link bcdui.core.AbstractExecutable} is or gets ready
     * @property {function} [onFailure] - callback function which is called when {@link bcdui.core.AbstractExecutable} gets into failed status
     * @property {boolean}  [executeIfNotReady=false] - do execute {@link bcdui.core.AbstractExecutable} if it's not ready
     */

/**
   * @typedef {object} OnReadyParam
   * @property {function} onSuccess - callback function which is called when {@link bcdui.core.AbstractExecutable} is or gets ready
   * @property {function} [onFailure] - callback function which is called when {@link bcdui.core.AbstractExecutable} gets into failed status
   * @property {boolean}  [onlyOnce=false] - call callback only once or on each ready state
   * @property {boolean}  [onlyFuture=false] - only future ready states will trigger the callback. Per default the callback is called immediately (but async), if the AbstractExecutable is already in ready state
   * @property {boolean}  [executeIfNotReady=false] - do execute {@link bcdui.core.AbstractExecutable} if it's not ready
   */

/**
   * @typedef {object} RemoveDataListenerParam
   * @property {string} [id] - listener id
   * @property {string} [callback] - listener function
   */

/**
   * Adds a data listener to the DataProvider which can be triggered when the data (XML
   * document) is changed. The listener offers two options: It can either be fired on
   * any change or on a change in a specific XPath result.
   * Note that no uniqueness check is done before adding the listener so it is possible to add the same listener twice or more times.
   * /
   /**
   * @typedef {object} OnChangeParam
   * @property {function} callback - function to be called after changes
   * @property {string}   [trackingXPath] - xPath to monitor for changes
   * @property {boolean}  [onlyOnce=false] - fire on each change or only once  (higher priority than listenerObject's onlyOnce)
   * @property {string}   [id] - listener id (only needed for removeDataListener usability)
   */

/**
   * @typedef {object} SimpleModelParamSaveOptions
   * @property {chainDef}                                      [saveChain]              - The definition of the transformation chain
   * @property {Object}                                        [saveParameters]         - An object, where each property holds a DataProvider, used as a transformation parameters.
   * @property {boolean}                                       [reload=false]           - Useful especially for models of type SimpleModel for refreshing from server after save
   * @property {function}                                      [onSuccess]              - Callback after saving (and optionally reloading) was successfully finished
   * @property {function}                                      [onFailure]              - Callback on failure, is called if error occurs
   * @property {function}                                      [onWrsValidationFailure] - Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
   * @property {import("./exports").core.DataProvider}                       [urlProvider]            - dataProvider holding the request url (by default taken from the args.url).
   */

/**
   * @typedef {object} SimpleModelParam
   * @property {(string|import("./exports").core.RequestDocumentDataProvider)} url                 - A string with the URL or a RequestDocumentDataProvider providing the request. See {@link bcdui.core.RequestDocumentDataProvider RequestDocumentDataProvider} for an example.
   * @property {string}                                        [uri]                 - uri extension as a suffix to .url to tag requests, must not start with '/'. This parameter is ineffective if .url is provided.
   * @property {string}                                        [id]                  - Globally unique id for used in declarative contexts
   * @property {boolean}                                       [isAutoRefresh=false] - If true, each change of args.urlProvider triggers a reload of the model
   * @property {string}                                        [mimeType=auto]       - Mimetype of the expected data. If "auto" or none is given it is derived from the url
   * @property {SimpleModelParamSaveOptions}                   [saveOptions]         - An argument map for save options {@link SimpleModelParamSaveOptions}
   */

/**
   * @typedef {Object} StaticModelParam
   * @property {string}                 [id] - Globally unique id for use in declarative contexts, ignored if args.data is not set
   * @property {(string|Object|DomDocument)} data - An XML string, which is parsed, a DOM document </p>or a parameter map
   */

/**
   * @typedef {object} Type_RendererExecute_Args
   * @property {function} [fn] A function called once when the object becomes ready again. Called immediately if we are already ready && shouldRefresh==false
   * @property {string} [partialHtmlTargets] Space separated list of html element ids. If given, only these elements within targetHmtlElement of the render
   *         are touched in the DOM tree, plus the chain gets the parameter bcdPartialHtmlTargets set to this value. Valid for this one call only, cleared after.
   * @property {boolean} [shouldRefresh] "false" if this method should do nothing when the object is already in the ready status. Default is "true"false".
   */

/**
   * Translates and formats if needed the given message id.
   * The function should be used only if bcduiI18Model ready. If
   * the catalog is not initialized up to this moment (the catalog
   * initialization is asychronous) then NULL is returned in production
   * and an error is thrown in debug mode.
   *
   /**
   * @typedef {object} SyncTranslateFormatMessageParam
   * @property {string} [msgid] - the message id
  */

/**
   * @typedef {object} PostWrsParam
   * @property {DomDocument|DomDocument[]|import("./exports").core.DataProvider|import("./exports").core.DataProvider[]}          args.wrsDoc - Document(s) / DataProvider
   * @property {function}                           [onSuccess]              - Callback on success, is called after successful POST or if POST was not issued due to to changes in the document 
   * @property {function}                           [onFailure]              - Callback on failure, is called if error occurs
   * @property {function}                           [onWrsValidationFailure] - Callback on serverside validate failure, if omitted the onFailure is used in case of validation failures
   * @property {string}                             [uri]                    - An URI (i.e. SomeDoc) which is appended as pathInfo to WrsServlet
   */

/**
   * @typedef {string} Type_Quickedit_CallbackHandler_TYPE
   * @description
   * Defined callback handler types:
   * "DISPOSE" - this type is called when disposing the widget, either on explicit close or via destruction.
   */

/**
     * This callback is displayed as part of the Requester class.
     * @callback Type_Quickedit_CallbackHandler
     * @param {import("./exports").widgetNg.QuickEdit} instance - the QuickEdit instance
     * @param {Type_Quickedit_CallbackHandler_TYPE} type - a string specifying the type of callback
     * @param {object} args - arguments specific to the type
     */

