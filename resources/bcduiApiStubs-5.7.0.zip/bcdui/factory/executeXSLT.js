/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_FactoryExecuteXSLT_Args
  @property {(bcdui.core.DataProvider|SymLink|string)} targetModel -  The ID of the Model (DataProvider) whose content is supposed to be transformed.
  @property {(bcdui.core.DataProvider|SymLink|string)} [chain] -  from modelWrapper - A DataProvider (or SymLink or its ID) which contains the list of style sheets that make up the transformation chain of this renderer. This DataProvider must contain an XML document satisfying the XML Schema 'chain-1.0.0.xsd'. The 'url' and 'chain' parameters are mutually exclusive.
  @property {string} [url] -  from modelWrapper - This parameter can be set when the renderer should only apply one single XSLT style sheet. It contains the URL pointing to it. If this parameter is set the 'chain' parameter must be omitted.
  @property {(bcdui.core.DataProvider|SymLink)} [inputModel] -  from modelWrapper - The DataProvider instance that becomes the input of the transformation chain. If omitted the first element of the dataProviders[] array is the input.
  @property {(bcdui.core.DataProvider|Array.<SymLink>)} [dataProviders] -  from modelWrapper - An array of DataProviders passed to the transformation chain. These data providers can be access in the transformation style sheets with xsl:param.
  @property {Object} [parameters] -  from modelWrapper - A mapping from parameter names to DataProviders (or SymLinks) which are passed to the transformation chain. This is a more convenient way to pass parameters compared to the dataProviders array.
  */
  /**
@param {Type_FactoryExecuteXSLT_Args} args -  The parameter map
    ````js
    { targetModel, chain?, url?, inputModel?, dataProviders?, parameters? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.html#.executeXSLT)
  @description   Executes a transformation chain producing an XML document. Then it replaces the XML document of the specified target DataProvider with the generated XML document. This is useful when the target DataProvider should be initialized with some client-side computed values. The behavior of the function is similar to the createModelWrapper function and therefore it inherits all parameters from it. The only additional parameter required is the "targetModel" parameter described below.
  @method executeXSLT

  @example
  ````js
    // Usage
    bcdui.factory.executeXSLT({ targetModel });
  ````


  @example
  bcdui.factory.executeXSLT({
        targetModel    : myModel,
        url            : "../../insertValues.xslt",
        parameters     : { rowCount: 5 },
      });
  @return {void}
  @memberOf bcdui.factory
 */
export function executeXSLT(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
