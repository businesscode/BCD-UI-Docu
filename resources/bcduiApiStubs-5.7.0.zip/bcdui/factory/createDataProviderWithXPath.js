/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {Object} args   The parameter map contains the same members as {@link bcdui.core.DataProviderWithXPath}
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.factory.createDataProviderWithXPath)
  @description   Creates a dataprovider from an xPath, its value is the evaluated xPath
  @method createDataProviderWithXPath
@return {void}
  @memberOf bcdui.factory
 */
export function createDataProviderWithXPath(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
