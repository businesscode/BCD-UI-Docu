/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.html)
 * @description   Most parts of this package are not intended to be used from JavaScript and thus not part of the API documentation. <p/> The factory package implements the functionality necessary to use BCD-UI objects in the context of jsp, XSLT-templates and XAPI and widget XPath expressions, in other words, wherever objects are connected by id rather than by providing JavaScript objects. <p/> The main difference between JavaScript and declarative contexts are that <ul> <li>All objects are identified and connected by a string id rather than by JavaScript references. For this reason, all objects created by the factory are registered automatically. <li>Second, it is allowed for objects to be created in an order following HTML output, as for example jsp tags are put into their output place. This leads to situations, where an object receives an object as input, which is only defined further down, something that cannot happen in JavaScript. Therefore the factories in here delay the object creation until all objects ot depends on are defined. </ul>
 * @namespace bcdui.factory
 */

/**
 * This is a singleton object of type ({@link bcdui.factory.ObjectRegistry}) where instances of {@link bcdui.core.DataProvider}can be registered by their globally unique id. It allows listeners to wait for these registrations so that they can safely accessthese objects no matter which time they are created at. Therefore it plays a vital role in the development of robust code and forthe creation of a higher abstraction layer like JSP markup.
 */
export const objectRegistry = new bcdui.factory.ObjectRegistry();
