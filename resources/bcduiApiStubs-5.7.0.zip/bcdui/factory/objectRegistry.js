/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.factory.ObjectRegistry
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html)
  @description The object registry is a class that tracks registration of BCD-UI objects by their id. It also offers methods to wait for the registration of one or more objects so that the dependencies can be managed more easily. <p/> Use the singleton {@link bcdui.factory.objectRegistry} for registering
  @description This class should not be instantiated directly, because there is already a singleton instance at {@link bcdui.factory.objectRegistry} which is used by the factory methods.
  */
// @ts-ignore
export class ObjectRegistry {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html)
  @description The object registry is a class that tracks registration of BCD-UI objects by their id. It also offers methods to wait for the registration of one or more objects so that the dependencies can be managed more easily. <p/> Use the singleton {@link bcdui.factory.objectRegistry} for registering
  @description This class should not be instantiated directly, because there is already a singleton instance at {@link bcdui.factory.objectRegistry} which is used by the factory methods.
    */
  constructor() {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#getObject)
  @description   Retrieves a DataProvider from the ObjectRegistry by the provided id. Use this if you need access from JavaScript to objects, which where created via XSLT, XAPI or JSP.
  @param {(string|SymLink)} id -  The object to be resolved from the registry.
  @public
  @return {bcdui.core.DataProvider} The object registered under the id or null if no such object exists.
  */
  getObject(id) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#generateTemporaryId)
  @description   Get a new page-unique id. Use this if you don't car about the id's value but need a unique one.
  @public
  @return {void}
  */
  generateTemporaryId() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#generateTemporaryIdInScope)
  @description   Get a new page-unique id for a certain scope, i.e. prefix. The prefix makes it easier to debug.
  @public
  @return {void}
  */
  generateTemporaryIdInScope() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#withObjects)
  @description   Waits until one or more ids are registered (but not necessarily ready) and then calls a JavaScript function. If they are already registered the JavaScript function will be called immediately. <p/> Use this if you need access from JavaScript to objects, which where created via XSLT, XAPI or JSP.  See {@link bcdui.factory.objectRegistry.withReadyObjects withReadyObjects()}
  @param {(Object|Array.<string>|string)} args1 -  This can either be a parameter object or an array of id strings or a single id. The format of the parameter object is as follows <ul> <li>ids: {string[]|string} The array of ids that must be registered before the callback function is called.</li> <li>fn: {Function} The function to be called when the ids are registered.</li> </ul>
  @param {function} args2 -  If the first parameter is not a parameter object, then this is the callback function that is called as soon as the requested ids are registered.
  @public
  
  @example
  ````js
    // Usage
myOR.withObjects( args1, args2 );
  ````

@return {void}
  */
  withObjects(args1,args2) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#deRegisterObject)
  @description   Removes a DataProvider from the object registry. <p/> Use this if you need access from XSLT, XAPI or JSP to objects created via JavaScript.
  @param {bcdui.core.DataProvider} obj -  The DataProvider to be removed from the registry.
  @public
  @return {void}
  */
  deRegisterObject(obj) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#registerObject)
  @description   Registers a new object in the object registry by its unique id property. Pending listeners can be informed on that event. Additionally it creates a JavaScript variable with the name of the object id and the object as value. <p/> Use this if you need access from XSLT, XAPI or JSP to objects created via JavaScript.
  @param {bcdui.core.DataProvider} obj -  The DataProvider to be registered.
  @public
  @return {void}
  */
  registerObject(obj) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#withReadyObjects)
  @description   Waits until the specified DataProvider ids are registered and reach their ready states. Then it calls the specified callback function. Please note that it also works when the data providers are already in their ready state; then the callback is called immediately. Note that it will also execute the DataProviders it waits fir, if they are not yet ready. The interface is identical to the {@link bcdui.factory.objectRegistry.withObjects withObjects()} function.
  @param {(Object|Array.<string>|string)} args1 -  The parameter object or the object ids.
  @param {function} args2 -  The callback function if argsOrIds is an array.
  @param {boolean} skipExecute -  do not execute the non-ready dataproviders
  @public
  
  @example
  ````js
    // Usage
myOR.withReadyObjects( args1, args2, skipExecute );
  ````

@return {void}
  */
  withReadyObjects(args1,args2,skipExecute) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#withReadyObjectsNoExecute)
  @description   Waits until the specified DataProvider ids are registered and reach their ready states. Then it calls the specified callback function. Please note that it also works when the data providers are already in their ready state; then the callback is called immediately. It does not execute the DataProviders it waits for, it waits until somebody else executes it. The interface is identical to the {@link bcdui.factory.objectRegistry.withObjects} function.
  @param {(Object|Array.<string>|string)} args1 -  The parameter object or the object ids.
  @param {function} args2 -  The callback function if argsOrIds is an array.
  @public
  
  @example
  ````js
    // Usage
myOR.withReadyObjectsNoExecute( args1, args2 );
  ````

@return {void}
  */
  withReadyObjectsNoExecute(args1,args2) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.factory.ObjectRegistry.html#toString)
  @public
  @return {string} A string describing the current state of the object registry.
  */
  toString() { return ""; }
}


