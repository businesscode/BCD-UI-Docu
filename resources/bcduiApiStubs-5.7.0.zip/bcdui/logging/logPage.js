/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_LoggingLogPage_Args
  @property {Array.<string>} idRef -  Id(s) of DataProvider(s) to wait for, or wait for all renderers registered at the moment of {@link bcdui.core.ready}
  @property {string} [logName] -  If provided, this is the name for which the log is written. If not given, idRef is used
  @property {string} [addInfo] -  Optionally any text that should be also logged
  @property {function} [jsCallback] -  A callback function can be supplied which is triggered once the log has captured data. The callback is called with a parameter object with a duration property, indicating the logged duration
  */
  /**
@param {Type_LoggingLogPage_Args} args -  The parameter map containing
    ````js
    { idRef, logName?, addInfo?, jsCallback? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.logging.html#.logPage)
  @description   Useful for performance testing. <p/> Sends a log message with the duration since start of page load to the server perf-log table, once a certain set of DataProviders or all current Renderers are ready Use this for example to trace the duration from page loading start to the end of load of a major or all Renderers to be shown to the user. <p/> Well-known bindingSet bcd_log_pageperformance must be available for using this.
  @method logPage

  @example
  ````js
    // Usage
    bcdui.logging.logPage({ idRef });
  ````

@return {void}
  @memberOf bcdui.logging
 */
export function logPage(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
