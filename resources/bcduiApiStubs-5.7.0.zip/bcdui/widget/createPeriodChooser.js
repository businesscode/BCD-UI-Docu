/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreatePeriodChooser_Args
  @property {writableModelXPath} targetModelXPath -  Unless you don't use the useSimpleXPath option, this targetModelXPath acts slightly different than for other widgets. You only define a root node like '/guiStatus:Status/f:Filter/f:And[&commat;id='period']' here. The period chooser places its f:Expression elements below this given rootnode automatically. The number of expressions and how they are added depends on periodChooser settings (e.g. a range or writing mo/yr instead of yyyy-mm-dd etc.)
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [caption] -  Default 'Date', it will be used as i18n key to translate the caption if isFreeRangeSelectable set to true, then caption may contain two terms for 'From' and 'To' captions. Divider: ';' Example: caption = 'i18.md.From;i18.md.To'
  @property {string} [firstSelectableDay] -  The first day that can be selected. A week or month can only be selected if all days are selectable.
  @property {boolean} [lastSelectableDay] -  The last day that can be selected. A week or month can only be selected if all days are selectable.
  @property {boolean} [isFreeRangeSelectable] -  Allows date free range selection.
  @property {boolean} [isSecondSelectable] -  Allows second selection.
  @property {boolean} [isMinuteSelectable] -  Allows minute selection.
  @property {boolean} [isHourSelectable] -  Allows hour selection.
  @property {boolean} [isDaySelectable=true] - default=true  Allows day selstion.
  @property {boolean} [isWeekSelectable] -  Allows week selection.
  @property {boolean} [isMonthSelectable=true] - default=true  Allows month selection.
  @property {boolean} [isQuarterSelectable=true] - default=true  Allows quarter selection
  @property {boolean} [isYearSelectable=true] - default=true  Allows year selection.
  @property {boolean} [mandatory] -  An empty value is invalid if this parameters sets to true. Default is false.
  @property {boolean} [outputPeriodType] -  Produces selected dates as one of known date periods. For example if this contains mo and the user selects a data range, which fits a month, mo with be written. This is usefull if you allow free range but you also have a month aggregation for performance optimization. On the other hand, if this is not set and the user selects a month in the widget, then the month is written in terms of dy.
  @property {boolean} [showPrevNextButtons] -  If this is set to 'true' the buttons Previous Period and Next Period are showed. The default value is 'false'.
  @property {boolean} [suppressCaptions] -  Set this to true if the buttons should not have any caption text. Default is false.
  @property {boolean} [textInput] -  Add the free range feature.
  @property {boolean} [validate=true] - default=true  Turn on-off the validation of the keyboard entered date values.
  @property {modelXPath} [optionsModelXPath] -  Allows to use a single period chooser widget for different logical types of dates (see args.postfix), which then can be selected from a drop-down. The node set found at this xPath lists the postfixes.
  @property {string} [optionsModelRelativeValueXPath] -  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {string} [postfix] -  An optional postfix which is added to the filter bRefs (dy/mo.., see above). Use this if you deal with different types of dates. If optionsModel is given, this value should be one of the available ones.
  @property {string} [widgetCaption] -  A caption which is used as prefix for navPath generation for this widget.
  @property {string} [useSimpleXPath] -  Set this to true if you want a minimal periodchooser setup (only day selectable via popcalendar) which only writes an ISO date to an XPath which you provide (not a complex one in normal mode).
  @property {string} [autoPopup] -  Set this to true if the popup calendar should appear after creation.
  @property {string} [suppressButtons] -  Set this to true if from and to buttons should be hidden. Default is false.
  @property {boolean} [enableNavPath] -  Set to true if widget should not be added to navpath handling.
  @property {boolean} [showClearButton] -  Set this to true if you need one clear button which removes the currently set date.
  @property {string} [label] -  If provided, renders label element to this periodchooser.
  */
  /**
@param {Type_WidgetCreatePeriodChooser_Args} args -  The parameter map contains the following properties.
    ````js
    { targetModelXPath, targetHtml, id?, caption?, firstSelectableDay?, lastSelectableDay?, isFreeRangeSelectable?, isSecondSelectable?, isMinuteSelectable?, isHourSelectable?, isDaySelectable?, isWeekSelectable?, isMonthSelectable?, isQuarterSelectable?, isYearSelectable?, mandatory?, outputPeriodType?, showPrevNextButtons?, suppressCaptions?, textInput?, validate?, optionsModelXPath?, optionsModelRelativeValueXPath?, postfix?, widgetCaption?, useSimpleXPath?, autoPopup?, suppressButtons?, enableNavPath?, showClearButton?, label? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createPeriodChooser)
  @description   Creates a period chooser. The period chooser supports a number of options and formats, see parameters. You can control what kind of periods a user may select and in which format it is written. Note that the bRef written are <b>always</b> <code>yr, qr, mo, cwyr, cw or dy</code> with an optional postfix of there are different types of dates.<br/> The period chooser outputs to args.targetModelXPath, which may point to any model but needs to end with <code>f:And[&commat;id='myPeriod']</code>, where &commat;id is the period chooser's id.
  @method createPeriodChooser

  @example
  ````js
    // Usage
    bcdui.widget.createPeriodChooser({ targetModelXPath: "$guiStatus/cust:Elem/@value", targetHtml: "#myDiv" });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createPeriodChooser(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
