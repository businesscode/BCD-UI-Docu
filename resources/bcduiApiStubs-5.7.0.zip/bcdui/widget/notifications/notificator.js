/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_NotificatorConstructor_Args
  @property {integer} [retainMessagesNumber=5] - default=5  number of messages to retain in viewable area
  @property {boolean} [attachMouseHandler] -  if true, the mousehover/unhover will close the box
  @property {integer} [autoHideMs] -  if greater 0, the box will autohide after that amount of ms, otherwise the box has to be closed manually
  */
  
/**
  @class bcdui.widget.notifications.Notificator
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html)
  @description Notificator component displaying user notifications
  
  @example
  ````js
    // Usage
    var myNtf = new bcdui.widget.notifications.Notificator();
  ````

*/
// @ts-ignore
export class Notificator {
  /**
  @param {Type_NotificatorConstructor_Args} args -  Parameter object
    ````js
    { retainMessagesNumber?, attachMouseHandler?, autoHideMs? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html)
  @description Notificator component displaying user notifications
    */
  constructor(args) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html#addMessage)
  @description   adds a message to notificator and displays notificator if appropriate
  @param {string} message -  The message you want to display
  @param {string} [type=INFO] -  The type of the message, use WARN or INFO
  @param {string} [anchorId] -  If given the message will contain a link to that anchor)
  @public
  
  @example
  ````js
    // Usage
myNtf.addMessage( message );
  ````

@return {void}
  */
  addMessage(message,type,anchorId) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html#removeAllMessages)
  @description   removes all messages and hides notification window
  @public
  @return {void}
  */
  removeAllMessages() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html#displayNotificationBar)
  @description   displays notification bar rendering messages in the queue
  @public
  @return {void}
  */
  displayNotificationBar() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html#hideNotificationBar)
  @description   hides notification bar
  @public
  @return {void}
  */
  hideNotificationBar() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.notifications.Notificator.html#showNotificationBar)
  @description   shows notification bar
  @public
  @return {void}
  */
  showNotificationBar() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


