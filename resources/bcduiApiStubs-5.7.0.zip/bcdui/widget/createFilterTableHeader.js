/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateFilterTableHeader_Args
  @property {(string|bcdui.core.Renderer)} renderer -  Id of the registered renderer to work on or the render itself
  @property {boolean} [isSync] -  Decide whether the action is to be called synchronous or not
  @property {boolean} [alwaysShowHeader=true] - default=true  If filtering leads to no rows to be displayed, this flag will show the table header to allow removal of filters
  @property {function} [getCaptionForColumnValue] -  Function (colIdx, colValue) which returns the rendered caption for the cell. By default standard wrs &commat;caption, wrs:references and unit/scale handling is supported already
  @property {function} [getFilteredValues] -  Function (colIdx) which needs to return a wrs:C array which holds the valid values for the current column. Use this to e.g. only show prefiltered values
  */
  /**
@param {Type_WidgetCreateFilterTableHeader_Args} args -  The parameter map contains the following properties.
    ````js
    { renderer, isSync?, alwaysShowHeader?, getCaptionForColumnValue?, getFilteredValues? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createFilterTableHeader)
  @description   Create filter table header
  @method createFilterTableHeader

  @example
  ````js
    // Usage
    bcdui.widget.createFilterTableHeader({ renderer });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createFilterTableHeader(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
