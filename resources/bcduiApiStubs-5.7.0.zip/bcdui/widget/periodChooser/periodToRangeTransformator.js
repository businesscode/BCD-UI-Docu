/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_PeriodChooserPeriodToRangeTransformator_Args
  @property {integer} rangeSize -  Size of the range.
  @property {string} targetModelXPath -  The xPath pointing to the period filter within the transformed document.
  */
  /**
@param {Type_PeriodChooserPeriodToRangeTransformator_Args} parameters -
    ````js
    { rangeSize, targetModelXPath }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.periodChooser.html#.periodToRangeTransformator)
  @description   A transformer, taking the input, leaving everything 1:1 except a period filter, which is transformed to a range with the given date or range end as the end and keeping the input period type
  @method periodToRangeTransformator

  @example
  ````js
    // Usage
    bcdui.widget.periodChooser.periodToRangeTransformator({ rangeSize, targetModelXPath: "$guiStatus/cust:Elem/@value" });
  ````

@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function periodToRangeTransformator(parameters) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
