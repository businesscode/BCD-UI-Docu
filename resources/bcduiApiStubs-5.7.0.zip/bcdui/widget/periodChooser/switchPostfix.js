/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} id -  id of the period chooser widget
  @param {string} period_type -  new period_type
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.periodChooser.html#.switchPostfix)
  @description   Switch periodchooser to a different period_type by replacing the bRef attributes and the bcdPostfix attribute
  @method switchPostfix

  @example
  ````js
    // Usage
    bcdui.widget.periodChooser.switchPostfix( id, period_type );
  ````

@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function switchPostfix(id, period_type) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
