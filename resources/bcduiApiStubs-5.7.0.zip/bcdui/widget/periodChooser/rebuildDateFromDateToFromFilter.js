/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomDocument} targetModelDoc -  containing the filter nodes which needs to get worked on
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.periodChooser.html#.rebuildDateFromDateToFromFilter)
  @description   adds/overwrites dateFrom/dateTo attributes on periodChoosers filter nodes (outer And) based on the currently available filters
  @method rebuildDateFromDateToFromFilter
@return {void}
  @memberOf bcdui.widget.periodChooser
 */
export function rebuildDateFromDateToFromFilter(targetModelDoc) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
