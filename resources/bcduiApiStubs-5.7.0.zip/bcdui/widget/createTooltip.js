/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateTooltip_Args
  @property {string} [targetRendererId] -  The renderer the tooltip is attached to. The HTML listeners are placed on the targetHtml of this renderer. If 'tableMode' is set to 'true' the renderer is expected to render an HTML table with the appropriate 'bcdRowIdent/bcdColIdent' attributes of tr rows header columns.
  @property {bcdui.core.DataProvider} [targetRenderer] -  The renderer the tooltip is attached to. The HTML listeners are placed on the targetHtml of this renderer. If 'tableMode' is set to 'true' the renderer is expected to render an HTML table with the appropriate 'bcdRowIdent/bcdColIdent' attributes of tr rows header columns.
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {integer} [delay] -  The delay in Miliseconds that the tooltip should wait before it appears.
  @property {string} [filter] -  An optional filter on the tag name where the tooltip should appear. In 'tableMode' it is recommended to set it on 'td' or 'th|td'.
  @property {string} [identsWithin] -  Id of an element. If given bcdColIdent and bcdRowIdent are set to the innermost values given between the event source and the element given here. bcdRow/ColIdent do not need to be set at the same element.
  @property {string} [stylesheetUrl] -  This parameter can be set when you only want to apply one single XSLT style sheet. It contains the URL pointing to it. If this parameter is set no nested 'chain' tag must be provided
  @property {boolean} [tableMode] -  This flag can be set to 'true' if the 'bcdRowIdent' and 'bcdColIdent' parameters should be extracted from the HTML and added as parameters on the tooltipRenderer. They are derived from 'bcdRowIdent' and 'bcdColIdent' attributes of tr rows and header columns (td or th).
  @property {targetHtmlRef} [targetHtml] -  The HTML listeners are placed on this Element instead of the targetHtml of the given targetRendererId.
  @property {string} [tooltipTargetHtmlId] -  Existing HTML Element Id which is used for the tooltip. By default this is 'bcdTooltipDiv'.
  */
  /**
@param {Type_WidgetCreateTooltip_Args} args -  The parameter map contains the following properties.
    ````js
    { targetRendererId?, targetRenderer?, id?, delay?, filter?, identsWithin?, stylesheetUrl?, tableMode?, targetHtml?, tooltipTargetHtmlId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createTooltip)
  @description   Generates a tooltip for another renderer.
  @method createTooltip

  @example
  ````js
    // Usage
    bcdui.widget.createTooltip();
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createTooltip(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
