/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} [values] -  A space separated string which lists the ordered targetIds of the widgets which should be queried (or empty for all)
  @param {string} [separator=" "] -  A string used for delimiter between single widget navpath values
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.getCurrentNavPath)
  @description   Get current navpath widget information for the given widget targets.
  @method getCurrentNavPath

  @example
  ````js
    // Usage
    var ret = bcdui.widget.getCurrentNavPath();
  ````

@return {string}  string containing the current navPath for your selected values
@memberOf bcdui.widget
 */
export function getCurrentNavPath(values, separator) { return ""; };
