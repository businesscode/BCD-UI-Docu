/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} id -  targetHtml of widget
  @param {function} callback -  to be called with generated caption
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.inputField.html#.getNavPath)
  @description 
  @method getNavPath

  @example
  ````js
    // Usage
    var ret = bcdui.widget.inputField.getNavPath( id, callback );
  ````

@return {string}  NavPath information via callback for widget
@memberOf bcdui.widget.inputField
 */
export function getNavPath(id, callback) { return ""; };
