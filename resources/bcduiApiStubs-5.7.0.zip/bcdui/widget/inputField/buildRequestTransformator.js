/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.inputField.html#.buildRequestTransformator)
  @description   Transformator for building a MultiLevelSuggestion request Connect the inputfield with a (auto)model using this as request builder (input doesn't matter, use guistatus) And refresh it via additionalFilterXPath, same as for plain suggest
  @method buildRequestTransformator
@return {void}
  @memberOf bcdui.widget.inputField
 */
export function buildRequestTransformator() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
