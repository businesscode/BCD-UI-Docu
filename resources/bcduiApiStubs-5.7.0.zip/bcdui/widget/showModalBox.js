/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetShowModalBox_Args
  @property {string} [title] -  Modal box title. You can also use titleTranslate.
  @property {string} [titleTranslate] -  It will be used as i18n key to translate the title.
  @property {string} [message] -  Modal box message. You can also use messageTranslate.
  @property {string} [messageTranslate] -  It will be used as i18n key to translate the message.
  @property {integer} [modalBoxType] -  One of three types modalBoxTypes.ok, modalBoxTypes.warning, modalBoxTypes.error. By default = modalBoxTypes.ok
  @property {integer} [width=300] - default=300  Width of modal box. 300 by default
  @property {integer} [height] -  Height of modal box. auto by default
  @property {string} [onclick] -  Optional js function which is called after closing the modal box
  @property {string} [position] -  jQuery position parameter bag. Default is center top
  @property {string} [htmlElementId] -  Id of a html segment which is taken as messagebox instead. ModalBoxType is ignored in this case.
  */
  /**
@param {Type_WidgetShowModalBox_Args} args -  The parameter map contains the following properties.
    ````js
    { title?, titleTranslate?, message?, messageTranslate?, modalBoxType?, width?, height?, onclick?, position?, htmlElementId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.showModalBox)
  @description   Open and show modalbox
  @method showModalBox

  @example
  ````js
    // Usage
    bcdui.widget.showModalBox();
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function showModalBox(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
