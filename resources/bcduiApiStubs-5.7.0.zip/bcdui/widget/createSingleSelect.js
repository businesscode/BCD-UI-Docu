/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateSingleSelect_Args
  @property {writableModelXPath} targetModelXPath -  The xPath pointing to the root-node this widget will place entered selected items into. The underlying XML  format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target.
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {modelXPath} optionsModelXPath -  xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [optionsModelRelativeValueXPath] -  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {boolean} [keepEmptyValueExpression] -  A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty.
  @property {string} [widgetCaption] -  A caption which is used as prefix for navPath generation for this widget.
  @property {boolean} [enableNavPath] -  Set to true if widget should not be added to navpath handling.
  @property {string} [label] -  If provided, renders label element to this widget
  @property {string} [skin="radio"] - default="radio"  Decide between radio or panel skin.
  */
  /**
@param {Type_WidgetCreateSingleSelect_Args} args -  The parameter map contains the following properties.
    ````js
    { targetModelXPath, targetHtml, optionsModelXPath, id?, optionsModelRelativeValueXPath?, keepEmptyValueExpression?, widgetCaption?, enableNavPath?, label?, skin? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createSingleSelect)
  @description   Creates a single selection radio button group where a value can be selected and stored to the target model.
  @method createSingleSelect

  @example
  ````js
    // Usage
    bcdui.widget.createSingleSelect({ targetModelXPath: "$guiStatus/cust:Elem/@value", targetHtml: "#myDiv", optionsModelXPath: "$myModel/wrs:Wrs/wrs:Data/wrs:R/wrs:C[1]" });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createSingleSelect(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
