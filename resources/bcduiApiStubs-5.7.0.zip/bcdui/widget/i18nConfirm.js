/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} msgKey -
  @param {string} defaultValue -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.i18nConfirm)
  @description   shows a js confirm box with the given message
  @method i18nConfirm

  @example
  ````js
    // Usage
    bcdui.widget.i18nConfirm( msgKey, defaultValue );
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function i18nConfirm(msgKey, defaultValue) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
