/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {(HtmlElement|string)} elOrId -  An existing HTML element or its id representing a widget targetHtml
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.getWidgetCaption)
  @description   Get widgetCaption information from the given target
  @method getWidgetCaption
@return {string}  string of found widgetCaption or empty string
@memberOf bcdui.widget
 */
export function getWidgetCaption(elOrId) { return ""; };
