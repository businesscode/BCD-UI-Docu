/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateTableHeadFilter_Args
  @property {HtmlElement} tableElement -  The HTML Table Element which you want to use for injection
  @property {writableModelXPath} targetModelXPath -  The xPath pointing to the root-node this widget will place entered selected items into
  @property {bcdui.core.DataProvider} inputModel -  WRS datamodel representing the table columns
  @property {bcdui.core.DataProvider} [statusModel=bcdui.wkModels.guiStatus] - default=bcdui.wkModels.guiStatus  StatusModel where the widget will write its content to.
  @property {boolean} [useCustomHeaderRenderer] -  Set to true when your code adds bcdFilterButton classes on its own (e.g. grid)
  @property {function} [callback] -  Function which will be executed after a change of the filters have been performed
  @property {function} [getCaptionForColumnValue] -  Function (colIdx, colValue) which returns the rendered caption for the cell. By default standard wrs &commat;caption, wrs:references and unit/scale handling is supported already. Deprecated (prefer valueCaptionProvider parameter).
  @property {function} [getFilteredValues] -  Function (colIdx) which needs to return a wrs:C array which holds the valid values for the current column. Use this to e.g. only show prefiltered values . Deprecated (prefer valueCaptionProvider parameter).
  @property {function} [valueCaptionProvider] -  Function (inputModel, colIdx) which needs to return a Promise which resolves with an array of objects {value, caption, isFiltered}
  @property {Object} [columnFiltersCustomFilter] -  CustomColumnFilter functions passed to column filter. columnFiltersCustomFilter is an array holding an object per bRef/column and an operations array which defines id, caption, valueCaptionProvider, filterFunction and gridFilterRowFunction
  */
  /**
@param {Type_WidgetCreateTableHeadFilter_Args} args -  The parameter map contains the following properties.
    ````js
    { tableElement, targetModelXPath, inputModel, statusModel?, useCustomHeaderRenderer?, callback?, getCaptionForColumnValue?, getFilteredValues?, valueCaptionProvider?, columnFiltersCustomFilter? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createTableHeadFilter)
  @description   injectFilter in table
  @method createTableHeadFilter

  @example
  ````js
    // Usage
    bcdui.widget.createTableHeadFilter({ tableElement, targetModelXPath: "$guiStatus/cust:Elem/@value", inputModel: myModel });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createTableHeadFilter(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
