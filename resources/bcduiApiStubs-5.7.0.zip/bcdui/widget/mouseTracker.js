/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_MouseTrackerConstructor_Args
  @property {(HtmlElement|string)} baseElement -  The id or HTML element that contains the sub-elements the mouse enter / leave events should be tracked on. It is recommended to use an HTML DIV element as base element.
  @property {function} [onEnter] -  The function to be executed when an observed element is entered by the mouse pointer. This function gets an event parameter (of the type {@link bcdui.widget.DetachedEvent}) as argument.
  @property {function} [onLeave] -  A function which is run when the mouse leaves an observed element. The function has no arguments.
  @property {string} [filter] -  The tag name (or multiple pipe-separated tag names) that should be observed for the onEnter / onLeave events. It is often TD or TR so that moving the mouse over table cells / rows inside the base element is observed. If omitted every child element is observed.
  @property {integer} [delay] -  The duration in milliseconds defining how long the events should be idle until the provided function is triggered. The default value is 200.
  */
  
/**
  @class bcdui.widget.MouseTracker
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.MouseTracker.html)
  @description <p>   A utility class tracking mouse enter and leave events within a specified   parent element. It keeps track of the mouse movement and fires the event   as soon as the mouse does not move for a certain amount of time (default   200 ms). This is useful because when the function does a complex   computation like executing a tooltip XSLT it is not recommended to   execute it with every mouse move. </p> <p>   Please note that "onLeave" does NOT work on HTML table elements in FireFox. So   in this case the baseElement must be the DIV containing the table. </p> <p>   Example: </p> <pre>  new bcdui.widget.MouseTracker({            baseElement: $$("table.treeView")[0].up()          , delay: 1000          , onEnter: function(e) {              bcdui.log.isTraceEnabled() && bcdui.log.trace("row No: " + e.element().rowIndex);            }          , onLeave: function() {              bcdui.log.isTraceEnabled() && bcdui.log.trace("onLeave")            }          , filter: "tr"        }).start();  </pre>
  @description Creates a new mouse tracker instance. This instance is inactive until the {@link #start()} method is called. Then it tracks the mouse movement on the specified base element until the {@link #stop()} method is executed.
  
  @example
  ````js
    // Usage
    var myMT = new bcdui.widget.MouseTracker({ baseElement });
  ````

*/
// @ts-ignore
export class MouseTracker {
  /**
  @param {Type_MouseTrackerConstructor_Args} args -  The argument map offers the following properties:
    ````js
    { baseElement, onEnter?, onLeave?, filter?, delay? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.MouseTracker.html)
  @description <p> A utility class tracking mouse enter and leave events within a specified parent element. It keeps track of the mouse movement and fires the event as soon as the mouse does not move for a certain amount of time (default 200 ms). This is useful because when the function does a complex computation like executing a tooltip XSLT it is not recommended to execute it with every mouse move. </p> <p> Please note that "onLeave" does NOT work on HTML table elements in FireFox. So in this case the baseElement must be the DIV containing the table. </p> <p> Example: </p> <pre> new bcdui.widget.MouseTracker({ baseElement: $$("table.treeView")[0].up() , delay: 1000 , onEnter: function(e) { bcdui.log.isTraceEnabled() && bcdui.log.trace("row No: " + e.element().rowIndex); } , onLeave: function() { bcdui.log.isTraceEnabled() && bcdui.log.trace("onLeave") } , filter: "tr" }).start(); </pre>
  @description Creates a new mouse tracker instance. This instance is inactive until the {@link #start()} method is called. Then it tracks the mouse movement on the specified base element until the {@link #stop()} method is executed.
    */
  constructor(args) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.MouseTracker.html#start)
  @description   Starts the observation of the base element. New instances of the MouseTracker object do not automatically start tracking so the start() method should be called on them.
  @public
  @return {void}
  */
  start() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.MouseTracker.html#stop)
  @description   Stops observing the base element for mouse enter / leave.
  @public
  @return {void}
  */
  stop() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


