/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateCredentialsMenu_Args
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [modelId] -  id of model holding custom model definition. If not provided, a standard one with just logout is created.
  @property {string} [userName] -  string to use as the username, by default it takes bcdui.config.userName
  */
  /**
@param {Type_WidgetCreateCredentialsMenu_Args} args -  The parameter map contains the following properties.
    ````js
    { targetHtml, modelId?, userName? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createCredentialsMenu)
  @description   Creates credential menu
  @method createCredentialsMenu

  @example
  ````js
    // Usage
    bcdui.widget.createCredentialsMenu({ targetHtml: "#myDiv" });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createCredentialsMenu(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
