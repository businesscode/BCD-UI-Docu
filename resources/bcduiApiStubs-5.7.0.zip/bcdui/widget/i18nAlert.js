/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {string} msgKey -
  @param {string} defaultValue -
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.i18nAlert)
  @description   shows a js alert box with the given message
  @method i18nAlert

  @example
  ````js
    // Usage
    bcdui.widget.i18nAlert( msgKey, defaultValue );
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function i18nAlert(msgKey, defaultValue) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
