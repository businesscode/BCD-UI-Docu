/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.effects)
 * @description   A namespace for the BCD-UI widget effects.
 * @namespace bcdui.widget.effects
 */

/**
 * default duration of effects
 */
export const defaultDuration = 0.2;
