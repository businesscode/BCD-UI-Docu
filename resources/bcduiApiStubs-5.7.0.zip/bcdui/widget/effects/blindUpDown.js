/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_EffectsBlindUpDown_Args
  @property {Object} idOrElement -  HTML element or ID that contains element(s) to blind Up/Down
  @property {string} [blindBodyClassName="bcdBlindUpDownBody"] - default="bcdBlindUpDownBody"  CSS className of HTML element to blind Up/Down
  @property {integer} [duration=2] - default=2  duration in seconds used for blind animation
  @property {boolean} [noEffect] -  True for a simple show/hide without blind effect (blind can influence charts gradients on IE
  */
  /**
@param {Type_EffectsBlindUpDown_Args} args -  The parameter map contains the following properties.
    ````js
    { idOrElement, blindBodyClassName?, duration?, noEffect? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.effects.html#.blindUpDown)
  @description   blinds the content Up/Down
  @method blindUpDown

  @example
  ````js
    // Usage
    bcdui.widget.effects.blindUpDown({ idOrElement });
  ````

@return {void}
  @memberOf bcdui.widget.effects
 */
export function blindUpDown(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
