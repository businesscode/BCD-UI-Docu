/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.widget.XMLDataUpdateListener
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.XMLDataUpdateListener.html)
  @description This listener is an abstract base class for XML listeners registered to a targetModel   and depending on the existence of a specific HTML element. When the HTML element disappears   the listener de-registers itself from the target model.
  */
// @ts-ignore
export class XMLDataUpdateListener {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.XMLDataUpdateListener.html)
  @description This listener is an abstract base class for XML listeners registered to a targetModel and depending on the existence of a specific HTML element. When the HTML element disappears the listener de-registers itself from the target model.
    */
  constructor() {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.XMLDataUpdateListener.html#hasBeenUnRegistered)
  @description   Tests, if the class has already unregistered itself from its target model. This happens when the listener is called, but the HTML element it is assigned to has disappeared.
  @public
  @return {boolean} True, if the class is unregistered.
  */
  hasBeenUnRegistered() { return false; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.XMLDataUpdateListener.html#unregister)
  @description   This method removes this listener from the targetModel. It is called by the {@link #callback} method when the listener is triggered and the HTML element has disappeared.
  @public
  @return {void}
  */
  unregister() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
/**
   * The ID of the HTML element to be watched.
   * @type {string}
   */
  htmlElementId= null;
  
/**
   * The generated id of the listener.
   * @type {string}
   */
  id= null;
  
/**
   * The hidden referenceId of targetModel to be watched.will be needed when idRef will be removed from object.
   * @type {bcdui.core.DataProvider}
   */
  _targetModelId= null;
  
/**
   * The referenceId of targetModel to be watched.
   * @type {bcdui.core.DataProvider}
   */
  idRef= null;
  
/**
   * The XPath within the targetModel that should be observed by the clientclass. It is not evaluated in this base class.
   * @type {string}
   */
  trackingXPath= null;
  
}


