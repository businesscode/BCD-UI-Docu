/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";
/**
@param {function} callback -  A callback function which gets the final navpath string and an object holding the single ids/captions
  @param {string} [values] -  A space separated string which lists the ordered targetIds of the widgets which should be queried (or empty for all)
  @param {string} [separator=" "] -  A string used for delimiter between single widget navpath values
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.getLiveNavPath)
  @description   Get current live navpath widget information via callback for the given widget targets. This function regets the current caption information from the widgets themselves and does not use the navPath model which represents the captions when entering the page
  @method getLiveNavPath

  @example
  ````js
    // Usage
    bcdui.widget.getLiveNavPath( callback );
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function getLiveNavPath(callback, values, separator) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
