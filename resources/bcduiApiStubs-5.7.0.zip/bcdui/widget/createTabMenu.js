/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateTabMenuArgs_Args
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  */
  
/**
  @typedef {Object} Type_WidgetCreateTabMenu_Args
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} defElementId -  Html element id where tabs are defined.
  @property {string} [handlerJsClassName] -  Own JS class name to handler click action on tab.
  @property {string} [rendererUrl] -  URL to own renderer.
  @property {boolean} [isPersistent] -  Set this to true to make the tab selection persistent.
  */
  /**
@param {Type_WidgetCreateTabMenu_Args} args -  The parameter map contains the following properties.
    ````js
    { targetHtml, defElementId, handlerJsClassName?, rendererUrl?, isPersistent? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createTabMenu)
  @description   Creates tab menu widget.
  @method createTabMenu

  @example
  ````js
    // Usage
    bcdui.widget.createTabMenu({ targetHtml: "#myDiv", defElementId });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createTabMenu(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
