/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_VisualizeXmlVisualizeModel_Args
  @property {targetHtmlRef} targetHtml -  Id of the html element where to show the output.
  @property {string} [title] -  Title of the content box; if not provided, the title is set to the ID of the visualized model.
  @property {string} [idRef] -  Id of the model to be visualized
  @property {bcdui.core.DataProvider} [inputModel] -  Instead of an id, the model can be provided directly
  @property {boolean} [isAutoRefresh=true] - default=true  Automatically redraw when model changes
  @property {string} [stylesheetUrl="/bcdui/js/widget/visualizeXml/visualizeXmlCaller.xslt"] - default="/bcdui/js/widget/visualizeXml/visualizeXmlCaller.xslt"  renderer stylesheet
  @property {function} [onReady] -  onReady function for renderer
  */
  /**
@param {Type_VisualizeXmlVisualizeModel_Args} args -  The argument map containing the following elements:
    ````js
    { targetHtml, title?, idRef?, inputModel?, isAutoRefresh?, stylesheetUrl?, onReady? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.visualizeXml.html#.visualizeModel)
  @description   Visualiazes data of a model / data provider
  @method visualizeModel

  @example
  ````js
    // Usage
    bcdui.widget.visualizeXml.visualizeModel({ targetHtml: "#myDiv" });
  ````


  @example
  // Load, transform and visualize a modellet sm = new bcdui.core.SimpleModel("input.xml");let mw = new bcdui.core.ModelWrapper({inputModel: sm, chain: "transformer.xslt"});bcdui.widget.visualizeXml.visualizeModel({targetHtml: "testOutput", inputModel: mw, title: "Transformed Output"});
  @return {void}
  @memberOf bcdui.widget.visualizeXml
 */
export function visualizeModel(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
