/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../../exports.js";
/**
@see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.formulaEditor.Parser.html#.shunting_yard)
  @description   Parse a maths formula in input like "2+3*A" into a calc:Calc expression If optionsModel and optionsModelXPath are given, only variable names (like A) are allowed which exist in the options model
  @method shunting_yard
@return {void}
  @memberOf bcdui.widget.formulaEditor.Parser
 */
export function shunting_yard() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
