/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetOpenDialog_Args
  @property {function} open -  function to execute when dialog is opened, it gets args object with properties: targetHtml
  @property {function} [close] -  function to execute after dialog is closed
  @property {function} [create] -  function to execute when dialog is created
  @property {function} [beforeClose] -  function to execute before dialog is closed - it gets args object with properties: targetHtml; if this function returns false, the dialog is not closed.
  @property {string} [title] -  dialog title
  @property {number} [width=640] - default=640  dialog width; > 1 means absolute size <= 1 means percentage of the current view-port size, i.e. .75 = 75% of view-port size
  @property {number} [width=320] - default=320  dialog height; > 1 means absolute size <= 1 means percentage of the current view-port size, i.e. .75 = 75% of view-port size
  */
  /**
@param {Type_WidgetOpenDialog_Args} args -  arguments
    ````js
    { open, close?, create?, beforeClose?, title?, width?, width? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.openDialog)
  @description   opens a modal dialog ready for renderer and delegates to callbacks from arguments; you can trigger 'dialog-close' event within body to close the dialog programmatically, any argument to this event will be provided to the resolving promise as well as to the 'close' callback. In addition to those parameters described in this documentation you can provide any other valid parameter according to jQueryUI Dialog Widget API. This dialog returns a Promise resolving with value provided to 'dialog-close' event, allowing you to easily build on cascading dialogs utilizing promise chain.
  @method openDialog

  @example
  ````js
    // Usage
    var ret = bcdui.widget.openDialog({ open });
  ````


  @example
  bcdui.widget.openDialog({  open : (args) => {    new bcdui.core.Renderer({      targetHtml : args.targetHtml, chain : "confirm.buy.dott"    });  },  title : bcdui.i18n.TAG + "confirm.buy"});
  @return {Promise.<string>}  resolving with value provided from 'dialog-close' event, when dialog is closed.
@memberOf bcdui.widget
 */
export function openDialog(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
