/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateFixedTableHeader_Args
  @property {string} rendererId -  Id of the renderer to work on
  @property {boolean} [storeSize=true] - default=true  Decide whether the action is to be called synchronous or not
  @property {boolean} [enableColumnFilters] -  Set to true if you wnat to enable column filters, too
  @property {function} [getCaptionForColumnValue] -  if you enabled column filters, you can set its getCaptionForColumnValue here
  */
  /**
@param {Type_WidgetCreateFixedTableHeader_Args} args -  The parameter map contains the following properties.
    ````js
    { rendererId, storeSize?, enableColumnFilters?, getCaptionForColumnValue? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createFixedTableHeader)
  @description   Create fixed table header by adding a fixed copy of the original Its size is derived from the "original" header, still in place for the table
  @method createFixedTableHeader

  @example
  ````js
    // Usage
    bcdui.widget.createFixedTableHeader({ rendererId });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createFixedTableHeader(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
