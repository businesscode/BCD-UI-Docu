/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateInputField_Args
  @property {writableModelXPath} targetModelXPath -  The xPath pointing to the root-node this widget will place entered selected items into. The underlying XML format of data written is implemented by individual widget. If pointing into a Wrs, it switches to Wrs mode, i.e. the wrs:R will be marked as modified, target node will not be deleted. If you specify a targetmodelxpath, the box automatically acts as target.
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {modelXPath} [optionsModelXPath] -  xPath pointing to an absolute xpath (starts with $model/..) providing a node-set of available options to display; especially this one supports cross references between models, i.e. $options / * / Value[&commat;id = $guiStatus / * / MasterValue]
  @property {xPath} [optionsModelRelativeValueXPath] -  xPath expression relative to 'optionsModelXPath' providing values for options to display, if this is defined, values referenced by optionsModelXPath are treated as captions. Wins over &commat;caption and &commat;ignoreCaption param.
  @property {boolean} [optionsModelIsSuggestionOnly] -  If true, values different from the options model can are allowed. Default is that, if an optionsModel is given, only values from that model are allowed.
  @property {writableModelXPath} [additionalFilterXPath] -  An additional XPath created, kept up-to-date during writing, not only when a final value us choosen, not listened on. Usually used to control a server-side filtered options model.
  @property {boolean} [keepEmptyValueExpression] -  A flag that can be set to 'true' if the target node should not be removed as soon as the value is empty.
  @property {string} [clearOption] -  If != 'false', an additional option to clear the selection is shown in the drop-down box. If 'true' bcd_autoCompletionBox_clearOption is used for the text, otherwise this is the i18n key.
  @property {string} [emptyValue] -  If != 'false', a text is displayed if nothing is selected / entered. If 'true' bcd_autoCompletionBox_emptyValue is used for the text, otherwise this is the i18n key.
  @property {boolean} [mandatory] -  An empty value is invalid if this parameters sets to true. Default is false.
  @property {string} [wildcard] -  For a f:Filter with &commat;op='like', this controls the prefilling with wildcards ('*') when the value is yet empty and the field gets the focus. Can be 'contains', 'startswith' or 'endswith'. The user can overwrite this by adding/removing wildcards when editing the field. The wildcards apply to filtering within the top down list and for server side filters, both plain and for retrieving drop-down values dynamically from the server.
  @property {boolean} [bcdAutofit] -  If true, drop down resizes depending on available options.
  @property {boolean} [isSortOptions] -  A flag that can be set to 'true' if the options shown in popup should be sorted alphabetically.
  @property {integer} [maxlength] -  Maximum number of characters for the input field.
  @property {string} [onEnterKey] -  Handler function NAME triggered on ENTER key.
  @property {string} [onEscKey] -  Handler function NAME triggered on ESC key.
  @property {string} [onTabKey] -  Handler function NAME triggered on TAB key.
  @property {string} [onBlur] -  Handler function NAME triggered on blur event.
  @property {string} [onFocus] -  Handler function NAME triggered on focus event.
  @property {boolean} [setCursorPositionAtEnd] -  If true, the cursor is automatically positioned at the end of the input box.
  @property {boolean} [setFocus] -  If true, let this input field get focus after creation.
  @property {string} [tabIndex] -  Tab index of html element.
  @property {string} [widgetCaption] -  A caption which is used as prefix for navPath generation for this widget.
  @property {boolean} [enableNavPath] -  Set to true if widget should not be added to navpath handling.
  @property {boolean} [isPassword] -  If true, input element type will be 'password'.
  @property {string} [label] -  If provided, renders label element to this input
  @property {boolean} [hideWildcardChar] -  If true, no asterisk characters are shown
  */
  /**
@param {Type_WidgetCreateInputField_Args} args -  The parameter map contains the following properties.
    ````js
    { targetModelXPath, targetHtml, id?, optionsModelXPath?, optionsModelRelativeValueXPath?, optionsModelIsSuggestionOnly?, additionalFilterXPath?, keepEmptyValueExpression?, clearOption?, emptyValue?, mandatory?, wildcard?, bcdAutofit?, isSortOptions?, maxlength?, onEnterKey?, onEscKey?, onTabKey?, onBlur?, onFocus?, setCursorPositionAtEnd?, setFocus?, tabIndex?, widgetCaption?, enableNavPath?, isPassword?, label?, hideWildcardChar? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createInputField)
  @description   Creates a field where the user can enter a value or select it from a list of pre-defined values. These values are copied to a target model under a specified target XPath. When there is a list of allowed values the inputField can also apply a caption-value translation so that the displayed values can differ from the data that is actually placed in XML.This function creates an input field in the given target HTML element. This input field can be a text box or a combo box, dependent on the parameters.
  @method createInputField

  @example
  ````js
    // Usage
    bcdui.widget.createInputField({ targetModelXPath: "$guiStatus/cust:Elem/@value", targetHtml: "#myDiv" });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createInputField(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
