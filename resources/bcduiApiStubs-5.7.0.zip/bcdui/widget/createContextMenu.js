/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateContextMenu_Args
  @property {bcdui.core.DataProvider} inputModel -  A model with context menu definition according to namespace http://www.businesscode.de/schema/bcdui/contextMenu-1.0.0
  @property {string} [targetRendererId] -  The renderer the tooltip is attached to. The HTML listeners are placed on the targetHtml of this renderer.
  @property {bcdui.core.DataProvider} [targetRenderer] -  The renderer the tooltip is attached to. The HTML listeners are placed on the targetHtml of this renderer.
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {boolean} [refreshMenuModel] -  This flag can be set to 'true' if the menu model needs to be executed always. Needs to be true, if the menu depends on the position in a table, i.e. technically on bcdColIdent and bcdRowIdent.
  @property {string} [url] -  This parameter can be set when you only want to apply one single XSLT style sheet. It contains the URL pointing to it. If this parameter is set no nested 'chain' tag must be provided; provided XSLT must produce HTML.
  @property {string} [identsWithin] -  Id of an element. If given bcdColIdent and bcdRowIdent are set to the innermost values given between the event source and the element given here. bcdRow/ColIdent do not need to be set at the same element.
  @property {boolean} [tableMode] -  This flag can be set to 'true' if the 'bcdRowIdent' and 'bcdColIdent' parameters should be extracted from the HTML and added as parameters on the tooltipRenderer. They are derived from 'bcdRowIdent' and 'bcdColIdent' attributes of tr rows and header columns (td or th).
  @property {targetHtmlRef} [targetHtml] -  The HTML listeners are placed on this Element instead of the targetHtml of the given targetRendererId.
  */
  /**
@param {Type_WidgetCreateContextMenu_Args} args -  The parameter map contains the following properties.
    ````js
    { inputModel, targetRendererId?, targetRenderer?, id?, refreshMenuModel?, url?, identsWithin?, tableMode?, targetHtml? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createContextMenu)
  @description   Create an instance of dynamic context menu. Consider setting args.refreshMenuModel to true. If 'tableMode' is set to 'true' the renderer is expected to render an HTML table with the appropriate 'bcdRowIdent/bcdColIdent' attributes of tr rows header columns.
  @method createContextMenu

  @example
  ````js
    // Usage
    bcdui.widget.createContextMenu({ inputModel: myModel });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createContextMenu(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
