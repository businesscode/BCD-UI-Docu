/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_WidgetCreateMenu_Args
  @property {targetHtmlRef} targetHtml -  An existing HTML element this widget should be attached to, provide a dom element, a jQuery element or selector, or an element id.
  @property {string} [id] -  ID of the Executable object which renders this widget this must be UNIQUE and MUST NOT have same names as any global JavaScript variable. If not given, an auto-id is generated.
  @property {string} [menuHandlerClassName] -  Javascript menu handler class name, could extend bcdui.widget.menu.Menu.
  @property {boolean} [menuRootElementId] -  Root menu HTML element (UL) id
  @property {string} [modelId] -  xml model id, can be used for menues defined in folder '/WEB-INF/bcdui/menu/'.
  @property {string} [modelUrl] -  Optional: URL where model get data from, allows reading a random xml file from the server.
  @property {string} [parameters] -  Own action handler.
  @property {(string|chainDef)} [rendererUrl] -  URL to XSLT stylesheet that renders the model or chain definition; default is "/bcdui/js/widget/menu/menu.xslt"
  @property {string} [menuId] -  Optional menuId to use one specific menu out of the available ones. If not available, the default one is used.
  */
  /**
@param {Type_WidgetCreateMenu_Args} args -  The parameter map contains the following properties.
    ````js
    { targetHtml, id?, menuHandlerClassName?, menuRootElementId?, modelId?, modelUrl?, parameters?, rendererUrl?, menuId? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html#.createMenu)
  @description   Creates menu with default renderer an default menu js handler.
  @method createMenu

  @example
  ````js
    // Usage
    bcdui.widget.createMenu({ targetHtml: "#myDiv" });
  ````

@return {void}
  @memberOf bcdui.widget
 */
export function createMenu(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
