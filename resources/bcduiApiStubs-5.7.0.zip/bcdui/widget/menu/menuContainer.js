/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @class bcdui.widget.menu.MenuContainer
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.menu.MenuContainer.html)
  @description MenuContainer
  */
// @ts-ignore
export class MenuContainer {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.menu.MenuContainer.html)
  @description MenuContainer
    */
  constructor() {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.menu.MenuContainer.html#getClassName)
  @public
  @return {string} class name
  */
  getClassName() { return ""; }
}


