/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @class bcdui.widget.menu.MenuItem
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.MenuItem)
  @description Menu
  @extends bcdui.widget.menu.MenuContainer
*/
// @ts-ignore
export class MenuItem extends bcdui.widget.menu.MenuContainer {
  /**
  @description Menu
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.MenuItem)
    */
  constructor() {
    // @ts-ignore (ignore wrong param list)
    super(); 
    }
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.MenuItem?id=getclassname)
  @overrides bcdui.widget.menu.MenuContainer#getClassName
  @public
  @return {string} class name
  */
  getClassName() { return ""; }
}


