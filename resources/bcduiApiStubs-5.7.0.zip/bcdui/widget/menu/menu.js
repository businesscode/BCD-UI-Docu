/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_MenuConstructor_Args
  @property {(string|HtmlElement)} rootIdOrElement   root Node of the menu (ul)
  @property {string} name   name of the variable that stores the result
                                                          of this constructor function
  @property {function} customConfigFunction   optional config function to override the default settings
                                                         for an example see Menu.prototype.config
  */
  
/**
  @class bcdui.widget.menu.Menu
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.Menu)
  
  @example
  // Usage
var myMn = new bcdui.widget.menu.Menu({ rootIdOrElement, name, customConfigFunction });

*/
// @ts-ignore
export class Menu {
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.Menu)
  
  @example
  // Usage
var myMn = new bcdui.widget.menu.Menu({ rootIdOrElement, name, customConfigFunction });

@param {Type_MenuConstructor_Args} args 
    ````js
    { rootIdOrElement, name, customConfigFunction }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
    */
  constructor(args) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.widget.menu.Menu?id=getclassname)
  @public
  @return {string} class name
  */
  getClassName() { return ""; }
}


