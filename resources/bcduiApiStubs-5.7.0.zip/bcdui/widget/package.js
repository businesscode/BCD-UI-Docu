/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.html)
 * @description   A namespace for the BCD-UI widgets.
 * @namespace bcdui.widget
 */

/**
 * well known html dom events, which are fired by widgets at given circumstances,these events are fired by widgets using jQuery.trigger() and can be consumed byjQuery.on(). Values: writeValueToModel
 */
export const events = {};

/**
 * Enumeration with modalBox types. Values: ok | ‚warning | error | plainText
 */
export const modalBoxTypes = {};
