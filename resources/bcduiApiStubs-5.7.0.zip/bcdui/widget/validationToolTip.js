/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @typedef {Object} Type_ValidationToolTipConstructor_Args
  @property {string} id -  option widget identifier
  @property {string} targetModelId -  identifier of model that should be tracked
  @property {xPath} targetModelXPath -  xpath of model that should be tracked
  @property {DomElement} containerHtmlElement -  html container with binded control
  @property {url} validateWrapperUrl -  xstl transformation which implement concrete validation logic
  @property {object} validateWrapperParameters -  parameters that should be passed to validateWrapper
  */
  
/**
  @class bcdui.widget.validationToolTip
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.validationToolTip.html)
  @description Tooltip for widget validation results
  @description Initializing tooltip widget
  
  @example
  ````js
    // Usage
    var myTT = new bcdui.widget.validationToolTip({ id, targetModelId, targetModelXPath: "$guiStatus/cust:Elem/@value", containerHtmlElement, validateWrapperUrl, validateWrapperParameters });
  ````

*/
// @ts-ignore
export class validationToolTip {
  /**
  @param {Type_ValidationToolTipConstructor_Args} args -
    ````js
    { id, targetModelId, targetModelXPath, containerHtmlElement, validateWrapperUrl, validateWrapperParameters }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.validationToolTip.html)
  @description Tooltip for widget validation results
  @description Initializing tooltip widget
    */
  constructor(args) {}
  
}


