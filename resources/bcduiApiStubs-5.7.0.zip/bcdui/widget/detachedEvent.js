/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../exports.js";

/**
  @class bcdui.widget.DetachedEvent
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html)
  @description <p>   This class represents a DOM event which can be stored for later use,   especially in a timeout function. It encapsulates the event functionality   provided by prototype.js, but it is not destroyed when the event has   finished. Instead it can be kept to invoke the event handler later. </p> <p>   A use case for this event object is for example a delayed tooltip   appearing for example 200 ms after the mouse over event has occurred. </p>
  
  @example
  ````js
    // Usage
    var myDE = new bcdui.widget.DetachedEvent( event );
  ````

*/
// @ts-ignore
export class DetachedEvent {
  /**
  @param {Event} event -  The event object that should be the base for this object.
  @param {HtmlElement} [element] -  The source element of the event if it should not be derived from the provided event.
  @param {HtmlElement} [endElement] -  The optional end element for the findAttribute method. No attribute on of an ancestor of this element is returned by findAttribute.
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html)
  @description <p> This class represents a DOM event which can be stored for later use, especially in a timeout function. It encapsulates the event functionality provided by prototype.js, but it is not destroyed when the event has finished. Instead it can be kept to invoke the event handler later. </p> <p> A use case for this event object is for example a delayed tooltip appearing for example 200 ms after the mouse over event has occurred. </p>
    */
  constructor(event, element, endElement) {}
  
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html#element)
  @description   Getter for the event origin element.
  @public
  @return {HtmlElement} The element that caused the event.
  */
  element() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html#pointer)
  @description   Getter for the coordinates the event has been triggered at.
  @public
  @return {Object} An object in the form { x: ##, y: ## } holding the x and y positionwhere the event has been triggered.
  */
  pointer() { return {}; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html#pointerX)
  @description   Getter for the X coordinate of the event.
  @public
  @return {integer} The X coordinate where the event has been triggered.
  */
  pointerX() { return 0; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html#pointerY)
  @description   Getter for the Y coordinate of the event.
  @public
  @return {integer} The Y coordinate where the event has been triggered.
  */
  pointerY() { return 0; }
  /**
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.widget.DetachedEvent.html#findAttribute)
  @description   A convenience wrapper for {@link bcdui.widget._findAttribute}.
  @public
  @return {void}
  */
  findAttribute() { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   }
}


