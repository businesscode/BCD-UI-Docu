/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(DomElement|DomDocument)} wrsRootNode -  Wrs itself or an element containing Wrs (i.e. Wrs document) where to replace the validation result in
  @param {(DomElement|DomDocument)} validationResultNode -  wrs:ValidationResult (or container with it) containing wrs:Wrs element(s) (which obligatory is tagged with bcdValidationId attribute) if NULL, then the possible existing validationResult is effectively removed from wrs document
  @param {string} validationId -  the validationId of the validation result Wrs to replace
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.replaceValidationResult)
  @description   Replaces validationResult/Wrs document in the Wrs, the validationDoc can be provided as NULL to remove the validationResult Wrs from previous validation; the validationId is mandatory to provide to uniquelly identify the subject of validation.
  @method replaceValidationResult

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.replaceValidationResult( wrsRootNode, validationResultNode, validationId );
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function replaceValidationResult(wrsRootNode, validationResultNode, validationId) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
