/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilDeleteRows_Args
  @property {bcdui.core.DataProvider} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} rowStartPos -  Delete rows from
  @property {integer} [rowEndPos=rowStartPos] - default=rowStartPos  Delete rows including to. By default is equal rowStartPos
  @property {function} [fn] -  Callback function called after operation
  @property {boolean} [propagateUpdate=true] - default=true  If false, model is not fired
  */
  /**
@param {Type_WrsUtilDeleteRows_Args} args -  Parameter object with the following properties
    ````js
    { model, rowStartPos, rowEndPos?, fn?, propagateUpdate? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.deleteRows)
  @description   Deleting rows (operation will change source model). See {@link bcdui.wrs.wrsUtil.restore restore()} on how the change history is maintained.
  @method deleteRows

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.deleteRows({ model, rowStartPos });
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function deleteRows(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
