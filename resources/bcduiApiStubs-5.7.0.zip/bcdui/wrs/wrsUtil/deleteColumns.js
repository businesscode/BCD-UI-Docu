/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomElement} wrs -  WRSRootNode: Pointing to wrs:Wrs
  @param {Array.<string>} colIdArray -  Array of column-ids to remove
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.deleteColumns)
  @description   Phsyically drops columns from Wrs
  @method deleteColumns

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.deleteColumns( wrs, colIdArray );
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function deleteColumns(wrs, colIdArray) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
