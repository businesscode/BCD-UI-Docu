/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {Document} doc -  the document to operate on
  @param {string} xPath -  xPath pointing to the node which is set to the value value or plain xPath to be created if not there. It tries to reuse all matching parts that are already there. If you provide for example "/n:Root/n:MyElem/&commat;attr2" and there is already "/n:Root/n:MyElem/&commat;attr1", then "/n:Root/n:MyElem" will be "re-used" and get an additional attribute attr2. Many expressions are allowed, for example "/n:Root/n:MyElem[&commat;attr1='attr1Value']/n:SubElem" is also ok. By nature, some xPath expressions are not allowed, for example using '//' or "/n:Root/n:MyElem/[&commat;attr1 or &commat;attr2]/n:SubElem" is obviously not unambiguous enough and will throw an error. This method is Wrs aware, use for example '/wrs:Wrs/wrs:Data/wrs:*[2]/wrs:C[3]' as xPath and it will turn wrs:R[wrs:C] into wrs:M[wrs:C and wrs:O], see Wrs format. (can include dot template placeholders which get filled with the given params)
  @param {Object} [params] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions Example: bcdui.wkModels.guiStatus.write("/guiStatus:Status/guiStatus:ClientSettings/guiStatus:Test[&commat;caption='{{=it[0]}}' and &commat;caption2='{{=it[1]}}']", ["china's republic", "drag\"n drop"])
  @param {string} [value] -  Optional value which should be written, for example to "/n:Root/n:MyElem/&commat;attr" or with "/n:Root/n:MyElem" as the element's text content. If not provided, the xPath contains all values like in "/n:Root/n:MyElem[&commat;attr='a' and &commat;attr1='b']" or needs none like "/n:Root/n:MyElem"
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.write)
  @description   Set a value to on a certain xPath and create the xPath where necessary. This combines Element.evaluate() for a single node with creating the path where necessary. It will prefer extending an existing start-part over creating a second one. After the operation the xPath (with the optional value) is guaranteed to exist (pre-existing or created or extended) and the addressed node is returned.
  @method write

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.write( doc, xPath );
  ````

@return {DomNode}  the resulting element (either newly created or existing one)
@memberOf bcdui.wrs.wrsUtil
 */
export function write(doc, xPath, params, value) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
