/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} wrs -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {string} validationId -  validationId
  @param {boolean} doCreate -  optional, in case no wrs:ValidationResult/wrs:Wrs exists, create one (empty)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.getValidationResult)
  @description   get wrs:ValidationResult/wrs:Wrs element for given Wrs (optionally creates an empty one)
  @method getValidationResult

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.getValidationResult( wrs, validationId, doCreate );
  ````

@return {DomNode}  wrs:ValidationResult/wrs:Wrs or NULL if none exists and doCreate=false
@memberOf bcdui.wrs.wrsUtil
 */
export function getValidationResult(wrs, validationId, doCreate) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
