/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {string} rowId -  Id of row to be deleted
  @param {boolean} [propagateUpdate] -  If true, fire after change
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.restoreRow)
  @description   Restores a wrs:D, wrs:M identified by id, also see {@link bcdui.wrs.wrsUtil.restore restore()}
  @method restoreRow

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.restoreRow( model, rowId );
  ````

@return {boolean}  true if given row has been restored or false if row is not wrs:M nor wrs:D
@memberOf bcdui.wrs.wrsUtil
 */
export function restoreRow(model, rowId, propagateUpdate) { return false; };
