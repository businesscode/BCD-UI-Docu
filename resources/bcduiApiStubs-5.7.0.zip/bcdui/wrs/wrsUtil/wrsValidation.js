/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilWrsValidationCellValidation_Args
  @property {function} func -  function taking args object with: 'wrsC'        - the wrs:C element to validate 'wrsHeaderC'  - the wrs:Header/wrs:Columns/wrs:C meta info element returns either NULL (valid) or { validationMessage:String }
  @property {function} bRefSelector -  function taking wrs:Header element and returns node-set of wrs:Columns/wrs:C to get validated
  */
  
/**
  @typedef {Object} Type_WrsUtilWrsValidation_Args
  @property {string} validationId -  the ID of this validator
  @property {(string|bcdui.core.DataProvider)} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  */
  /**
@param {Type_WrsUtilWrsValidation_Args} args -  Parameter object with the following properties
    ````js
    { validationId, model }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.wrsValidation)
  @description   Wrs validation which validates selected wrs:C against provided validation function parameters:
  @method wrsValidation

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.wrsValidation({ validationId, model, cellValidation, cellValidation });
  ````

@return {DomDocument}  wrsDoc
@memberOf bcdui.wrs.wrsUtil
 */
export function wrsValidation(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
