/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilSaveModel_Args
  @property {(string|bcdui.core.DataProvider)} model -  DataProvider (or its id), holding the Wrs with wrs:R|I|M|D row and wrs:C|O column nodesto be saved
  @property {boolean} [reload] -  Useful especially for models of type SimpleModel for refreshing from server after save
  @property {function} [onSuccess] -  Callback after saving (and optionally reloading) was successfully finished
  */
  /**
@param {Type_WrsUtilSaveModel_Args} args -  Parameter object with the following properties:
    ````js
    { model, reload?, onSuccess? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.saveModel)
  @description   Save Wrs data of a {@link bcdui.core.DataProvider}
  @method saveModel

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.saveModel({ model });
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function saveModel(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
