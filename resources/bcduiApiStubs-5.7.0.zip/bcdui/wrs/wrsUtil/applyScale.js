/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomDocument} wrsDoc -  the Wrs document to apply changes on
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.applyScale)
  @description   applies number rounding at defined wrs:Header/wrs:Columns/wrs:C/&commat;scale
  @method applyScale
@return {DomDocument}  wrsDoc
@memberOf bcdui.wrs.wrsUtil
 */
export function applyScale(wrsDoc) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
