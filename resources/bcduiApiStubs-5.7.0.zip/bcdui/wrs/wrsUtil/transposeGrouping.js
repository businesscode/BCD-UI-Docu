/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} input -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.transposeGrouping)
  @description   This transposes the inner-most &commat;dim column column of a WRS from rows to columns. This is faster using the XLST with the same name except for Webkit, where this is faster
  @method transposeGrouping
@return {DomDocument}  The transposed document
@memberOf bcdui.wrs.wrsUtil
 */
export function transposeGrouping(input) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
