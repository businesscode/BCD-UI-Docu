/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} wrs -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {(string|number)} rowId -  The row-id or 1-based position of row
  @param {(string|number)} columnId -  ID or 1-based position of column
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.getCellValue)
  @description   Get cell value
  @method getCellValue

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.getCellValue( wrs, rowId, columnId );
  ````

@return {string}  Current cell value or null
@memberOf bcdui.wrs.wrsUtil
 */
export function getCellValue(wrs, rowId, columnId) { return ""; };
