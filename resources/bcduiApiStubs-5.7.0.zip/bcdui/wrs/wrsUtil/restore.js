/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilRestore_Args
  @property {bcdui.core.DataProvider} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} rowStartPos -  Restore rows from
  @property {integer} [rowEndPos=rowStartPos] - default=rowStartPos  Restore rows including to.
  @property {integer} [colStartPos=1] - default=1  Restore cols from
  @property {integer} [colEndPos=colStartPos] - default=colStartPos  Restore cols including to.
  @property {function} [fn] -  Callback function called after operation
  @property {boolean} [propagateUpdate=true] - default=true  If false, model is not fired
  */
  /**
@param {Type_WrsUtilRestore_Args} args -  Parameter object with the following properties
    ````js
    { model, rowStartPos, rowEndPos?, colStartPos?, colEndPos?, fn?, propagateUpdate? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.restore)
  @description   Restore (operation will change source model). Client side operations on Wrs keep a history, wrs:R turns into wrs:M for modified rows and wrs:D for deleted. Changed columns change from wrs:C to wrs:O. This allows undoing such a change till the data is send to the server.
  @method restore

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.restore({ model, rowStartPos });
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function restore(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
