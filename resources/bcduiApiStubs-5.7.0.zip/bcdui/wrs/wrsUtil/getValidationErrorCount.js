/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} wrs -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.getValidationErrorCount)
  @description   Convenience method to return error count in current document (possibly validated by validateWrs.xml)
  @method getValidationErrorCount
@return {integer}  -2: if no validation has been performed, -1: if the data provider is not ready yet, otherwise the number of errors found is returned
@memberOf bcdui.wrs.wrsUtil
 */
export function getValidationErrorCount(wrs) { return 0; };
