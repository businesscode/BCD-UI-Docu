/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {Document} doc -  the document to operate on
  @param {string} xPath -  xPath pointing to value (can include dot template placeholders which get filled with the given params)
  @param {Object} [params] -  array or object holding the values for the dot placeholders in the xpath. Values with "'" get 'escaped' with a concat operation to avoid bad xpath expressions
  @param {string} [defaultValue] -  default value in case xPath value does not exist
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.read)
  @description   Reads the string value from a given xPath (or optionally return default value).
  @method read

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.read( doc, xPath );
  ````

@return {string}  text value stored at xPath (or null if no text was found and no defaultValue supplied)
@memberOf bcdui.wrs.wrsUtil
 */
export function read(doc, xPath, params, defaultValue) { return ""; };
