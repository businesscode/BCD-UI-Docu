/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} wrs -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {string} id -  The column-id wrs:C/&commat;id
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.getColPosById)
  @description   get column position by id
  @method getColPosById

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.getColPosById( wrs, id );
  ````

@return {integer}  1-based column position from the header/pos attribute, 0 if no such column was found
@memberOf bcdui.wrs.wrsUtil
 */
export function getColPosById(wrs, id) { return 0; };
