/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} wrs -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {(string|number)} rowId -  The row-id or 1-based position of row
  @param {(string|number)} columnIdOrPos -  ID or 1-based position of column
  @param {string} [value] -  If NULL then wrs:null node is appended to column
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.setCellValue)
  @description   Sets cell value, both, the row and cell MUST exist in target model This also changes wrs:R to wrs:M and clones wrs:C to wrs:O values.
  @method setCellValue

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.setCellValue( wrs, rowId, columnIdOrPos );
  ````

@return {boolean}  true if value has been set, false otherwise
@memberOf bcdui.wrs.wrsUtil
 */
export function setCellValue(wrs, rowId, columnIdOrPos, value) { return false; };
