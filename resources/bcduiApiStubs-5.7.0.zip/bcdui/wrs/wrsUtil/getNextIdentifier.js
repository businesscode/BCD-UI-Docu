/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilGetNextIdentifier_Args
  @property {string} scope -  The scope requested
  @property {function} onSuccessCb -  The callback, receives following args <ul> <li>scope           {string}    - Requested scope <li>isRange         {boolean}   - false if blockSize = 1, true otherwise <li>forEach:        {function}  - Helper iterating function, executing a passed function for each identifier; follows forEach() JS API spec; <li>nextIdentifier  {integer}   - The next identifier; ONLY defined if isRange = false; otherwise undefined <li>firstIdentifier {integer}   - First identifier; ONLY defined if isRange = true; otherwise undefined <li>lastIdentifier  {integer}   - Last identifier; ONLY defined if isRange = true; otherwise undefined </ul>
  @property {integer} [blockSize=1] - default=1  Number of identifiers to be retrieved
  @property {function} [onErrorCb] -  An error callback
  */
  /**
@param {Type_WrsUtilGetNextIdentifier_Args} args -  Parameter object with the following properties
    ````js
    { scope, onSuccessCb, blockSize?, onErrorCb? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.getNextIdentifier)
  @description   Retrieves next identifier from the server (async)
  @method getNextIdentifier

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.getNextIdentifier({ scope, onSuccessCb });
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function getNextIdentifier(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
