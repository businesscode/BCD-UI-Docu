/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilCopy_Args
  @property {bcdui.core.DataProvider} model   Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} rowStartPos   Restore rows from
  @property {integer} [rowEndPos=rowStartPos]  default=rowStartPos  Restore rows including to.
  @property {integer} [colStartPos=1]  default=1  Restore cols from
  @property {integer} [colEndPos=colStartPos]  default=colStartPos  Restore cols including to.
  @property {function} [fn]   Callback function called after operation
  */
  /**
@param {Type_WrsUtilCopy_Args} args   Parameter object with the following properties
    ````js
    { model, rowStartPos, rowEndPos?, colStartPos?, colEndPos?, fn? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/index.html#/generated/elements/bcdui.wrs.wrsUtil.copy)
  @description   Copy (copies selected cells to clipboard, not changes source model)
  @method copy

  @example
  // Usage
bcdui.wrs.wrsUtil.copy({ model, rowStartPos });

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function copy(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
