/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilValidateModel_Args
  @property {(string|bcdui.core.DataProvider)} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {string} [stylesheetUrl="defauldValidation-stypesheet"] - default="defauldValidation-stypesheet"  URL to validation stylesheet, defaults to 'xslt/validate/validateWrs.xslt'
  @property {Array.<bcdui.core.DataProvider>} dataProviders -  additional data providers as parameters
  @property {function} [fn] -  callback function called after validation done, gets object as parameter, containig properties: validationResult: the wrs:ValidationResult node of resulting transformation, may be null
  */
  /**
@param {Type_WrsUtilValidateModel_Args} args -  Parameter object with the following properties
    ````js
    { model, stylesheetUrl?, dataProviders, fn? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @param {string} validationId -  'bcdValidationId' attribute in ValidationResult/Wrs yields this value
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.validateModel)
  @description   runs validation xslt against given model, you can access the result via returned trafo, see return section. for one-time validation you can supply the callback function (fn parameter)
  @method validateModel

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.validateModel({ model, dataProviders });
  ````

@return {bcdui.core.TransformationChain}  created transformation chain for the validation, it can be reused via bcdui.core.reExecute(_validatorTrafo, callBackFn);         the data can be accessed via _validatorTrafo.getData() which returns wrs:ValidationResult or null or ValidationResult with empty wrs:Data
@memberOf bcdui.wrs.wrsUtil
 */
export function validateModel(args, validationId) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
