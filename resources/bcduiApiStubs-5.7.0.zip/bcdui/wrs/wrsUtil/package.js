/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
 * @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html)
 * @description   Utility functions for working with wrs:Wrs documents from JavaScript. These are mainly JavaScript wrappers around XML library found a bcdui/xslt
 * @namespace bcdui.wrs.wrsUtil
 */
