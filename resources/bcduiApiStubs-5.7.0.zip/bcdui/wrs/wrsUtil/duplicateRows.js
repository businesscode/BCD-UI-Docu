/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilDuplicateRows_Args
  @property {bcdui.core.DataProvider} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} [rowStartPos] -  First row to be duplicated
  @property {integer} [rowEndPos=rowStartPos] - default=rowStartPos  Last row to be duplicated
  @property {function} [fn] -  Callback function called after operation
  @property {boolean} [insertBeforeSelection=true] - default=true
  @property {boolean} [propagateUpdate=true] - default=true  If false, model is not fired
  */
  /**
@param {Type_WrsUtilDuplicateRows_Args} args -  Parameter object with the following properties
    ````js
    { model, rowStartPos?, rowEndPos?, fn?, insertBeforeSelection?, propagateUpdate? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.duplicateRows)
  @description   Duplicate rows in Wrs. Fires fire
  @method duplicateRows

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.duplicateRows({ model });
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function duplicateRows(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
