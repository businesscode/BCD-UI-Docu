/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {string} expression -  the expression to parse
  @param {object} params -  the expression to parse
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.parseFilterExpression)
  @description 
  @method parseFilterExpression

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.parseFilterExpression( expression, params );
  ````


  @example
  bcdui.wrs.wrsUtil.parseFilterExpression("country = :country or (revenue >= :revenue or today = :today and allow='true' or string='a and b')",{    country:"DE",    revenue:1000,    today:"2018-12-09"  });    // yields following result document  &lt;f:And xmlns:f="http://www.businesscode.de/schema/bcdui/filter-1.0.0">   &lt;f:Or>     &lt;f:Expression bRef="country" op="=" value="DE"/>     &lt;f:Or>       &lt;f:Or>         &lt;f:Expression bRef="revenue" op="&gt;=" value="1000"/>         &lt;f:And>           &lt;f:Expression bRef="today" op="=" value="2018-12-09"/>           &lt;f:Expression bRef="allow" op="=" value="true"/>         &lt;/f:And>       &lt;/f:Or>       &lt;f:Expression bRef="string" op="=" value="a and b"/>     &lt;/f:Or>   &lt;/f:Or>  &lt;/f:And>
  @return {DomDocument}  containing parsed expression
@memberOf bcdui.wrs.wrsUtil
 */
export function parseFilterExpression(expression, params) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
