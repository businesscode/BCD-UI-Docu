/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {DomDocument} wrsDoc -  WRS Document to build a header from
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.generateWrsHeaderMeta)
  @description   Generates metadata JS object from a Wrs document
  @method generateWrsHeaderMeta
@return {object}  with { [column-id] : {object-with-attrs from wrs:Column/wrs:C} }
@memberOf bcdui.wrs.wrsUtil
 */
export function generateWrsHeaderMeta(wrsDoc) { return {}; };
