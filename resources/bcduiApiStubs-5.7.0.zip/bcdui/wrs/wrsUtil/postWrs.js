/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(PostWrsParam|XMLDocument|Array.<XMLDocument>|bcdui.core.DataProvider|Array.<bcdui.core.DataProvider>)} args -  DataProvider(s), Document(s) or a parameter object
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.postWrs)
  @description 
  @method postWrs
@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function postWrs(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
