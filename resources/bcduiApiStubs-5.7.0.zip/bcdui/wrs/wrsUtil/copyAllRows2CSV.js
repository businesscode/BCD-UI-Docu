/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilCopyAllRows2CSV_Args
  @property {bcdui.core.DataProvider} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {function} [fn] -  Callback function called after operation
  */
  /**
@param {Type_WrsUtilCopyAllRows2CSV_Args} args -  Parameter object with the following properties
    ````js
    { model, fn? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.copyAllRows2CSV)
  @description   Copy all rows to CVS
  @method copyAllRows2CSV

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.copyAllRows2CSV({ model });
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function copyAllRows2CSV(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
