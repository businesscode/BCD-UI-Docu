/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(string|bcdui.core.DataProvider)} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @param {string} rowId -  Id of row to be deleted
  @param {boolean} [propagateUpdate] -  If true, fire after change
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.deleteRow)
  @description   Deletes a row identified by id, also see {@link bcdui.wrs.wrsUtil.deleteWrsRow deleteWrsRow()}
  @method deleteRow

  @example
  ````js
    // Usage
    var ret = bcdui.wrs.wrsUtil.deleteRow( model, rowId );
  ````

@return {boolean}  true if given row has been modified and converted to wrs:D or false
@memberOf bcdui.wrs.wrsUtil
 */
export function deleteRow(model, rowId, propagateUpdate) { return false; };
