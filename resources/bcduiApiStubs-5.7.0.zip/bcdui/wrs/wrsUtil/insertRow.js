/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";

/**
  @typedef {Object} Type_WrsUtilInsertRow_Args
  @property {bcdui.core.DataProvider} model -  Id of a DataProvider or the DataProvider itself (dp must be ready)
  @property {integer} [rowStartPos=1] - default=1  Start
  @property {integer} [rowEndPos=rowStartPos] - default=rowStartPos  End
  @property {function} [fn] -  Callback function called after operation
  @property {boolean} [insertBeforeSelection=true] - default=true
  @property {boolean} [propagateUpdate=true] - default=true  If false, model is not fired
  */
  /**
@param {Type_WrsUtilInsertRow_Args} args -  Parameter object with the following properties
    ````js
    { model, rowStartPos?, rowEndPos?, fn?, insertBeforeSelection?, propagateUpdate? }
    ````
    <br/>Use autocomplete in {} to get a full parameter description <br/>
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.insertRow)
  @description   Inserting empty wrs:I rows at the given location, respecting default values. Values can be filled in fn().
  @method insertRow

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.insertRow({ model });
  ````


  @example
  bcdui.wrs.wrsUtil.insertRow({model: model, propagateUpdate: false, rowStartPos:1, rowEndPos:1, fn: function(){   bcdui.wrs.wrsUtil.setCellValue(model, 1, "comment_text", conf.comment);   bcdui.wrs.wrsUtil.setCellValue(model, 1, "scope", conf.scope); });
  @return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function insertRow(args) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
