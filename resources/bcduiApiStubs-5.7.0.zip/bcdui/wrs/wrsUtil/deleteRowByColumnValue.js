/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {(DomDocument|DomElement)} wrs -  the Wrs document
  @param {(number|string)} colIdOrPos -  column id or position
  @param {Array.<string>} values -  array of string values to lookup
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.wrsUtil.html#.deleteRowByColumnValue)
  @description   delete rows identified by the column value(s)
  @method deleteRowByColumnValue

  @example
  ````js
    // Usage
    bcdui.wrs.wrsUtil.deleteRowByColumnValue( wrs, colIdOrPos, values );
  ````

@return {void}
  @memberOf bcdui.wrs.wrsUtil
 */
export function deleteRowByColumnValue(wrs, colIdOrPos, values) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
