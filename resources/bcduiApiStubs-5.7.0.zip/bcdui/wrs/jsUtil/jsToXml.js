/** BCD-UI library, @see https://businesscode.github.io/BCD-UI-Docu, Copyright 2010-2025 BusinessCode GmbH, Germany, Apache License, Version 2.0 */
import * as bcdui from "../../exports.js";
/**
@param {Object} arg -  The JavaScript object following Wrs conventions, from which the XML document is to be created
  @see [Online Documentation](https://businesscode.github.io/BCD-UI-Docu/jsdoc/bcdui.wrs.jsUtil.html#.jsToXml)
  @description   Converts a js object created with domToJs to an XML document
  @method jsToXml
@return {void}
  @memberOf bcdui.wrs.jsUtil
 */
export function jsToXml(arg) { 
    // @ts-ignore (Return dummy value may be of wrong type)
    return null;
   };
